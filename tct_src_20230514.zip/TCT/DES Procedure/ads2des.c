/* ASCII DES to (Binary) DES translation */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include <io.h>


#include <ctype.h>
#include "des_data.h"
#include "setup.h"
#include "tct_io.h"
#include "ads2des.h"
#include "mymalloc.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ADS file format:
# One line comments
FILENAME\n\r
State size (State set will be (0,1....,size-1))
\n\r
\n\r                         <--- End of number of states
Marker states:
                             <--- One marker per line?
\n\r                         <--- End of marker states
Vocal states:
                             <--- One state vocal output? (space to separate)
\n\r                         <--- End of vocal states
Transitions:
                             <--- One transition per line? (space to separate)
\n\r                         <--- Do we need this?  EOF?
*/

#define A2D_NAME     1
#define A2D_STATE_L  2
#define A2D_STATE    3
#define A2D_MARK_L   4
#define A2D_MARK     5
#define A2D_VOCAL_L  6
#define A2D_VOCAL    7
#define A2D_TRANS_L  8
#define A2D_TRANS    9

ads_t ads_error_str[] = {
   "ok",
   "File does not exist",
   "Unexpected end of file",
   "Internal error",
   "No file name present",
   "File name too long",
   "Expecting string 'State size'",
   "State out of range",
   "State number too large",
   "Expecting string 'Marker states:'",
   "Marker state out of range",
   "Marker state too large",
   "Expecting string 'Vocal states:'",
   "Vocal output too small",
   "Vocal output too large",
   "Expecting string 'Transitions:'",
   "Transition label out of range",
   "Transition label too large",
   "Invalid state number",
   "Invalid marker state",
   "Invalid vocal output",
   "Invalid transition label",
   "Exit state out of range",
   "Exit state too large",
   "Entrance state out of range",
   "Entrance state too large",
   "Nondeterministic transition"
};

char des_filename[80];
INT_OS a2d_state;
static state_node *t;
static INT_S s;

typedef struct tranList_t {
   INT_S i;
   INT_T e;
   INT_S j;
   long line;
} tranList_t;

tranList_t *tranList;
long s_tranList;

ads_err_log_t* ads_err_list;
long ads_err_num;
long ads_line_num;
long ads_line_num2;

void log_ads_err(INT_OS err, long line_num, long line_num2)
{
   ads_err_num++;
   ads_err_list = (ads_err_log_t*) REALLOC(ads_err_list, sizeof(ads_err_log_t)*(ads_err_num));
   ads_err_list[ads_err_num-1].fail_code = err;
   ads_err_list[ads_err_num-1].line_num1 = line_num;
   ads_err_list[ads_err_num-1].line_num2 = line_num2;
}

INT_OS A2D_ReadName(char* line)
{
   INT_OS len;

   if (strcmp(line, "") == 0)
      return 0;

   sscanf(line, "%s", des_filename);
   len = (INT_OS)strlen(des_filename);

   if (len <= 0)
   {
      log_ads_err(ADS_FILENAME_EMPTY, ads_line_num, -1);
      return ADS_FILENAME_EMPTY;
   }

/*   if (len > MAX_DES_NAME_LEN)
      return ADS_FILENAME_TOO_LONG;
*/
   a2d_state++;
   return 0;
}

INT_OS A2D_StateLabel(char* line)
{
   char label[80];

   if (strcmp(line, "") == 0)
      return 0;

   sscanf(line, "%s", label);

   if (strcmp(label, "State") != 0)
   {
      log_ads_err(ADS_STATE_LABEL_EXPECTED, ads_line_num, -1);
      return ADS_STATE_LABEL_EXPECTED;
   }

   a2d_state++;
   return 0;
}

INT_OS A2D_ReadState(char* line)
{
   INT_OS max_states = -1;
   INT_OS result = 0;

   if (strcmp(line, "") == 0)
      return 0;

   result = sscanf(line, "%d", &max_states);
   if (result <= 0)
   {
      log_ads_err(ADS_STATE_UNKNOWN, ads_line_num, -1);
      return ADS_STATE_UNKNOWN;
   }

   if (max_states < 0)
   {
      log_ads_err(ADS_STATE_TOO_SMALL, ads_line_num, -1);
      return ADS_STATE_TOO_SMALL;
   }

   if (max_states > MAX_STATES)
   {
      log_ads_err(ADS_STATE_TOO_LARGE, ads_line_num, -1);
      return ADS_STATE_TOO_LARGE;
   }

   s = (INT_S) max_states;
   t = newdes(s);
   if (s != 0) {
     if (t == NULL) {
        mem_result = 1;
        return -1;
     }
   }

   a2d_state++;
   return 0;
}

INT_OS A2D_MarkLabel(char* line)
{
   if (strcmp(line, "") == 0)
      return 0;

   if (strcmp(line, "Marker states:") != 0)
   {
      log_ads_err(ADS_MARK_LABEL_EXPECTED, ads_line_num, -1);
      return ADS_MARK_LABEL_EXPECTED;
   }

   a2d_state++;
   return 0;
}

INT_OS A2D_ReadMark(char* line)
{
   INT_OS mark;
   INT_S i;
   INT_OS result;

/*   if (*line == '\0')
   {
     a2d_state++;
     return 0;
   }
*/
   if (*line == '\0')
      return 0;

   if (strcmp(line, "Vocal states:") == 0)
   {
      a2d_state++;
      a2d_state++;
      return 0;
   }

   if ( (strcmp(line, "*") == 0) ||
        (strcmp(line, " *") == 0) )
   {
      a2d_state++;

      for (i=0; i < s; i++)
         t[i].marked = true;
      return 0;
   }

   result = sscanf(line, "%d", &mark);

   if (result <= 0)
   {
     log_ads_err(ADS_MARK_UNKNOWN, ads_line_num, -1);
     return ADS_MARK_UNKNOWN;
   }

   if (mark < 0)
   {
     log_ads_err(ADS_MARK_TOO_SMALL, ads_line_num, -1);
     return ADS_MARK_TOO_SMALL;
   }

   if (mark >= s)
   {
     log_ads_err(ADS_MARK_TOO_LARGE, ads_line_num, -1);
     return ADS_MARK_TOO_LARGE;
   }

   t[mark].marked = true;
   return 0;
}

INT_OS A2D_VocalLabel(char* line)
{
   if (strcmp(line, "") == 0)
      return 0;

   if (strcmp(line, "Vocal states:") != 0)
   {
      log_ads_err(ADS_VOCAL_LABEL_EXPECTED, ads_line_num, -1);
      return ADS_VOCAL_LABEL_EXPECTED;
   }

   a2d_state++;
   return 0;
}

INT_OS A2D_ReadVocal(char* line)
{
   INT_OS state;
   INT_OS vocal;
   INT_OS result;
   INT_OS err;

   err = 0;

/*   if (*line == '\0')
   {
     a2d_state++;
     return 0;
   }
*/

   if (*line == '\0')
      return 0;

   if (strcmp(line, "Transitions:") == 0)
   {
      a2d_state++;
      a2d_state++;
      return 0;
   }

   result = sscanf(line, "%d %d", &state, &vocal);
   if (result <= 1)
   {
      log_ads_err(ADS_VOCAL_UNKNOWN, ads_line_num, -1);
      return ADS_VOCAL_UNKNOWN;
   }

   if (state < 0)
   {
      log_ads_err(ADS_STATE_TOO_SMALL, ads_line_num, -1);
      err = ADS_STATE_TOO_SMALL;
   }

   if (state >= s)
   {
      log_ads_err(ADS_STATE_TOO_LARGE, ads_line_num, -1);
      err = ADS_STATE_TOO_LARGE;
   }

   if (vocal <= 9)
   {
      log_ads_err(ADS_VOCAL_TOO_SMALL, ads_line_num, -1);
      err = ADS_VOCAL_TOO_SMALL;
   }

   if (vocal > MAX_VOCAL_OUTPUT)
   {
      log_ads_err(ADS_VOCAL_TOO_LARGE, ads_line_num, -1);
      err = ADS_VOCAL_TOO_LARGE;
   }

   if (err == 0)
      t[state].vocal = (INT_V) vocal;

   return err;
}

INT_OS A2D_TransLabel(char* line)
{
   if (strcmp(line, "") == 0)
      return 0;

   if (strcmp(line, "Transitions:") != 0)
   {
      log_ads_err(ADS_TRANS_LABEL_EXPECTED, ads_line_num, -1);
      return ADS_TRANS_LABEL_EXPECTED;
   }

   a2d_state++;
   return 0;
}

INT_OS A2D_ReadTrans(char* line, long *line_num, long *line_num2)
{
   INT_OS i, e, j, jj;
   INT_B  ok;
   INT_OS result;
   long ii;
   INT_OS err;

   err = 0;

   if (*line == '\0')
     return 0;

   result = sscanf(line, "%d %d %d", &i, &e, &j);

   if (result <= 2)
   {
     log_ads_err(ADS_TRANS_UNKNOWN, ads_line_num, -1);
     return ADS_TRANS_UNKNOWN;
   }

   if (i < 0)
   {
     log_ads_err(ADS_EXIT_STATE_TOO_SMALL, ads_line_num, -1);
     err = ADS_EXIT_STATE_TOO_SMALL;
   }

   if (i >= s)
   {
     log_ads_err(ADS_EXIT_STATE_TOO_LARGE, ads_line_num, -1);
     err = ADS_EXIT_STATE_TOO_LARGE;
   }

   if (e < 0)
   {
     log_ads_err(ADS_TRANS_TOO_SMALL, ads_line_num, -1);
     err = ADS_TRANS_TOO_SMALL;
   }

   if (e > MAX_TRANSITIONS)
   {
     log_ads_err(ADS_TRANS_TOO_LARGE, ads_line_num, -1);
     err = ADS_TRANS_TOO_LARGE;
   }

   if (j < 0)
   {
     log_ads_err(ADS_ENTRANCE_STATE_TOO_SMALL, ads_line_num, -1);
     err = ADS_ENTRANCE_STATE_TOO_SMALL;
   }

   if (j >= s)
   {
     log_ads_err(ADS_ENTRANCE_STATE_TOO_LARGE, ads_line_num, -1);
     err = ADS_ENTRANCE_STATE_TOO_LARGE;
   }

   if (err != 0)
      return err;

   /* Check for non-deterministic transitions */
   for (jj=0; jj < t[i].numelts; jj++) {
      if ( (e == t[i].next[jj].data1) &&
           (j != t[i].next[jj].data2) )
      {
         /* Find the line number that mismatch with this transition */
         for (ii =0; ii < s_tranList; ii++)
         {
            if ( (tranList[ii].i == i) &&
                 (tranList[ii].e == e))
               *line_num2 = tranList[ii].line;
         }

         log_ads_err(ADS_NONDETERMINISTIC, ads_line_num, *line_num2);
         return ADS_NONDETERMINISTIC;
      }
   }

   /* Record transition and line number */
   tranList = (tranList_t*) REALLOC(tranList, sizeof(tranList_t)*(s_tranList+1));
   if (tranList == NULL)
   {
      mem_result = 1;
      return 0;
   }
   tranList[s_tranList].i = i;
   tranList[s_tranList].e = e;
   tranList[s_tranList].j = j;
   tranList[s_tranList].line = *line_num;
   s_tranList++;

   addordlist1((INT_T) e, (INT_S) j, &t[i].next, t[i].numelts, &ok);
   if (ok) t[i].numelts++;
   return 0;
}

INT_OS A2D_ProcessLine(char* line, long* line_num, long* line_num2)
{
   INT_OS err = 0;

   switch( a2d_state ) {
      case A2D_NAME:     err = A2D_ReadName(line);   break;
      case A2D_STATE_L:  err = A2D_StateLabel(line); break;
      case A2D_STATE:    err = A2D_ReadState(line);  break;
      case A2D_MARK_L:   err = A2D_MarkLabel(line);  break;
      case A2D_MARK:     err = A2D_ReadMark(line);   break;
      case A2D_VOCAL_L:  err = A2D_VocalLabel(line); break;
      case A2D_VOCAL:    err = A2D_ReadVocal(line);  break;
      case A2D_TRANS_L:  err = A2D_TransLabel(line); break;
      case A2D_TRANS:    err = A2D_ReadTrans(line, line_num, line_num2);  break;
   default:
      log_ads_err(ADS_UNKNOWN, ads_line_num, -1);
      err = ADS_UNKNOWN;
      break;
   }
   return err;
}

INT_OS ads_2_des(char* name, ads_err_log_t** ads_list, long *ads_num_err,
              state_node** t1, INT_S* s1)
{
   FILE *in;
   char line[256];
   INT_OS err;

   in = fopen(name, "r");
   if (in == NULL) {
      log_ads_err(ADS_FILENAME_EMPTY, -1, -1);
      *ads_list    = ads_err_list;
      *ads_num_err = ads_err_num;
      return ADS_FILE_DOES_NOT_EXIST;
   }

   tranList = NULL;
   s_tranList = 0;

   ads_err_list = NULL;
   ads_err_num = 0;

   a2d_state = A2D_NAME;
   ads_line_num = 0;
   s = *s1;
   t = *t1;

   do {
      fgets(line, 255, in);
      if (feof(in)) break;
      ads_line_num++;
      if (line[0] != '#') {
         line[strlen(line)-1] = '\0';
         err = A2D_ProcessLine(line, &ads_line_num, &ads_line_num2);
      }
   } while ((!feof(in)) && (a2d_state <= A2D_TRANS));

   if (ads_err_num == 0)
   {
      if (a2d_state < A2D_TRANS_L)
         log_ads_err(ADS_FILE_TOO_SHORT, ads_line_num, -1);
   }

   if (ads_err_num == 0)
   {
      *t1 = t;
      *s1 = s;
   }

   free(tranList);   tranList = NULL;
   fclose(in);

   *ads_list    = ads_err_list;
   *ads_num_err = ads_err_num;

   return ads_err_num;
}

/***********************************/
/***     For "ALL" ADS->DES      ***/
/***********************************/

INT_OS A2D_ReadName_all(char* line)
{
   INT_OS len;

   if (strcmp(line, "") == 0)
      return 0;

   sscanf(line, "%s", des_filename);
   len = (INT_OS)strlen(des_filename);

   if (len <= 0)
      return ADS_FILENAME_EMPTY;

/*   if (len > MAX_DES_NAME_LEN)
      return ADS_FILENAME_TOO_LONG;
*/
   a2d_state++;
   return 0;
}

INT_OS A2D_StateLabel_all(char * line)
{
   char label[80];

   if (strcmp(line, "") == 0)
      return 0;

   sscanf(line, "%s", label);

   if (strcmp(label, "State") != 0)
      return ADS_STATE_LABEL_EXPECTED;

   a2d_state++;
   return 0;
}

INT_OS A2D_ReadState_all(char* line)
{
   INT_OS max_states = -1;
   INT_OS result = 0;

   if (strcmp(line, "") == 0)
      return 0;

   result = sscanf(line, "%d", &max_states);
   if (result <= 0)
      return ADS_STATE_UNKNOWN;

   if (max_states < 0)
      return ADS_STATE_TOO_SMALL;

   if (max_states > MAX_STATES)
      return ADS_STATE_TOO_LARGE;

   s = (INT_S) max_states;
   t = newdes(s);
   if (s != 0) {
     if (t == NULL) {
        mem_result = 1;
        return -1;
     }
   }

   a2d_state++;
   return 0;
}

INT_OS A2D_MarkLabel_all(char* line)
{
   if (strcmp(line, "") == 0)
      return 0;

   if (strcmp(line, "Marker states:") != 0)
      return ADS_MARK_LABEL_EXPECTED;

   a2d_state++;
   return 0;
}

INT_OS A2D_ReadMark_all(char* line)
{
   INT_OS mark;
   INT_S i;
   INT_OS result;

/*   if (*line == '\0')
   {
     a2d_state++;
     return 0;
   }
*/
   if (*line == '\0')
      return 0;

   if (strcmp(line, "Vocal states:") == 0)
   {
      a2d_state++;
      a2d_state++;
      return 0;
   }

   if ( (strcmp(line, "*") == 0) ||
        (strcmp(line, " *") == 0) )
   {
      a2d_state++;

      for (i=0; i < s; i++)
         t[i].marked = true;
      return 0;
   }

   result = sscanf(line, "%d", &mark);

   if (result <= 0)
     return ADS_MARK_UNKNOWN;

   if (mark < 0)
     return ADS_MARK_TOO_SMALL;

   if (mark >= s)
     return ADS_MARK_TOO_LARGE;

   t[mark].marked = true;
   return 0;
}

INT_OS A2D_VocalLabel_all(char* line)
{
   if (strcmp(line, "") == 0)
      return 0;

   if (strcmp(line, "Vocal states:") != 0)
      return ADS_VOCAL_LABEL_EXPECTED;

   a2d_state++;
   return 0;
}

INT_OS A2D_ReadVocal_all(char* line)
{
   INT_OS state;
   INT_OS vocal;
   INT_OS result;

/*   if (*line == '\0')
   {
     a2d_state++;
     return 0;
   }
*/

   if (*line == '\0')
      return 0;

   if (strcmp(line, "Transitions:") == 0)
   {
      a2d_state++;
      a2d_state++;
      return 0;
   }

   result = sscanf(line, "%d %d", &state, &vocal);
   if (result <= 1)
     return ADS_VOCAL_UNKNOWN;

   if (state < 0)
     return ADS_STATE_TOO_SMALL;

   if (state >= s)
     return ADS_STATE_TOO_LARGE;

   if (vocal <= 9)
     return ADS_VOCAL_TOO_SMALL;

   if (vocal > MAX_VOCAL_OUTPUT)
     return ADS_VOCAL_TOO_LARGE;

   t[state].vocal = (INT_V) vocal;
   return 0;
}

INT_OS A2D_TransLabel_all(char* line)
{
   if (strcmp(line, "") == 0)
      return 0;

   if (strcmp(line, "Transitions:") != 0)
      return ADS_TRANS_LABEL_EXPECTED;

   a2d_state++;
   return 0;
}

INT_OS A2D_ReadTrans_all(char* line, long *line_num, long *line_num2)
{
   INT_OS i, e, j, jj;
   INT_B  ok;
   INT_OS result;
   long ii;

   if (*line == '\0')
     return 0;

   result = sscanf(line, "%d %d %d", &i, &e, &j);

   if (result <= 2)
     return ADS_TRANS_UNKNOWN;

   if (i < 0)
     return ADS_EXIT_STATE_TOO_SMALL;

   if (i >= s)
     return ADS_EXIT_STATE_TOO_LARGE;

   if (e < 0)
     return ADS_TRANS_TOO_SMALL;

   if (e > MAX_TRANSITIONS)
     return ADS_TRANS_TOO_LARGE;

   if (j < 0)
     return ADS_ENTRANCE_STATE_TOO_SMALL;

   if (j >= s)
     return ADS_ENTRANCE_STATE_TOO_LARGE;

   /* Check for non-deterministic transitions */
   for (jj=0; jj < t[i].numelts; jj++) {
      if ( (e == t[i].next[jj].data1) &&
           (j != t[i].next[jj].data2) )
      {
         /* Find the line number that mismatch with this transition */
         for (ii =0; ii < s_tranList; ii++)
         {
            if ( (tranList[ii].i == i) &&
                 (tranList[ii].e == e))
               *line_num2 = tranList[ii].line;
         }

         return ADS_NONDETERMINISTIC;
      }
   }

   /* Record transition and line number */
   tranList = (tranList_t*) REALLOC(tranList, sizeof(tranList_t)*(s_tranList+1));
   if (tranList == NULL)
   {
      mem_result = 1;
      return 0;
   }
   tranList[s_tranList].i = i;
   tranList[s_tranList].e = e;
   tranList[s_tranList].j = j;
   tranList[s_tranList].line = *line_num;
   s_tranList++;

   addordlist1((INT_T) e, (INT_S) j, &t[i].next, t[i].numelts, &ok);
   if (ok) t[i].numelts++;
   return 0;
}

INT_OS A2D_ProcessLine_all(char* line, long* line_num, long* line_num2)
{
   INT_OS err = 0;

   switch( a2d_state ) {
      case A2D_NAME:     err = A2D_ReadName_all(line);   break;
      case A2D_STATE_L:  err = A2D_StateLabel_all(line); break;
      case A2D_STATE:    err = A2D_ReadState_all(line);  break;
      case A2D_MARK_L:   err = A2D_MarkLabel_all(line);  break;
      case A2D_MARK:     err = A2D_ReadMark_all(line);   break;
      case A2D_VOCAL_L:  err = A2D_VocalLabel_all(line); break;
      case A2D_VOCAL:    err = A2D_ReadVocal_all(line);  break;
      case A2D_TRANS_L:  err = A2D_TransLabel_all(line); break;
      case A2D_TRANS:    err = A2D_ReadTrans_all(line, line_num, line_num2);  break;
   default:
      err = ADS_UNKNOWN;
      break;
   }
   return err;
}

INT_OS ads_2_des_all(char* name, long* line_num, long *line_num2, state_node** t1, INT_S* s1)
{
   FILE *in;
   char line[256];
   INT_OS err;
   
   tranList = NULL;
   s_tranList = 0;

   in = fopen(name, "r");
   if (in == NULL) {
      return ADS_FILE_DOES_NOT_EXIST;
   }

   err = 0;
   a2d_state = A2D_NAME;
   *line_num = 0;
   s = *s1;
   t = *t1;

   do {
      fgets(line, 255, in);
      if (feof(in)) break;
      (*line_num)++;
      if (line[0] != '#') {
         line[strlen(line)-1] = '\0';
         err = A2D_ProcessLine_all(line, line_num, line_num2);
      }
   } while ((!feof(in)) && (a2d_state <= A2D_TRANS) && (err == 0));

   if (err == 0)
   {
      if (a2d_state < A2D_TRANS_L)
         err = ADS_FILE_TOO_SHORT;
   }

   if (err == 0)
   {
      *t1 = t;
      *s1 = s;
   }

   free(tranList);  tranList = NULL;

   fclose(in);
   return err;
}

INT_OS generate_ads_file(char *longname, char *shortname)
{
   FILE *out;

   out = fopen(longname, "wt");
   if (out == NULL)
      return 1;

   fprintf(out, "# CTCT ADS Template\n");
   fprintf(out, "\n");
   fprintf(out, "%s\n", shortname);
   fprintf(out, "\n");
   fprintf(out, "State size (State set will be (0,1....,size-1)):\n");
   fprintf(out, "# <-- Enter state size, in range 0 to 2000000, on line below.\n");
   fprintf(out, "\n");

   fprintf(out, "Marker states:\n");
   fprintf(out, "# <-- Enter marker states, one per line.\n");
   fprintf(out, "# To mark all states, enter *.\n");
   fprintf(out, "# If no marker states, leave line blank.\n");
   fprintf(out, "# End marker list with blank line.\n");
   fprintf(out, "\n");

   fprintf(out, "Vocal states:\n");
   fprintf(out, "# <-- Enter vocal output states, one per line.\n");
   fprintf(out, "# Format: State  Vocal_Output.  Vocal_Output in range 10 to 99.\n");
   fprintf(out, "# Example: 0 10\n");
   fprintf(out, "# If no vocal states, leave line blank.\n");
   fprintf(out, "# End vocal list with blank line.\n");
   fprintf(out, "\n");

   fprintf(out, "Transitions:\n");
   fprintf(out, "# <-- Enter transition triple, one per line.\n");
   fprintf(out, "# Format: Exit_(Source)_State  Transition_Label  Entrance_(Target)_State.\n");
   fprintf(out, "# Transition_Label in range 0 to 9999.\n");
   fprintf(out, "# Example: 2 0 1 (for transition labeled 0 from state 2 to state 1).\n");
   fprintf(out, "\n");

   fclose(out);
   return 0;
}

INT_OS des_to_ads(char *shortname,
               FILE *out,
               state_node *t1,
               INT_S s1)
{
   INT_S i;
   INT_T j;

   fprintf(out, "# CTCT ADS auto-generated\n");
   fprintf(out, "\n");
   fprintf(out, "%s\n", shortname);
   fprintf(out, "\n");
   fprintf(out, "State size (State set will be (0,1....,size-1)):\n");
   fprintf(out, "# <-- Enter state size, in range 0 to 2000000, on line below.\n");
   fprintf(out, "%ld\n", s1);
   fprintf(out, "\n");

   fprintf(out, "Marker states:\n");
   fprintf(out, "# <-- Enter marker states, one per line.\n");
   fprintf(out, "# To mark all states, enter *.\n");
   fprintf(out, "# If no marker states, leave line blank.\n");
   fprintf(out, "# End marker list with blank line.\n");
   for (i=0; i < s1; i++)
   {
      if (t1[i].marked)
        fprintf(out, "%ld\n", i);
   }
   fprintf(out, "\n");

   fprintf(out, "Vocal states:\n");
   fprintf(out, "# <-- Enter vocal output states, one per line.\n");
   fprintf(out, "# Format: State  Vocal_Output.  Vocal_Output in range 10 to 99.\n");
   fprintf(out, "# Example: 0 10\n");
   fprintf(out, "# If no vocal states, leave line blank.\n");
   fprintf(out, "# End vocal list with blank line.\n");
   for (i=0; i < s1; i++)
   {
     if (t1[i].vocal > 0)
       fprintf(out, "%-5ld %-4d\n", i, t1[i].vocal);
   }
   fprintf(out, "\n");

   fprintf(out, "Transitions:\n");
   fprintf(out, "# <-- Enter transition triple, one per line.\n");
   fprintf(out, "# Format: Exit_(Source)_State  Transition_Label  Entrance_(Target)_State.\n");
   fprintf(out, "# Transition_Label in range 0 to 9999.\n");
   fprintf(out, "# Example: 2 0 1 (for transition labeled 0 from state 2 to state 1).\n");
   for (i=0; i < s1; i++) {
      for (j=0; j < t1[i].numelts; j++)
         fprintf(out, "%-5ld %-3d %-5d\n", i, t1[i].next[j].data1, t1[i].next[j].data2);
   }
   fprintf(out, "\n");
   return 0;
}

#ifdef __cplusplus
}
#endif
