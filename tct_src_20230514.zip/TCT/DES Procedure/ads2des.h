#ifndef _ADS2DES_H
#define _ADS2DES_H

#include "des_data.h"

#ifdef __cplusplus
extern "C" {
#endif

#define ADS_FILE_DOES_NOT_EXIST  1
#define ADS_FILE_TOO_SHORT       2
#define ADS_UNKNOWN              3
#define ADS_FILENAME_EMPTY       4
#define ADS_FILENAME_TOO_LONG    5
#define ADS_STATE_LABEL_EXPECTED 6
#define ADS_STATE_TOO_SMALL      7
#define ADS_STATE_TOO_LARGE      8
#define ADS_MARK_LABEL_EXPECTED  9
#define ADS_MARK_TOO_SMALL       10
#define ADS_MARK_TOO_LARGE       11
#define ADS_VOCAL_LABEL_EXPECTED 12
#define ADS_VOCAL_TOO_SMALL      13
#define ADS_VOCAL_TOO_LARGE      14
#define ADS_TRANS_LABEL_EXPECTED 15
#define ADS_TRANS_TOO_SMALL      16
#define ADS_TRANS_TOO_LARGE      17
#define ADS_STATE_UNKNOWN        18
#define ADS_MARK_UNKNOWN         19
#define ADS_VOCAL_UNKNOWN        20
#define ADS_TRANS_UNKNOWN        21
#define ADS_EXIT_STATE_TOO_SMALL 22
#define ADS_EXIT_STATE_TOO_LARGE 23
#define ADS_ENTRANCE_STATE_TOO_SMALL 24
#define ADS_ENTRANCE_STATE_TOO_LARGE 25
#define ADS_NONDETERMINISTIC     26
#define MAX_ADS_ERROR_STR        (ADS_NONDETERMINISTIC+1)

typedef char ads_t[60];
extern ads_t ads_error_str[MAX_ADS_ERROR_STR];

typedef struct ads_err_log_t {
   INT_OS  fail_code;
   long line_num1;
   long line_num2;
} ads_err_log_t;

extern INT_OS ads_2_des(char* , ads_err_log_t**, long*, state_node**, INT_S*);
extern INT_OS ads_2_des_all(char* , long*, long*, state_node**, INT_S*);
extern INT_OS generate_ads_file(char*, char*);
extern INT_OS des_to_ads(char*, FILE*, state_node*, INT_S);

#ifdef __cplusplus
}
#endif

#endif
