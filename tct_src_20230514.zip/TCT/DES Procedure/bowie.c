#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "wtct.h"
#include "tct_proc.h"
#include "display.h"
#include "io.h"
#include "curses.h"
#include "editor.h"
#include "show.h"
#include "setup.h"
#include "des_data.h"
#include "mymalloc.h"
#include "hicons.h"
#include "bowie.h"
#include "des_proc.h"

static filename   name1, name2, name3, name4;
static INT_BOOL    quit;
static int TAU_NOT = 777;
static int temp = 0;

/******************************************************************************/
/*                            AUXILIARY FUNCTIONS                             */
/******************************************************************************/

//Make a copy of a DES
state_node* copyDES(state_node* G, INT_S sizeG) {

   state_node* G_new = (state_node*) malloc(sizeG * sizeof(state_node));
   int i,j;
   
   for(i = 0; i < sizeG; i++)
   {
      G_new[i].marked = G[i].marked;
      G_new[i].reached = G[i].reached;
      G_new[i].coreach = G[i].coreach;
      G_new[i].vocal = G[i].vocal;
      G_new[i].numelts = G[i].numelts;
      G_new[i].next = (tran_node*) malloc(G_new[i].numelts * sizeof(tran_node));
      
      for(j = 0; j < G_new[i].numelts; j++)
      {
         G_new[i].next[j].data1 = G[i].next[j].data1;
         G_new[i].next[j].data2 = G[i].next[j].data2;
      }
   }
   return G_new;
}

//get or append to a list of events from an automaton 
INT_T* getEventList(INT_T* list, int* sizeList, state_node* G, INT_S sizeG) {
   
   INT_BOOL isMember;
   int i,j,k;
   
   for(i = 0; i < sizeG; i++) {
      for(j = 0; j < G[i].numelts; j++) {
         isMember = false;
         for(k = 0; k < *sizeList; k++) {
            if(G[i].next[j].data1 == list[k]) {
               isMember = true;
               break;
            }
         }
         if(isMember == false) {
            (*sizeList)++;
            list = (INT_T*) realloc(list, (*sizeList) * sizeof(INT_T));
            list[(*sizeList) - 1] = G[i].next[j].data1;
         }
      }
   }
   return list;         
}

INT_T* getT(state_node* G, state_node* G_hat, INT_S sizeG, INT_S sizeG_hat, int* sizeT)
{
   int i,j;
   int sizeG_list = 0;
   INT_T* G_list = NULL;
   
    
   int sizeG_hat_list= 0;
   INT_T* G_hat_list = NULL;

   int size = 0;
   INT_T* T = NULL;   
   INT_BOOL memberFlag;

   G_list = getEventList(G_list, &sizeG_list, G, sizeG);   
   G_hat_list = getEventList(G_hat_list, &sizeG_hat_list, G_hat, sizeG_hat);
   
   for(i = 0; i < sizeG_hat_list; i++) {
      memberFlag = false;
      for(j = 0; j < sizeG_list; j++) {
         if(G_hat_list[i] == G_list[j]) {
            memberFlag = true;         
         }
      }
      if(memberFlag == false) {
         size++;
         T = (INT_T*) realloc(T, size*(sizeof(INT_T)));
         T[size - 1] = G_hat_list[i];
      }
   }
   *sizeT = size;  
   
   return T;
}

//get list of vocal event outputs from G_hat
int* getVocList(state_node* G_hat, INT_S sizeG_hat, int* numOutputs) {
     
     int i,j,k;
	 int *tempList;
     int* vocList;
	     INT_BOOL isMember = false;
     int listCount = 0;
     
	 tempList = (int*)CALLOC(sizeG_hat, sizeof(int));
     zeroArray(tempList, sizeG_hat);
     

     
     for(j = 0; j < sizeG_hat; j++)
     {
           for(k = 0; k < sizeG_hat; k++)
               {
                     if(G_hat[j].vocal == tempList[k])
                           isMember = true;
               }     
           if(isMember == false && G_hat[j].vocal > 0)
           {      
                 tempList[listCount] = G_hat[j].vocal; 
                 listCount++;
           }   
           isMember = false;
     }
     
     *numOutputs = listCount;
     vocList = (int*) malloc(listCount * sizeof(int));
     
     for(i = 0; i < listCount; i++)
           vocList[i] = tempList[i];

	 free(tempList);
     
     return vocList;
}

//set each element in an array to be 0
void zeroArray(int* array, int size) {
     
     int i;
     for(i = 0; i < size; i++)
     {
           array[i] = 0;
     }
     return;
}

//check if two members elements of a coset are equal
INT_BOOL equalMembers(set* a, set* b, INT_S sizeG_hat) {
        
	 int *a_table, *b_table;
	 int i;
	 INT_BOOL isEqual = true;  

	 a_table = (int *)CALLOC(sizeG_hat, sizeof(int));
	 b_table = (int *)CALLOC(sizeG_hat, sizeof(int));

     zeroArray(a_table, sizeG_hat);
     zeroArray(b_table, sizeG_hat);
     
     
     for(i = 0; a[i] != -1; i++)
     {
           a_table[a[i]] = 1;
     }
     for(i = 0; b[i] != -1; i++)
     {
           b_table[b[i]] = 1;
     }
     
     for(i = 0; i < sizeG_hat; i++)
     {
           if(a_table[i] != b_table[i])
           {
                 isEqual = false;
                 break;
           }
     }
	 free(a_table);free(b_table);
     return isEqual;
}

/******************************************************************************/
/*                          CORE PROGRAM FUNCTIONS                            */
/******************************************************************************/

//replace entrance transitions with vocal output as new event label
state_node* getG_hat(INT_S sizeG, state_node *G)  {
   
   state_node* G_hat;

   int i = 0;
   int j = 0;

    G_hat = newdes(sizeG);

   //for each state in G
   for(i = 0; i < sizeG; i++)
   {
         G_hat[i].marked = G[i].marked;
         G_hat[i].reached = G[i].reached;
         G_hat[i].coreach = G[i].coreach;
         G_hat[i].numelts = G[i].numelts;
         G_hat[i].vocal = G[i].vocal; //...vocal > 0 is a flag for a vocal transition
         
         //allocate memory for *next array
         G_hat[i].next = (tran_node*) MALLOC(sizeof(tran_node)*(G[i].numelts));
         
         
         //for each exit transition in a given state
         for(j = 0; j < G_hat[i].numelts; j++)
         {
               tran_node temp = G[i].next[j];
               
               (G_hat[i].next[j]).data2 = temp.data2;    //target state
               
               //if the target state is vocal in G, then replace its entrance
               //transition label with that of the vocal output
               if( G[temp.data2].vocal > 0 )
                   (G_hat[i].next[j]).data1 = G[temp.data2].vocal;
               else
                   (G_hat[i].next[j]).data1 = temp.data1;    
         }
   }           
   return G_hat;
}  

//look for next set of downstream silent transitions from state q
//used to fill out a deltaTauTableRow
void findNextSilent( INT_S q, state_node *G_hat, int* row, INT_T* T, int sizeT, 
                     int* silentFlag) 
{     
	int i,j;
     INT_T event;
     INT_S targetState;
     INT_BOOL in_T;
     silentFlag[q] = 1;
     row[q] = 1;
     
     
     for(i = 0; i < G_hat[q].numelts; i++)
     {
           event = G_hat[q].next[i].data1;
           targetState = G_hat[q].next[i].data2;
           
           in_T = false;
           for(j = 0; j < sizeT; j++) {
              if(event == T[j]) {
                 in_T = true;
                 break;
              }
           }           
           //if it is a silent, unflagged transition
           if(in_T == false && silentFlag[targetState] == 0) {
              findNextSilent(targetState, G_hat, row, T, sizeT, silentFlag);
           }
     }
     return;
}

//look for next set of downstream output transitions from state q
//used to fill out a deltaTauTableRow
void findNextTau( INT_S q, state_node *G_hat, int* row, INT_T tau, INT_T* T, 
                  int sizeT, int* tauFlag, int* silentFlag) 
{     
   INT_S targetState;
   INT_T event;
   INT_BOOL in_T;     
   int i,j;
     
   for(i = 0; i < G_hat[q].numelts; i++)
   {
      event = G_hat[q].next[i].data1;
      targetState = G_hat[q].next[i].data2;
           
      in_T = false;
      for(j = 0; j < sizeT; j++) {
         if(event == T[j]) {
            in_T = true;
            break;
         }
      }                    
           //if it is an unflagged 'tau' transition 
      if(event == tau && tauFlag[targetState] == 0) {
         tauFlag[targetState] = 1;
         findNextSilent(targetState, G_hat, row, T, sizeT, silentFlag);
      }
           //if it is a low-level transition      
      else if(in_T == false && tauFlag[targetState] == 0) {
         tauFlag[targetState] = 1;
         findNextTau(targetState, G_hat, row, tau, T, sizeT, tauFlag, silentFlag);
      }
   }
   return;
}

//Returns a row for the deltaTauTable used in the Fernandez algorithm        
int* deltaTauTableRow(INT_S q, state_node *G_hat, INT_S sizeG_hat, INT_T tau, INT_T* T, int sizeT) {
     
     int *row = (int*) malloc(sizeG_hat * sizeof(int));
	 int* tauFlag = (int*) malloc(sizeG_hat * sizeof(int));
	 int* silentFlag = (int*) malloc(sizeG_hat * sizeof(int));

     zeroArray(row, sizeG_hat);
     
     
     zeroArray(tauFlag, sizeG_hat);
     
     
     zeroArray(silentFlag, sizeG_hat);

     findNextTau(q, G_hat, row, tau, T, sizeT, tauFlag, silentFlag);      
     return row;
}   
 
//locate next state in deltaM(q) set
void findNextM( INT_S q, state_node* G_hat, int* row, INT_T* T, int sizeT, 
                int* MFlag) 
{        
     

     
     INT_S targetState;
     INT_T event;
     INT_BOOL in_T;
     
     int i,j;

	 MFlag[q] = 1;

	 if(G_hat[q].marked ==1)
        row[q] = 1;
     for(i = 0; i < G_hat[q].numelts; i++) {
           event = G_hat[q].next[i].data1;
           targetState = G_hat[q].next[i].data2;
           
           in_T = false;
           for(j = 0; j < sizeT; j++) {
              if(event == T[j]) {
                 in_T = true;
                 break;
              }
           }
           //if it is a low-level, unflagged transition
           if(in_T == false && MFlag[targetState] == 0) {
               findNextM(targetState, G_hat, row, T, sizeT, MFlag);
           }
     }
     return;
}

//Returns a row for the deltaMTable used in the Fernandez algorithm
int* deltaMTableRow(INT_S q, state_node *G_hat, INT_S sizeG_hat, INT_T* T, int sizeT) {
     
   int *row = (int*) malloc(sizeG_hat * sizeof(int));
     
   int* MFlag = (int*) malloc(sizeG_hat * sizeof(int));

   zeroArray(row, sizeG_hat); 
   
   zeroArray(MFlag, sizeG_hat);
     
   findNextM(q, G_hat, row, T, sizeT, MFlag);          
   return row;
}   

//get a delta-tau table
int** deltaTauTable(state_node* G_hat, INT_S sizeG_hat, INT_T tau, INT_T* T, int sizeT) {
      
      int** table = (int**) malloc(sizeG_hat * sizeG_hat * sizeof(int));
      
      INT_S i;
      for(i = 0; i< sizeG_hat; i++) {
            table[i] = deltaTauTableRow(i, G_hat, sizeG_hat, tau, T, sizeT);
      }
      
      return table;
}      

//get a delta-m (as in marked state) table
int** deltaMTable(state_node* G_hat, INT_S sizeG_hat, INT_T* T, int sizeT) {
      
   int** table = (int**) malloc(sizeG_hat * sizeG_hat * sizeof(int));
        
   int i;
   for(i = 0; i< sizeG_hat; i++) {
      table[i] = deltaMTableRow(i, G_hat, sizeG_hat, T, sizeT);
   }
      
   return table;
}

//get a linked list of deltaTables covering all tau's and m
deltaTable* getDeltaTable(state_node* G_hat, INT_S sizeG_hat, INT_T* T, int sizeT, int counter) {
       
      deltaTable* table = (deltaTable*) malloc(sizeof(deltaTable));
      
      if(counter == 0) {
           
          table->tau = 0;
          table->m = true;
          table->table = deltaMTable(G_hat, sizeG_hat, T, sizeT);
          table->next = NULL;
      }
      else
      {
          table->tau = T[counter-1];
          table->m = false;
          table->table = deltaTauTable(G_hat, sizeG_hat, table->tau, T, sizeT);
          table->next = getDeltaTable(G_hat, sizeG_hat, T, sizeT, counter - 1);
      }
      
      return table;
}    

//compute the phi function for a state q
int* phiQ(INT_S q, int** deltaTauTable, INT_S sizeG_hat) {
     
     set* resultPhiQ = (set*) malloc(sizeG_hat * sizeof(int));
     
     int i;
     //mark non-zero entries in column q of the delta-table in resultPhiQ
     for(i = 0; i < sizeG_hat; i++)
     {
           if( deltaTauTable[i][q] > 0 )
               resultPhiQ[i] = 1;
           else
               resultPhiQ[i] = 0;
     }
     return resultPhiQ;
}

//compute the phi function for a set, B, of states
int* phiB(set* B, int** deltaTauTable, INT_S sizeG_hat) {
     
     int* resultPhiQ = NULL;
     int* resultPhiB = (int*) malloc(sizeG_hat * sizeof(int));
     
     
     int i;
     int j; 

	 zeroArray(resultPhiB, sizeG_hat);
     for(i = 0; B[i] != -1; i++)
     {
           resultPhiQ = phiQ(B[i], deltaTauTable, sizeG_hat);
           for(j = 0; j < sizeG_hat; j++)
           {
                 resultPhiB[j] = max(resultPhiB[j], resultPhiQ[j]);
           }
     }
     return resultPhiB;
}            

//Compute the set I_tau,B 
coset* getI(coset* roh, set* B, int** deltaTable, INT_S sizeG_hat) {
     

	int *isMember;
	int* resultPhiB = phiB(B, deltaTable, sizeG_hat);
	int sizeRoh;
	int *X;
     int commElem, sizeX, i, j;

	 isMember = (int*)CALLOC(sizeRoh, sizeof(int));
	 X = (int*)CALLOC(sizeG_hat, sizeof(int));

     coset* I = NULL;
     
     
     coset* curr = roh;
     //Count the number of elements in roh
     
     for(sizeRoh = 0; curr != NULL; sizeRoh++)
     {
           curr = curr->next;
     }
     
     //initialize variables needed for next computation
     
     zeroArray(isMember, sizeRoh);    

     
     //for each element, X, in roh
     curr = roh;
     for(i = 0; i < sizeRoh; i++)
     {
           zeroArray(X, sizeG_hat);
           sizeX = 0;
           //mark the contents of X by a 1 in table X
           //also count the number of states in X
           for(sizeX = 0; curr->members[sizeX] != -1; sizeX++) 
           {
                 X[curr->members[sizeX]] = 1;
           }
           
           commElem = 0;   
           //for each state in G_hat
           for(j = 0; j < sizeG_hat; j++)
           {
                 //if the state is in both X and phiB
                 if(X[j] == 1 && resultPhiB[j] == 1) 
                 {
                        //increment the common elements counter
                        commElem = commElem + 1;
                 }
           }
           //if X intersect phiB is non-empty...
           if(commElem > 0)
           {
                 //... and X is not contained in phiB
                 if( (sizeX - commElem) > 0)
                 {
                       //then the i-th member of roh (in linked list) is in I
                       isMember[i] = 1;
                 }
           }
           //increment to next element of roh
           curr = curr->next;
     }
     
     coset* I_curr = (coset*) malloc(sizeof(coset)); //create new object for I
     curr = roh;
     for(i = 0; i < sizeRoh; i++)
     {
           if(isMember[i] == 1 && I != NULL)
           {
                I_curr->next = (coset*) malloc(sizeof(coset));
                *(I_curr->next) = *curr;
                I_curr = I_curr->next;
           }
           else if(isMember[i] == 1 && I == NULL)
           {
                *I_curr = *curr;
                I = I_curr; //I points to head of linked list of cosets
           }
           curr = curr->next;
     }
     //set the tail element of I to be NULL
     if(I_curr != NULL)
           I_curr->next = NULL;
     
	 free(isMember); free(X);
     return I;
}

//Compute the set I_tau,B^1,2 from I_tau,B 
coset* getI12(coset* I, set* B, int** deltaTable, INT_S sizeG_hat) {
       
     //If I is empty, then terminate right away
     if(I == NULL)
     {
          return NULL;
     }
     
     coset* I12 = NULL;
     int* resultPhiB = phiB(B, deltaTable, sizeG_hat);
     
     coset* curr = I;
     //Count the number of elements in I
     int sizeI;
     for(sizeI = 0; curr != NULL; sizeI++)
     {
           curr = curr->next;
     }
     
     //initialize variables needed for next computation
     int common[sizeI][sizeG_hat];
     int uncommon[sizeI][sizeG_hat];
     int X[sizeG_hat];
     int i, j;
     
     curr = I;
     //for each element, X, in I
     for(i = 0; i < sizeI; i++)
     {       
           //mark the contents of X by a 1 in table X
           zeroArray(X, sizeG_hat);
           for(j = 0; curr->members[j] != -1; j++) 
           {
                 X[curr->members[j]] = 1;
           }
                    
           //for each state in G_hat
           for(j = 0; j < sizeG_hat; j++)
           {
                 //if the state is in both X and phiB
                 if(X[j] == 1 && resultPhiB[j] == 1) 
                 {                       
                        common[i][j] = 1;
                        uncommon[i][j] = 0;
                 }
                 //if the state is in X but not in phiB
                 else if(X[j] == 1 && resultPhiB[j] == 0) 
                 {
                        common[i][j] = 0;
                        uncommon[i][j] = 1;
                 }
                 //if the state is in neither X nor phiB
                 else
                 {
                        common[i][j] = 0;
                        uncommon[i][j] = 0;
                 }   
           }
     }
     
     coset* I12_curr = NULL;
     int sizeCommon, sizeUncommon, k;
     //for each set pair in I12 (split from a single set in I)
     //i.e. we're dealing with elements, X, from the set I
     for(i = 0; i < sizeI; i++)
     {
           //If I12 points to NULL then we're adding the first element in list
           if(I12 == NULL)
           {
                  I12_curr = (coset*) malloc(sizeof(coset)); //create first element
                  I12 = I12_curr; //I12 points to the first element
           }
           else
           {
                  I12_curr->next = (coset*) malloc(sizeof(coset)); //create the next element
                  I12_curr = I12_curr->next; //I12_curr points to the next element
           }
           
           //Count the number of common elements between X and phiB       
           sizeCommon = 0;
           for(j = 0; j < sizeG_hat; j++)
           {
                 sizeCommon = sizeCommon + common[i][j];
           }
           
           //First build the coset of common elements
           I12_curr->members = (set*) malloc((sizeCommon + 1) * sizeof(int));         
           
           //For each state in G_hat
           k = 0;
           for(j = 0; j < sizeG_hat; j++)
           {
                 //If the state is marked common then add it to coset
                 if(common[i][j] == 1)
                 {
                       I12_curr->members[k] = j;
                       k++;
                 }
           }
           I12_curr->members[k] = -1; //Terminate coset list with -1
           
           //Next create the coset of uncommon elements
           I12_curr->next = (coset*) malloc(sizeof(coset));
           I12_curr = I12_curr->next;
           
           //Count the number of uncommon elements between X and phiB     
           sizeUncommon = 0;
           for(j = 0; j < sizeG_hat; j++)
           {
                 sizeUncommon = sizeUncommon + uncommon[i][j];
           }
           
           //Create a list of uncommon states for the coset
           I12_curr->members = (set*) malloc((sizeUncommon + 1) * sizeof(int));
           
           //For each state in G_hat
           k = 0;
           for(j = 0; j < sizeG_hat; j++)
           {
                 //If the state is marked uncommon then add it to the coset
                 if(uncommon[i][j] == 1)
                 {
                       I12_curr->members[k] = j;
                       k++;
                 }
           }
           I12_curr->members[k] = -1; //Terminate list with -1
     }
     
     //If I12 is nonempty then terminate the linked list with a NULL element
     if(I12 != NULL)
     {        
           I12_curr->next = NULL;
     }
     
     return I12;  
}   
        
//Calculate and create the set nextRoh = {roh - I}U{I_12}
coset* getNextRoh(coset* roh, coset* I, coset* I12, INT_S sizeG_hat) {
         
     coset* nextRoh = NULL;
     coset* nextRoh_curr = NULL;
     coset* roh_curr = NULL;
     coset* I_curr = NULL;
     coset* I12_curr = NULL;
     INT_BOOL isMember;
     
     //Add the elements of roh that are not in I to nextRoh
     //For each element in roh
     for(roh_curr = roh; roh_curr != NULL; roh_curr = roh_curr->next)
     {
          isMember = false;
          //For each element in I                          
          for(I_curr = I; I_curr != NULL; I_curr = I_curr->next)
          {
               //if this member of roh is in I, mark the isMember flag
               //move on to next element of roh              
               if(equalMembers(roh_curr->members, I_curr->members, sizeG_hat))
               {
                    isMember = true;
                    break;
               }
          }
          //If this member of roh is not in I, add it to nextRoh
          if(isMember == false && nextRoh == NULL)
          {
               nextRoh_curr = (coset*) malloc(sizeof(coset)); //create new object
               *nextRoh_curr = *roh_curr;
               nextRoh = nextRoh_curr; //nextRoh points to this first element
          }
          else if(isMember == false && nextRoh != NULL)
          {
               nextRoh_curr->next = (coset*) malloc(sizeof(coset));
               *(nextRoh_curr->next) = *(roh_curr);
               nextRoh_curr = nextRoh_curr->next;
          }
     }
     
     //add the elements of I_12 to nextRoh
     for(I12_curr = I12; I12_curr != NULL; I12_curr = I12_curr->next)
     {
          if(nextRoh == NULL)
          {
                nextRoh_curr = (coset*) malloc(sizeof(coset)); //create new object
                *nextRoh_curr = *I12_curr;
                nextRoh = nextRoh_curr; //nextRoh points to this first element
          }
          else
          {
                nextRoh_curr->next = (coset*) malloc(sizeof(coset));
                *(nextRoh_curr->next) = *I12_curr;
                nextRoh_curr = nextRoh_curr->next;
          }
     }
     //If nextRoh is non-empty, terminate the linked list with NULL           
     if(nextRoh != NULL)
     {
          nextRoh_curr->next = NULL;
     }
     
     return nextRoh;
}                    

//Calculate and create the set nextW = {W - I}U{I_12}
coset* getNextW(coset* W, coset* I, coset* I12, INT_S sizeG_hat) {
         
     coset* nextW = NULL;
     coset* nextW_curr = NULL;
     coset* W_curr = NULL;
     coset* I_curr = NULL;
     coset* I12_curr = NULL;
     INT_BOOL isMember;
     
     //Add the elements of W that are not in I to nextW
     //For each element in W
     for(W_curr = W; W_curr != NULL; W_curr = W_curr->next)
     {
          isMember = false;
          //For each element in I                          
          for(I_curr = I; I_curr != NULL; I_curr = I_curr->next)
          {
               //if this member of W is in I, mark the isMember flag
               //move on to next element of W              
               if(equalMembers(W_curr->members, I_curr->members, sizeG_hat))
               {
                    isMember = true;
                    break;
               }
          }
          //If this member of W is not in I, add it to nextW
          if(isMember == false && nextW == NULL)
          {
               nextW_curr = (coset*) malloc(sizeof(coset)); //create new object
               *nextW_curr = *W_curr;
               nextW = nextW_curr; //nextW points to this first element
          }
          else if(isMember == false && nextW != NULL)
          {
               nextW_curr->next = (coset*) malloc(sizeof(coset));
               *(nextW_curr->next) = *(W_curr);
               nextW_curr = nextW_curr->next;
          }
     }
     
     //add the elements of I_12 to nextW
     for(I12_curr = I12; I12_curr != NULL; I12_curr = I12_curr->next)
     {
          if(nextW == NULL)
          {
                nextW_curr = (coset*) malloc(sizeof(coset)); //create new object
                *nextW_curr = *I12_curr;
                nextW = nextW_curr; //nextW points to this first element
          }
          else
          {
                nextW_curr->next = (coset*) malloc(sizeof(coset));
                *(nextW_curr->next) = *I12_curr;
                nextW_curr = nextW_curr->next;
          }
     }
     //If nextW is non-empty, terminate the linked list with NULL           
     if(nextW != NULL)
     {
          nextW_curr->next = NULL;
     }
     
     return nextW;
}  
  
//Implementation of the Fernandez algorithm to compute coarsest right congruence
coset* getQuasiCong(deltaTable* table, INT_S sizeG_hat){
     
     //Create rohInit, containing only allStates - a set containing all states  
     int allStates[sizeG_hat + 1];
     int i, j;
     for(i = 0; i < sizeG_hat; i++)
     {
           allStates[i] = i;
     }
     allStates[sizeG_hat] = -1;
     
     coset* rohInit = (coset*) malloc(sizeof(coset));
     rohInit->members = allStates;
     rohInit->next = NULL;
     
     //Initialize variables for main algorithm
     coset* roh = (coset*) malloc(sizeof(coset)); 
     *roh = *rohInit;    
     coset* W = (coset*) malloc(sizeof(coset));
     *W = *rohInit;
     
     free(rohInit); //No longer have use for rohInit
     rohInit = NULL;
     
     set* B;
     coset* I = NULL;
     coset* I12 = NULL;
     
     coset* W_head = (coset*) malloc(sizeof(coset));
     coset* W_free = NULL;
     coset* nextW = NULL;
     coset* nextRoh = NULL;
     coset* roh_curr = NULL;
     coset* W_curr = NULL;
     deltaTable* table_curr = NULL;
     coset* nextW_curr = NULL;
     coset* I_curr;
     coset* I12_curr;
     
     
     
     while(W != NULL)
     {            
           *W_head = *W; //W_head is a dummy copy of the head of W-list
           W_free = W; //Head of W-list will be freed
           W = W->next; //New head of W-list is the next item in line
           free(W_free); //Free the former head of W
           W_free = NULL;
           
           B = W_head->members;
           
           for(table_curr = table; table_curr != NULL; table_curr = table_curr->next)
           {             
                 I = getI(roh, B, table_curr->table, sizeG_hat);
                 I12 = getI12(I, B, table_curr->table, sizeG_hat);
                 nextRoh = getNextRoh(roh, I, I12, sizeG_hat);
                 nextW = getNextW(W, I, I12, sizeG_hat);

                 //Clear roh and W linked lists
                 while(roh != NULL)
                 {
                       roh_curr = roh;
                       roh = roh->next;
                       free(roh_curr);
                       roh_curr = NULL;
                 }
                 while(W != NULL)
                 {
                       W_curr = W;
                       W = W->next;
                       free(W_curr);
                       W_curr = NULL;
                 }
                 
                 //Assign roh and W their new values      
                 roh = nextRoh;
                 W = nextW;
           }
     }
     //Return the refined partition, roh
     return roh;   
}

//Return transition structure for quotient if transition leaves the coset or is a tau-transition
tran_node* getQuotTran(INT_S q, tran_node transition, set** cosetTable, INT_T* T, int sizeT) {
     
     //initialize variable needed to get quotTran
     INT_S target = transition.data2;
     INT_T event = transition.data1;
     tran_node* quotTran = NULL;
     int qCoset = -1;
     int targetCoset = -1;
     int i, j;
     
     //First check if transition is a tau or tau_not event
     INT_BOOL isTau = false;
     for(i = 0; i < sizeT; i++)
     {
           if(event == T[i])
           {
                isTau = true;
                break;
           }
     }
     //If a tau_not transition, label it as such
     if(isTau == false)
           event = TAU_NOT;
     
     //Determine the cosets to which 'q' and 'target' belong
     for(i = 0; cosetTable[i] != NULL; i++)
     {
           //For each state in coset i
           for(j = 0; cosetTable[i][j] != -1; j++)
           {
                 //If q is in coset i, flag qCoset
                 if(q == cosetTable[i][j])
                      qCoset = i;
                 //If target is in coset i, flag targetCoset     
                 if(target == cosetTable[i][j])
                      targetCoset = i;
           }
           //If we've already found the cosets for q and targetCoset
           if(qCoset != -1 && targetCoset != -1)
           {
                break;
           }
     }     
     //If the transition exits the coset
     if(targetCoset != qCoset || isTau == true)
     {
          quotTran = (tran_node*) malloc(sizeof(tran_node));
          quotTran->data2 = targetCoset;
          quotTran->data1 = event;
     }
     return quotTran;            
}

//Get the quotient transition list for G_hat/G_bar w.r.t. the partition roh (quasi-cong)
highLowPair* getPairList( coset* roh, state_node* G_hat, INT_S sizeG_hat, 
                          INT_S initG_hat, INT_S* initQuotient, 
                          INT_S* sizeQuotient, int* sizePairList, 
                          INT_BOOL* markList, INT_T* T, int sizeT) {
     
     //initialize variables needed to create transition list 
     int i,j,k,l;
     *sizePairList = 0;
     highLowPair* pairList = NULL;
     //vocList = getVocList(G_hat, sizeG_hat, &vocCount);           
     int numEvents;
     int q;
     tran_node* quotTran = NULL;
     
     //count the number of cosets i.e. # states in quotient
     int numCoset = 0;
     coset* roh_curr = NULL;
     for(roh_curr = roh; roh_curr != NULL; roh_curr = roh_curr->next)
     {
          numCoset++;
     }            
     *sizeQuotient = numCoset;
     
     //create an array of pointers to coset 'members'
     //each element in cosetTable points to a set of coset members
     set** cosetTable = (set**) malloc((numCoset + 1)*sizeof(set*));
     roh_curr = roh;
     for(i = 0; i < numCoset; i++)
     {
          cosetTable[i] = roh_curr->members;
          roh_curr = roh_curr->next;
     }
     cosetTable[numCoset] = NULL;
     
     //Build transition structure for quotient DES
     //For each coset, i 
     for(i = 0; i < numCoset; i++)
     {
           //for each state, q, in coset i...
           for(j = 0; cosetTable[i][j] != -1; j++)
           {
                 q = cosetTable[i][j]; 
                               
                 //if initial state is in coset i, then i is initial state in quotient
                 if(initG_hat == q)
                    *initQuotient = i;
                 
                 numEvents = G_hat[q].numelts;
                 //for all exit transitions from state q...
                 for(k = 0; k < numEvents; k++)
                 {
                       //get the tran_node structure for quotient
                       quotTran = getQuotTran(q, (G_hat[q].next)[k], cosetTable, T, sizeT);
                       
                       //if transition leaves coset, then add it to transition structure
                       if(quotTran != NULL)
                       {    
                            //add highLowPair to pairList
                            (*sizePairList)++;
                            pairList = (highLowPair*) realloc(pairList, (*sizePairList) * sizeof(highLowPair));
                            //G_hat transition     
                            pairList[(*sizePairList) - 1].low.i = q;
                            pairList[(*sizePairList) - 1].low.e = G_hat[q].next[k].data1;
                            pairList[(*sizePairList) - 1].low.j = G_hat[q].next[k].data2;
                            //G_bar transition                                
                            pairList[(*sizePairList) - 1].high.i = i;
                            pairList[(*sizePairList) - 1].high.e = quotTran->data1;
                            pairList[(*sizePairList) - 1].high.j = quotTran->data2;   
                       }
                 }
           }
     }          
     //If a coset contains a marked state then the corresponding quotient
     //state should also be marked
     zeroArray((int*) markList, sizeG_hat);    
     for(i = 0; i < numCoset; i++)
     {
           //for each state, q, in coset i...
           for(j = 0; cosetTable[i][j] != -1; j++)
           {
                 q = cosetTable[i][j];
                 if(G_hat[q].marked == true)
                 {
                      //quotient[i].state.marked = true;
                      markList[i] = 1;
                      break;
                 }
           }
     }         
     return pairList;             
}

state_node* getG_bar(highLowPair* pairList, int sizePairList, INT_S sizeQuotient, INT_BOOL* markList) {
   
   state_node* G_bar = (state_node*) malloc(sizeQuotient * sizeof(state_node));
   
   int i,j,k;
   int numTran;
   INT_BOOL duplicate;
   
   //For each state in G_bar
   for(i = 0; i < sizeQuotient; i++)
   {
      numTran = 0;
      G_bar[i].next = NULL;
      //For each transition triple in the list
      for(j = 0; j < sizePairList; j++)
      {
         //If an exit state matches the current state in G_bar   
         if(i == pairList[j].high.i)
         {
            //Check if this transition is already in G_bar
            duplicate = false;
            for(k = 0; k < numTran; k++)
            {
               if(G_bar[i].next[k].data1 == pairList[j].high.e && G_bar[i].next[k].data2 == pairList[j].high.j)
               {   
                  duplicate = true;
                  break;
               }
            }
            //If not a duplicate, then add to transition structure
            if(duplicate == false)
            {
               numTran++;
               G_bar[i].next = (tran_node*) realloc(G_bar[i].next, numTran * sizeof(tran_node));
               G_bar[i].next[numTran - 1].data1 = pairList[j].high.e;
               G_bar[i].next[numTran - 1].data2 = pairList[j].high.j;
            }
         }
      }
      
      G_bar[i].numelts = numTran;
      G_bar[i].marked = markList[i];
      G_bar[i].reached = 0;
      G_bar[i].coreach = 0;
      G_bar[i].vocal = 0;
   }
   
   return G_bar;   
}

//Check if quotient, G_bar, is deterministic and contains no tau_not transitions
INT_BOOL isObserver(state_node* G_bar, INT_S sizeG_bar) {
   
   INT_BOOL isObs = true;
   int i,j,k;
        
   //First check for tau_not transitions
   for(i = 0; i < sizeG_bar; i++)
   {
      for(j = 0; j < G_bar[i].numelts; j++)
      {
         if(G_bar[i].next[j].data1 == TAU_NOT)
         {
            isObs = false;
            return isObs;
         }
      }
   }
   
   //If no tau_not transitions, check if G_bar is deterministic
   INT_T currEvent, compEvent;
   
   for(i = 0; i < sizeG_bar; i++)
   {
      //go through each state and check for duplicate exit events
      for(j = 0; j < G_bar[i].numelts; j++)
      {
         currEvent = G_bar[i].next[j].data1;
         for(k = j+1; k < G_bar[i].numelts; k++)
         {
            compEvent = G_bar[i].next[k].data1;
            //if two exit events from state i are the same, then not an observer
            if(currEvent == compEvent)
            {
               isObs = false;
               return isObs;
            }
         }
      }
   }      
   return isObs;
}

//Relabeling algorithm for when G_bar is not an observer
//first get G_barPrime
state_node* relabelG_bar( state_node* G_bar, INT_S sizeG_bar, 
                          highLowPair* pairList, int sizePairList,
                          INT_T* eventList, int sizeEventList) {
   
   state_node* G_barPrime = copyDES(G_bar, sizeG_bar);
   int i,j,k,l,m;
   
   //Relabel tau_not and non-deterministic transitions in G_bar'
   //1. All relabelings are done with new labels
   //2. Two transitions are relabeled with the same label only if original labels are the same
   
   triple* relList = NULL;
   int sizeRelList = 0;
   INT_T newEvent = 0;
   INT_T currEvent, compEvent, compTarg;
   INT_BOOL memberFlag;
   
   //Count the number of transitions in G_bar that need new labels
   //For each state in G_bar
   for(i = 0; i < sizeG_bar; i++)
   {
      //Go through each state and check for duplicate exit events
      //For each exit transition from state i
      for(j = 0; j < G_bar[i].numelts; j++)
      {
         currEvent = G_bar[i].next[j].data1;
         //If currEvent is a TAU_NOT transition, then add to list immediately
         if(currEvent == TAU_NOT)
         {
            sizeRelList++;
            relList = (triple*) realloc(relList, sizeRelList * sizeof(triple));
            relList[sizeRelList - 1].i = i;
            relList[sizeRelList - 1].e = currEvent;
            relList[sizeRelList - 1].j = G_bar[i].next[j].data2;
         } 
         else //Otherwise, check for non-deterministic transitions 
         {   
            for(k = j+1; k < G_bar[i].numelts; k++)
            {
               compEvent = G_bar[i].next[k].data1;
               compTarg = G_bar[i].next[k].data2;
               memberFlag = false;
               
               //if two exit events from state i are the same, then non-deterministic
               if(currEvent == compEvent)
               {
                  //Check if compEvent transition is in relList already
                  for(l = 0; l < sizeRelList; l++)
                  {
                     if(relList[l].i == i && relList[l].e == compEvent && relList[l].j == compTarg)
                     {
                        memberFlag = true;
                        break;
                     }
                  }
                  
                  if(memberFlag == false)
                  {
                     sizeRelList++;
                     relList = (triple*) realloc(relList, sizeRelList * sizeof(triple));
                     relList[sizeRelList - 1].i = i;
                     relList[sizeRelList - 1].e = compEvent;
                     relList[sizeRelList - 1].j = compTarg;
                  }
               }
            }
         }
      }
   } 
   
   /*
   printf("relList: ");
   for(i = 0; i < sizeRelList; i++)
   {
      printf("[%d %d %d], ", relList[i].i, relList[i].e, relList[i].j);
   }
   printf("\n\n");
   */
   
   
   //relList now contains all transitions [i e j] that need to be relabeled   
   INT_T newEvents[sizeRelList];
   INT_T event;
   INT_BOOL isMember;
   
   //printf("sizeRelList = %d \n", sizeRelList);
   for(i = 0, j = 10; j <= 99 && i < sizeRelList; j++)
   { 
      isMember = false;
      event = (INT_T)(j);
      //Check if event is in eventList
      for(k = 0; k < sizeEventList; k++)
      {
         if(eventList[k] == event)
         {   
            isMember = true;
            break;
         }
      }
      //If it is a new event, then add to list
      if(isMember == false)
      {
         newEvents[i] = event;
         i++;
      }
   }
   if(j == 100)
   { 
      printf("ERROR: TOO MANY EVENTS TO RELABEL\n");
      user_pause();
      return G_bar;
   }
   
   //Modify the 'high' elements in pairlist according to high level relabeling   
   INT_BOOL breakFlag;
   INT_S q, targ;
   int numRelabelled = 0;
   for(i = 0; i < sizeRelList && numRelabelled < sizeRelList; i++)
   {
      q = relList[i].i;
      event = relList[i].e;
      targ = relList[i].j;
      
      //For states other than q replace first transition with 'event' with newEvents[i]
      //For state q, replace [q event targ] with [q newEvents[i] targ]
      //Also replace high.e corresponding to high.i in pairList
      for(j = 0; j < sizeG_bar; j++)
      {
         //If the exit state j == q
         if(j == q)
         {  //For all exit transitions  
            for(k = 0; k < G_barPrime[j].numelts; k++)
            {          
               //Find the transition [q event targ]
               if(G_barPrime[j].next[k].data1 == event && G_barPrime[j].next[k].data2 == targ)
               {
                  //Replace event with a newEvent in G_bar'                       
                  G_barPrime[j].next[k].data1 = newEvents[i];
                  numRelabelled++;
                  
                  //Scan through pairList
                  for(l = 0; l < sizePairList; l++)
                  {
                     //Find transitions [q event targ] in pairList
                     if(pairList[l].high.i == q && pairList[l].high.e == event && pairList[l].high.j == targ)
                     {
                        //Replace high level [q event targ] with [q newEvent targ] in pairList
                        pairList[l].high.e = newEvents[i];
                        
                        //don't break, there may be more than 1 corresponding entry in pairList
                     }
                  }
                  break; //We've already found and dealt with [q event targ]
               }
            }
         }
         else //When the exit state, j != q
         {  
            breakFlag = false;
            //Scan through relList
            for(k = 0; k < sizeRelList; k++)
            {
               //If there is a transition [j event *] to be relabelled
               if(relList[k].i == j && relList[k].e == event)
               {
                  for(l = 0; l < G_barPrime[j].numelts; l++)
                  {
                     if(G_barPrime[j].next[l].data1 == event && G_barPrime[j].next[l].data2 == relList[k].j)
                     {         
                        //Replace [j event relList[k].j] in G_bar with newEvent label
                        G_barPrime[j].next[k].data1 = newEvents[i];
                        numRelabelled++;
                        
                        //Scan through pairList
                        for(m = 0; m < sizePairList; m++)
                        {
                           //Find transitions [j event G_barPrime[j].next[k].data2] in pairList
                           if(pairList[m].high.i == j && pairList[m].high.e == event && pairList[m].high.j == G_barPrime[j].next[l].data2)
                           {
                              //Replace 'event' with 'newEvent' in pairList
                              pairList[m].high.e = newEvents[i];
                              //printf("\nSECOND, newEvent [%d %d]\n",j,event);
                              breakFlag = true;
                              
                           }
                        }
                        break; //We've already found an exit tran from state j to be relabelled
                     }
                  }
               }
               if(breakFlag == true) break;
            }
         }
      }   
   }      

   return G_barPrime;
}

//Relabel G_hat transitions in accordance with pairList, as modified in relabG_bar
state_node* relabelG_hat( state_node* G_hat, INT_S sizeG_hat, 
                          highLowPair* pairList, int sizePairList) {
   
   state_node* G_hatPrime = copyDES(G_hat, sizeG_hat);
   int i,j;
   int q, event, newEvent, target;
   
   for(i = 0; i < sizePairList; i++)
   {
      q = pairList[i].low.i;
      event = pairList[i].low.e;
      target = pairList[i].low.j;
      newEvent = pairList[i].high.e;
      
      for(j = 0; j < G_hatPrime[q].numelts; j++)
      {
         if(G_hatPrime[q].next[j].data1 == event && G_hatPrime[q].next[j].data2 == target)
         {
            G_hatPrime[q].next[j].data1 = newEvent;
            G_hatPrime[target].vocal = newEvent;
            //printf("newEvent %d added\n", newEvent);
            break;
         }   
      }
   }
   
   //Note, this procedure doesn't actually produce the 'full' G_hatPrime since it
   //neglects relabelling other entry transitions into newly vocalized states in 
   //alignment with the new vocalizations. However, it's effects are sufficient
   //for the way in which we implement the full algorithm.
      
   return G_hatPrime;
}

//Check if G has the observer property
INT_BOOL checkObserver(state_node* G, INT_S sizeG, INT_S initG) {
   
   state_node* G_hat = getG_hat(sizeG, G);
   INT_S sizeG_hat = sizeG;
   INT_S initG_hat = initG;
   int i;
   
   int vocCount = 0;
   int* vocList = getVocList(G_hat, sizeG_hat, &vocCount);
   /*
      printf("vocList: ");      
      for(i = 0; i < vocCount; i++)
      {
         printf("%d ", vocList[i]);
      }
      printf("\n");
      printf("\n");
   */
   int sizeT = 0;
   INT_T* T = getT(G, G_hat, sizeG, sizeG_hat, &sizeT);
   
   deltaTable* table = getDeltaTable(G_hat, sizeG_hat, T, sizeT, sizeT);  
   coset* rho = getQuasiCong(table, sizeG_hat); 
   
   INT_S sizeQuotient, initQuotient;
   int sizePairList;
   INT_BOOL markList[sizeG_hat];
   
   highLowPair* pairList = getPairList( rho, G_hat, sizeG_hat, initG_hat, 
                                        &initQuotient, &sizeQuotient, 
                                        &sizePairList, markList, T, sizeT);
                              
   state_node* G_bar = getG_bar(pairList, sizePairList, sizeQuotient, markList);
   INT_S sizeG_bar = sizeQuotient;
   INT_S initG_bar = initQuotient;
   
   INT_BOOL result = isObserver(G_bar, sizeG_bar);
    
   free(T);
   free(table);
   free(rho);
   free(pairList);
   free(G_bar);
   
   return result;
}

//Modify G so that it has the observer property
state_node* makeObserver(state_node* G, INT_S sizeG, INT_S initG) {
   
   int i,j;
   
   state_node* G_hat = getG_hat(sizeG, G);
   state_node* G_bar = NULL;
   state_node* G_hatPrime = NULL;
   state_node* G_barPrime = NULL;

   INT_S initG_hat = initG; 
   INT_S sizeG_hat = sizeG; 
   INT_S initG_bar, sizeG_bar;
   
   int vocCount = 0;
   int* vocList = getVocList(G_hat, sizeG_hat, &vocCount);
   
   int sizeT = 0;
   INT_T* T = getT(G, G_hat, sizeG, sizeG_hat, &sizeT);
   
   deltaTable* table = NULL;
   coset* quasiCong = NULL;
   
   highLowPair* pairList = NULL;
   int sizePairList;
   INT_BOOL markList[sizeG];
   INT_BOOL result = false;
   
   INT_T* eventList = NULL;
   int sizeEventList;
   int iterations = 0;
   
   while(result == false)
   {      
      sizeT = 0;
      T = getT(G, G_hat, sizeG, sizeG_hat, &sizeT);
        
      table = getDeltaTable(G_hat, sizeG_hat, T, sizeT, sizeT);  
      
      quasiCong = getQuasiCong(table, sizeG_hat); 
   
      pairList = getPairList( quasiCong, G_hat, sizeG_hat, initG_hat, 
                              &initG_bar, &sizeG_bar,
                              &sizePairList, markList, T, sizeT);                                                    
                              
      G_bar = getG_bar(pairList, sizePairList, sizeG_bar, markList); 
   
      result = isObserver(G_bar, sizeG_bar);
   
      if(result == true)
      {
         break;
      }
      else
      {    
         sizeEventList = 0;
         eventList = getEventList(eventList, &sizeEventList, G, sizeG);
         eventList = getEventList(eventList, &sizeEventList, G_hat, sizeG_hat);
         eventList = getEventList(eventList, &sizeEventList, G_bar, sizeG_bar);
   
         G_barPrime = relabelG_bar(G_bar, sizeG_bar, pairList, sizePairList, eventList, sizeEventList);                  
         G_hatPrime = relabelG_hat(G_hat, sizeG_hat, pairList, sizePairList);
         
         free(G_hat);
         G_hat = copyDES(G_hatPrime, sizeG_hat);
      }
      
      free(vocList); vocList = NULL;
      free(table); table = NULL;
      free(quasiCong); quasiCong = NULL;
      free(pairList); pairList = NULL;
      free(eventList); eventList = NULL;
      free(G_bar); G_bar = NULL;
      free(G_barPrime); G_barPrime = NULL;
      free(G_hatPrime); G_hatPrime = NULL;
      
      iterations++;
   }
   return G_hat;
}

INT_BOOL T_member(INT_T event, INT_T* T, int sizeT)
{
   int i;
   for(i = 0; i < sizeT; i++)
   {
      if(event == T[i])
         return true;
   }
   return false;
}

state_node* getMoore( state_node* G_obs, INT_S sizeG_obs, state_node* G, 
                      INT_S sizeG, INT_S initG_final, INT_S* sG_final)
{
   int i,j,k;
   state_node* G_final = copyDES(G, sizeG);
   INT_S sizeG_final = sizeG;
   
   //Get T, the set of high-level transition labels
   int sizeT = 0;
   INT_T* T = getT(G, G_obs, sizeG, sizeG_obs, &sizeT);
   
   //Create a list of all transitions in G_obs
   triple* tranList = NULL;
   int numTran = 0;
   for(i = 0; i < sizeG_obs; i++)
   {   
      for(j = 0; j < G_obs[i].numelts; j++)
      {
         numTran++;
         tranList = (triple*) realloc(tranList, numTran*(sizeof(triple)));
         tranList[numTran - 1].i = i; 
         tranList[numTran - 1].e = G_obs[i].next[j].data1;
         tranList[numTran - 1].j = G_obs[i].next[j].data2;
      }
   }
   
   //Fill out the array vocalizeState to identify which states in G_final should be vocalized
   int vocalizeState[sizeG_final];
   INT_T firstLabel;
   zeroArray(vocalizeState, sizeG_final);
   for(i = 0; i < sizeG_final; i++)
   {
      firstLabel = 0;
      //if all transitions into state i are high-level and of the same label then vocalize
      for(j = 0; j < numTran; j++)
      {
         if(tranList[j].j == i)
         {
            if(T_member(tranList[j].e, T, sizeT) == false) //if an event is low-level
            {
               vocalizeState[i] = 0;
               break;
            }
            else if(firstLabel == 0) //for the first high-level event
            {
               vocalizeState[i] = tranList[j].e;
               firstLabel = tranList[j].e;
            }   
            else if(tranList[j].e != firstLabel) //for each subsequent high-level event
            {
               vocalizeState[i] = 0;
               break;
            }
         }
      }
   }
   
   //At this point the array vocalizeState tells us which states in G should be 
   //immediately vocalized
   for(i = 0; i < sizeG_final; i++)
   {
      G_final[i].vocal = vocalizeState[i];
   }
   
   //Next step is to figure out which high-level transitions need a new entry 
   //state to be preserved
   INT_T event;
   INT_S target;
   for(i = 0; i < sizeG_obs; i++)
   {
      //for each transition in G_obs   
      for(j = 0; j < G_obs[i].numelts; j++) 
      {
         event = G_obs[i].next[j].data1;
         target = G_obs[i].next[j].data2;
         
         //if it is a high-level transition in need of a new entry state
         if(T_member(event, T, sizeT) == true && G_final[target].vocal == 0)
         {
            sizeG_final++;
            G_final = (state_node*) realloc(G_final, sizeG_final * sizeof(state_node));
            G_final[sizeG_final - 1].vocal = event;
            
            //The new entrance state should look identical to the target state in G_final
            G_final[sizeG_final - 1].marked = G_final[target].marked;
            G_final[sizeG_final - 1].reached = G_final[target].reached;
            G_final[sizeG_final - 1].coreach = G_final[target].coreach;
            G_final[sizeG_final - 1].numelts = G_final[target].numelts;
            G_final[sizeG_final - 1].next = (tran_node*) malloc(G_final[sizeG_final - 1].numelts * sizeof(tran_node));
            for(k = 0; k < G_final[sizeG_final - 1].numelts; k++) 
            {
               G_final[sizeG_final - 1].next[k] = G_final[target].next[k];
            }
            
            //Assign the transition to point to this new state
            G_final[i].next[j].data2 = sizeG_final - 1;
         }
      }
   }
   
   //if initial state is vocal, add an additional reentry state and
   //make its transition output structure and vocalization identical
   //to the initial state, then clear the vocalization of the initial state     
   if(G_final[initG_final].vocal != 0)
   {
      sizeG_final++;                           
      G_final = (state_node*) realloc(G_final, (sizeG_final)*sizeof(state_node));
      G_final[sizeG_final - 1].vocal = G_final[initG_final].vocal;
      G_final[initG_final].vocal = 0;
      G_final[sizeG_final - 1].marked = G_final[initG_final].marked;
      G_final[sizeG_final - 1].reached = G_final[initG_final].reached;
      G_final[sizeG_final - 1].coreach = G_final[initG_final].coreach;
      G_final[sizeG_final - 1].numelts = G_final[initG_final].numelts;
      G_final[sizeG_final - 1].next = (tran_node*) malloc(G_final[sizeG_final - 1].numelts * sizeof(tran_node));
         
      for(i = 0; i < G_final[initG_final].numelts; i++) {
         G_final[sizeG_final - 1].next[i] = G_final[initG_final].next[i];
      }
         
      for(i = 0; i < sizeG_final; i++) {
         for(j = 0; j < G_final[i].numelts; j++) {
            //if an exit transition has target state initG_final
            //the replace target state with G_final[sizeG_final - 1]
            if(G_final[i].next[j].data2 == initG_final) {
               G_final[i].next[j].data2 = sizeG_final - 1;
            }
         }
      }
   }
   
   //Get list of new (automatically generated) vocalizations
   INT_BOOL newEventFlag;
   
   printf("New state output events: ");
   for(i = 0; i < sizeT; i++)
   {
      newEventFlag = true;
      for(j = 0; j < sizeG; j++) {
         if(T[i] == G[j].vocal) {
            newEventFlag = false;
            break;   
         }
      }
      
      if(newEventFlag == true) {
         printf("%d ",T[i]);
      }
   }
   println();
   println();
              
   *sG_final = sizeG_final;
   return G_final;
}

INT_BOOL distinctHiLo(state_node* G, INT_S sizeG) {
   
   int sizeEventList = 0;
   int sizeVocList = 0;
   INT_T* eventList = NULL;
   int* vocList = NULL;
   
   eventList = getEventList(eventList, &sizeEventList, G, sizeG);
   vocList = getVocList(G, sizeG, &sizeVocList);
   
   int i,j;
   
   for(i = 0; i < sizeVocList; i++)
   {
      for(j = 0; j < sizeEventList; j++)
      {
         //If there is a common element between vocList and eventList
         if( vocList[i] == eventList[j] )
            return false;
      }
   }
   return true;
}

/******************************************************************************/
/*                           DEBUGGING FUNCTIONS                              */
/******************************************************************************/

//Print deltaTables to screen
void printDeltaTable(deltaTable* table, INT_S sizeG_hat) {
     
   deltaTable* curr = table;
   int i,j;
   
   while(curr != NULL)
   {    
        printf("Delta '%d' Table: \n", curr->tau);
        for(i=0; i<sizeG_hat; i++) {
             for(j = 0; j < sizeG_hat; j++) {
                   printf("%d ", curr->table[i][j]);
             }
             printf("\n");
        }
        printf("\n");
        curr = curr->next;
   }
   return;
}

//Print the members of quasiCong
void printQuasiCong(coset* quasiCong) {
   
   coset* quasiCong_curr;
   quasiCong_curr = quasiCong;
   int i,j;
   
   if(quasiCong_curr == NULL)
        printf("NULL\n");
        
   printf("members of quasiCong: ");
   for(i = 0; quasiCong_curr != NULL; i++) {
         printf("{ ");
         for(j = 0; quasiCong_curr->members[j] != -1; j++) {
               printf("%d ", quasiCong_curr->members[j]);
         }
         quasiCong_curr = quasiCong_curr->next;
         printf("} ");
   }
   printf("\n\n");   
   return;
}

//Print the contents of a pairList
void printPairList(highLowPair* pairList, int sizePairList) {
   
   int i; 
   printf("G_hat\t\tQuotient\n");   
   for(i = 0; i < sizePairList; i++) { 
      printf("[%d %d %d],\t[%d %d %d]\n", pairList[i].low.i, pairList[i].low.e, 
                                          pairList[i].low.j, pairList[i].high.i,
                                          pairList[i].high.e, pairList[i].high.j);
   }     
   return;
}

//Print the transition list of a DES
void printTranList(state_node* G, INT_S sizeG) {
     
   int i,j;   
   printf("TranList: ");
   for(i = 0; i < sizeG; i++) {
      for(j = 0; j < G[i].numelts; j++) {
         printf("[%d %d %d], ", i, G[i].next[j].data1, G[i].next[j].data2);
      }
   }
   printf("\n\n");  
   return;
}

/******************************************************************************/
/*                        OBSERVER FUNCTION EXECUTION                         */
/******************************************************************************/
     
//main function to run observer process
void observer() { 
   //get names of DES1 and DES2 into name1 and name2, respectively
   clear();
   printw("This function checks DES1 for the observer property."); println();
   println();
   
   //get filename for DES to be modified
   quit = getname("Enter name of DES1 to be checked ....  ", EXT_DES, name1, false);
   if (quit) return;
   
   //initialize auxiliary variables
   int i,j,k; //counter variables for loops
   
   //initialize structural variables
   state_node* G = NULL;   
   INT_S sizeG = 0; 
   INT_S initG = 0;
   
   //open DES1 file
   getdes(name1, &sizeG, &initG, &G);  
   
   INT_BOOL tempBool = distinctHiLo(G, sizeG);

   //check for distinct high and low level event sets
   if( tempBool == false)
   {
      printf("Error: vocal outputs not distinct from low-level event set");
      user_pause();
      return;
   }
   
   //check for a lack of vocal outputs
   int* tempVocList = NULL;
   int sizeTempVocList = 0;
   tempVocList = getVocList(G, sizeG, &sizeTempVocList);
   if(sizeTempVocList == 0)
   {
      printf("Error: DES has no vocal outputs");
      user_pause();
      return;
   }

   //check whether or not G satisfies the observer property
   INT_BOOL checkResult = checkObserver(G, sizeG, initG);
   
   //If G does satisfy the observer property, we're done
   if(checkResult == true)
   {
      printf("%s satisfies the observer property.", name1);
      println();
      println();
      
      FILE* out;
      
      /* Write to a tempory file */
      out = fopen("tmp.$$$", "w");
      if (out == NULL) return;
      fprintf(out, "TRUE = checkObserver(%s)", name1);
      fprintf(out, "\n\n");
      fclose(out);

      /* Merge file into MAKEIT.TXT */
      mergeChop(strlen(name2)+3);
      
   }
   else //If it does not satisfy the observer property, request modification
   {
      printf("%s does not satisfy the observer property.", name1);
      println();
      println();
      printw("Modify %s to obtain the observer property?   (*y/n)   ", name1);
      refresh();
      char ch = read_key();
      if (ch == CEsc) 
      {
         quit = true;
         return;
      }

      //If user decides to modify G
      if ( (ch != 'N') && (ch != 'n') ) 
      {
         if (ch != CEnter) 
         {
            printw("%c", ch);
         }
         println();
         println();
         
         //Get name of new DES to be constructed
         quit = getname("Enter name of new DES2 ...............  ", EXT_DES, name2, true);
         if (quit) return;
   
         //Modify G to satisfy the observer property
         state_node* G_obs = makeObserver(G, sizeG, initG);
         INT_S sizeG_obs = sizeG;
         INT_S initG_obs = initG;
   
         INT_S sizeG_final;
         INT_S initG_final = initG;   
         state_node* G_final = getMoore( G_obs, sizeG_obs, G, sizeG, initG_final, &sizeG_final);
         
         FILE* out;

         /* Write to a tempory file */
         out = fopen("tmp.$$$", "w");
         if (out == NULL) return;
         fprintf(out, "%s = makeObserver(%s)", name2, name1);
         fprintf(out, "  (%d,%ld)", sizeG_final, count_tran(G_final, sizeG_final));
         fprintf(out, "\n\n");
         fclose(out);

         /* Merge file into MAKEIT.TXT */
         mergeChop(strlen(name2)+3);
              
         //save new DES file
         filedes(name2, sizeG_final, initG_final, G_final);
      }
   }
   
   
   
   //process over
   user_pause();
    
   return;
}


/******************************************************************************/
/*                            HNB FUNCTION EXECUTION                          */
/******************************************************************************/

void HNB() {
   
   //Get a DES from file
   clear();
   printw("Check for HNB Generator"); println();
   println();
   //printw("DES2 = HNB(DES1)"); println();
   //println();
   
   //get filename for DES to be modified
   quit = getname("Enter name of DES1 to be checked ....  ", EXT_DES, name1, false);
   if (quit) return;
   
  //initialize auxiliary variables
   int i,j,k; //counter variables for loops
   
   //initialize structural variables
   state_node* G = NULL;   
   INT_S sizeG = 0; 
   INT_S initG = 0;
   
   //open DES1 file
   getdes(name1, &sizeG, &initG, &G);   
   
   //check for distinct high and low level event sets
   if(distinctHiLo(G, sizeG) == false)
   {
      printf("Error: vocal outputs not distinct from low-level event set");
      user_pause();
      return;
   }
   
   //check for a lack of vocal outputs
   int* tempVocList = NULL;
   int sizeTempVocList = 0;
   tempVocList = getVocList(G, sizeG, &sizeTempVocList);
   if(sizeTempVocList == 0)
   {
      printf("Error: DES has no vocal outputs");
      user_pause();
      return;
   }
   
   //create a copy of G for comparative purposes
   state_node* G_copy = copyDES(G, sizeG);
   INT_S sizeG_copy = sizeG;
   INT_S initG_copy = initG;
   
   //check whether or not G is SOCC
   INT_BOOL hccResult = false;
   
   //run hiconsis procedure on G_copy
   INT_BOOL errorNoMoreVocal;   
   errorNoMoreVocal = hiconsis_1_des(&G_copy, &sizeG_copy);

   //initialize parameters to pass into iso1 (isomorph) function
   INT_S* mapState = (INT_S*)calloc(sizeG, sizeof(INT_S));
   memset(mapState, -1, sizeof(INT_S)*(sizeG)); //puts a -1 in each block in mapState array
   mapState[0] = 0;
   INT_BOOL isoResult = true;
   
   iso1(sizeG, sizeG_copy, G, G_copy, &isoResult, mapState);
   
   if(isoResult == true) hccResult = true;
   
   //check whether or not G satisfies the observer property
   INT_BOOL observerResult = checkObserver(G, sizeG, initG);
   
   //If G is both HCC and satisfies the observer property, we're done
   if(observerResult == true && hccResult == true)
   {
      printf("%s is HNB.", name1);
      println();
      println();
      
      FILE* out;
      
      /* Write to a tempory file */
      out = fopen("tmp.$$$", "w");
      if (out == NULL) return;
      fprintf(out, "TRUE = hnbCheck(%s)", name1);
      fprintf(out, "\n\n");
      fclose(out);

      /* Merge file into MAKEIT.TXT */
      mergeChop(strlen(name2)+3);
   }
   else //If it does not satisfy the observer property, request modification
   {
      printf("%s is not HNB.", name1);
      println();
      println();
      printw("Modify %s to satisfy the HNB property?   (*y/n)   ", name1);
      refresh();
      char ch = read_key();
      if (ch == CEsc) 
      {
         quit = true;
         return;
      }

      //If user decides to modify G
      if ( (ch != 'N') && (ch != 'n') ) 
      {
         if (ch != CEnter) 
         {
            printw("%c", ch);
         }
         println();
         println();
         
         //Get name of new DES to be constructed
         quit = getname("Enter name of new DES2 ...............  ", EXT_DES, name2, true);
         if (quit) return;
   
         //Modify G to be HNB
         INT_BOOL successFlag = false;
         state_node* G_final = copyDES(G, sizeG); 
         INT_S sizeG_final = sizeG;
         INT_S initG_final = initG;
         
         while(successFlag == false) {
            if( checkObserver(G_final, sizeG_final, initG_final) == false )
            {
               G = G_final;
               sizeG = sizeG_final;
               G_final = makeObserver(G_final, sizeG_final, initG_final); 
               G_final = getMoore(G_final, sizeG_final, G, sizeG, initG_final, &sizeG_final);
            }
            errorNoMoreVocal = hiconsis_1_des(&G_final, &sizeG_final);
            successFlag = checkObserver(G_final, sizeG_final, initG_final);
         }  
         
         FILE* out;

         /* Write to a tempory file */
         out = fopen("tmp.$$$", "w");
         if (out == NULL) return;
         fprintf(out, "%s = makeHNB(%s)", name2, name1);
         fprintf(out, "  (%d,%ld)", sizeG_final, count_tran(G_final, sizeG_final));
         fprintf(out, "\n\n");
         fclose(out);

         /* Merge file into MAKEIT.TXT */
         mergeChop(strlen(name2)+3);
         
         //save new DES file
         filedes(name2, sizeG_final, initG_final, G_final);         
      }
   }  
   //process over
   user_pause();
    
   return;
}
