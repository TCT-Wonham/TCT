#ifndef _BOWIE_H
#define _BOWIE_H

#include "des_data.h"

#ifdef __cplusplus
extern "C" {
#endif

//Data Structures

typedef struct deltaTable {
       INT_T tau;
       INT_BOOL m;
       int** table;
       struct deltaTable* next;
} deltaTable;
       
//a 'set' represents a set of states
//set* is a pointer to an array of integers, each representing a state
//the list is terminated with a -1
typedef int set;

typedef struct coset {
        set* members;
        struct coset* next;
} coset;

typedef struct highLowPair {
   triple low; //A triple is a transition table element with elements [i e j]
   triple high;
} highLowPair;

//Make a copy of a DES
extern state_node* copyDES(state_node*, INT_S);

//get or append to a list of events from an automaton 
extern INT_T* getEventList(INT_T* , int* , state_node* , INT_S );

//get list of vocal event outputs from G_hat
extern int* getVocList(state_node* , INT_S , int* );

//set each element in an array to be 0
extern void zeroArray(int* , int );

//check if two members elements of a coset are equal
extern INT_BOOL equalMembers(set* , set* , INT_S );

//replace entrance transitions with vocal output as new event label
extern state_node* getG_hat(INT_S , state_node*);

//look for next set of downstream silent transitions from state q
//used to fill out a deltaTauTableRow
extern void findNextSilent(INT_S , state_node*, int*, INT_T*, int, int*);

//look for next set of downstream output transitions from state q
//used to fill out a deltaTauTableRow
extern void findNextTau(INT_S, state_node*, int*, INT_T, INT_T*, int, int*, int*);

//locate next state in deltaM(q) set
extern void findNextM(INT_S, state_node*, int*, INT_T*, int, int*);

//Returns a row for the deltaTauTable used in the Fernandez algorithm        
extern int* deltaTauTableRow(INT_S , state_node *, INT_S , INT_T, INT_T*, int); 

//Returns a row for the deltaMTable used in the Fernandez algorithm
extern int* deltaMTableRow(INT_S , state_node *, INT_S, INT_T*, int);

//get a delta-tau table
extern int** deltaTauTable(state_node* , INT_S , INT_T, INT_T*, int);

//get a delta-m (as in marked state) table
extern int** deltaMTable(state_node*, INT_S, INT_T*, int );

//get a linked list of deltaTables covering all tau's and m
extern deltaTable* getDeltaTable(state_node* , INT_S , INT_T* , int, int );

//compute the phi function for a state q
extern int* phiQ(INT_S , int** , INT_S );

//compute the phi function for a set, B, of states
extern int* phiB(set* , int** , INT_S );

//Compute the set I_tau,B 
extern coset* getI(coset* , set* , int** , INT_S );

//Compute the set I_tau,B^1,2 from I_tau,B 
extern coset* getI12(coset* , set* , int** , INT_S );
        
//Calculate and create the set nextRoh = {roh - I}U{I_12}
extern coset* getNextRoh(coset* , coset* , coset* , INT_S );

//Calculate and create the set nextW = {W - I}U{I_12}
extern coset* getNextW(coset* , coset* , coset* , INT_S );
  
//Implementation of the Fernandez algorithm to compute coarsest right congruence
extern coset* getQuasiCong(deltaTable* , INT_S );

//Return transition structure for quotient if transition leaves the coset or is a tau-transition
extern tran_node* getQuotTran( INT_S , tran_node , set** , 
                               INT_T* , int );

//Get the quotient transition list for G_hat/G_bar w.r.t. the partition roh (quasi-cong)
extern highLowPair* getPairList( coset* , state_node* , INT_S , 
                                 INT_S , INT_S* , 
                                 INT_S* , int* , 
                                 INT_BOOL*, INT_T*, int);

extern state_node* getG_bar( highLowPair* , int , INT_S , INT_BOOL* );

//Relabeling algorithm for when G_bar is not an observer
//first get G_barPrime
extern state_node* relabelG_bar( state_node* , INT_S , 
                                 highLowPair* , int ,
                                 INT_T* , int );

//Relabel G_hat transitions in accordance with pairList, as modified in relabG_bar
extern state_node* relabelG_hat(state_node* , INT_S , 
                       highLowPair* , int );

//Check if quotient, G_bar, is deterministic and contains no tau_not transitions
extern INT_BOOL isObserver(state_node* , INT_S );

//Check if G has the observer property
extern INT_BOOL checkObserver(state_node* , INT_S , INT_S );

//Modify G so that it has the observer property
extern state_node* makeObserver(state_node* , INT_S , INT_S );

//Print deltaTables to screen
extern void printDeltaTable(deltaTable* , INT_S );

//Print the members of quasiCong
extern void printQuasiCong(coset* );

//Print the contents of a pairList
extern void printPairList(highLowPair* , int );

//Print all transition triples of a DES to the screen
extern void printTranList(state_node* , INT_S );
     
//main function to run observer process
extern void observer();

//main function to run HNB detector
extern void HNB();

#ifdef __cplusplus
}
#endif

#endif
