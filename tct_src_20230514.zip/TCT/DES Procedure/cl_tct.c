#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <stdarg.h>
#include <direct.h>
#include "cl_tct.h"
#include "tct_io.h"
#include <sys/stat.h>
#include <fcntl.h>
#include "curses.h"
#include "supred.h"
#include "ex_supred.h"
#include "higen.h"
#include "outcon.h"
#include "hicons.h"
#include "cnorm.h"
#include "canqc.h"
#include "obs_check.h"
#include "localize.h"
#include "mymalloc.h"
#include "des_proc.h"
#include "des_convert.h"
#include "tct_proc.h"

#include <io.h>

#ifdef __cplusplus
extern "C" {
#endif

#define STDOUT 1
#define STDERR 2

static INT_OS h_out, h_outbak;
static INT_OS h_err, h_errbak;

char prm_file[256];
char rst_file[256];
char errname[256];
char outname[256];
const char ctct_prm[] = "ctct.prm";
const char ctct_rst[] = "ctct.rst";
const char ctct_err[] = "ctct.err";
const char ctct_out[] = "ctct.out";

char *get_prm_file()
{
    strcpy(prm_file, prefix);
    strcat(prm_file, ctct_prm);
    return prm_file; 
}

char *get_rst_file()
{
    strcpy(rst_file, prefix);
    strcat(rst_file, ctct_rst);
    return rst_file;
}

char *get_err_file()
{
    strcpy(errname, prefix);
    strcat(errname, ctct_err);
    return errname;
}

char *get_out_file()
{
    strcpy(outname, prefix);
    strcat(outname, ctct_out);
    return outname;
}

char *open_stderr(void)
{
#ifdef O_BINARY
  h_err = _open(get_err_file(), O_WRONLY | O_BINARY | O_CREAT | O_TRUNC,
               S_IREAD | S_IWRITE);
#else
  h_err = open(get_err_file(), O_WRONLY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
#endif
  h_errbak = _dup(STDERR);
  fflush(stderr);               /*
                                   so any buffered chars will be written out
                                 */
  _dup2(h_err, STDERR);
  return errname;
}

void close_stderr(void)
{
   _dup2(h_errbak, STDERR);
   _close(h_err);
   _close(h_errbak);
   remove(get_err_file());
}

char *open_stdout(void)
{
#ifdef O_BINARY
   h_out = _open(get_out_file(), O_WRONLY | O_BINARY | O_CREAT | O_TRUNC, 
                S_IREAD | S_IWRITE);
#else
   h_out = open(get_out_file(), O_WRONLY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
#endif
   h_outbak = _dup(STDOUT);
   fflush(stdout);
     
   _dup2(h_out, STDOUT);
   return outname;
}    

void close_stdout(void)
{
   _dup2(h_outbak, STDOUT);
   _close(h_out);
   _close(h_outbak);
   remove(get_out_file());  
}
INT_OS ctct_result(INT_OS result)
{
	FILE *out;

	out = fopen(get_rst_file(), "w");

	if (out == NULL) 
		return -1;       /* Can do not much here so just return */
	fprintf(out, "%d\n", result);

	fclose(out);
	return 0;
}
INT_OS get_ctct_result()
{
	FILE *in;
	INT_OS result, flag;

	result = 0;

	if (_access(get_rst_file(), 0) == 0)
	{
		/* Results file was generated */
		in = fopen(get_rst_file(), "r");

		if (in == NULL) 
		{
			result = -5; /* File present but can not open */
		} 
		else
		{
			flag = fscanf(in, "%d", &result);
			if ((flag == 0) || (flag == EOF))
			{
				/* File created without content */
				result = -4;
			}
		}
		fclose(in);

		/* Clean-up for next time */
		remove(get_rst_file());        
	}
	else
	{
		result = -3;  /* No file generated -- failed to do operation */
	}
	return result;
}

INT_OS mySystem()
{
    char runParm[256];
    INT_OS result;
    
    sprintf(runParm, "\"%s\" -cmdline", argv0);
    
    if (debug_mode == 0)
    {      
       open_stdout();
       open_stderr();
    }
    
    result = system(runParm);

    if (debug_mode == 0)
    {
       close_stdout();
       close_stderr();
    }
    
    if (result != 0)
       return -2;  /* Some type of system error */
         
    return get_ctct_result();
}



//////////////////////////////////////////////////////////////////////////////

INT_OS selfloop_runProgram(char *name2, char *name1, INT_T slist, INT_T* list)
{
    FILE *f1;
    INT_T i;
    
    f1 = fopen(get_prm_file(), "w");
    if (f1 == NULL)
       return -1;  /* Some type of system error */

    fprintf(f1, "%d\n", debug_mode); /* Debug mode */    
    fprintf(f1, "%d\n", minflag);
    fprintf(f1, "1\n");  /* Selfloop */
    fprintf(f1, "%s\n", name1);
    fprintf(f1, "%s\n", name2);
    for (i=0; i < slist; i++)
       fprintf(f1, "%d\n", list[i]);
    fclose(f1);

//	cmdline_tct_run();
    
    return mySystem();
}

INT_OS trim_runProgram(char *name2, char *name1)
{
    FILE *f1;
    
    f1 = fopen(get_prm_file(), "w");
    if (f1 == NULL)
       return -1;   /* Some type of system error */
   
    fprintf(f1, "%d\n", debug_mode); /* Debug mode */       
    fprintf(f1, "%d\n", minflag);    
    fprintf(f1, "2\n");  /* Trim */
    fprintf(f1, "%s\n", name1);
    fprintf(f1, "%s\n", name2);
    fclose(f1);

//	cmdline_tct_run();

    return mySystem();
}

INT_OS synck_runProgram(char *name3, INT_OS num_component, char (*names1)[MAX_FILENAME])
{
	FILE *f1;
	INT_S i;

	f1 = fopen(get_prm_file(), "w");
	if (f1 == NULL)
		return -1;   /* Some type of system error */

	fprintf(f1, "%d\n", debug_mode); /* Debug mode */      
	fprintf(f1, "%d\n", minflag);
	fprintf(f1, "3\n");  /* SYNC */
	fprintf(f1, "%s\n", name3);
	fprintf(f1, "%d\n", num_component);
	for(i = 0; i < num_component; i ++){
		fprintf(f1, "%s\n", names1[i]);
	}
	fclose(f1);

	//cmdline_tct_run();

	return mySystem();
}

INT_OS meetk_runProgram(char *name3, INT_OS num_component, char (*names1)[MAX_FILENAME])
{
	FILE *f1;
	INT_S i;

	f1 = fopen(get_prm_file(), "w");
	if (f1 == NULL)
		return -1;   /* Some type of system error */

	fprintf(f1, "%d\n", debug_mode); /* Debug mode */      
	fprintf(f1, "%d\n", minflag);
	fprintf(f1, "4\n");  /* MEET */
	fprintf(f1, "%s\n", name3);
	fprintf(f1, "%d\n", num_component);
	for(i = 0; i < num_component; i ++){
		fprintf(f1, "%s\n", names1[i]);
	}
	fclose(f1);

//	cmdline_tct_run();
	return mySystem();
}

INT_OS supcon_runProgram(char *name3, char *name1, char *name2)
{
    FILE *f1;

    f1 = fopen(get_prm_file(), "w");
    if (f1 == NULL)
       return -1;  /* Some type of system error */

    fprintf(f1, "%d\n", debug_mode); /* Debug mode */          
    fprintf(f1, "%d\n", minflag);
    fprintf(f1, "5\n");  /* SUPCON */
    fprintf(f1, "%s\n", name1);
    fprintf(f1, "%s\n", name2);
    fprintf(f1, "%s\n", name3);
    fclose(f1);
    
	//cmdline_tct_run();
	return mySystem();
}

INT_OS mutex_runProgram(char *name3, char *name1, char *name2, 
                     state_pair *sp, INT_S s_sp)
{
    FILE *f1;
    INT_S i;
    
    f1 = fopen(get_prm_file(), "w");
    if (f1 == NULL)
       return -1; 

    fprintf(f1, "%d\n", debug_mode); /* Debug mode */          
    fprintf(f1, "%d\n", minflag);
    fprintf(f1, "6\n");  /* MUTEX */
    fprintf(f1, "%s\n", name1);
    fprintf(f1, "%s\n", name2);
    fprintf(f1, "%s\n", name3);
    for (i=0; i < s_sp; i++)
        fprintf(f1, "%ld %ld\n", sp[i].data1, sp[i].data2);    
    fclose(f1);

   // cmdline_tct_run();
    return mySystem();
}

INT_OS condat_runProgram(char *name3, char *name1, char *name2)
{
    FILE *f1;

    f1 = fopen(get_prm_file(), "w");
    if (f1 == NULL)
       return -1;

    fprintf(f1, "%d\n", debug_mode); /* Debug mode */          
    fprintf(f1, "%d\n", minflag);
    fprintf(f1, "7\n");  /* CONDAT */
    fprintf(f1, "%s\n", name1);
    fprintf(f1, "%s\n", name2);
    fprintf(f1, "%s\n", name3);
    fclose(f1);
//    cmdline_tct_run();
    return mySystem();
}

INT_OS get_ctct_result_supreduce(INT_S *lb, float *cr)
{
	FILE *in;
	INT_OS result, flag;

	result = 0;

	if (_access(get_rst_file(), 0) == 0)
	{
		/* Results file was generated */
		in = fopen(get_rst_file(), "r");

		if (in == NULL) 
		{
			result = -5; /* File present but can not open */
		} 
		else
		{
			flag = fscanf(in, "%d", &result);
			if ((flag == 0) || (flag == EOF))
			{
				/* File created without content */
				result = -4;
			}

			fscanf(in, "%ld", lb);
			fscanf(in, "%f", cr);
		}
		fclose(in);

		/* Clean-up for next time */
		remove(get_rst_file());        
	}
	else
	{
		result = -3;  /* No file generated -- failed to do operation */
	}
	return result;
}
INT_OS mySystem_supreduce(INT_S *lb, float *cr)
{
	char runParm[256];
	INT_OS result;

	sprintf(runParm, "\"%s\" -cmdline", argv0);

	if (debug_mode == 0)
	{      
		open_stdout();
		open_stderr();
	}    

	result = system(runParm);

	if (debug_mode == 0)
	{
		close_stdout();
		close_stderr();
	}

	if (result != 0)
		return -2;

	return get_ctct_result_supreduce(lb, cr);
}

INT_OS supreduce_runProgram(char *name4, char *name1, char *name2, char *name3, INT_OS mode,
                         INT_S *lb, float *cr, INT_B slb_flag)
{
    FILE *f1;

    f1 = fopen(get_prm_file(), "w");
    if (f1 == NULL) 
       return -1;
    
    fprintf(f1, "%d\n", debug_mode); /* Debug mode */          
    fprintf(f1, "%d\n", minflag);
    fprintf(f1, "8\n");  /* SUPREDUCE */
    fprintf(f1, "%s\n", name1);
    fprintf(f1, "%s\n", name2);
    fprintf(f1, "%s\n", name3);
    fprintf(f1, "%s\n", name4);
	fprintf(f1, "%d\n", mode);
	fprintf(f1, "%d\n", slb_flag);
    fclose(f1);

//	cmdline_tct_run();
    
    return mySystem_supreduce(lb, cr);
}

INT_OS minstate_runProgram(char *name2, char *name1) 
{
    FILE *f1;
    f1 = fopen(get_prm_file(), "w");
    if (f1 == NULL) 
       return -1;
    
    fprintf(f1, "%d\n", debug_mode); /* Debug mode */      
    fprintf(f1, "%d\n", minflag);
    fprintf(f1, "9\n");  /* MINSTATE */
    fprintf(f1, "%s\n", name1);
    fprintf(f1, "%s\n", name2);
    fclose(f1);

//	cmdline_tct_run();


	return mySystem();
}

INT_OS complement_runProgram(char *name2, char *name1, INT_T *list, INT_T slist)
{
    FILE *f1;
    INT_T i;
    
    f1 = fopen(get_prm_file(), "w");
    if (f1 == NULL)
       return -1;

    fprintf(f1, "%d\n", debug_mode); /* Debug mode */          
    fprintf(f1, "%d\n", minflag);
    fprintf(f1, "10\n");  /* COMPLEMENT */
    fprintf(f1, "%s\n", name1);
    fprintf(f1, "%s\n", name2);
    for (i=0; i < slist; i++) 
       fprintf(f1, "%d\n", list[i]);
    fclose(f1);
    
//	cmdline_tct_run();
    return mySystem();
}

INT_OS localize_runProgram(INT_S sfile, INT_S sloc,
	char * name1, char * name2,
	char (*names1)[MAX_FILENAME], char (*names2)[MAX_FILENAME])
{                     
	FILE *f1;
	INT_T i;

	f1 = fopen(get_prm_file(), "w");
	if (f1 == NULL)
		return -1;

	fprintf(f1, "%d\n", debug_mode);  /* Debug mode */
	fprintf(f1, "%d\n", minflag);
	fprintf(f1, "28\n");    /* localize */
	fprintf(f1, "%s\n", name1);
	fprintf(f1, "%s\n", name2);
	fprintf(f1, "%d\n", sfile);
	for(i = 0; i < sfile; i ++)
		fprintf(f1, "%s\n", names1[i]);
	fprintf(f1, "%d\n", sloc);
	for(i = 0; i < sloc; i ++)
		fprintf(f1, "%s\n", names2[i]);

	fclose(f1);

	return mySystem();   
}
INT_OS force_runProgram(char *name1, char *name2, INT_T s_force_event_list, INT_T *force_event_list,
	INT_T s_preempt_event_list, INT_T *preempt_event_list, INT_T timeout_event)
{                     
	FILE *f1;
	INT_T i;

	f1 = fopen(get_prm_file(), "w");
	if (f1 == NULL)
		return -1;

	fprintf(f1, "%d\n", debug_mode);  /* Debug mode */
	fprintf(f1, "%d\n", minflag);
	fprintf(f1, "12\n");    /* force */
	fprintf(f1, "%s\n", name1);
	fprintf(f1, "%s\n", name2);
	fprintf(f1, "%d\n", timeout_event);
	for (i=0; i < s_force_event_list; i++)
		fprintf(f1, "%d\n", force_event_list[i]);
	fprintf(f1, "-1\n");
	for (i=0; i < s_preempt_event_list; i++)
		fprintf(f1, "%d\n", preempt_event_list[i]);
	fclose(f1);  

//	cmdline_tct_run();
	return mySystem();
}

INT_OS project_runProgram(char *name2, char *name1, INT_T *list, INT_T slist)
{
    FILE *f1;
    INT_T i;
    
    f1 = fopen(get_prm_file(), "w");
    if (f1 == NULL)
       return -1;
    
    fprintf(f1, "%d\n", debug_mode); /* Debug mode */      
    fprintf(f1, "%d\n", minflag);
    fprintf(f1, "13\n");  /* PROJECT */
    fprintf(f1, "%s\n", name1);
    fprintf(f1, "%s\n", name2);
    for (i=0; i < slist; i++) 
       fprintf(f1, "%d\n", list[i]);
    fclose(f1);
    
	//cmdline_tct_run();
    return mySystem();
}

INT_OS convert_runProgram(char *name2, char *name1, state_pair *sp, INT_S s_sp) 
{
    FILE *f1;
    INT_S i;
    
    f1 = fopen(get_prm_file(), "w");
    if (f1 == NULL)
       return -1;

    fprintf(f1, "%d\n", debug_mode); /* Debug mode */          
    fprintf(f1, "%d\n", minflag);
    fprintf(f1, "14\n");  /* CONVERT */
    fprintf(f1, "%s\n", name1);
    fprintf(f1, "%s\n", name2);
    for (i=0; i < s_sp; i++) 
       fprintf(f1, "%ld %ld\n", sp[i].data1, sp[i].data2);
    fclose(f1);

//	cmdline_tct_run();
    

	return mySystem();
}

INT_OS vocalize_runProgram(char *name2, char *name1, quad__t *list, INT_S slist)
{
    FILE *f1;
    INT_S i;
    
    f1 = fopen(get_prm_file(), "w");
    if (f1 == NULL) 
       return -1;
    
    fprintf(f1, "%d\n", debug_mode); /* Debug mode */      
    fprintf(f1, "%d\n", minflag);
    fprintf(f1, "15\n");  /* VOCALIZE */
    fprintf(f1, "%s\n", name1);
    fprintf(f1, "%s\n", name2);
    for (i=0; i < slist; i++) 
       fprintf(f1, "%ld %d %ld %d\n", list[i].a, list[i].b, list[i].c, list[i].d);
    fclose(f1);

//	cmdline_tct_run();
    return mySystem();
}

INT_OS outconsis_runProgram(char *name2, char *name1)
{
    FILE *f1;

    f1 = fopen(get_prm_file(), "w");
    if (f1 == NULL)
       return -1;

    fprintf(f1, "%d\n", debug_mode); /* Debug mode */          
    fprintf(f1, "%d\n", minflag);
    fprintf(f1, "16\n");  /* OUTCONSIS */
    fprintf(f1, "%s\n", name1);
    fprintf(f1, "%s\n", name2);
    fclose(f1);
    
//	cmdline_tct_run();
    return mySystem();
}

INT_OS hiconsis_runProgram(char *name2, char *name1, INT_B oldconsis_flag)
{
    FILE *f1;

    f1 = fopen(get_prm_file(), "w");
    if (f1 == NULL) 
       return -1;

    fprintf(f1, "%d\n", debug_mode); /* Debug mode */          
    fprintf(f1, "%d\n", minflag);
    fprintf(f1, "17\n");  /* HICONSIS */
    fprintf(f1, "%s\n", name1);
    fprintf(f1, "%s\n", name2);
	fprintf(f1, "%d\n", oldconsis_flag);
    fclose(f1);
  
//	cmdline_tct_run();
    return mySystem();
}

INT_OS higen_runProgram(char *name2, char *name1)
{
    FILE *f1;

    f1 = fopen(get_prm_file(), "w");
    if (f1 == NULL) 
       return -1;

    fprintf(f1, "%d\n", debug_mode); /* Debug mode */          
    fprintf(f1, "%d\n", minflag);
    fprintf(f1, "18\n");  /* HIGEN */
    fprintf(f1, "%s\n", name1);
    fprintf(f1, "%s\n", name2);
    fclose(f1);
    
//	cmdline_tct_run();
    return mySystem();
}

INT_OS allevent_runProgram(char *name2, char *name1, INT_OS entry_type, INT_T s_list, INT_T * list)
{
    FILE *f1;
	INT_T i;

    f1 = fopen(get_prm_file(), "w");
    if (f1 == NULL)
       return -1;

    fprintf(f1, "%d\n", debug_mode); /* Debug mode */          
    fprintf(f1, "%d\n", minflag);
    fprintf(f1, "19\n");  /* ALLEVENTS */
    fprintf(f1, "%s\n", name1);
    fprintf(f1, "%s\n", name2);
	fprintf(f1, "%d\n", entry_type);
	for (i=0; i < s_list; i++)
		fprintf(f1, "%d\n", list[i]);
    fclose(f1);
    
//	cmdline_tct_run();
    return mySystem();
}

INT_OS supnorm_runProgram(char *name3, char *name1, char *name2, 
                       INT_T *list, INT_T slist)
{
    FILE *f1;
    INT_T i;
    
    f1 = fopen(get_prm_file(), "w");
    if (f1 == NULL)
       return -1;

    fprintf(f1, "%d\n", debug_mode); /* Debug mode */          
    fprintf(f1, "%d\n", minflag);
    fprintf(f1, "20\n");  /* SUPNORM */
    fprintf(f1, "%s\n", name1);
    fprintf(f1, "%s\n", name2);
    fprintf(f1, "%s\n", name3);
    for (i=0; i < slist; i++)
       fprintf(f1, "%d\n", list[i]);
    fclose(f1);
    
//	cmdline_tct_run();
    return mySystem();
}

INT_OS supscop_runProgram(char *name3, char *name1, char *name2, 
	INT_T *list, INT_T slist)
{
	FILE *f1;
	INT_T i;

	f1 = fopen(get_prm_file(), "w");
	if (f1 == NULL)
		return -1;

	fprintf(f1, "%d\n", debug_mode); /* Debug mode */          
	fprintf(f1, "%d\n", minflag);
	fprintf(f1, "21\n");  /* SUPSCOP */
	fprintf(f1, "%s\n", name1);
	fprintf(f1, "%s\n", name2);
	fprintf(f1, "%s\n", name3);
	for (i=0; i < slist; i++)
		fprintf(f1, "%d\n", list[i]);
	fclose(f1);

//	cmdline_tct_run();
	return mySystem();
} 

INT_OS supconrobs_runProgram(char *name3,char *name1, char *name2, INT_T slist, INT_T *list)
{                     
	FILE *f1;
	INT_T i;

	f1 = fopen(get_prm_file(), "w");
	if (f1 == NULL)
		return -1;

	fprintf(f1, "%d\n", debug_mode);  /* Debug mode */
	fprintf(f1, "%d\n", minflag);
	fprintf(f1, "22\n");    /* supconrobs */
	fprintf(f1, "%s\n", name1);
	fprintf(f1, "%s\n", name2);
	fprintf(f1, "%s\n", name3);
	for (i=0; i < slist; i++)
		fprintf(f1, "%d\n", list[i]);
	fclose(f1);   

//	cmdline_tct_run();
	return mySystem();
}

INT_OS get_ctct_result_canQC(INT_S *s_statemap, INT_S **statemap)
{
	FILE *in;
	INT_OS result, flag;
	INT_OS state;

	result = 0;

	if (_access(get_rst_file(), 0) == 0)
	{
		/* Results file was generated */
		in = fopen(get_rst_file(), "r");

		if (in == NULL) 
		{
			result = -5; /* File present but can not open */
		} 
		else
		{
			flag = fscanf(in, "%d", &result);
			if ((flag == 0) || (flag == EOF))
			{
				/* File created without content */
				result = -4;
			}

			/* Read the content of statemap */
			while( fscanf(in, "%d", &state) != EOF )
			{
				*statemap = (INT_S*) REALLOC( *statemap, (*s_statemap+1)*sizeof(INT_S) );
				(*statemap)[*s_statemap] = state;
				(*s_statemap)++;
			}               

		}
		fclose(in);

		/* Clean-up for next time */
		remove(get_rst_file());        
	}
	else
	{
		result = -3;  /* No file generated -- failed to do operation */
	}
	return result;    
}    

INT_OS mySystem_canQC(INT_S *s_statemap, INT_S **statemap)
{
	char runParm[256];
	INT_OS result;

	sprintf(runParm, "\"%s\" -cmdline", argv0);

	if (debug_mode == 0)
	{      
		open_stdout();
		open_stderr();
	}    

	result = system(runParm);

	if (debug_mode == 0)
	{
		close_stdout();
		close_stderr();
	}

	if (result != 0)
		return -2;

	return get_ctct_result_canQC(s_statemap, statemap);    
}    

INT_OS CanQC_runProgram(char *name2, char *name1,INT_T s_nulllist, INT_T *nulllist, INT_S *s_statemap, INT_S **statemap, INT_OS mode)
{                     
    FILE *f1;
    INT_T i;
    
    f1 = fopen(get_prm_file(), "w");
    if (f1 == NULL)
       return -1;
       
    fprintf(f1, "%d\n", debug_mode);  /* Debug mode */
    fprintf(f1, "%d\n", minflag);
    fprintf(f1, "23\n");    /* CanQC */
    fprintf(f1, "%d\n", mode);
    fprintf(f1, "%s\n", name1);
    fprintf(f1, "%s\n", name2);
    for (i=0; i < s_nulllist; i++)
       fprintf(f1, "%d\n", nulllist[i]);
    fclose(f1);   

//	cmdline_tct_run();
       
    return mySystem_canQC(s_statemap, statemap);   
}

INT_OS get_ctct_result_isomorph(INT_B *is_iso, INT_B *identity, INT_S *s_mapState, INT_S **mapState)
{
	FILE *in;
	INT_OS result, cur;

	result = 0;

	if (_access(get_rst_file(), 0) == 0)
	{
		/* Results file was generated */
		in = fopen(get_rst_file(), "r");

		if (in == NULL) 
		{
			result = -5; /* File present but can not open */
		} 
		else
		{
			fscanf(in, "%d", &result);
			fscanf(in, "%d", &cur);  *is_iso = cur;
			fscanf(in, "%d", &cur);  *identity = cur;
			
			/* Read the content of statemap */
			while( fscanf(in, "%d", &cur) != EOF )
			{
				*mapState = (INT_S*) REALLOC( *mapState, (*s_mapState + 1) * sizeof(INT_S) );
				(*mapState)[*s_mapState] = cur;
				(*s_mapState)++;
			}               

		}
		fclose(in);

		/* Clean-up for next time */
		remove(get_rst_file());        
	}
	else
	{
		result = -3;  /* No file generated -- failed to do operation */
	}
	return result;    
} 
INT_OS mySystem_isomorph(INT_B *is_iso, INT_B *identity, INT_S *s_mapState, INT_S **mapState)
{
	char runParm[256];
	INT_OS result;

	sprintf(runParm, "\"%s\" -cmdline", argv0);

	if (debug_mode == 0)
	{      
		open_stdout();
		open_stderr();
	}    

	result = system(runParm);

	if (debug_mode == 0)
	{
		close_stdout();
		close_stderr();
	}

	if (result != 0)
		return -2;

	return get_ctct_result_isomorph(is_iso, identity, s_mapState, mapState);    
} 
INT_OS isomorph_runProgram(char *name1, char *name2, INT_B *is_iso, INT_B *identity, INT_S *s_mapState, INT_S **mapState)
{                     
	FILE *f1;

	f1 = fopen(get_prm_file(), "w");
	if (f1 == NULL)
		return -1;

	fprintf(f1, "%d\n", debug_mode);  /* Debug mode */
	fprintf(f1, "%d\n", minflag);
	fprintf(f1, "24\n");    /* isomorph */
	fprintf(f1, "%s\n", name1);
	fprintf(f1, "%s\n", name2);
	fclose(f1);   
	
//	cmdline_tct_run();
	return mySystem_isomorph(is_iso, identity, s_mapState, mapState);   
}
INT_OS get_ctct_result_nonconflict(INT_B *is_nonconflict)
{
	FILE *in;
	INT_OS result, cur;

	result = 0;

	if (_access(get_rst_file(), 0) == 0)
	{
		/* Results file was generated */
		in = fopen(get_rst_file(), "r");

		if (in == NULL) 
		{
			result = -5; /* File present but can not open */
		} 
		else
		{
			fscanf(in, "%d", &result);
			fscanf(in, "%d", &cur);  *is_nonconflict = cur;           

		}
		fclose(in);

		/* Clean-up for next time */
		remove(get_rst_file());        
	}
	else
	{
		result = -3;  /* No file generated -- failed to do operation */
	}
	return result;    
} 
INT_OS mySystem_nonconflict(INT_B *is_nonconflict)
{
	char runParm[256];
	INT_OS result;

	sprintf(runParm, "\"%s\" -cmdline", argv0);

	if (debug_mode == 0)
	{      
		open_stdout();
		open_stderr();
	}    

	result = system(runParm);

	if (debug_mode == 0)
	{
		close_stdout();
		close_stderr();
	}

	if (result != 0)
		return -2;

	return get_ctct_result_nonconflict(is_nonconflict);    
} 
INT_OS nonconflict_runProgram(char *name1, char *name2, INT_B *is_nonconflict)
{                     
	FILE *f1;

	f1 = fopen(get_prm_file(), "w");
	if (f1 == NULL)
		return -1;

	fprintf(f1, "%d\n", debug_mode);  /* Debug mode */
	fprintf(f1, "%d\n", minflag);
	fprintf(f1, "25\n");    /* nonconflict */
	fprintf(f1, "%s\n", name1);
	fprintf(f1, "%s\n", name2);
	fclose(f1);   

//	cmdline_tct_run();
	return mySystem_nonconflict(is_nonconflict);   
}
INT_OS get_ctct_result_obs(INT_S *s, state_node **t, INT_B  *is_observable)
{
    FILE *in;
    INT_OS result, flag;
    INT_S init;
    char tempname[MAX_PATH];
    char long_tempname[MAX_PATH];
	int ee;

    result = 0;
    strcpy(tempname,"");
    init = 0;

    if (_access(get_rst_file(), 0) == 0)
    {
        /* Results file was generated */
        in = fopen(get_rst_file(), "r");
        
        if (in == NULL) 
        {
           result = -5; /* File present but can not open */
        } 
        else
        {
           flag = fscanf(in, "%d\n", &result);
           if ((flag == 0) || (flag == EOF))
           {
              /* File created without content */
              result = -4;
           }
           
           /* Read the content  */
           fscanf(in, "%d\n", &ee);
		   *is_observable = (INT_B)ee;
        
           if (fgets(tempname, MAX_FILENAME, in) == NULL)
           {
               ctct_result(CR_PRM_ERR);
               exit(0);
           }           
           tempname[strlen(tempname)-1] = '\0';
           strcpy(long_tempname,"");
           make_filename_ext(long_tempname,tempname,EXT_DES);
           if(exist(long_tempname)){
               if(getdes(tempname,s, &init,t) == false){
				   result = -1;
			   }
               remove(long_tempname);  
           } else
              result = -1;           
        }
        fclose(in);
        
        /* Clean-up for next time */
        remove(get_rst_file());        
    }
    else
    {
        result = -3;  /* No file generated -- failed to do operation */
    }

    return result;    
}
INT_OS mySystem_obs(INT_S *s, state_node **t, INT_B  *is_observable)
{
    char runParm[256];
    INT_OS result;
    
    sprintf(runParm, "\"%s\" -cmdline", argv0);
    
    if (debug_mode == 0)
    {      
       open_stdout();
       open_stderr();
    }    

    result = system(runParm);

    if (debug_mode == 0)
    {
        close_stdout();
        close_stderr();
    }
    
    if (result != 0)
       return -2;
       
    return get_ctct_result_obs(s,t,is_observable);    
}  
INT_OS obs_runProgram(char *name2, char *name1, INT_S *s, state_node **t, INT_T s_nulllist, INT_T *nulllist, INT_OS mode, INT_B  *is_observable)
{                     
    FILE *f1;
    INT_T i;
    
    f1 = fopen(get_prm_file(), "w");
    if (f1 == NULL)
       return -1;
       
    fprintf(f1, "%d\n", debug_mode);  /* Debug mode */
    fprintf(f1, "%d\n", minflag);
    fprintf(f1, "26\n");    /* Obs */
    fprintf(f1, "%d\n", mode);
    fprintf(f1, "%s\n", name1);
    fprintf(f1, "%s\n", name2);
    for (i=0; i < s_nulllist; i++)
       fprintf(f1, "%d\n", nulllist[i]);
    fclose(f1); 

//	cmdline_tct_run();
	
    return mySystem_obs(s,t,is_observable);   
}

INT_OS supobs_runProgram(char *name3,char *name1, char *name2, INT_T slist, INT_T *list, INT_OS mode)
{                     
	FILE *f1;
	INT_T i;

	f1 = fopen(get_prm_file(), "w");
	if (f1 == NULL)
		return -1;

	fprintf(f1, "%d\n", debug_mode);  /* Debug mode */
	fprintf(f1, "%d\n", minflag);
	fprintf(f1, "28\n");    /* suprobs */
	fprintf(f1, "%s\n", name1);
	fprintf(f1, "%s\n", name2);
	fprintf(f1, "%s\n", name3);
	fprintf(f1, "%d\n", mode);
	for (i=0; i < slist; i++)
		fprintf(f1, "%d\n", list[i]);
	fclose(f1);   
	
//	cmdline_tct_run();
	return mySystem();
}

INT_OS bfs_recode_runProgram(char *name2, char *name1)
{
	FILE *f1;

	f1 = fopen(get_prm_file(), "w");
	if (f1 == NULL)
		return -1;

	fprintf(f1, "%d\n", debug_mode); /* Debug mode */          
	fprintf(f1, "%d\n", minflag);
	fprintf(f1, "29\n");  /* BFS_RECODE */
	fprintf(f1, "%s\n", name1);
	fprintf(f1, "%s\n", name2);
	fclose(f1);

	//cmdline_tct_run();
	return mySystem();
}

INT_OS uncertmod_runProgram(char *name2, char *name1, INT_T *list, INT_T slist)
{
	FILE *f1;
	INT_T i;

	f1 = fopen(get_prm_file(), "w");
	if (f1 == NULL)
		return -1;

	fprintf(f1, "%d\n", debug_mode); /* Debug mode */      
	fprintf(f1, "%d\n", minflag);
	fprintf(f1, "32\n");  /* UNCERTMOD */
	fprintf(f1, "%s\n", name1);
	fprintf(f1, "%s\n", name2);
	for (i=0; i < slist; i++) 
		fprintf(f1, "%d\n", list[i]);
	fclose(f1);

//		cmdline_tct_run();
	return mySystem();
}
/////////////////////////////////////////////////////////////////////////////////

typedef char filename1[MAX_FILENAME];

static filename1   name1, name2, name3, name4, names1[MAX_DESS];
static char long_name1[MAX_FILENAME];
static char long_name2[MAX_FILENAME];
static char long_name3[MAX_FILENAME];
static char long_name4[MAX_FILENAME];

void create_program(FILE *f1)
{
	//INT_T slist, *list;
	state_node *t; INT_S s, init;
	INT_OS ee, flag;
	INT_S i,j,k;
	INT_B ok;


	t = NULL; s = 0;

	/* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	fscanf(f1, "%d\n", &s);

	t = newdes(s);

	while( fscanf(f1, "%d" , &ee) != EOF)
	{
		if(ee == -1){
			break;
		}
		t[ee].marked = true;
	}

	flag = 0;
	while( fscanf(f1, "%d" , &ee) != EOF)
	{
		if(flag == 0){
			flag = 1;
			i = ee;
			continue;
		}else if(flag == 1){
			flag = 2;
			j = ee;
			continue;
		}else if(flag == 2){
			flag = 0;
			k = ee;
			addordlist1((INT_T)j,k,&t[i].next, t[i].numelts, &ok);
			if(ok) t[i].numelts ++;
			continue;
		}
	}

	fclose(f1);
	remove(prm_file);

	init = 0L;
	filedes(name1, s, init, t);

	if(mem_result == 1)	{ 
		ctct_result(CR_OUT_OF_MEMORY);
		exit(0);
	}
	freedes(s, &t);
}

void selfloop_program(FILE *f1)
{  
    state_node *t1;
    INT_S s1, init;
    INT_T *list, slist;
    INT_T e;
    INT_OS ee;
    INT_B  ok;

    t1 = NULL; s1 = 0;
    list = NULL; slist = 0;
    
    /* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
    name2[strlen(name2)-1] = '\0';
    
    while( fscanf(f1, "%d" , &ee) != EOF)
    {
        e = (INT_T) ee;
        addordlist(e, &list, slist, &ok);
        if (ok) slist++;
    }

	fclose(f1);
	remove(prm_file); 
 
    init = 0L;   
	if(getdes(name1, &s1, &init, &t1) == false){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}    
    selfloop_gentran(slist, list, s1, t1);

	if (mem_result != 1)
	{
		filedes(name2, s1, init, t1);
	}
	else
	{
		ctct_result(CR_OUT_OF_MEMORY);
		exit(0);
	}
}

void trim_program(FILE *f1) 
{
    state_node *t1;
    INT_S s1, init;//,i;

    t1 = NULL; s1 = 0;
    /* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name2[strlen(name2)-1] = '\0';


	fclose(f1);
	remove(prm_file);
    
    init = 0L;    
    if(getdes(name1, &s1, &init, &t1) == false){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}
    
    trim1(&s1, &t1);
     
    if (mem_result != 1)
    {
       filedes(name2, s1, init, t1); 
    }
	else
	{ 
		ctct_result(CR_OUT_OF_MEMORY);
		exit(0);
	}
}

void synck_program(FILE *f1)
{
	state_node *t1, *t2, *t3;
	INT_S s1, s2, s3, init;
	INT_S  *macro_ab, *macro_c;
	INT_OS num, i, j, k;
	INT_T s_tranlist, *tranlist;
	INT_B ok;

	macro_ab = NULL;  macro_c  = NULL;
	t1 = t2 = t3 = NULL;
	s1 = s2 = s3 = 0;
	s_tranlist = 0; tranlist = NULL;

	/* Use "fgets" as names could have spaces in it */
	if (fgets(name3, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name3[strlen(name3)-1] = '\0';

	num = 0;
	// get number of files to be composed
	fscanf(f1, "%d\n", &num);

	for(i = 0; i < num; i ++){
		/* Use "fgets" as names could have spaces in it */
		if (fgets(names1[i], MAX_FILENAME, f1) == NULL)
		{
			fclose(f1);
			remove(prm_file);
			ctct_result(CR_PRM_ERR);
			exit(0);
		}
		names1[i][strlen(names1[i])-1] = '\0';
		init = 0L;
		if(getdes(names1[i], &s1, &init, &t1) == false){
			fclose(f1);
			remove(prm_file);
			ctct_result(CR_DES_FORMAT_ERR);
			exit(0);
		}
		for(j = 0; j < s1; j ++){
			for(k = 0; k < t1[j].numelts; k ++){
				addordlist(t1[j].next[k].data1,&tranlist, s_tranlist,&ok);
				if(ok) s_tranlist ++;
			}
		}
		freedes(s1,&t1);
		s1 = 0; t1 = NULL;
	}

	fclose(f1);
	remove(prm_file);


	init = 0L;   
	if(getdes(names1[0], &s1, &init, &t1) == false){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}

	for(i = 1; i < num; i ++){
		if(getdes(names1[i], &s2, &init, &t2) == false){
			ctct_result(CR_DES_FORMAT_ERR);
			exit(0);
		}
		if(i == 1){
			sync3(s1,t1,s2,t2,&s3,&t3, 0, s_tranlist, tranlist, &macro_ab,&macro_c); 
		}else{
			sync3(s1,t1,s2,t2,&s3,&t3, 1, s_tranlist, tranlist, &macro_ab,&macro_c); 
		}
		free(macro_ab); free(macro_c);
		macro_ab = macro_c = NULL;
		freedes(s1, &t1);
		freedes(s2, &t2);
		s1 = s2 = 0;
		t1 = t2 = NULL;
		export_copy_des(&s1, &t1, s3, t3);
		freedes(s3, &t3); s3 = 0; t3 = NULL;
	}
	
	if (mem_result != 1)
	{
		init = 0L;
		filedes(name3, s1, init, t1);   
	}
	else
	{
		ctct_result(CR_OUT_OF_MEMORY);
		exit(0);
	}
}

void meetk_program(FILE *f1)
{
	state_node *t1, *t2, *t3;
	INT_S s1, s2, s3, init;
	INT_S  *macro_ab, *macro_c;
	INT_OS num, i;

#if defined(_x64_)
	unsigned long long *macro64_c;
	macro64_c = NULL;
#endif

	macro_ab = NULL;  macro_c  = NULL;
	t1 = t2 = t3 = NULL;
	s1 = s2 = s3 = 0;

	/* Use "fgets" as names could have spaces in it */
	if (fgets(name3, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name3[strlen(name3)-1] = '\0';

	num = 0;
	// get number of files to be composed
	fscanf(f1, "%d\n", &num);

	for(i = 0; i < num; i ++){
		/* Use "fgets" as names could have spaces in it */
		if (fgets(names1[i], MAX_FILENAME, f1) == NULL)
		{
			fclose(f1);
			remove(prm_file);
			ctct_result(CR_PRM_ERR);
			exit(0);
		}
		names1[i][strlen(names1[i])-1] = '\0';
		
	}

	fclose(f1);
	remove(prm_file);

	init = 0L;   
	if(getdes(names1[0], &s1, &init, &t1) == false){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}

	for(i = 1; i < num; i ++){
		if(getdes(names1[i], &s2, &init, &t2) == false){
			ctct_result(CR_DES_FORMAT_ERR);
			exit(0);
		}

#if defined(_x64_)
		meet_x64(s1,t1,s2,t2,&s3,&t3,&macro64_c); 
		free(macro64_c); macro64_c = NULL;
#else
		meet2(s1,t1,s2,t2,&s3,&t3,&macro_ab,&macro_c); 
		free(macro_ab); free(macro_c);
		macro_ab = macro_c = NULL;
#endif
		freedes(s1, &t1);
		freedes(s2, &t2);
		s1 = s2 = 0;
		t1 = t2 = NULL;
		export_copy_des(&s1, &t1, s3, t3);
		freedes(s3, &t3); s3 = 0; t3 = NULL;
	} 

	free(macro_ab);

	if (mem_result != 1)
	{
		init = 0L;
		filedes(name3, s1, init, t1);  
		#if defined(_x64_)
			ctct_result(CR_OK);
			free(macro64_c);			 
		#else
			ctct_result(CR_OK); 
			//free(macro_c);
		#endif
		free(macro_c);
		exit(0);
	}
	else
	{
		ctct_result(CR_OUT_OF_MEMORY);
		#if defined(_x64_)
			free(macro64_c);
		#else			
			//free(macro_c);
		#endif
		free(macro_c);
		exit(0);
	}
}

void supcon_program(FILE *f1)
{
    state_node *t1, *t2, *t3;
    INT_S s1, s2, s3, init;
    INT_S *macro_ab, *macro_c;

    macro_ab = NULL;  macro_c  = NULL;
    t1 = t2 = t3= NULL;
	s1 = s2 = s3 = 0;

    /* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name2[strlen(name2)-1] = '\0';

	if (fgets(name3, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
    name3[strlen(name3)-1] = '\0';

	fclose(f1);
	remove(prm_file);
 
    init = 0L;    
    if((getdes(name1, &s1, &init, &t1) == false) || (getdes(name2, &s2, &init, &t2) == false)){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}
    
    meet2(s1,t1,s2,t2,&s3,&t3,&macro_ab,&macro_c); 
    freedes(s2,&t2); t2 = NULL;
    trim2(&s3,&t3,macro_c);
    shave1(s1,t1,&s3,&t3,macro_c);

    if (mem_result != 1)
    {
       filedes(name3, s3, init, t3);  
    }
    else
    {
		ctct_result(CR_OUT_OF_MEMORY);
		exit(0);
    }
}

void mutex_program(FILE *f1)
{
    state_node *t1, *t2, *t3;
    INT_S s1, s2, s3, init;
    INT_S  *macro_ab, *macro_c;
    state_pair *sp;
    INT_S s_sp;
    INT_S i,j;
    INT_B  ok;

    macro_ab = NULL;  macro_c  = NULL;
    t1 = t2 = t3 = NULL;
    s1 = s2 = s3 = 0;
    sp = NULL;
    s_sp = 0;
    
    /* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name2[strlen(name2)-1] = '\0';

	if (fgets(name3, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
    name3[strlen(name3)-1] = '\0';
    
    while( fscanf(f1, "%ld %ld" , &i, &j) != EOF)
    {
        addstatepair(i, j, &sp, s_sp, &ok);
        if (ok) s_sp++;
    }  

	fclose(f1);
	remove(prm_file);
 
    init = 0L;   
	if((getdes(name1, &s1, &init, &t1) == false) || (getdes(name2, &s2, &init, &t2) == false)){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}
    
    sync4(s1,t1,s2,t2,&s3,&t3,&macro_ab,&macro_c);
    free(macro_c);
    mutex1(&s3,&t3,s1,s2,macro_ab,sp,s_sp);
    reach(&s3,&t3);

    if (mem_result != 1)
    {
       filedes(name3, s3, init, t3);  
    }
    else
    {
		ctct_result(CR_OUT_OF_MEMORY);
		exit(0);
    }
}

void condat_program(FILE *f1)
{
    state_node *t1, *t2, *t3, *t4;
    INT_S s1, s2, s3, s4, init;
    INT_S  *macro_ab, *macro_c;

    macro_ab = NULL;  macro_c  = NULL;
    t1 = t2 = t3 = t4 = NULL;
    s1 = s2 = s3 = s4 = 0;
    
	/* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name2[strlen(name2)-1] = '\0';

	if (fgets(name3, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
    name3[strlen(name3)-1] = '\0';

	fclose(f1);
	remove(prm_file);

    init = 0L;    
	if((getdes(name1, &s1, &init, &t1) == false) || (getdes(name2, &s2, &init, &t2) == false)){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}

    meet2(s1,t1,s2,t2,&s3,&t3,&macro_ab,&macro_c);
    freedes(s2, &t2); t2 = NULL;
    free(macro_ab);
    
    condat1(t1,s1,s2,s3,t3,&s4,&t4,macro_c);
   
	if (mem_result != 1)
	{
		filedes(name3, s4, -1L, t4);  
	}
	else
	{
		ctct_result(CR_OUT_OF_MEMORY);
		exit(0);
	}
}

INT_OS ctct_result_supreduce(INT_OS result, INT_OS lb, float cr)
{
	FILE *out;

	out = fopen(get_rst_file(), "w");

	if (out == NULL) 
		return -1;       /* Can do not much here so just return */
	fprintf(out, "%d\n", result);
	fprintf(out, "%d ", lb);
	fprintf(out, "%f\n", cr);

	fclose(out);
	return 0;
}

void supreduce_program(FILE *f1)
{
    state_node *t1, *t2, *t3, *t4;
    INT_S s1, s2, s3, s4, init;
    INT_S lb;
    float cr;
    INT_OS supreduce_flag;
	INT_OS mode;
	INT_OS slb_flag;

    t1 = t2 = t3 = t4 = NULL;
    s1 = s2 = s3 = s4 = 0;
    lb = 0;
    cr = 0.0;
	mode = 0;

    /* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name2[strlen(name2)-1] = '\0';

	if (fgets(name3, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name3[strlen(name3)-1] = '\0';

	if (fgets(name4, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
    name4[strlen(name4)-1] = '\0';

	fscanf(f1, "%d\n", &mode);
	fscanf(f1, "%d\n", &slb_flag);

	fclose(f1);
	remove(prm_file);

    strcpy(long_name1, "");
    strcpy(long_name2, "");
    strcpy(long_name3, "");
    strcpy(long_name4, "");
    make_filename_ext(long_name1, name1, EXT_DES);
    make_filename_ext(long_name2, name2, EXT_DES);
    make_filename_ext(long_name3, name3, EXT_DAT);
    make_filename_ext(long_name4, name4, EXT_DES);

	if(mode == 0)
		supreduce_flag = supreduce(long_name1,long_name2,long_name3,long_name4,&lb,&cr, slb_flag);
	else{
		supreduce_flag = ex_supreduce(long_name1,long_name2,long_name3,long_name4,&lb,&cr, slb_flag);
	}

	if(supreduce_flag == 100){
		ctct_result(100);
		exit(0);
	}
    
    if (mem_result != 1) 
    {
       switch (supreduce_flag) {
         case  0: break;
         case -1: filedes(name4, s4, 0L, t4);
                  break;
         case -2: init = 0;
                  if(getdes(name2, &s4, &init, &t4) == false){
					  ctct_result(CR_DES_FORMAT_ERR);
					  exit(0);
				  }

                  filedes(name4, s4, init, t4);
                  cr = 1;
                  lb = s4;
                  break;
       }
        
       if (supreduce_flag > 0)
       {
          ctct_result(CR_SUPREDUCE_ERR);
          exit(0);
       }  
       else
       {
          /* On success, we need to pass the "lb" and "cr" */

          ctct_result_supreduce(CR_OK, (INT_OS)lb, cr);
          exit(0);
       }
    } 
    else
    {
        ctct_result(CR_OUT_OF_MEMORY);
    }   
}

void minstate_program(FILE *f1)
{
    state_node *t1;
    INT_S s1, init;

    t1 = NULL; s1 = 0;
    
    /* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
    name2[strlen(name2)-1] = '\0';

	fclose(f1);
	remove(prm_file);
    
    init = 0L;
    if(getdes(name1, &s1, &init, &t1) == false){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}
    
    reach(&s1, &t1);
    minimize(&s1, &t1);
     
    if (mem_result != 1)
    {
       filedes(name2, s1, init, t1); 
    }
    else
    {
       ctct_result(CR_OUT_OF_MEMORY);
       exit(0);
    }
}

void complement_program(FILE *f1)
{
    state_node *t1;
    INT_S s1, init;
    INT_T *list, slist;
    INT_T e;
    INT_OS ee;
    INT_B  ok;

    t1 = NULL; s1 = 0;
    list = NULL; slist = 0;

	/* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name2[strlen(name2)-1] = '\0';
    
    while( fscanf(f1, "%d" , &ee) != EOF)
    {
        e = (INT_T) ee;
        addordlist(e, &list, slist, &ok);
        if (ok) slist++;
    }

	fclose(f1);
	remove(prm_file);
 
    init = 0L;   
	if(getdes(name1, &s1, &init, &t1) == false){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}  
    
    complement1(&s1, &t1, slist, list);
    reach(&s1, &t1);

    if (mem_result != 1)
    {
       filedes(name2, s1, init, t1);
    }
    else
    {
       ctct_result(CR_OUT_OF_MEMORY);
       exit(0);
    }
}

void localize_program(FILE *f1)
{
	INT_OS result;
	INT_S sfile, sloc,i;
	char names1[MAX_DESS][MAX_FILENAME];
	char names2[MAX_DESS][MAX_FILENAME];  

	result = 0;

	/* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name2[strlen(name2)-1] = '\0';

	fscanf(f1,"%d\n",&sfile);

	for(i = 0; i < sfile; i ++){
		if (fgets(names1[i], MAX_FILENAME, f1) == NULL)
		{
			fclose(f1);
			remove(prm_file);
			ctct_result(CR_PRM_ERR);
			exit(0);
		}
		names1[i][strlen(names1[i])-1] = '\0';
	}
	fscanf(f1,"%d\n",&sloc);
	for(i = 0; i < sloc; i ++){
		if (fgets(names2[i], MAX_FILENAME, f1) == NULL)
		{
			ctct_result(CR_PRM_ERR);
			exit(0);
		}
		names2[i][strlen(names2[i])-1] = '\0';
	}

	fclose(f1);
	remove(prm_file);

	result = localize_proc(sfile,sloc,name1,name2,names1,names2,0,0); 

	if (result != 0)
	{       
		if (mem_result == 1){
			ctct_result(CR_OUT_OF_MEMORY);			
		} 
		exit(0);
	}   


}
void force_program(FILE *f1)
{
	INT_T s_force_event_list, *force_event_list;
	INT_T s_preempt_event_list, *preempt_event_list;
	INT_T timeout_event;
	INT_B flag, ok;
	INT_T e;
	INT_OS ee;

	s_force_event_list = s_preempt_event_list = 0;
	force_event_list = preempt_event_list = NULL;

	/* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name2[strlen(name2)-1] = '\0';

	fscanf(f1, "%d\n", &ee);
	timeout_event = (INT_T)ee;
	flag = false;
	while( fscanf(f1, "%d" , &ee) != EOF)
	{
		if(ee == -1){
			flag = true;
			continue;
		}
		e = (INT_T)ee;
		if(!flag){			
			addordlist(e, &force_event_list, s_force_event_list,&ok);
			if(ok) s_force_event_list ++;
		}else{
			addordlist(e, &preempt_event_list, s_preempt_event_list, &ok);
			if(ok) s_preempt_event_list ++;
		}

	}

	fclose(f1);
	remove(prm_file);

	force_proc(name1, name2, s_force_event_list, force_event_list,
		s_preempt_event_list, preempt_event_list, timeout_event);

	if(mem_result == 1)
	{
		ctct_result(CR_OUT_OF_MEMORY);
		exit(0);
	}
}

void project_program(FILE *f1)
{
    state_node *t1;
    INT_S s1, init;
    INT_T *list, slist;
    INT_T e;
    INT_OS ee;
    INT_B  ok;

    t1 = NULL; s1 = 0;
    list = NULL; slist = 0;

    /* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
    name2[strlen(name2)-1] = '\0';
    
    while( fscanf(f1, "%d" , &ee) != EOF)
    {
        e = (INT_T) ee;
        addordlist(e, &list, slist, &ok);
        if (ok) slist++;
    }

	fclose(f1);
	remove(prm_file);
 
    init = 0L;   
	if(getdes(name1, &s1, &init, &t1) == false){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}   

    project0(&s1,&t1,slist,list);

    if (mem_result != 1)
    {
		init = 0L;
       filedes(name2, s1, init, t1);
    }
    else
    {
       ctct_result(CR_OUT_OF_MEMORY);
       exit(0);
    }
}

void convert_program(FILE *f1)
{
    state_node *t1, *t2;
    INT_S s1, s2, init;
    state_pair *sp;
    INT_S s_sp;
    INT_S i,j;
    INT_B  ok;
    INT_T *list;
    INT_T s_list;

    t1 = t2 = NULL;
    s1 = s2 = 0;
    sp = NULL;
    s_sp = 0;
    list = NULL;
    s_list = 0;
    
    /* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
    name2[strlen(name2)-1] = '\0';
    
    while( fscanf(f1, "%ld %ld" , &i, &j) != EOF)
    {
        addstatepair(i, j, &sp, s_sp, &ok);
        if (ok) s_sp++;
    }  

	fclose(f1);
	remove(prm_file);
 
    init = 0L;   
	if(getdes(name1, &s1, &init, &t1) == false){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}
    
    eventmap_des(t1,s1,&t2,&s2,sp,s_sp,&list,&s_list,&ok);

    if (s_list != 0) 
		project0(&s2,&t2,s_list,list);

    if (mem_result != 1)
    {
       filedes(name2, s2, init, t2);  
    }
    else
    {
       ctct_result(CR_OUT_OF_MEMORY);
       exit(0);
    }
}

void vocalize_program(FILE *f1)
{
    state_node *t1, *t2;
    INT_S s1, s2, init;
    quad__t *list;
    INT_S slist;
    INT_B  ok;
    INT_S      i,j;
    INT_T      e;
    INT_OS        ee;
    INT_V      v;
    INT_OS        vv;

    t1 = t2 = NULL; 
    s1 = s2 = 0;
    list = NULL; slist = 0;
    
    /* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name2[strlen(name2)-1] = '\0';

    while( fscanf(f1, "%ld %d %ld %d" , &i, &ee, &j, &vv) != EOF)
    {
        e = (INT_T) ee;
        v = (INT_V) vv;
        add_quad(i,e,j,v, &list, slist, &ok);
        if (ok) slist++;
    }

	fclose(f1);
	remove(prm_file);
 
    init = 0L;   
	if(getdes(name1, &s1, &init, &t1) == false){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}  
    
    vocalize_des(&t1,&s1,&list,&slist);

    if (mem_result != 1)
    {
       filedes(name2, s1, init, t1);
    }
    else
    {
       ctct_result(CR_OUT_OF_MEMORY);
       exit(0);
    }
}

void outconsis_program(FILE *f1)
{
    state_node *t1;
    INT_S s1, init;

    t1 = NULL; s1 = 0;
    
	/* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name2[strlen(name2)-1] = '\0';
    
	fclose(f1);
	remove(prm_file);

    init = 0L;
	if(getdes(name1, &s1, &init, &t1) == false){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}

    if (s1 > 0) {
      if ((t1)[0].vocal != 0)
      {
         ctct_result(CR_VOCAL_ERR);
         exit(0);
      }
    }
    
    outcon_des(&t1,&s1);
   
    if (mem_result != 1)
    {
       filedes(name2, s1, init, t1); 
    }
    else
    {
       ctct_result(CR_OUT_OF_MEMORY);
       exit(0);
    }
}

void hiconsis_program(FILE *f1)
{
    state_node *t1;
    INT_S s1, init;
    INT_B  result;
	INT_OS oldconsis_flag;

    t1 = NULL; s1 = 0;
    
	/* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
    name2[strlen(name2)-1] = '\0';

	fscanf(f1, "%d\n", &oldconsis_flag);

	fclose(f1);
	remove(prm_file);
    
    init = 0L;
	if(getdes(name1, &s1, &init, &t1) == false){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}

    if (s1 > 0) {
      if ((t1)[0].vocal != 0)
      {
         ctct_result(CR_VOCAL_ERR);
         exit(0);
      }
    }
  
	if(oldconsis_flag)
		result = hiconsis_des(&t1,&s1);  
	else
		result = hiconsis_1_des(&t1,&s1);  
    if (result == true)
    {
       ctct_result(CR_HICONSIS_ERR);
       exit(0);
    }
   
    if (mem_result != 1)
    {
       filedes(name2, s1, init, t1); 
    }
    else
    {
       ctct_result(CR_OUT_OF_MEMORY);
       exit(0);
    }
}

void higen_program(FILE *f1)
{
    state_node *t1;
    INT_S s1, init;
    INT_T      *list, slist;

    t1 = NULL; s1 = 0;
    list = NULL; slist = 0;

	/* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
    name1[strlen(name1)-1] = '\0';
    
	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
    name2[strlen(name2)-1] = '\0';

	fclose(f1);
	remove(prm_file);
    
    init = 0L;
	if(getdes(name1, &s1, &init, &t1) == false){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}

    if (s1 > 0) {
       if ((t1)[0].vocal != 0)
       {
          ctct_result(CR_VOCAL_ERR);
          exit(0);
       }
    }
  
    higen_des(&t1, &s1, &list, &slist);

    /* Project the answer onto [0] */
    if (slist == 0) {
       reach(&s1, &t1);
       minimize(&s1, &t1);
    } else {
       project1(&s1,&t1,slist,list);
       if (s1 > 1) {
          reach(&s1, &t1);
          minimize(&s1,&t1);
       }
    }
     
    if (mem_result != 1)
    {
       filedes(name2, s1, init, t1); 
    }
    else
    {
       ctct_result(CR_OUT_OF_MEMORY);
       exit(0);
    }
}

void allevents_program(FILE *f1)
{
    state_node *t1, *t2;
    INT_S s1, s2, init;
	INT_OS entry_type, ee;
	INT_T e, s_list, *list, i;
	INT_B ok;

    t1 = t2 = NULL; 
    s1 = s2 = 0;
	s_list = 0; list = NULL;
    
    /* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
    name2[strlen(name2)-1] = '\0';

	fscanf(f1, "%d" , &entry_type);

	if(entry_type == 3){
		while( fscanf(f1, "%d" , &ee) != EOF)
		{
			e = (INT_T) ee;
			addordlist(e, &list, s_list, &ok);
			if (ok) s_list++;
		}  
	}

	fclose(f1);
	remove(prm_file);

	if(entry_type == 1){
		init = 0L;
		if(getdes(name1, &s1, &init, &t1) == false){
			ctct_result(CR_DES_FORMAT_ERR);
			exit(0);
		}
		allevent_des(&t1, &s1, &t2, &s2);
	}
	else if(entry_type == 2){
		init = -1L;
		if(getdes(name1, &s1, &init, &t1) == false){
			ctct_result(CR_DES_FORMAT_ERR);
			exit(0);
		}
		allevent_des(&t1, &s1, &t2, &s2);
	}else{
		s2 = 1;
		t2 = newdes(s2);
		(t2[0]).marked = true;
		for(i = 0; i < s_list; i ++){
			addordlist1(list[i],0, &t2[0].next, t2[0].numelts, &ok);
			if(ok) t2[0].numelts ++;
		}
	}
     
	free(list);
	if (mem_result != 1) {
		init = 0L;
		filedes(name2, s2, init, t2); 
	} else {
		ctct_result(CR_OUT_OF_MEMORY);
		exit(0);
	}
}

void supnorm_program(FILE *f1)
{
    state_node *t1, *t2, *t3;
    INT_S s1, s2, s3, init;
    INT_T *list;
    INT_T slist;
    INT_T e;
    INT_OS ee;
    INT_B  ok;

    t1 = t2 = t3 = NULL;
    s1 = s2 = s3 = 0;
    list = NULL;  slist = 0;
    
	/* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name2[strlen(name2)-1] = '\0';

	if (fgets(name3, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
    name3[strlen(name3)-1] = '\0';
    
    while( fscanf(f1, "%d" , &ee) != EOF)
    {
        e = (INT_T) ee;
        addordlist(e, &list, slist, &ok);
        if (ok) slist++;
    }  

	fclose(f1);
	remove(prm_file);
 
    init = 0L;   
	if((getdes(name1, &s1, &init, &t1) == false) || (getdes(name2, &s2, &init, &t2) == false)){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}
    
    suprema_normal(t1, s1, t2, s2, &t3, &s3, list, slist);

    if (mem_result != 1)
    {
       filedes(name3, s3, init, t3);  
    }
    else
    {
       ctct_result(CR_OUT_OF_MEMORY);
       exit(0);
    }
}

void supscop_program(FILE *f1)
{
    state_node *t1, *t2, *t3;
    INT_S s1, s2, s3, init;
    INT_T *list;
    INT_T slist;
    INT_T e;
    INT_OS ee;
    INT_B  ok;

    t1 = t2 = t3 = NULL;
    s1 = s2 = s3 = 0;
    list = NULL;  slist = 0;
    
    /* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name2[strlen(name2)-1] = '\0';

	if (fgets(name3, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
    name3[strlen(name3)-1] = '\0';
    
    while( fscanf(f1, "%d" , &ee) != EOF)
    {
        e = (INT_T) ee;
        addordlist(e, &list, slist, &ok);
        if (ok) slist++;
    }  

	fclose(f1);
	remove(prm_file);
 
    init = 0L;   
	if((getdes(name1, &s1, &init, &t1) == false) || (getdes(name2, &s2, &init, &t2) == false)){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}
    
    suprema_normal_scop(t1, s1, t2, s2, &t3, &s3, list, slist);

    if (mem_result != 1)
    {
       filedes(name3, s3, init, t3);  
    }
    else
    {
       ctct_result(CR_OUT_OF_MEMORY);
       exit(0);
    }
}

void supconrobs_program(FILE *f1)
{
	INT_T slist, *list;
	INT_T s_imagelist, *imagelist;
	INT_B ok;
	INT_T e;
	INT_OS ee;
	INT_S init, s1;
	state_node *t1;

	INT_S result;

	slist = s_imagelist = 0;
	list = imagelist = NULL;
	t1 = NULL; s1 = 0;

	result = 0;
	/* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';
	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name2[strlen(name2)-1] = '\0';

	if (fgets(name3, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name3[strlen(name3)-1] = '\0';

	while( fscanf(f1, "%d" , &ee) != EOF)
	{
		e = (INT_T)ee;		
		addordlist(e, &list, slist,&ok);
		if(ok) slist ++;

	}
	fclose(f1);
	remove(prm_file);

	init = 0L;
	if(getdes(name1, &s1, &init, &t1) == false){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}
	gen_complement_list(t1, s1,	list, slist, &imagelist, &s_imagelist);
	freedes(s1, &t1); s1 = 0; t1 = NULL;

	result = supconrobs_proc(name3, name1, name2, slist, list, s_imagelist, imagelist);

	if(result == 0){
		ctct_result(CR_OK);
		exit(0);
	}else{
		if(mem_result == 1)	{			
			ctct_result(CR_OUT_OF_MEMORY);			
		}
		exit(0);
	}
}

INT_OS ctct_result_canQC(INT_OS result, INT_S s_statemap, INT_S *statemap)
{
	FILE *out;
	INT_S i;

	out = fopen(get_rst_file(), "w");

	if (out == NULL) 
		return -1;       /* Can do not much here so just return */
	fprintf(out, "%d\n", result);

	for (i=0; i < s_statemap; i++)
		fprintf(out, "%d\n ", statemap[i]);

	fclose(out);
	return 0;
}
void canQC_program(FILE *f1)
{
	state_node *t1;
	INT_S s1, init;
	INT_T *list, slist;
	INT_T *imagelist, s_imagelist;
	INT_S *statemap, s_statemap;
	INT_T e;
	INT_OS ee;
	INT_B  ok;
	INT_OS result;
	INT_OS mode; 

	t1 = NULL; s1 = 0;
	list = NULL; slist = 0;
	imagelist = NULL; s_imagelist = 0;
	statemap = NULL; s_statemap = 0;

	fscanf(f1, "%d\n", &mode);

	/* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name2[strlen(name2)-1] = '\0';

	while( fscanf(f1, "%d" , &ee) != EOF)
	{
		e = (INT_T) ee;
		addordlist(e, &list, slist, &ok);
		if (ok) slist++;
	} 

	fclose(f1);
	remove(prm_file);

	init = 0L;
	if(getdes(name1, &s1, &init, &t1) == false){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}
	gen_complement_list(t1, s1,	list, slist, &imagelist, &s_imagelist);
	freedes(s1, &t1); s1 = 0; t1 = NULL;

	result = CanQC_proc1(name2, name1, slist, list, s_imagelist, imagelist,
		&s_statemap, &statemap, mode);

	if (result == 0)
	{
		/* On success, we need to pass the state partition */
		ctct_result_canQC(CR_OK, s_statemap, statemap);
		exit(0);       
	}else if (mem_result == 1){
		ctct_result(CR_OUT_OF_MEMORY);
		exit(0);
	}else{
		exit(0);
	}
}

INT_OS ctct_result_flag(INT_OS result, INT_B  flag)
{
	FILE *out;

	out = fopen(get_rst_file(), "w");

	if (out == NULL) 
		return -1;       /* Can do not much here so just return */
	fprintf(out, "%d\n", result);

	fprintf(out, "%d\n", flag);

	fprintf(out, "\n");

	fclose(out);
	return 0;
}

INT_OS ctct_result_isomorph(INT_OS result, INT_B is_iso, INT_B identity, INT_S s_mapState, INT_S *mapState)
{
	FILE *out;
	INT_S i;

	out = fopen(get_rst_file(), "w");

	if (out == NULL) 
		return -1;       /* Can do not much here so just return */
	fprintf(out, "%d\n", result);

	fprintf(out, "%d\n", is_iso);

	fprintf(out, "%d\n", identity);

	for (i=0; i < s_mapState; i++)
		fprintf(out, "%d\n ", mapState[i]);

	fclose(out);
	return 0;
}
void isomorph_program(FILE *f1)
{
	state_node *t1, *t2;
	INT_S s1, s2, init; 
	INT_B  is_iso, flag, identity;
	INT_S *mapState;

	t1 = t2 = NULL; s1 = s2 = 0;
	is_iso = false;
	mapState = NULL;
	identity = false;

	/* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name2[strlen(name2)-1] = '\0';

	fclose(f1);
	remove(prm_file);

	init = 0L;
	if((getdes(name1, &s1, &init, &t1) == false) || (getdes(name2, &s2, &init, &t2) == false)){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}

	if ( (strcmp(name1,name2) == 0) || ((s1 == 0) && (s2 == 0)) ) {
		is_iso   = true;
		identity = true;
		ctct_result_isomorph(CR_OK, is_iso, identity, 0, NULL);
		goto FREE_MEM;
	} else if(s1 != s2){
		ctct_result_isomorph(CR_OK, is_iso, identity, 0, NULL);
		goto FREE_MEM;
	}else{
		/* Need some memory here - Allocate map state */
		mapState = (INT_S*) CALLOC(s1, sizeof(INT_S));

		if ((s1 != 0) && (mapState == NULL)) {
			mem_result = 1;	
			ctct_result(CR_OUT_OF_MEMORY);
			goto FREE_MEM;
		}
		memset(mapState, -1, sizeof(INT_S)*(s1));
		mapState[0] = 0;

		flag = true;
		iso1(s1, s2, t1, t2, &flag, mapState);
		if (flag) is_iso = true;
	}

	if (mem_result == 1){
		ctct_result(CR_OUT_OF_MEMORY);
	}else{
		ctct_result_isomorph(CR_OK, is_iso, identity, s1, mapState);
	}
FREE_MEM:
	freedes(s1, &t1); 
	freedes(s2, &t2);
	free(mapState);
	exit(0);  
}

void nonconflict_program(FILE *f1)
{
	state_node *t1, *t2, *t3;
	INT_S s1, s2, s3, init; 
	INT_B  is_nonconflict;
	INT_S *macro_ab, *macro_c;

	t1 = t2 = t3 = NULL; 
	s1 = s2 = s3 = 0;
	is_nonconflict = false;
	macro_c = macro_ab = NULL;

	/* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name2[strlen(name2)-1] = '\0';

	fclose(f1);
	remove(prm_file);

	init = 0L;
	if((getdes(name1, &s1, &init, &t1) == false) || (getdes(name2, &s2, &init, &t2) == false)){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}

	is_nonconflict = false;

	nc_meet2(s1,t1,s2,t2,&s3,&t3,&macro_ab,&macro_c);
	is_nonconflict = nonconflict(s3,t3);


	if (mem_result == 1){
		ctct_result(CR_OUT_OF_MEMORY);
	}else{
		ctct_result_flag(CR_OK, is_nonconflict);
	}

	freedes(s1, &t1); 
	freedes(s2, &t2);
	freedes(s3, &t3); 
	free(macro_ab);
	free(macro_c);
	exit(0);  
}

INT_OS ctct_result_obs(INT_OS result, INT_S s, state_node *t, INT_B  is_observable)
{
	FILE *out;
	//   INT_S i;
	INT_S init;

	out = fopen(get_rst_file(), "w");

	if (out == NULL) 
		return -1;       /* Can do not much here so just return */
	fprintf(out, "%d\n", result);

	fprintf(out, "%d\n", is_observable);

	init = 0;
	filedes(OBS_TEMP_NAME,s,init,t);
	fprintf(out,OBS_TEMP_NAME); 

	fprintf(out, "\n");

	fclose(out);
	return 0;
}

void obs_program(FILE *f1)
{
	state_node *t1;
	INT_S s1, init;
	INT_T *list, slist;
	INT_T *imagelist, s_imagelist;
	INT_S *statemap, s_statemap;
	INT_T e;
	INT_OS ee;
	INT_B  ok;
	INT_B  flag;
	INT_OS result;
	INT_OS mode; 
	INT_B  is_observable;

	t1 = NULL; s1 = 0;
	list = NULL; slist = 0;
	imagelist = NULL; s_imagelist = 0;
	statemap = NULL; s_statemap = 0;
	is_observable = true;

	fscanf(f1, "%d\n", &mode);
	/* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name2[strlen(name2)-1] = '\0';

	flag = false;
	while( fscanf(f1, "%d" , &ee) != EOF)
	{
		e = (INT_T) ee;
		addordlist(e, &list, slist, &ok);
		if (ok) slist++;
	} 
	fclose(f1);
	remove(prm_file);

	init = 0L;
	if(getdes(name1, &s1, &init, &t1) == false){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}
	gen_complement_list(t1, s1,	list, slist, &imagelist, &s_imagelist);
	freedes(s1, &t1); s1 = 0; t1 = NULL;
	

	result = obs_proc(name1,name2,&s1,&t1,slist,list,s_imagelist,imagelist,mode,&is_observable);

	if (result == 0) {       
		ctct_result_obs(CR_OK, s1,t1, is_observable);
		exit(0);       
	} else if (mem_result == 1){
		ctct_result(CR_OUT_OF_MEMORY);
		exit(0);
	} else{
		exit(0);
	}
}

void natobs_program(FILE *f1)
{
	state_node *t1;
	INT_S s1, init;
	INT_T *list, slist;
	INT_T *imagelist, s_imagelist, *ext_imagelist, s_ext_imagelist;
	INT_S *statemap, s_statemap;
	INT_T e;
	INT_OS ee,i;
	INT_B ok;
	INT_OS result;

	t1 = NULL; s1 = 0;
	list = NULL; slist = 0;
	imagelist = ext_imagelist = NULL; s_imagelist = s_ext_imagelist = 0;
	statemap = NULL; s_statemap = 0;

	/* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name2[strlen(name2)-1] = '\0';

	if (fgets(name3, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name3[strlen(name3)-1] = '\0';

	while( fscanf(f1, "%d" , &ee) != EOF)
	{
		e = (INT_T) ee;
		addordlist(e, &imagelist, s_imagelist, &ok);
		if (ok) s_imagelist++;
	} 

	fclose(f1);
	remove(prm_file);

	init = 0L;
	if(getdes(name1, &s1, &init, &t1) == false){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}

	gen_complement_list(t1, s1,	imagelist, s_imagelist, &list, &slist);

	freedes(s1, &t1); s1 = 0; t1 = NULL;

	result = ext_obs_proc(name2, name4, name1, name3, &slist, &list, &s_imagelist, &imagelist,
		&s_ext_imagelist, &ext_imagelist, &s_statemap, &statemap, 1, 0, 3);

	free(list); free(imagelist);  free(statemap);

	if(result == CR_OK){
		s1 = 1;
		t1 = newdes(s1);
		(t1[0]).marked = true;
		for(i = 0; i < s_ext_imagelist; i ++){
			addordlist1(ext_imagelist[i],0, &(t1)[0].next, (t1)[0].numelts, &ok);
			if(ok) (t1)[0].numelts ++;
		}
		if (mem_result != 1)
		{
			init = 0L;
			filedes(name3, s1, init, t1); 
		}
		free(ext_imagelist);
		ctct_result(CR_OK);
		exit(0);

	} else{
		free(ext_imagelist);
		if(mem_result == 1)
			ctct_result(CR_OUT_OF_MEMORY);
		exit(0);

	}
}

void supobs_program(FILE *f1)
{
	INT_T slist, *list;
	INT_T s_imagelist, *imagelist;
	INT_OS mode;
	INT_B ok;
	INT_T e;
	INT_OS ee;
	INT_S init, s1;
	state_node *t1;
	INT_S result;

	slist = s_imagelist = 0;
	list = imagelist = NULL;
	t1 = NULL; s1 = 0;

	result = 0;
	/* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';
	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name2[strlen(name2)-1] = '\0';

	if (fgets(name3, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name3[strlen(name3)-1] = '\0';

	fscanf(f1, "%d\n", &mode);

	while( fscanf(f1, "%d" , &ee) != EOF)
	{
		e = (INT_T)ee;		
		addordlist(e, &list, slist,&ok);
		if(ok) slist ++;
	}

	fclose(f1);
	remove(prm_file);

	init = 0L;
	if(getdes(name1, &s1, &init, &t1) == false){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}
	gen_complement_list(t1, s1,	list, slist, &imagelist, &s_imagelist);
	freedes(s1, &t1); s1 = 0; t1 = NULL;

	if(mode == 1)
		result = supobs_proc1(name3, name1,name2,slist,list,s_imagelist,imagelist);

	if(result != 0){
		if(mem_result == 1)	{			
			ctct_result(CR_OUT_OF_MEMORY);			
		}
		exit(0);
	}
}

void bfs_recode_program(FILE *f1)
{
	state_node *t1;
	INT_S s1, s2, init;
	INT_S *recode_array;

	recode_array = NULL;
	t1 = NULL; 
	s1 = s2 = 0;

	/* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name2[strlen(name2)-1] = '\0';

	fclose(f1);
	remove(prm_file);

	init = 0L;
	if(getdes(name1, &s1, &init, &t1) == false){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}

	reach(&s1,&t1);
	b_recode(s1,&t1,&s2,&recode_array);

	if (mem_result != 1)
	{
		filedes(name2, s2, init, t1); 
	}
	else
	{
		ctct_result(CR_OUT_OF_MEMORY);
		exit(0);
	}
}

void display_program(FILE *f1) 
{
	INT_S result;

	result = 0;

	/* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name2[strlen(name2)-1] = '\0';

	fclose(f1);
	remove(prm_file);

	result = convert_des_program(name1, name2, 0);	

	if(result != 0){
		if(mem_result == 1)	{			
			ctct_result(CR_OUT_OF_MEMORY);			
		}
		exit(0);
	}
}

INT_OS ctct_result_des_parameter(INT_OS result, INT_S s1, state_node *t1, INT_S tran_size, INT_B is_det, INT_B is_contrl)
{
	FILE *out;
	INT_S i,j;

	out = fopen(get_rst_file(), "w");

	if (out == NULL) 
		return -1;       /* Can do not much here so just return */
	fprintf(out, "%d\n", result);

	fprintf(out, "%d\n", s1);

	fprintf(out, "%d\n", tran_size);

	fprintf(out, "%d\n", is_det);

	fprintf(out, "%d\n", is_contrl);

	for (i=0; i < s1; i++){
		for(j = 0; j < t1[i].numelts; j ++){
			fprintf(out, "%d\n%d\n%d\n", i, t1[i].next[j].data1, t1[i].next[j].data2);
		}
	}
	fprintf(out, "-1\n");
	for (i=0; i < s1; i++){
		if(t1[i].marked){
			fprintf(out, "%d\n", i);
		}
	}

	fprintf(out, "\n");

	fclose(out);

	return 0;
}
void getdes_parameter_program(FILE *f1)
{
	state_node *t1;
	INT_S s1, init, tran_size;
	INT_B is_determin, is_controllable;
	int format;

	t1 = NULL; 
	s1 = 0;
	tran_size = -1;

	/* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	fscanf(f1, "%d\n", &format);

	fclose(f1);
	remove(prm_file);

	init = format;    
	if(getdes(name1, &s1, &init, &t1) == false){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}
	if(mem_result == 1){
		ctct_result(CR_OUT_OF_MEMORY);
		exit(0);
	}

	tran_size = count_tran(t1,s1);

	is_determin = is_deterministic(t1,s1);

	if(format == -1)
		is_controllable = compute_controllable(t1, s1);
	else
		is_controllable = 0;

	ctct_result_des_parameter(CR_OK, s1, t1, tran_size, is_determin, is_controllable);
	exit(0);

}

void uncertmod_program(FILE *f1)
{
	state_node *t1, *t2;
	INT_S s1,s2, init;
	INT_T *list, slist;
	INT_T e;
	INT_OS ee;
	INT_B  ok;
	state_map * macrosets; INT_S s_macrosets;
	INT_S i,j, k, ss;

	t1 = t2 = NULL; s1 = s2 = 0;
	list = NULL; slist = 0;
	s_macrosets = 0;
	macrosets = NULL;

	/* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name2[strlen(name2)-1] = '\0';

	while( fscanf(f1, "%d" , &ee) != EOF)
	{
		e = (INT_T) ee;
		addordlist(e, &list, slist, &ok);
		if (ok) slist++;
	}

	fclose(f1);
	remove(prm_file);

	init = 0L;   
	if(getdes(name1, &s1, &init, &t1) == false){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}  

	export_copy_des(&s2, &t2, s1, t1);
	obs_project(&s2, &t2, slist, list, &s_macrosets, &macrosets);
	for(i = 0; i < s_macrosets; i ++){
		for(j = 0; j < macrosets[i].numelts; j ++){
			ss = macrosets[i].next[j];
			for(k = 0; k < t1[ss].numelts; k ++){
				ee = t1[ss].next[k].data1;
				if(inlist((INT_T)ee, list, slist)){
					addordlist1((INT_T)ee,i,&t2[i].next, t2[i].numelts,&ok);
					if(ok) t2[i].numelts ++;
				}
			}
		}
	}

	freedes(s1, &t1); 
	free_map(s_macrosets, &macrosets);
	free(list);

	if (mem_result != 1)
	{
		init = 0L;
		filedes(name2, s2, init, t2);
		freedes(s2, &t2);
	}
	else
	{
		freedes(s2, &t2);
		ctct_result(CR_OUT_OF_MEMORY);
		exit(0);
	}
}

void printdes_program(FILE *f1) 
{
	INT_S result;
	INT_S init;
	FILE *out;
	INT_S s1; state_node *t1;

	s1 = 0; t1 = NULL;

	result = 0;
	/* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name2[strlen(name2)-1] = '\0';

	fclose(f1);
	remove(prm_file);

	init = 0L;		
	if(getdes(name1, &s1, &init, &t1) == false){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}

	make_filename_ext(long_name2, name2, EXT_TXT);
	out = fopen(long_name2, "w");

	print_des_stat_header(out, name1, s1, init);
	fprintf(out, "\n");

	if (num_mark_states(t1, s1) > 0) {
		print_marker_states(out, t1, s1);
	} else {
		fprintf(out, "marker states: none\n");
		fprintf(out, "\n");
	}

	if (num_vocal_output(t1, s1) > 0) {
		print_vocal_output(out, t1, s1);
	} else {
		fprintf(out, "\n");
		fprintf(out, "vocal states: none\n");
		fprintf(out, "\n");
	}

	if (count_tran(t1, s1) > 0) {
		print_transitions(out, t1, s1);
		fprintf(out, "\n");
	} else {
		fprintf(out, "transition table : empty\n");
	}

	fclose(f1);
	freedes(s1, &t1);

	if(result != 0){
		if(mem_result == 1)	{			
			ctct_result(CR_OUT_OF_MEMORY);			
		}
		exit(0);
	}
}

void printdat_program(FILE *f1) 
{
	INT_S result;
	INT_S init;
	FILE *out;
	INT_S s1; state_node *t1;

	s1 = 0; t1 = NULL;

	result = 0;
	/* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name2[strlen(name2)-1] = '\0';

	fclose(f1);
	remove(prm_file);

	init = -1L;
	if(getdes(name1, &s1, &init, &t1) == false){
		ctct_result(CR_DES_FORMAT_ERR);
		exit(0);
	}

	make_filename_ext(long_name2, name2, EXT_TXT);
	out = fopen(long_name2, "w");

	print_dat_header_stat(out, name1, compute_controllable(t1,s1));

	if (count_tran(t1, s1) > 0) {
		print_dat(out, t1, s1);
		fprintf(out, "\n");
	} else {
		fprintf(out, "empty.\n");
	}

	fclose(f1);
	freedes(s1, &t1);

	if(result != 0){
		if(mem_result == 1)	{			
			ctct_result(CR_OUT_OF_MEMORY);			
		}
		exit(0);
	}
}

void localize_event_program(FILE *f1)
{
	INT_OS result;
	INT_S  sloc,i;
//	char names1[MAX_DESS][MAX_FILENAME];
	char names2[MAX_DESS][MAX_FILENAME];  
	INT_T *list, slist;
	INT_T eventlist[1];
	INT_T e;
	INT_OS ee;
	INT_B ok;
	INT_OS mode, is_single;

	result = 0;
	slist = 0;
	list = NULL;

	fscanf(f1, "%d\n", &mode);
	fscanf(f1, "%d\n", &is_single);

	/* Use "fgets" as names could have spaces in it */
	if (fgets(name1, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name1[strlen(name1)-1] = '\0';

	if (fgets(name2, MAX_FILENAME, f1) == NULL)
	{
		fclose(f1);
		remove(prm_file);
		ctct_result(CR_PRM_ERR);
		exit(0);
	}
	name2[strlen(name2)-1] = '\0';

	if(is_single == 1){
		fscanf(f1,"%d\n",&sloc);
		for(i = 0; i < sloc; i ++){
			fscanf(f1, "%d\n" , &ee);
			e = (INT_T) ee;
			addordlist(e, &list, slist, &ok);
			if (ok) slist++;

			if (fgets(names2[i], MAX_FILENAME, f1) == NULL)
			{
				ctct_result(CR_PRM_ERR);
				exit(0);
			}
			names2[i][strlen(names2[i])-1] = '\0';
		}

		if(slist != sloc){
			ctct_result(CR_PRM_ERR);
			exit(0);
		}
	}else
	{
		if (fgets(name3, MAX_FILENAME, f1) == NULL)
		{
			ctct_result(CR_PRM_ERR);
			exit(0);
		}
		name3[strlen(name3)-1] = '\0';
		while( fscanf(f1, "%d" , &ee) != EOF)
		{
			e = (INT_T)ee;		
			addordlist(e, &list, slist,&ok);
			if(ok) slist ++;
		}

	}

	fclose(f1);
	remove(prm_file);

	if(mode == 1){
		if(is_single == 1){
			for(i = 0; i < sloc; i ++){
				eventlist[0] = list[i];
				if(eventlist[0] < EEE)
					result = exlocalize_proc1(name1,name2,names2[i], 1, eventlist, false);
				else{
					result = exlocalize_proc1(name1,name2,names2[i], 0, NULL, false);
				}
			}
		}else
		{
			result = exlocalize_proc1(name1,name2,name3, slist, list, false);
		}
	}else if (mode == 2){
		if(is_single == 1){
			for(i = 0; i < sloc; i ++){
				eventlist[0] = list[i];
				if(eventlist[0] < EEE)
					result = exlocalize_proc_new(name1,name2,names2[i], 1, eventlist, false);
				else{
					//result = exlocalize_proc1(name1,name2,names2[i], 0, NULL, false);
				}
			}
		}else
		{
			result = exlocalize_proc_new(name1,name2,name3, slist, list, false);
		}
	}
	
	free(list);

	if (result != 0)
	{       
		if (mem_result == 1){
			ctct_result(CR_OUT_OF_MEMORY);			
		} 
		exit(0);
	}   
}

///////////////////////////////////////////////////
//Command center
INT_OS cmdline_tct_run(void) {
    FILE *f1;
    INT_OS oper;

    f1 = fopen(get_prm_file(), "r");    
    if (f1 == NULL)
    {
       ctct_result(CR_NO_PRM_FILE);
       return -1;
    }
    
    fscanf(f1, "%d\n", &debug_mode);
    fscanf(f1, "%d\n", &minflag);
    fscanf(f1, "%d\n", &oper);
	switch (oper) {
	case 0 :  create_program(f1);			break;
	case 1 :  selfloop_program(f1);			break;
	case 2 :  trim_program(f1);				break;
	case 3 :  synck_program(f1);			break;
	case 4:   meetk_program(f1);			break;
	case 5 :  supcon_program(f1);			break;
	case 6 :  mutex_program(f1);			break;
	case 7 :  condat_program(f1);			break;
	case 8 :  supreduce_program(f1);		break;
	case 9 :  minstate_program(f1);			break;
	case 10:  complement_program(f1);		break;
	case 11:  localize_program(f1);			break;
	case 12:  force_program(f1);			break;
	case 13:  project_program(f1);			break;
	case 14:  convert_program(f1);			break;
	case 15:  vocalize_program(f1);			break;
	case 16:  outconsis_program(f1);		break;
	case 17:  hiconsis_program(f1);			break;
	case 18:  higen_program(f1);			break;
	case 19:  allevents_program(f1);		break;
	case 20:  supnorm_program(f1);			break;
	case 21:  supscop_program(f1);			break;
	case 22:  supconrobs_program(f1);		break;
	case 23:  canQC_program(f1);			break;
	case 24:  isomorph_program(f1);			break;
	case 25:  nonconflict_program(f1);		break;
	case 26:  obs_program(f1);				break;
	case 27:  natobs_program(f1);			break;
	case 28:  supobs_program(f1);			break;
	case 29:  bfs_recode_program(f1);		break;
	case 30:  display_program(f1);			break;
	case 31:  getdes_parameter_program(f1);	break;
	case 32:  uncertmod_program(f1);		break;
	case 33:  printdes_program(f1);			break;
	case 34:  printdat_program(f1);			break;
	case 35:  localize_event_program(f1);	break;
	default:  break;
	}
    ctct_result(CR_OK); 
    return 0;
}

#ifdef __cplusplus
}
#endif
