#ifndef _CL_TCT_H
#define _CL_TCT_H

#include "setup.h"
#include "des_data.h"
#include "des_proc.h"
#include "tct_proc.h"

#include <dos.h>
#include <io.h>

#define EXT_DES       ".DES"
#define EXT_DAT       ".DAT"
#define EXT_TXT       ".TXT"
#define EXT_PDS       ".PDS"
#define EXT_PDT       ".PDT"
#define EXT_PSS       ".PSS"
#define EXT_PST       ".PST"
#define EXT_ADS       ".ADS"
#define EXT_GIF       ".GIF"
#define EXT_SPL       ".SPL"
#define EXT_CSV       ".CSV"

#define LOC_TEMP_NAME "###"
#define OBS_TEMP_NAME "$$$"


#ifdef __cplusplus
extern "C" {
#endif

extern INT_OS selfloop_runProgram(char *, char *, INT_T, INT_T*);
extern INT_OS trim_runProgram(char *, char *);
extern INT_OS synck_runProgram(char *, INT_OS, char (*)[MAX_FILENAME]);
extern INT_OS meetk_runProgram(char *, INT_OS, char (*)[MAX_FILENAME]);
extern INT_OS supcon_runProgram(char *, char *, char *);
extern INT_OS mutex_runProgram(char *, char *, char *, state_pair *, INT_S);
extern INT_OS condat_runProgram(char *, char *, char *);
extern INT_OS supreduce_runProgram(char *, char *, char *, char *, INT_OS, INT_S*, float*, INT_B);
extern INT_OS minstate_runProgram(char *, char *);
extern INT_OS complement_runProgram(char *, char *, INT_T *, INT_T);
extern INT_OS localize_runProgram(INT_S , INT_S ,char *, char *, char (*)[MAX_FILENAME], char (*)[MAX_FILENAME]);
extern INT_OS force_runProgram(char *, char *, INT_T, INT_T *, INT_T, INT_T *, INT_T);

extern INT_OS project_runProgram(char *, char *, INT_T *, INT_T);
extern INT_OS convert_runProgram(char *, char *, state_pair *, INT_S);

extern INT_OS vocalize_runProgram(char *, char *, quad__t *, INT_S);
extern INT_OS outconsis_runProgram(char *, char *);
extern INT_OS hiconsis_runProgram(char *, char *, INT_B);
extern INT_OS higen_runProgram(char *, char *);
extern INT_OS allevent_runProgram(char *, char *, INT_OS, INT_T, INT_T*);

extern INT_OS supnorm_runProgram(char *, char *, char *, INT_T *, INT_T); 
extern INT_OS supscop_runProgram(char *, char*, char *, INT_T *, INT_T);
extern INT_OS supconrobs_runProgram(char *,char *, char *, INT_T , INT_T *);
extern INT_OS CanQC_runProgram(char *, char*, INT_T, INT_T *, INT_S*, INT_S**, INT_OS);

extern INT_OS isomorph_runProgram(char *, char *, INT_B *, INT_B *, INT_S *, INT_S **);
extern INT_OS nonconflict_runProgram(char *, char *, INT_B *);
extern INT_OS obs_runProgram(char *, char *,INT_S *, state_node **,INT_T , INT_T *,INT_OS , INT_B  *);
extern INT_OS supobs_runProgram(char *,char *, char *, INT_T , INT_T *,  INT_OS);
extern INT_OS uncertmod_runProgram(char *, char *, INT_T *, INT_T);

extern INT_OS bfs_recode_runProgram(char *, char *);

extern INT_OS cmdline_tct_run(void);       

#define  CR_OK            0
#define  CR_NO_PRM_FILE   1
#define  CR_PRM_ERR       2
#define  CR_OUT_OF_MEMORY 3
#define  CR_SUPREDUCE_ERR 4
#define  CR_HICONSIS_ERR  5
#define  CR_VOCAL_ERR     6
#define  CR_DES_FORMAT_ERR            7

#ifdef __cplusplus
}
#endif

#endif
