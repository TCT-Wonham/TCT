/********************************************************************
 *
 * ctct_cl.c - "C" version of TCT using a command-line interface.
 *
 * Author: Pok Lee     (leep@control.toronto.edu)
 *         W.M. Wonham (wonham@control.toronto.edu)
 *
 *
 ********************************************************************/

#include <stdio.h>
#include <time.h>
#include "des_data.h"
#include "des_proc.h"
#include "setup.h"

#if defined(__BORLANDC__)
#include <string.h>
#include <stdlib.h>
#include <conio.h>
#endif

#define  des_filesize   80


/*
 * Create - create a new DES file
 */
void create_main() {
   char        name[des_filesize];    /* Name of DES file              */
   state_node *t1;                    /* Pointer to DES data structure */
   INT_S       s1;                    /* Number of states (t1, s1)     */
   INT_S       i,j;                   /* Tempory variables             */
   INT_T       e;                     /* event label                   */
   INT_S       mark;                  /* Mark state                    */
   INT_BOOL     ok;                    /* Flag                          */

   t1 = NULL;

   printf("CREATE\n");

   /* Enter name of file */
   printf("Enter name of DES ...");
   scanf("%s", &name);

   /* Enter number of states */
   printf("Enter the number of states ... ");
   scanf("%ld", &s1);

   t1 = newdes(s1);
   if (t1 == NULL) {
      fprintf(stderr, "Out of memory.\n");
      return;
   }

   /* Enter list of marker states */
   do {
      printf("Enter marker states ... ");
      scanf("%ld", &mark);
      if (mark != -1L) {
        t1[mark].marked = true;
      }
    } while (mark != -1L);

    /* Enter transitions */
    do {
       printf("Enter transition [i,e,j] ... ");
       scanf("%ld %hu %ld", &i, &e, &j);
       if (i != -1L) {
          addordlist1(e, j, &t1[i].next, t1[i].numelts, &ok);
          if (ok) t1[i].numelts++;
       }
    } while (i != -1L);

    filedes(name, s1, 0L, t1);

    freedes(s1, &t1);
}


/* Trim */
#ifdef _TRIM_
void main() {
#else
void trim_main() {
#endif
   char name1[80], name2[80];
   state_node *t1;
   INT_S s1, init;
   time_t start_time, stop_time, read_time, compute_time;

   t1 = NULL;

   printf("TRIM\n");
   printf("Enter DES1 ... "); scanf("%s", &name1);
   printf("Enter DES2 ... "); scanf("%s", &name2);

   start_time = time(NULL);

   init = 0L;
   if (getdes(name1, &s1, &init, &t1) == false) {
      printf("Problems with reading file %s\n", name1);
      return;
   }

   read_time = time(NULL);

   printf("Reading done\n");
   trim1(&s1,&t1);

   compute_time = time(NULL);

   printf("Computing done\n");
   filedes(name2, s1, init, t1);

   printf("Saving done\n");

   stop_time = time(NULL);

   printf("\n");
   printf("Disk reading time   : %6.0f sec\n", difftime(read_time, start_time));
   printf("CPU computation time: %6.0f sec\n", difftime(compute_time, read_time));
   printf("Disk writing time   : %6.0f sec\n", difftime(stop_time, compute_time));
   printf("Total time          : %6.0f sec\n", difftime(stop_time, start_time));

   freedes(s1, &t1);
}


/*
 * Show - display a DES file to the stdout.
 */
void show_main() {
  char       name[des_filesize];    /* Name of DES file              */
  state_node *t1;                   /* Pointer to DES data structure */
  INT_S      s1;                    /* Number of states (t1, s1)     */
  INT_S      init, i;
  INT_T      j;
  long       nTransitions;
  char       ch;

  printf("SHOW\n");
  printf("Enter DES name ... ");
  scanf("%s", &name);

  init = 0L;
  if (getdes(name, &s1, &init, &t1) == false) {
     printf("Problems with reading file %s\n", name);
     return;
  }

  /* Print a general summary */
  printf("\n");
  printf("%s        # states: %d", name, s1);
  if (s1 > 0L) {
     printf("    state set: 0..%ld     initial state: %ld\n", s1-1L, init);
  } else  {
     printf("    state set: empty      initial state: none\n");
  }

  /* Print a list of marker states */
  printf("\n");
  printf("Marker states:\n");
  for (i=0L; i < s1; i++) {
    if (t1[i].marked)
       printf("%ld ", i);
  }
  printf("\n\n");

  /* Print a list of vocal states */
  printf("Vocal states:\n");
  for (i=0L; i < s1; i++) {
    if (t1[i].vocal != 0)
       printf("[%ld,%hd] ", i, t1[i].vocal);
  }
  printf("\n\n");

  /* Count the number of transitions */
  nTransitions = 0L;
  for (i=0L; i < s1; i++) {
     nTransitions = nTransitions + t1[i].numelts;
  }

  /* Print out the transitions */
  printf("Transitions: %ld\n", nTransitions);

  /* Prompt user to continue */
  getch();

  for (i=0L; i < s1; i++) {
    for (j=0; j < t1[i].numelts; j++) {
       printf("[%ld,%hu,%ld] ", i, t1[i].next[j].data1, t1[i].next[j].data2);
    }
  }
  printf("\n\n");

  freedes(s1, &t1);
}


/*
 * Sync - Synchronous product of two DES files.
 */
void sync_main() {
   char name1[des_filesize], name2[des_filesize], name3[des_filesize];
                               /* Name of DES files              */
   state_node *t1, *t2, *t3;   /* Pointer to DES data structures */
   INT_S s1, s2, s3, init;     /* Size of DES (s1, t1), (s2, t2), (s3, t3) */
   INT_S *macro_ab, *macro_c;
   time_t start_time, stop_time, read_time, compute_time;

   t1 = t2 = t3 = NULL;

   printf("SYNC\n");
   printf("Enter DES1 ... "); scanf("%s", &name1);
   printf("Enter DES2 ... "); scanf("%s", &name2);
   printf("Enter DES3 ... "); scanf("%s", &name3);

   start_time = time(NULL);   /* Record the start time */

   init = 0L;
   if (getdes(name1, &s1, &init, &t1) == false) {
      printf("Problems with reading file %s\n", name1);
      return;
   }

   init = 0L;
   if (getdes(name2, &s2, &init, &t2) == false) {
      printf("Problems with reading file %s\n", name2);
      return;
   }

   read_time = time(NULL);    /* Time to read the files */

   printf("Reading done\n");
   sync2(s1,t1,s2,t2,&s3,&t3,&macro_ab,&macro_c);

   compute_time = time(NULL); /* Time of the actual computation */

   printf("Computing done\n");
   filedes(name3, s3, init, t3);

   printf("Saving done\n");

   stop_time = time(NULL);    /* Stop time */

   /* Print out a run-time summary */
/*   printf("\n");
   printf("Disk reading time: %6.0f sec\n", difftime(read_time, start_time));
   printf("Computation time : %6.0f sec\n", difftime(compute_time, read_time));
   printf("Disk writing time: %6.0f sec\n", difftime(stop_time, compute_time));
   printf("Total time       : %6.0f sec\n", difftime(stop_time, start_time));
*/
   freedes(s1, &t1);
   freedes(s2, &t2);
   freedes(s3, &t3);
}


/*
 * Supcon - supremal controllable of 2 DES file.
 */
void supcon_main() {
   char name1[des_filesize], name2[des_filesize], name3[des_filesize];
   state_node *t1, *t2, *t3;
   INT_S s1, s2, s3, init;
   INT_S *macro_ab, *macro_c;
   time_t start_time, stop_time, read_time, compute_time;

   t1 = t2 = t3 = NULL;

   printf("SUPCON\n");
   printf("Enter DES1 ... "); scanf("%s", &name1);
   printf("Enter DES2 ... "); scanf("%s", &name2);
   printf("Enter DES3 ... "); scanf("%s", &name3);

   start_time = time(NULL);

   init = 0L;
   if (getdes(name1, &s1, &init, &t1) == false) {
      printf("Problems with reading file %s\n", name1);
      return;
   }

   init = 0L;
   if (getdes(name2, &s2, &init, &t2) == false) {
      printf("Problems with reading file %s\n", name2);
      return;
   }

   read_time = time(NULL);

   printf("Reading done\n");

   meet2(s1,t1,s2,t2,&s3,&t3,&macro_ab,&macro_c);
   printf("Meet done %ld\n", s3);
   freedes(s2,&t2);
/*   free(macro_ab); */
   printf("Free some memory done\n");
   trim2(&s3,&t3,macro_c);
   printf("trim done %ld\n", s3);
   shave1(s1,t1,&s3,&t3,macro_c);

   compute_time = time(NULL);

   printf("Computing done\n");
   filedes(name3,s3,init,t3);

   printf("Saving done\n");

   stop_time = time(NULL);    /* Stop time */

   /* Print out a run-time summary */
   printf("\n");
   printf("Disk reading time: %6.0f sec\n", difftime(read_time, start_time));
   printf("Computation time : %6.0f sec\n", difftime(compute_time, read_time));
   printf("Disk writing time: %6.0f sec\n", difftime(stop_time, compute_time));
   printf("Total time       : %6.0f sec\n", difftime(stop_time, start_time));
}


/*
 *  - one DES file.
 */
void selfloop_main() {
   char name1[des_filesize], name2[des_filesize];
   state_node *t1;
   INT_S      s1, init;
   INT_T      *list, slist;
   INT_T      i;
   short      sign_i;
   INT_BOOL    ok;
   time_t     start_time, stop_time, read_time, compute_time;

   t1 = NULL;
   slist = 0; list = NULL;

   printf("SELFLOOP\n");
   printf("Enter DES1 ... "); scanf("%s", &name1);
   printf("Enter DES2 ... "); scanf("%s", &name2);

   printf("Enter list of events to be adjoined.\n");
   do {
      scanf("%hd", &sign_i);
      if (sign_i != -1) {
        i = (INT_T) sign_i;
        addordlist(i, &list, slist, &ok);
        if (ok)
          slist++;
      }
   } while (sign_i != -1);

   start_time = time(NULL);

   init = 0L;
   if (getdes(name1, &s1, &init, &t1) == false) {
      printf("Problems with reading file %s\n", name1);
      return;
   }

   read_time = time(NULL);

   printf("Reading done\n");
   gentran(slist, list, s1, t1);

   compute_time = time(NULL);

   printf("Computing done\n");
   filedes(name2, s1, init, t1);

   printf("Saving done\n");

   stop_time = time(NULL);    /* Stop time */

   /* Print out a run-time summary */
   printf("\n");
   printf("Disk reading time: %6.0f sec\n", difftime(read_time, start_time));
   printf("Computation time : %6.0f sec\n", difftime(compute_time, read_time));
   printf("Disk writing time: %6.0f sec\n", difftime(stop_time, compute_time));
   printf("Total time       : %6.0f sec\n", difftime(stop_time, start_time));

   freedes(s1, &t1);
}


/*
 * Meet - form the meet of two DES
 */
void meet_main() {
   char name1[des_filesize], name2[des_filesize], name3[des_filesize];
   state_node *t1, *t2, *t3;
   INT_S      s1, s2, s3, init;
   INT_S      *macro_ab, *macro_c;
   time_t     start_time, stop_time, read_time, compute_time;

   t1 = t2 = t3 = NULL;

   printf("MEET\n");
   printf("Enter DES1 ... "); scanf("%s", &name1);
   printf("Enter DES2 ... "); scanf("%s", &name2);
   printf("Enter DES3 ... "); scanf("%s", &name3);

   start_time = time(NULL);

   init = 0L;
   if (getdes(name1, &s1, &init, &t1) == false) {
      printf("Problems with reading file %s\n", name1);
      return;
   }

   if (getdes(name2, &s2, &init, &t2) == false) {
      printf("Problems with reading file %s\n", name2);
      return;
   }

   read_time = time(NULL);

   printf("Reading done\n");
   meet2(s1,t1,s2,t2,&s3,&t3,&macro_ab,&macro_c);

   compute_time = time(NULL);

   printf("Computing done\n");
   filedes(name3, s3, init, t3);

   printf("Saving done\n");

   stop_time = time(NULL);    /* Stop time */

   /* Print out a run-time summary */
   printf("\n");
   printf("Disk reading time: %6.0f sec\n", difftime(read_time, start_time));
   printf("Computation time : %6.0f sec\n", difftime(compute_time, read_time));
   printf("Disk writing time: %6.0f sec\n", difftime(stop_time, compute_time));
   printf("Total time       : %6.0f sec\n", difftime(stop_time, start_time));

/*   freedes(s1, &t1);
   freedes(s2, &t2);
   freedes(s3, &t3); */
}


/*
 * BUF Generator - generate DES file based on the formula ...
 */
void bufgen_main() {
   char       name[des_filesize];
   state_node *t1;
   INT_S      s1, sbuf, i, j;
   INT_T      e, *list, slist;
   INT_BOOL    ok;

   t1 = NULL;

   printf("CREATE BUF_X\n");

   /* Enter X */
   printf("Enter the BUF_X number: ");
   scanf("%d", &sbuf);

   s1 = sbuf+1;

   t1 = newdes(s1);
   t1[0].marked = true;

   if (t1 == NULL) {
      fprintf(stderr, "Out of memory\n");
      return;
   }

   for (i=0; i < sbuf; i++) {
     for (j=1; j< s1; j++) {
        e = j*10;
        addordlist1(e,i+1, &t1[i].next, t1[i].numelts, &ok);
        if (ok) t1[i].numelts++;
     }
   }

   for (i=1; i <= sbuf; i++) {
     for (j=sbuf+1; j <= sbuf*2; j++) {
       e = j*10+1;
       addordlist1(e,i-1L,&t1[i].next, t1[i].numelts, &ok);
       if (ok) t1[i].numelts++;
     }
   }

   slist = 0; list = NULL;
   for (i=1; i <= sbuf; i++) {
     e = i*10+1;
     addordlist(e, &list, slist, &ok);
     if (ok) slist++;
   }

   for (i=sbuf+1; i <= sbuf*2; i++) {
     e = i*10;
     addordlist(e, &list, slist, &ok);
     if (ok) slist++;
   }

   gentran(slist, list, s1, t1);

   sprintf(name, "buf%d", sbuf);
   filedes(name, s1, 0L, t1);
}


/*
 * Machgen - generate "N" DES files.
 */
void machgen_main() {
   char name[des_filesize];
   state_node *t;
   INT_S      s;
   INT_S      i, size;
   INT_BOOL ok;

   printf("Enter number of machines: ");
   scanf("%ld", &size);

   for (i=1; i <= size; i++) {
     sprintf(name, "mach%d", i);

     s = 2;
     t = newdes(s);

     t[0].marked = true;
     addordlist1(i*10+1, 1, &t[0].next, t[0].numelts, &ok);
     t[0].numelts = 1;
     addordlist1(i*10, 0, &t[1].next, t[1].numelts, &ok);
     t[1].numelts = 1;

     filedes(name, s, 0L, t);
     freedes(s, &t);
   }
}


/*
 * Condat
 */
void condat_main() {
   char name1[des_filesize], name2[des_filesize], name3[des_filesize];
   state_node *t1, *t2, *t3, *t4;
   INT_S      s1, s2, s3, s4, init;
   INT_S      *macro_ab, *macro_c;
   time_t     start_time, stop_time, read_time, compute_time;

   t1 = t2 = t3 = t4 = NULL;

   printf("CONDAT\n");
   printf("Enter DES1 ... "); scanf("%s", &name1);
   printf("Enter DES2 ... "); scanf("%s", &name2);
   printf("Enter DES3 ... "); scanf("%s", &name3);

   start_time = time(NULL);

   init = 0L;
   if (getdes(name1, &s1, &init, &t1) == false) {
      printf("Problems with reading file %s\n", name1);
      return;
   }

   if (getdes(name2, &s2, &init, &t2) == false) {
      printf("Problems with reading file %s\n", name2);
      return;
   }

   read_time = time(NULL);

   printf("Reading done\n");

   meet2(s1,t1,s2,t2,&s3,&t3,&macro_ab,&macro_c);
   printf("Meet done\n");
   freedes(s2, &t2);
   free(macro_ab);
   printf("Free some memory done\n");
   condat1(t1,s1,s2,s3,t3,&s4,&t4,macro_c);

   compute_time = time(NULL);

   printf("Computing done\n");
   filedes(name3,s4,-1L,t4);

   printf("Saving done\n");

   stop_time = time(NULL);    /* Stop time */

   /* Print out a run-time summary */
   printf("\n");
   printf("Disk reading time: %6.0f sec\n", difftime(read_time, start_time));
   printf("Computation time : %6.0f sec\n", difftime(compute_time, read_time));
   printf("Disk writing time: %6.0f sec\n", difftime(stop_time, compute_time));
   printf("Total time       : %6.0f sec\n", difftime(stop_time, start_time));
}


/*
 * Show DAT file
 */
void showdat_main() {
  char       name[des_filesize];
  state_node *t1;
  INT_S      s1, init;
  INT_S      i;
  INT_T      j;
  long       nTransitions;
  char       ch;

  printf("SHOW DAT\n");

  printf("Enter DAT name ... ");
  scanf("%s", &name);

  init = -1L;
  if (getdes(name, &s1, &init, &t1) == false) {
     printf("Problems with reading file %s\n", name);
     return;
  }

  printf("\n");
  printf("Control data are displayed as a list of supervisor states\n");
  printf("where disabling occurs, together with the events that must\n");
  printf("be disabled there.\n\n");
  printf("control data: ");

  /* Count the number of transitions */
  nTransitions = 0L;
  for (i=0L; i < s1; i++) {
     nTransitions = nTransitions + t1[i].numelts;
  }

  if (nTransitions == 0) {
     printf("empty\n.");
  } else {
     printf("\n");
     for (i=0; i < s1; i++) {
       if (t1[i].numelts > 0) {
          printf("%7ld: ", i);
          for (j=0; j < t1[i].numelts; j++) {
             printf("%d ", t1[i].next[j].data1);
          }
          printf("\n");
       }
     }
  }

  freedes(s1, &t1);
}


/*
 * Recode - reachability and breadth first search recoding.
 */
void recode_main() {
   char       name1[des_filesize], name2[des_filesize];
   state_node *t1;
   INT_S      s1, s2, init;
   INT_S      *recode_array;
   time_t     start_time, stop_time, read_time, compute_time;

   t1 = NULL;

   printf("Reachability and breadth first search recoding\n");
   printf("Enter DES1 ... "); scanf("%s", &name1);
   printf("Enter DES2 ... "); scanf("%s", &name2);

   start_time = time(NULL);

   init = 0L;
   if (getdes(name1, &s1, &init, &t1) == false) {
      printf("Problems with reading file %s\n", name1);
      return;
   }

   read_time = time(NULL);

   printf("Reading done\n");
   b_recode(s1,&t1,&s2,&recode_array);

   compute_time = time(NULL);

   printf("Computing done\n");
   filedes(name2, s2, init, t1);

   printf("Saving done\n");

   stop_time = time(NULL);    /* Stop time */

   /* Print out a run-time summary */
   printf("\n");
   printf("Disk reading time: %6.0f sec\n", difftime(read_time, start_time));
   printf("Computation time : %6.0f sec\n", difftime(compute_time, read_time));
   printf("Disk writing time: %6.0f sec\n", difftime(stop_time, compute_time));
   printf("Total time       : %6.0f sec\n", difftime(stop_time, start_time));
}


/*
 * Complement
 */
void complement_main()
{
   char       name1[des_filesize], name2[des_filesize];
   state_node *t1;
   INT_S      s1, init;
   INT_T      *list, slist;
   INT_T      i;
   short      sign_i;
   INT_BOOL    ok;
   time_t     start_time, stop_time, read_time, compute_time;

   slist = 0;  list = NULL;
   t1 = NULL;

   printf("COMPLEMENT\n");
   printf("Enter DES1 ... "); scanf("%s", &name1);
   printf("Enter DES2 ... "); scanf("%s", &name2);

   /* Get auxiliary information */
   printf("Enter auxiliary LIST of event labels not in DES1.\n");
   do {
      scanf("%hd", &sign_i);
      if (sign_i != -1) {
        i = (INT_T) sign_i;
        addordlist(i, &list, slist, &ok);
        if (ok) slist++;
      }
   } while (sign_i != -1);

   start_time = time(NULL);

   init = 0L;
   if (getdes(name1, &s1, &init, &t1) == false) {
      printf("Problems with reading file %s\n", name1);
      return;
   }

   read_time = time(NULL);

   printf("Reading done\n");

   /* Do some work here */
   complement1(&s1, &t1, slist, list);
   reach(&s1, &t1);

   compute_time = time(NULL);

   printf("Computing done\n");
   filedes(name2, s1, init, t1);

   printf("Saving done\n");

   stop_time = time(NULL);    /* Stop time */

   /* Print out a run-time summary */
   printf("\n");
   printf("Disk reading time: %6.0f sec\n", difftime(read_time, start_time));
   printf("Computation time : %6.0f sec\n", difftime(compute_time, read_time));
   printf("Disk writing time: %6.0f sec\n", difftime(stop_time, compute_time));
   printf("Total time       : %6.0f sec\n", difftime(stop_time, start_time));
}


/*
 * Minstate
 */
void minstate_main()
{
   char       name1[des_filesize], name2[des_filesize];
   state_node *t1;
   INT_S      s1, init;
   INT_BOOL    ok;
   time_t     start_time, stop_time, read_time, compute_time;

   t1 = NULL;

   printf("MINSTATE\n");
   printf("Enter DES1 ... "); scanf("%s", &name1);
   printf("Enter DES2 ... "); scanf("%s", &name2);

   start_time = time(NULL);

   init = 0L;
   if (getdes(name1, &s1, &init, &t1) == false) {
      printf("Problems with reading file %s\n", name1);
      return;
   }

   read_time = time(NULL);

   printf("Reading done\n");

   /* Do some work here */
   reach(&s1, &t1);
   minimize(&s1, &t1);

   compute_time = time(NULL);

   printf("Computing done\n");
   filedes(name2, s1, init, t1);

   printf("Saving done\n");

   stop_time = time(NULL);    /* Stop time */

   /* Print out a run-time summary */
   printf("\n");
   printf("Disk reading time: %6.0f sec\n", difftime(read_time, start_time));
   printf("Computation time : %6.0f sec\n", difftime(compute_time, read_time));
   printf("Disk writing time: %6.0f sec\n", difftime(stop_time, compute_time));
   printf("Total time       : %6.0f sec\n", difftime(stop_time, start_time));
}


/*
 * Project
 */
void project_main()
{
   char       name1[des_filesize], name2[des_filesize];
   state_node *t1;
   INT_S      s1, init;
   INT_T      *list, slist;
   INT_T      i;
   short      sign_i;
   INT_BOOL    ok;
   time_t     start_time, stop_time, read_time, compute_time;

   t1 = NULL;

   printf("PROJECT\n");
   printf("Enter DES1 ... "); scanf("%s", &name1);
   printf("Enter DES2 ... "); scanf("%s", &name2);

   /* Get auxiliary information */
   printf("Enter auxiliary LIST of event labels not in DES1.\n");
   do {
      scanf("%hd", &sign_i);
      if (sign_i != -1) {
        i = (INT_T) sign_i;
        addordlist(i, &list, slist, &ok);
        if (ok)
          slist++;
      }
   } while (sign_i != -1);

   start_time = time(NULL);

   init = 0L;
   if (getdes(name1, &s1, &init, &t1) == false) {
      printf("Problems with reading file %s\n", name1);
      return;
   }

   read_time = time(NULL);

   printf("Reading done\n");

   /* Do some work here */
   if (slist == 0) {
      reach(&s1, &t1);
      minimize(&s1, &t1);
   } else {
      project1(&s1,&t1,slist,list);
      if (s1 > 1) {
         reach(&s1, &t1);
         minimize(&s1,&t1);
      }
   }

   /* Computation work ends here */
   compute_time = time(NULL);

   printf("Computing done\n");
   filedes(name2, s1, init, t1);

   printf("Saving done\n");

   stop_time = time(NULL);    /* Stop time */

   /* Print out a run-time summary */
   printf("\n");
   printf("Disk reading time: %6.0f sec\n", difftime(read_time, start_time));
   printf("Computation time : %6.0f sec\n", difftime(compute_time, read_time));
   printf("Disk writing time: %6.0f sec\n", difftime(stop_time, compute_time));
   printf("Total time       : %6.0f sec\n", difftime(stop_time, start_time));
}


/*
 * Mutex
 */
void mutex_main()
{
   char name1[des_filesize], name2[des_filesize], name3[des_filesize];
   state_node *t1, *t2, *t3;
   INT_S s1, s2, s3, init;
   state_pair *sp;
   INT_S s_sp, i, j;
   INT_BOOL ok;
   INT_S *macro_ab, *macro_c;
   time_t start_time, stop_time, read_time, compute_time;

   t1 = t2 = t3 = NULL;

   sp = NULL; s_sp = 0;

   printf("MUTEX\n");
   printf("Enter DES1 ... "); scanf("%s", &name1);
   printf("Enter DES2 ... "); scanf("%s", &name2);
   printf("Enter DES3 ... "); scanf("%s", &name3);

   /* Enter list of state pair */
   do {
      printf("Enter excluded state pair [i,j] ... ");
      scanf("%ld %ld", &i, &j);
      if (i != -1L) {
         addstatepair(i,j, &sp, s_sp, &ok);
         if (ok) s_sp++;
       }
   } while (i != -1L);

   start_time = time(NULL);   /* Record the start time */

   init = 0L;
   if (getdes(name1, &s1, &init, &t1) == false) {
      printf("Problems with reading file %s\n", name1);
      return;
   }

   init = 0L;
   if (getdes(name2, &s2, &init, &t2) == false) {
      printf("Problems with reading file %s\n", name2);
      return;
   }

   read_time = time(NULL);    /* Time to read the files */

   printf("Reading done\n");

   /* Do work here */
   sync2(s1,t1,s2,t2,&s3,&t3,&macro_ab,&macro_c);
/*   free(macro_c); */
   mutex1(&s3,&t3,s1,s2,macro_ab,sp,s_sp);
   reach(&s3,&t3);

   compute_time = time(NULL); /* Time of the actual computation */

   printf("Computing done\n");
   filedes(name3, s3, init, t3);

   printf("Saving done\n");

   stop_time = time(NULL);    /* Stop time */

   /* Print out a run-time summary */
   printf("\n");
   printf("Disk reading time   : %6.0f sec\n", difftime(read_time, start_time));
   printf("CPU computation time: %6.0f sec\n", difftime(compute_time, read_time));
   printf("Disk writing time   : %6.0f sec\n", difftime(stop_time, compute_time));
   printf("Total time          : %6.0f sec\n", difftime(stop_time, start_time));
}


INT_BOOL nonconflict(s,t)
INT_S s;
state_node *t;
{
   INT_S state;

   if (s==0) return true;

   for (state=0; state < s; state++) {
     if (t[state].marked) {
        t[state].reached = true;
        b_reach(t[state].next, state, &t, s);
     }
   }

   for (state=0; state < s; state++) {
      if (!t[state].reached) {
        return false;
      }
   }
   return true;
}

/*
 * Nonconflict
 */
void nonconflict_main()
{
   char name1[des_filesize], name2[des_filesize];
   state_node *t1, *t2, *t3;
   INT_S      s1, s2, s3, init;
   INT_S      *macro_ab, *macro_c;
   INT_BOOL    flag;
   time_t     start_time, stop_time, read_time, compute_time;

   t1 = t2 = t3 = NULL;

   printf("NONCONFLICT\n");
   printf("Enter DES1 ... "); scanf("%s", &name1);
   printf("Enter DES2 ... "); scanf("%s", &name2);

   start_time = time(NULL);   /* Record the start time */

   init = 0L;
   if (getdes(name1, &s1, &init, &t1) == false) {
      printf("Problems with reading file %s\n", name1);
      return;
   }

   init = 0L;
   if (getdes(name2, &s2, &init, &t2) == false) {
      printf("Problems with reading file %s\n", name2);
      return;
   }

   read_time = time(NULL);    /* Time to read the files */

   printf("Reading done\n");

   /* Do work here */
   meet2(s1, t1, s2, t2, &s3, &t3, &macro_ab, &macro_c);
   free(macro_ab);
   free(macro_c);
   flag = nonconflict(s3,t3);

   compute_time = time(NULL); /* Time of the actual computation */

   printf("Computing done\n");

   stop_time = time(NULL);    /* Stop time */

   if (flag)
      printf("%s and %s are NONCONFLICTING", name1, name2);
   else
      printf("%s and %s are CONFLICTING!", name1, name2);

   /* Print out a run-time summary */
   printf("\n");
   printf("Disk reading time: %6.0f sec\n", difftime(read_time, start_time));
   printf("Computation time : %6.0f sec\n", difftime(compute_time, read_time));
   printf("Total time       : %6.0f sec\n", difftime(stop_time, start_time));
}

/* INT_S num_marked(s, t)
INT_S s;
state_node *t;
{
   INT_S i, count;

   count = 0;
   for (i=0; i < s; i++) {
      if (t[i].marked) count++;
   }
   return count;
}
*/

INT_S num_tran(s, t)
INT_S s;
state_node *t;
{
   INT_S i, count;

   count = 0;
   for (i=0; i < s; i++)
     count += t[i].numelts;
   return count;
}


/* void iso1(s1, s2, t1, t2, inflag,mapState)
INT_S s1, s2;
state_node *t1, *t2;
INT_BOOL *inflag;
INT_S *mapState;
{
   state_pair *iEj;
   INT_S s_iEj;
   ** Pre-conditions:
      Same number of states.
      Same number of transitions.
      Same number of marker states.
      Same number of vocal states
   **
   INT_BOOL flag, equal;
   INT_S count1, count2;
   INT_S t1i, t2j;

   iEj = NULL;
   s_iEj = 0;

   flag = (s1 == s2);
   if (flag) {
      count1 = num_marked(s1, t1);
      count2 = num_marked(s2, t2);
      flag = (count1 == count2);
   }
   if (flag) {
      count1 = num_tran(s1, t1);
      count2 = num_tran(s2, t2);
      flag = (count1 == count2);
   }
   if (flag) {
      if ((s1 == 0) && (s2 == 0)) {
         flag = true;
      } else {
         equal = false;
         if (iEj != NULL) {
            free(iEj); iEj = NULL; s_iEj = 0;
         }
         compare_states(0L,0L,&equal,mapState,&iEj,&s_iEj,t1,t2);
         if (equal) {
            mapState[0] = 0;
            t1i = 1;
            while ((t1i < s1) && equal) {
              if (!t1[t1i].reached) {
                 equal = false;
                 t2j = 1;
                 while ((t2j < s2) && (!equal)) {
                    if (!t2[t2j].reached) {
                        if (iEj != NULL) {
                           free(iEj); iEj = NULL; s_iEj = 0;
                        }
                        compare_states(t1i,t2j,&equal,mapState,&iEj,&s_iEj,t1,t2);

                        if (equal) {
                           mapState[t1i] = t2j;
                           t1[t1i].reached = true;
                           t2[t2j].reached = true;
                           t1i++;
                           t2j = 1;
                        } else {
                           t2j++;
                        }
                    } else {
                        t2j++;
                    }
                 }
              } else {
                 t1i++;
              }
            }
         }
         flag = equal;
      }
   }

   *inflag = flag;
   if (iEj != NULL) {
      free(iEj); iEj = NULL; s_iEj = 0;
   }
}
*/

void printlist1(s1,t1,flag,mapState)
INT_S s1;
state_node *t1;
INT_BOOL *flag;
INT_S *mapState;
{
   INT_S i;

   if (s1 == 0) return;

   for (i=0; i < s1; i++) {
     if (mapState[i] != i) {
       *flag = false;
       printf("[%ld,%ld] ", i, mapState[i]);
     }
   }
   printf("\n");
}


/*
 *  Isomorphic
 */
void isomorph_main()
{
   char name1[des_filesize], name2[des_filesize];
   state_node *t1, *t2;
   INT_S      s1, s2, init;
   time_t     start_time, stop_time, read_time, compute_time;
   INT_BOOL    identity, is_iso, flag;
   INT_S      *mapState;

   mapState = NULL;
   t1 = t2 = NULL;

   printf("ISOMORPH\n");
   printf("Enter DES1 ... "); scanf("%s", &name1);
   printf("Enter DES2 ... "); scanf("%s", &name2);

   start_time = time(NULL);   /* Record the start time */

   init = 0L;
   if (getdes(name1, &s1, &init, &t1) == false) {
      printf("Problems with reading file %s\n", name1);
      return;
   }

   init = 0L;
   if (getdes(name2, &s2, &init, &t2) == false) {
      printf("Problems with reading file %s\n", name2);
      return;
   }

   read_time = time(NULL);    /* Time to read the files */

   printf("Reading done\n");

   /* Do work here */
   identity = false;
   is_iso   = false;
   flag     = false;

   if ( (stricmp(name1,name2) == 0) || ((s1 == 0) && (s2 == 0)) ) {
     is_iso   = true;
     identity = true;
   } else {
     /* Need some memory here */
     /* Allocate map state */
     mapState = (INT_S*) calloc(s1, sizeof(INT_S));
     if (mapState == NULL) {
       printf("Out of memory\n");
       exit(1);
     }
     memset(mapState, -1, sizeof(INT_S)*s1);

     flag = true;
     iso1(s1, s2, t1, t2, &flag, mapState);
     if (flag) is_iso = true;
   }

   compute_time = time(NULL); /* Time of the actual computation */

   printf("Computing done\n");

   stop_time = time(NULL);    /* Stop time */

   /* Output the answer */
   if (is_iso) {
      printf("%s and %s are isomorphic, under state correspondence\n\n",
              name1, name2);
      if (flag) {
         printlist1(s1,t1,&flag,mapState);
         if (flag) {
            printf("   IDENTITY\n");
            identity = true;
         }
      } else {
         printf("   IDENTITY\n");
      }
   } else {
      printf("%s and %s are not isomorphic\n",name1,name2);
   }

   /* Print out a run-time summary */
   printf("\n");
   printf("Disk reading time: %6.0f sec\n", difftime(read_time, start_time));
   printf("Computation time : %6.0f sec\n", difftime(compute_time, read_time));
   printf("Total time       : %6.0f sec\n", difftime(stop_time, start_time));
}


/*
 *  Check if the DES file is deterministics.
 */
void checkdet_main()
{
   char name1[des_filesize];
   state_node *t1;
   INT_S s1, init;
   time_t start_time, stop_time, read_time, compute_time;
   INT_BOOL det;

   t1 = NULL;

   printf("CHECK DETERMINISM\n");
   printf("Enter DES1 ... "); scanf("%s", &name1);

   start_time = time(NULL);   /* Record the start time */

   init = 0L;
   if (getdes(name1, &s1, &init, &t1) == false) {
      printf("Problems with reading file %s\n", name1);
      return;
   }

   read_time = time(NULL);    /* Time to read the files */

   printf("Reading done\n");

   /* Do work here */
   det = checkdet(s1,t1);

   compute_time = time(NULL); /* Time of the actual computation */
   printf("\n");
   if (det)
     printf("Deterministic\n");
   else
     printf("Non-deterministic\n");
   printf("\n");

   printf("Computing done\n");

   stop_time = time(NULL);    /* Stop time */

   /* Output the answer */

   /* Print out a run-time summary */
   printf("\n");
   printf("Disk reading time   : %6.0f sec\n", difftime(read_time, start_time));
   printf("Computation time: %6.0f sec\n", difftime(compute_time, read_time));
   printf("Total time          : %6.0f sec\n", difftime(stop_time, start_time));
}


/*
 * CTCT main program
 */
void main() {
  short operation;

  strcpy(path,"");
  strcpy(prefix, "");

  operation = -1;
  printf("CTCT 960316\n\n");
  while (operation == -1) {
    printf("(0)  quit\n");
    printf("(1)  create\n");
    printf("(2)  show\n");
    printf("(3)  sync\n");
    printf("(4)  selfloop\n");
    printf("(5)  trim\n");
    printf("(6)  meet\n");
    printf("(7)  supcon\n");
    printf("(8)  bufgen\n");
    printf("(9)  machgen\n");
    printf("(10) condat\n");
    printf("(11) showdat\n");
    printf("(12) reach and recode\n");
    printf("(13) complement\n");
    printf("(14) minstate\n");
    printf("(15) project\n");
    printf("(16) mutex\n");
    printf("(17) nonconflict\n");
    printf("(18) isomorph\n");
    printf("(19) check determinism\n");

    printf("Enter choice: "); scanf("%hd", &operation);
    if ( ! ((0 <= operation) && (operation <= 19)) ) {
       operation = -1;
    }
  }

  switch (operation) {
    case 0:  exit(0);            break;
    case 1:  create_main();      break;
    case 2:  show_main();        break;
    case 3:  sync_main();        break;
    case 4:  selfloop_main();    break;
    case 5:  trim_main();        break;
    case 6:  meet_main();        break;
    case 7:  supcon_main();      break;
    case 8:  bufgen_main();      break;
    case 9:  machgen_main();     break;
    case 10: condat_main();      break;
    case 11: showdat_main();     break;
    case 12: recode_main();      break;
    case 13: complement_main();  break;
    case 14: minstate_main();    break;
    case 15: project_main();     break;
    case 16: mutex_main();       break;
    case 17: nonconflict_main(); break;
    case 18: isomorph_main();    break;
    case 19: checkdet_main();    break;
  }
}

