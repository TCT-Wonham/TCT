#include"des_convert.h"
#include "display.h"
#include <stdio.h>
#include <direct.h>
#include <stdlib.h>
#include <string.h>
#include "curses.h"
#include "tct_io.h"
#include <io.h>
#include "ads2des.h"
#include "des_data.h"
#include "setup.h"
#include <ctype.h>
#include <time.h>
#include "mymalloc.h"
#include"tct_proc.h"


#include <dos.h>


#ifdef __cplusplus
extern "C" {
#endif
static time_t curTime;

// Combine together the transitions that have the same source and target states
//zry:2014.07.16

// Find event index
INT_S state_getindex(INT_S e, INT_S *L, INT_S size)
{
	INT_S k;

	for(k = 0; k < size; k ++){
		if(e == L[k])
			return k;
	}

	return -1;
}

// Version with the entering arrow added at state 0 to indicate initial
INT_OS GenerateTxtFile(INT_S s1,state_node *t1, char * txtFilename,char *desName, INT_B color_flag)
{
    char txtFile_fullname[MAX_PATH];
    char txttime[30]; char strtime[30];
    FILE *txt;
    INT_S i,j;
//    int ti;    
    struct tm *ts;
    INT_S entr;
    INT_T event;
	INT_B flag_mark;
	char eventlabel[WIDTH_EVENT];


    strcpy(txtFile_fullname,txtFilename);
    
    txt = fopen(txtFile_fullname,"w");
    //tmp = fopen("Transition.txt", "w");
    if(txt == NULL)
           return 0;
     curTime = time(NULL);     
     ts = localtime(&curTime);  
   strcpy(txttime,"");
   strcpy(strtime,"");
   fprintf(txt,"digraph finite_state_machine {\n");
   fprintf(txt,"graph [label = \"");
   fprintf(txt,"\\n\\nDES ");
   fprintf(txt,"%s \\n",desName);
   sprintf(txttime,"%4d.",ts->tm_year+1900);
   strcat(strtime,txttime);
   if(ts->tm_mon + 1 > 9 )
     sprintf(txttime,"%2d.",ts->tm_mon + 1);
   else
     sprintf(txttime,"0%d.",ts->tm_mon + 1);
   strcat(strtime,txttime);
   if(ts->tm_mday > 9 )
     sprintf(txttime,"%2d/",ts->tm_mday);
   else
     sprintf(txttime,"0%d/",ts->tm_mday);
   strcat(strtime,txttime);
   if(ts->tm_hour > 9 )
     sprintf(txttime,"%2d:",ts->tm_hour);
   else
     sprintf(txttime,"0%d:",ts->tm_hour);
   strcat(strtime,txttime);
   if(ts->tm_min > 9 )
     sprintf(txttime,"%2d ",ts->tm_min);
   else
     sprintf(txttime,"0%d ",ts->tm_min);
   strcat(strtime,txttime);

   fprintf(txt,"%s \"",strtime);
   fseek(txt,ftell(txt)-2,SEEK_SET);
   fprintf(txt,"\"];\n");
   fprintf(txt,"rankdir=LR;\n");
   fprintf(txt,"node [shape = doublecircle]; ");
   
   flag_mark = false;
   for(i=0;i<s1;i++){
       if(t1[i].marked == true){
          fprintf(txt,"%d ",i);
		  flag_mark = true;
	   }
   }
   if(flag_mark)
       fprintf(txt,";\n");

   if(s1 == 0){
	   fprintf(txt,"}");
	   fclose(txt);
	   return 1;
   }

   fprintf(txt, "a [shape = point, color = white];\n");
   fprintf(txt,"node [shape = circle];\n");
   //Add the entering arrow to state 0 to indicate initial
   //fprintf(txt, "a [color = white, fontsize = 0.1, fontcolor = white, length = 0.3, width = 0.3, fixedsize = true];\n");
   if(color_flag == 1)
	   fprintf(txt, "a -> 0 [color = red];\n");     
   else
	   fprintf(txt, "a -> 0;\n");    

   if(s1 == 1 && t1[0].numelts == 0){
	   fprintf(txt, "%d", 0);
   }

   for(i=0;i<s1;i++){
        for(j=0;j<t1[i].numelts;j++){
            fprintf(txt,"%d -> ",i);
            entr = t1[i].next[j].data2;
            event = t1[i].next[j].data1;
			get_strlabel_by_intlabel(event, eventlabel);
            fprintf(txt,"%d  [ label = \"",entr);	

			if(event < 2000){

			if(event != EEE){
				if(t1[entr].vocal >= 1 && t1[entr].vocal <= MAX_VOCAL_OUTPUT){
					fprintf(txt,"%d/%d",event,t1[entr].vocal);
				} else{
					fprintf(txt,"%d",event); 
				}    
			} else{
				if(t1[entr].vocal >= 1 && t1[entr].vocal <= MAX_VOCAL_OUTPUT){
					fprintf(txt,"/%d",t1[entr].vocal);
				} else{
                     //fprintf(txt," \" ];\n"); 
				} 
			}  
			}else
			{
				if(t1[entr].vocal >= 1 && t1[entr].vocal <= MAX_VOCAL_OUTPUT){
					fprintf(txt,"%s/%d",eventlabel,t1[entr].vocal);
				} else{
					fprintf(txt,"%s",eventlabel); 
				} 
			}
			fprintf(txt, "\"");
			if(color_flag == 1){
				if(event %2 == 1){
					fprintf(txt, ",color = red");
					//fprintf(txt, ",color = red, fontcolor = red");
				}else{
					fprintf(txt, ",color = green");
					//fprintf(txt, ",color = green, fontcolor = green");
				}
			}
			fprintf(txt, " ];\n");
	
        } 
   }
   fprintf(txt,"}");
   fclose(txt);

   return 1;
}
// the version with 1) the entering arrow added at state 0 to indicate initial; and (2) the (sometimes)
//	improved labeling of multiple events by using a single transition arrow
//	with the appropriate string of labels written above it.
INT_OS second_GenerateTxtFile(INT_S s1,state_node *t1, char * txtFilename,char *desName, INT_T showevent)
{
    char txtFile_fullname[MAX_PATH];
    char txttime[30]; char strtime[30];
    FILE *txt;
    INT_S i,j,k;
//    int ti;    
    struct tm *ts;
    INT_S targ,voc;
    INT_T event;
	INT_S s_list, *list;
	part_node *par;
	INT_B ok;

	s_list = 0; list = NULL; par = NULL; //Here we use s_list to represent the size of list and par since they have the same size, 

    strcpy(txtFile_fullname,txtFilename);
    
    txt = fopen(txtFile_fullname,"w");
    //tmp = fopen("Transition.txt", "w");
    if(txt == NULL)
           return 0;
     curTime = time(NULL);     
     ts = localtime(&curTime);  
   strcpy(txttime,"");
   strcpy(strtime,"");
   fprintf(txt,"digraph finite_state_machine {\n");
   fprintf(txt,"graph [label = \"");
   fprintf(txt,"\\n\\nDES ");
   fprintf(txt,"%s \\n",desName);
   sprintf(txttime,"%4d.",ts->tm_year+1900);
   strcat(strtime,txttime);
   if(ts->tm_mon + 1 > 9 )
     sprintf(txttime,"%2d.",ts->tm_mon + 1);
   else
     sprintf(txttime,"0%d.",ts->tm_mon + 1);
   strcat(strtime,txttime);
   if(ts->tm_mday > 9 )
     sprintf(txttime,"%2d/",ts->tm_mday);
   else
     sprintf(txttime,"0%d/",ts->tm_mday);
   strcat(strtime,txttime);
   if(ts->tm_hour > 9 )
     sprintf(txttime,"%2d:",ts->tm_hour);
   else
     sprintf(txttime,"0%d:",ts->tm_hour);
   strcat(strtime,txttime);
   if(ts->tm_min > 9 )
     sprintf(txttime,"%2d ",ts->tm_min);
   else
     sprintf(txttime,"0%d ",ts->tm_min);
   strcat(strtime,txttime);

   fprintf(txt,"%s \"",strtime);
   fseek(txt,ftell(txt)-2,SEEK_SET);
   fprintf(txt,"\"];\n");
   fprintf(txt,"rankdir=LR;\n");
   fprintf(txt,"overlap=scale;\n");
   fprintf(txt,"node [shape = doublecircle]; ");
   
   for(i=0;i<s1;i++){
       if(t1[i].marked == true)
          fprintf(txt,"%d ",i);
   }
   fprintf(txt,";\n");
   fprintf(txt,"node [shape = circle];\n");
   fprintf(txt, "a [color = white, fontcolor = white, length = 0, width = 0, fixedsize = true];\n");
   fprintf(txt, "a -> 0  [ label = \" \"];\n");   
   if(s1 == 1 && t1[0].numelts == 0){
	   fprintf(txt, "%d", 0);
   }

   for(i=0;i<s1;i++){
        for(j=0;j<t1[i].numelts;j++){             
             targ = t1[i].next[j].data2;
             event = t1[i].next[j].data1;
			 if(event == EEE){
				 fprintf(txt,"%d -> ",i);
				 fprintf(txt,"%d  [ label = \"",targ);
				 if(t1[targ].vocal >= 1 && t1[targ].vocal <= MAX_VOCAL_OUTPUT){
					 fprintf(txt,"/%d\" ];\n",t1[targ].vocal);
				 } else{
					 fprintf(txt," \" ];\n"); 
				 } 
				 continue;
			 }
			 k = state_getindex(targ,list,s_list);
			 if(k == -1){				
				 list = (INT_S*)REALLOC(list, (s_list + 1) * sizeof(INT_S));
				 list[s_list] = targ;
				 par = (part_node *)REALLOC(par, (s_list + 1) * sizeof(part_node));
				 par[s_list].next = NULL; par[s_list].numelts = 0;
				 addstatelist(event, &par[s_list].next, par[s_list].numelts, &ok);
				 if(ok) par[s_list].numelts ++;				
				 s_list ++;
			 }else{
				 addstatelist(event, &par[k].next, par[k].numelts, &ok);
				 if(ok) par[k].numelts ++;
			 }      
            /* if(event == showevent){
                 fprintf(tmp, "%d - %d - %d\n\n", i, event, entr);
             }           */
        }  
		//zprint_par(s_list, par);
		for(j = 0; j < s_list; j ++){
			fprintf(txt,"%d -> ",i);
			targ = list[j];
			fprintf(txt,"%d  [ label = \"",targ);
			voc = t1[targ].vocal;
			if(voc >= 1 && voc <= MAX_VOCAL_OUTPUT){
				for(k = 0; k < par[j].numelts; k ++){
					if(k < par[j].numelts - 1)
						fprintf(txt, "%d/%d,", par[j].next[k],voc);
					else{
						fprintf(txt, "%d/%d", par[j].next[k],voc);
					}
				}
			}else{
				for(k = 0; k < par[j].numelts; k ++){
					if(k < par[j].numelts - 1)
						fprintf(txt, "%d,", par[j].next[k]);
					else{
						fprintf(txt, "%d", par[j].next[k]);
					}
				}
			}		
		    fprintf(txt,"\"];\n",event); 
		}
		
		free(list);
		free_part(s_list, &par);
		s_list = 0; list = NULL; par = NULL;
   }
   fprintf(txt,"}");
   fclose(txt);
   //fclose(tmp);
   free(list);
   free_part(s_list, &par);
   return 1;
}

INT_OS orig_GenerateTxtFile(INT_S s1,state_node *t1, char * txtFilename,char *desName, INT_T showevent)
{
    char txtFile_fullname[MAX_PATH];
    char txttime[30]; char strtime[30];
    FILE *txt;
    INT_S i,j;
//    int ti;    
    struct tm *ts;
    INT_S entr;
    INT_T event;
	INT_B flag_mark;


    strcpy(txtFile_fullname,txtFilename);
    
    txt = fopen(txtFile_fullname,"w");
    //tmp = fopen("Transition.txt", "w");
    if(txt == NULL)
           return 0;
     curTime = time(NULL);     
     ts = localtime(&curTime);  
   strcpy(txttime,"");
   strcpy(strtime,"");
   fprintf(txt,"digraph finite_state_machine {\n");
   fprintf(txt,"graph [label = \"");
   fprintf(txt,"\\n\\nDES ");
   fprintf(txt,"%s \\n",desName);
   sprintf(txttime,"%4d.",ts->tm_year+1900);
   strcat(strtime,txttime);
   if(ts->tm_mon + 1 > 9 )
     sprintf(txttime,"%2d.",ts->tm_mon + 1);
   else
     sprintf(txttime,"0%d.",ts->tm_mon + 1);
   strcat(strtime,txttime);
   if(ts->tm_mday > 9 )
     sprintf(txttime,"%2d/",ts->tm_mday);
   else
     sprintf(txttime,"0%d/",ts->tm_mday);
   strcat(strtime,txttime);
   if(ts->tm_hour > 9 )
     sprintf(txttime,"%2d:",ts->tm_hour);
   else
     sprintf(txttime,"0%d:",ts->tm_hour);
   strcat(strtime,txttime);
   if(ts->tm_min > 9 )
     sprintf(txttime,"%2d ",ts->tm_min);
   else
     sprintf(txttime,"0%d ",ts->tm_min);
   strcat(strtime,txttime);

   fprintf(txt,"%s \"",strtime);
   fseek(txt,ftell(txt)-2,SEEK_SET);
   fprintf(txt,"\"];\n");
   fprintf(txt,"rankdir=LR;\n");
   fprintf(txt,"node [shape = doublecircle]; ");
   
   flag_mark = false;
   for(i=0;i<s1;i++){
       if(t1[i].marked == true){
          fprintf(txt,"%d ",i);
		  flag_mark = true;
	   }
   }
   if(flag_mark)
       fprintf(txt,";\n");
   fprintf(txt,"node [shape = circle];\n");
   
   if(s1 == 1 && t1[0].numelts == 0){
	   fprintf(txt, "%d", 0);
   }

   for(i=0;i<s1;i++){
        for(j=0;j<t1[i].numelts;j++){
             fprintf(txt,"%d -> ",i);
             entr = t1[i].next[j].data2;
             event = t1[i].next[j].data1;
             fprintf(txt,"%d  [ label = \"",entr);
             if(event != EEE){
                 if(t1[entr].vocal >= 1 && t1[entr].vocal <= MAX_VOCAL_OUTPUT){
                     fprintf(txt,"%d/%d\" ];\n",event,t1[entr].vocal);
                 } else{
                     fprintf(txt,"%d\" ];\n",event); 
                 }    
             } else{
                 if(t1[entr].vocal >= 1 && t1[entr].vocal <= MAX_VOCAL_OUTPUT){
                     fprintf(txt,"/%d\" ];\n",t1[entr].vocal);
                 } else{
                     fprintf(txt," \" ];\n"); 
                 } 
             }         
            /* if(event == showevent){
                 fprintf(tmp, "%d - %d - %d\n\n", i, event, entr);
             }           */
        }  
   }
   fprintf(txt,"}");
   fclose(txt);
   //fclose(tmp);

   return 1;
}

INT_OS convert_des_program(char * name1, char * name2, INT_B color_flag)
{  
     INT_OS errorno;
     state_node *t1;
     INT_S s1,init;
     INT_OS txtFlag = 0;    
     INT_OS result;
     
     char cwd[MAX_PATH];
	 char cmdLine[1024];

	 char dotdirectory[MAX_PATH] = "Graphviz\\";
	 char dotname[MAX_PATH]="dot.exe";
	 char long_dotname[MAX_PATH]="";


     char picname[MAX_PATH];
	 char long_picname[MAX_PATH];
	  char long_picname1[MAX_PATH];

     char txtname[MAX_PATH];

	 s1 = 0; t1 = NULL;
     
     errorno = -1;
     result = 0;
     
     init = 0L;
     if(getdes(name1,&s1,&init,&t1)==false){         
         return -1;
     } 
     
	 _getcwd(cwd,MAX_PATH);
//	 printw(cwd);
   //  system("pause");
     //_chdir(prefix);
     
     /*Make full name of GIF file*/     
     strcpy(picname,"");
     strcat(picname,name2);
     strcat(picname,".GIF"); 
     
     /*Make full name of dot.exe and check wether it exists or doesn't*/
    // strcpy(dotdirectory,"");
     //strcat(dotdirectory,cwd);  
	 //strcat(dotdirectory, "Grap\\");
     sprintf(long_dotname,"%s%s",dotdirectory,dotname);
     if(!exist(long_dotname)){
         printw("Conversion failure: Graphviz folder must be placed in workspace!");
         return -1;
     }
	 
     strcpy(cmdLine,dotname);
     strcat(cmdLine," -T");
     strcat(cmdLine,"gif");
             
     strcat(cmdLine," -o ");
     strcat(cmdLine,picname);      
     
     /*Make full name of TXT file which is used to generate GIF file*/
     strcpy(txtname,"");
     strcat(txtname,name2);     
     strcat(txtname,".txt");     

	 _chdir(dotdirectory);
     
     /*Generate TXT file*/
     txtFlag = GenerateTxtFile(s1,t1,txtname,name1, color_flag);
     if(txtFlag == 0){
         freedes(s1, &t1);
		 _chdir(cwd);
		 return -1;
     }
     
     /*Make command line*/
     strcat(cmdLine," ");
     strcat(cmdLine,txtname);

     /*Execute the command line */
     errorno = system(cmdLine); 
     
     if(errorno ==127 || errorno == -1){
		 freedes(s1, &t1);
		 _chdir(cwd);
		 return -2;
	 }
	 
	 /*Remove the TXT file and change work directory to the original*/
	 remove(txtname); 
	 _chdir(cwd);

	 strcpy(long_picname, "");
	 sprintf(long_picname, "%s%s",dotdirectory, picname);
        
     /*Check whether the object file be generated or not*/
     if(!exist(long_picname))  {
		  freedes(s1, &t1);
        return -1;    
	 }



	 // If the target gif file has already existed, remove it.
	 strcpy(long_picname1, "");
	 sprintf(long_picname1, "%s%s", prefix, picname);
	 if(exist(long_picname1))
		 remove(long_picname1);

	 strcpy(cmdLine, "");
	 sprintf(cmdLine, "copy %s \"%s\"", long_picname, prefix);
	 errorno = system(cmdLine); 

	 if(errorno ==127 || errorno == -1){
		 result = -1;
	 }	 
      
	 remove(long_picname); 

	 freedes(s1, &t1);

     return result;
}
INT_OS orig_convert_des_program(char * name1, char * name2, INT_T event)
{  
	INT_OS errorno;
	state_node *t1;
	INT_S s1,init;
	INT_OS txtFlag = 0;    
	INT_OS result;
	FILE *f1;

	char *pos;
	char currentpath[MAX_PATH];
	char exefullpath[MAX_PATH];
	char cmdLine[1024];
	char path1[MAX_PATH];
	char cprefix[MAX_PATH];
	char exname2[MAX_PATH];
	char long_name2[MAX_PATH];
	char long_txtname[MAX_PATH];
	char txtname[MAX_PATH];
	char binname[MAX_PATH]="\\GRAPHVIZ\\dot.exe";
	char long_binname[MAX_PATH];

	s1 = 0; t1 = NULL;

	errorno = -1;
	result = 0;

	init = 0L;
	if(getdes(name1,&s1,&init,&t1)==false){         
		return -1;
	} 
	/*Get current path and set new work path */
	f1 = fopen(ctct_ini_file,"rt");
	fgets(path1,255,f1);
	if (path1[strlen(path1)-1] == '\n')
		path1[strlen(path1)-1] = '\0';
	fclose(f1);
	pos = strrchr(path1,'\\');
	if(pos)
		pos ++;
	else
		pos = path1;

	_getcwd(currentpath,MAX_PATH);
	strcpy(cprefix,currentpath);
	if (cprefix[strlen(cprefix)-1] == '\\')
		cprefix[strlen(cprefix)-1] = '\0';
	strcat(cprefix,"\\");
	strcat(cprefix,pos);
	strcat(cprefix,"\\");

	_chdir(cprefix);

	/*Make full name of GIF file*/     
	strcpy(exname2,"");
	strcat(exname2,name2);
	strcat(exname2,".GIF"); 
	strcpy(long_name2,"");
	strcat(long_name2,cprefix);
	strcat(long_name2,exname2);

	/*Make full name of dot.exe and check wether it exists or doesn't*/
	strcpy(long_binname,"");
	strcat(long_binname,currentpath);     
	strcat(long_binname,binname);
	if(!exist(long_binname)){
		printw("Conversion failure: Graphviz folder must be placed in workspace!");
		result = -1;
		goto CONVERT_LABEL;
	}
	strcpy(exefullpath,"\"");
	strcat(exefullpath,long_binname); 
	strcat(exefullpath,"\"");   

	strcpy(cmdLine,exefullpath);
	strcat(cmdLine," -T");
	strcat(cmdLine,"gif");

	strcat(cmdLine," -o ");
	strcat(cmdLine,exname2);      

	/*Make full name of TXT file which is used to generate GIF file*/
	strcpy(txtname,"");
	strcat(txtname,name2);     
	strcat(txtname,".txt");     
	strcpy(long_txtname,"");     
	strcat(long_txtname,cprefix);
	strcat(long_txtname,txtname);

	/*Generate TXT file*/
	//txtFlag = GenerateTxtFile(s1,t1,long_txtname,name1, event);
	if(txtFlag == 0){
		result = -1;
		goto CONVERT_LABEL;
	}

	/*Make command line*/
	strcat(cmdLine," ");
	strcat(cmdLine,txtname);

	/*Execute the command line */
	errorno = system(cmdLine); 

	if(errorno ==127 || errorno == -1)
		result = -1;

	/*Check whether the object file be generated or not*/
	if(!exist(long_name2))  
		result = -2;                         

CONVERT_LABEL:
	/*Remove the TXT file and change work directory to the original*/
	remove(long_txtname);     
	_chdir(currentpath);

	freedes(s1, &t1);

	return result;
}

#ifdef __cplusplus
}
#endif
