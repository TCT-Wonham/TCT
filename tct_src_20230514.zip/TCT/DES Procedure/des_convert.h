#ifndef _CONVERT_H
#define _CONVERT_H


#include "des_data.h"

#ifdef __cplusplus
extern "C" {
#endif

extern INT_OS convert_des_program(char * name1, char * name2, INT_B);


#ifdef __cplusplus
}
#endif
                   
#endif 
