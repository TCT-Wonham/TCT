/* DES data structure */

#include "des_data.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "setup.h"
#include "display.h"
#include "mymalloc.h"
#include "curses.h"
#include "higen.h"
#include "des_proc.h"
#include "tct_io.h"
#include "tct_proc.h"

#ifdef __cplusplus
extern "C" {
#endif

INT_OS mem_result = 0;

INT_T s_global_labellist = 0;
event_label *global_labellist = NULL;

/* Func: newdes(size)
   Description:
      Allocate a new DES data structure with a given number of states.
      No transitions, silent states.

   Parameters:
      size    - number of states.  Must be greater than zero.
   Returns:
      Pointer to start of "state_node" array.
*/
state_node* newdes(INT_S size)
{
   return (state_node*) CALLOC(size, sizeof(state_node));
}

state_node nil_state_node = {false, false, false, 0, 0, NULL};

void resize_des(state_node **t, INT_S oldsize, INT_S newsize)
{
   INT_S i;

   *t = (state_node*) REALLOC(*t, sizeof(state_node)*(newsize));
   if (*t == NULL) {
      mem_result = 1;
      return;
   }

   if (oldsize < newsize) {
      for (i=oldsize; i < newsize; i++) {
/*         (*t)[i].marked       = false;
         (*t)[i].reached      = false;
         (*t)[i].coreach      = false;
         (*t)[i].vocal        = 0;
         (*t)[i].numelts      = 0;
         (*t)[i].next         = NULL;
*/
         (*t)[i] = nil_state_node;
      }
   }
}


/* Func: freedes(size, data)
   Description:
      Deallocate all memory held by the DES data structure.

   Parameters:
      size   - number of states.  Must be a number zero or greater.
      data   - pointer to DES data structure.
   Returns:
      nothing.
      Sets the pointer of "data" to NIL.
*/
void freedes(INT_S size, state_node** data)
{
   INT_S i;

   if (*data == NULL) return;
   if (size <= 0) return;

   for (i=0L; i < size; i++)
     if ((*data)[i].next != NULL) {
        free((*data)[i].next);
        (*data)[i].next = NULL;
     }

   if (*data != NULL) free(*data);
   *data = NULL;
}

void free_map(INT_S size, state_map** data)
{
   INT_S i;

   if (*data == NULL) return;

   for (i=0L; i < size; i++)
     if ((*data)[i].next != NULL) {
        free((*data)[i].next);
        (*data)[i].next = NULL;
     }

   if (*data != NULL) free(*data);
   *data = NULL;
}

void free_part(INT_S s1,
               part_node **pn)
{
   INT_S i;

   for (i=0; i < s1; i++) {
     if ( (*pn)[i].next != NULL )
       free((*pn)[i].next);
   }
   free(*pn);
}

void free_t_part(INT_S s1,
	t_part_node **pn)
{
	INT_S i;

	for (i=0; i < s1; i++) {
		if ( (*pn)[i].next != NULL )
			free((*pn)[i].next);
	}
	free(*pn);
}
void free_bt_part(INT_S s1,
	bt_part_node **pn)
{
	INT_S i;

	for (i=0; i < s1; i++) {
		if ( (*pn)[i].next != NULL )
			free((*pn)[i].next);
	}
	free(*pn);
}
void free_cc_check_table(INT_S size,
	cc_check_table **data)
{
	INT_S i,j;

	if (*data == NULL) return;
	if (size <= 0) return;

	for (i=0L; i < size; i++){
		if ((*data)[i].next != NULL) {
			for(j = 0; j < (*data)[i].numelts; j ++){
				if((*data)[i].next[j].dynindex != NULL){
					free((*data)[i].next[j].dynindex);
					(*data)[i].next[j].dynindex = NULL;
				}
			}
			free((*data)[i].next);
			(*data)[i].next = NULL;
		}
	}

	if (*data != NULL) free(*data);
	*data = NULL;
}

void get_event_label_list_from_global(INT_T s_eventlist, INT_T *eventlist, INT_T *s_labellist, event_label **labellist)
{
	INT_T i, j;

	*s_labellist = 0;
	*labellist = NULL;

	for(i = 0; i < s_eventlist; i ++){
		for(j = 0; j < s_global_labellist; j ++){
			if(eventlist[i] == global_labellist[j].intlabel){
				*labellist = (event_label*)REALLOC(*labellist, (*s_labellist + 1) * sizeof(event_label));
				(*labellist)[*s_labellist].intlabel = global_labellist[j].intlabel;
				strcpy((*labellist)[*s_labellist].strlabel, global_labellist[j].strlabel);
				(*s_labellist) ++;
				break;
			}
		}
	}
}

void get_strlabel_by_intlabel(INT_T intlabel, char* strlabel)
{
	INT_T j;
	for(j = 0; j < s_global_labellist; j ++){
		if(intlabel == global_labellist[j].intlabel){
			strcpy(strlabel, global_labellist[j].strlabel);
			return;
		}
	}
}

INT_B update_global_event_list(INT_T s_labellist, event_label *labellist, INT_S *s_sp, state_pair **sp, INT_T *s_conflictlist, INT_T **conflictlist)
{
	INT_T i, j, newlabel;
	INT_B bExist, bControl, ok, bUpdate;
	
	*s_sp = 0; 	*sp = NULL;
	*s_conflictlist = 0; *conflictlist = NULL;

	for(i = 0; i < s_labellist; i ++){
		bControl = labellist[i].intlabel%2;
		for(j = 0; j< s_global_labellist; j ++){
			if(strcmp(labellist[i].strlabel, global_labellist[j].strlabel) == 0){
				if(bControl != (global_labellist[j].intlabel%2)){
					addordlist(i, conflictlist, *s_conflictlist, &ok);
					if(ok) (*s_conflictlist)++;
				}
			}
		}
	}
//	if(*s_conflictlist != 0)
//		return 0;

	bUpdate = 0;
	for(i = 0; i < s_labellist; i ++){
		bExist = 0;
		bControl = labellist[i].intlabel%2;
		for(j = 0; j< s_global_labellist; j ++){
			if(strcmp(labellist[i].strlabel, global_labellist[j].strlabel) == 0){
				bExist = 1;
				if(labellist[i].intlabel != global_labellist[j].intlabel){
				//	bExist = 1;
				//}
				//else{	
					addstatepair(labellist[i].intlabel, global_labellist[j].intlabel, sp, *s_sp, &ok);
					if(ok) (*s_sp) ++;
				}
				break;
			}
		}
		if(bExist == 0){
			global_labellist = (event_label *)REALLOC(global_labellist, sizeof(event_label) * (s_global_labellist + 1));
			if(global_labellist == NULL){
				mem_result = 1;
				return -1;
			}
			//global_labellist[s_global_labellist].strlabel = (char*) CALLOC(strlen(labellist[i].strlabel), sizeof(char));
			strcpy(global_labellist[s_global_labellist].strlabel, labellist[i].strlabel);

			newlabel = START_INTLABEL + (s_global_labellist)*2 + bControl; //Generate the new index automatically and be compatible with the old version (integer label from 0-999)

			global_labellist[s_global_labellist].intlabel = newlabel;
			addstatepair(labellist[i].intlabel, newlabel, sp, *s_sp, &ok);
			if(ok) (*s_sp) ++;

			s_global_labellist ++;
			//bUpdate = 1;
		}
	}
	update_labellist_file();

	return 1;
}

static char  signature[8] = {"Z8^0L;1"};
static char  signature_x32[8] = {"Z8^0L;1"};
static char  signature_x64[8] = {"Z8^0L;2"};
static INT_OS   signature_length = 7;
static INT_OS endian = 0xFF00AA55;

/* "filedes" function */
INT_OS filedes(char*       name,
             INT_S       size,
             INT_S       init,
             state_node *data)
{
   char  fullname[_MAX_PATH];
   FILE  *out;
   INT_S i;
   INT_V v;
   char  header[100];
   INT_S header_len;
   long block_type, block_size;
   long cur_pos;
   INT_S temp;
#if !defined(_x64_)
   INT_S z,yy;
#endif
   INT_B ok;
   INT_T j, s_eventlist, *eventlist;
   INT_T s_labellist = 0;
   event_label *labellist = NULL;
   INT_T labellength;

   s_eventlist = 0; eventlist = NULL;
   
//   if (z) {}  /* Remove warning in some version of TCT */
//   if (yy) {} /* Remove warning in some version of TCT */


   if (init == -1L)     /* CONDAT file */
      sprintf(fullname, "%s%s.DAT", prefix, name);
   else
      sprintf(fullname, "%s%s.DES", prefix, name);


   out = fopen(fullname, "wb");
   if (out == NULL) {
      printf("Could not create file: %s\n", fullname);
      return 1;
   }

   /* Setup a buffer for faster IO */
   setvbuf(out, NULL, _IOFBF, 32000);

   /* Enter some useful ASCII text */
   sprintf(header, "%s DES file. Version 1.0", TCTNAME);

   header_len = strlen(header);
   header[header_len] = 26;  /* Mark end of ASCII file */
   fwrite(&header, sizeof(char), header_len+1, out);

   /* Unique string to uniquely identify it is a CTCT DES file.
      Some other program put a header string. */
#if defined(_x64_)
   fwrite(&signature_x64, sizeof(char), signature_length, out);
#else
   fwrite(&signature_x32, sizeof(char), signature_length, out);
#endif

   /* Big-endian and Little-endian information */
   fwrite(&endian, sizeof(INT_OS), 1, out);

   /* Block type zero (0) - required */
   block_type = 0;
   fwrite(&block_type, sizeof(long), 1, out);

   /* Save the current position because we have to fill in the size */
   fwrite(&block_size, sizeof(long), 1, out);
   block_size = ftell(out);

   fwrite(&size, sizeof(INT_S), 1, out);
   fwrite(&init, sizeof(INT_S), 1, out);

   /* Write the marker states */
   for (i=0L; i < size; i++)
     if (data[i].marked)
       fwrite(&i, sizeof(INT_S), 1, out);
   i = -1L; fwrite(&i, sizeof(INT_S), 1, out);

   /* Write the transitions */
   for (i=0L; i < size; i++) {
     if ((data[i].next != NULL) && (data[i].numelts > 0)){
       fwrite(&i, sizeof(INT_S), 1, out);
       fwrite(&data[i].numelts, sizeof(INT_T), 1, out);
#if defined(_x64_)
	    fwrite(data[i].next, sizeof(tran_node), data[i].numelts, out);
		for(j = 0; j < data[i].numelts; j ++){
			addordlist(data[i].next[j].data1, &eventlist, s_eventlist, &ok);
			if(ok) s_eventlist ++;
		}
#else 
	   for (z=0; z < data[i].numelts; z++) {
		   yy = (unsigned long) data[i].next[z].data1;
		   yy = yy << 22;
		   yy = yy | data[i].next[z].data2;
		   fwrite(&yy, sizeof(INT_S), 1, out);
	   }
#endif
     }
   }
   i = -1L; fwrite(&i, sizeof(INT_S), 1, out);

   /* Write the vocal states */
   for (i=0L; i < size; i++) {
     if (data[i].vocal != 0) {
       fwrite(&i, sizeof(INT_S), 1, out);
       v = data[i].vocal;
       fwrite(&v, sizeof(INT_V), 1, out);
     }
   }
   i = -1L; fwrite(&i, sizeof(INT_S), 1, out);

   if (ferror(out)) {
      fclose(out);
      return 1;
   }

#if defined(_x64_)
   get_event_label_list_from_global(s_eventlist, eventlist, &s_labellist, &labellist);
   i = -1L; fwrite(&i, sizeof(INT_S), 1, out);
   fwrite(&s_labellist, sizeof(INT_T), 1, out);
   for(i = 0; i < s_labellist; i ++){
	   fwrite(&(labellist[i].intlabel), sizeof(INT_T), 1, out);
	   labellength = (INT_T)strlen(labellist[i].strlabel);
	   fwrite(&labellength, sizeof(INT_T), 1, out);
	   fwrite(&(labellist[i].strlabel), sizeof(char), labellength, out);
   }
  // fwrite(labellist, sizeof(event_label), s_labellist, out);
#endif

   /* Update the block size */
   cur_pos = ftell(out);
   fseek(out, block_size, SEEK_CUR);
   block_size = cur_pos - block_size;
   fwrite(&block_size, sizeof(INT_S), 1, out);
   fseek(out, 0, SEEK_END);

   /* Block type zero (-1) - required */
   block_type = -1;
   fwrite(&block_type, sizeof(long), 1, out);
   block_size = 8;
   fwrite(&block_size, sizeof(long), 1, out);
   temp = 0;
   fwrite(&temp, sizeof(INT_S), 1, out);
   fwrite(&temp, sizeof(INT_S), 1, out);

   if (ferror(out)) {
      fclose(out);
      return 1;
   }

   fclose(out);

   //update the global label list
   update_labellist_file();
   return 0;      /* Success in writing file to disk */
}

/* GetDes function */
INT_B  getdes(char*        name,
               INT_S       *size,
               INT_S       *init,
               state_node **data)
{
   FILE *in;
   char fullname[_MAX_PATH];
   INT_S mark, s, z, yy;
   INT_T num;
   INT_V vocal;
   char ch;
   char header[8];
   INT_OS read_endian;
   long block_type, block_size;
   INT_B bFormat, ok; // win32 file or x64 file

   state_node *t1 = NULL;
   INT_S s1 = 0;

   INT_T s_list = 0; INT_T *list = NULL;
   INT_T s_labellist = 0;
   event_label *labellist = NULL;
   INT_S s_sp = 0;
   state_pair *sp = NULL;
   INT_T s_conflictlist = 0;
   INT_T *conflictlist = NULL;
   INT_T i, labellength;
   int        row, col;
   INT_B bUpdateLabel, bChangeStatus;

//   if (z) {}  /* Remove warning in some versions of TCT */
//   if (yy) {} /* Remove warning in some versions of TCT */
   in = NULL;
   strcpy(fullname, "");

   if (*init == -1L) {
      sprintf(fullname, "%s%s.dat", prefix, name);
   } else {
      sprintf(fullname, "%s%s.des", prefix, name);
   }

   in = fopen(fullname, "rb");
   if (in == NULL) {return false;}
   /* Setup a buffer for faster IO */
   setvbuf(in, NULL, _IOFBF, 32000);

   /* Read the ASCII header and junk */
   ch = 0;
   while ((ch != 26) && !feof(in)) {
      fread(&ch, sizeof(char), 1, in);
   }

   memset(header, 0, 8); /* Zero out the string */
   /* Read the unique string to authenic CTCT DES file */
   fread(header, sizeof(char), 7, in);
   if(strcmp(header, signature_x32) == 0){
	   bFormat = 0;
   }else if(strcmp(header, signature_x64) == 0){
	   bFormat = 1;
   }else{
      fclose(in);
      return false;
   }

   /* Big-endian and Little-endian information */
   fread(&read_endian, sizeof(INT_OS), 1, in);
   if (read_endian != endian) {
      fclose(in);
      return false;
   }

   /* Block type */
   fread(&block_type, sizeof(long), 1, in);
   if (block_type != 0) {
      fclose(in);
      return false;
   }

   /* Read the number of bytes of this block type */
   fread(&block_size, sizeof(long), 1, in);

#if defined(_x64_)
   if(bFormat){
	   fread(size, sizeof(INT_S), 1, in);
	   fread(init, sizeof(INT_S), 1, in);

	   if (ferror(in)) {
		   fclose(in);
		   return false;
	   }

	   *data = newdes(*size);
	   if ((*size != 0) && (*data == NULL)) {
		   mem_result = 1;
		   fclose(in);
		   return false;
	   }

	   if (*size > 0L) (*data)[0L].reached = true;

	   /* Read the marked states */
	   mark = 0L;
	   while (mark != -1L) {
		   fread(&mark, sizeof(INT_S), 1, in);
		   if (mark != -1L)
			   (*data)[mark].marked = true;
	   }

	   /* Read the transitions */
	   s = 0L;
	   while (s != -1L) {
		   fread(&s, sizeof(INT_S), 1, in);

		   if (s == -1L) break;

		   fread(&num, sizeof(INT_T), 1, in);
		   (*data)[s].next = (tran_node*) MALLOC(sizeof(tran_node)*num);
		   if ( (*data)[s].next == NULL ) {
			   mem_result = 1;
			   fclose(in);
			   return false;
		   }

		   (*data)[s].numelts = num;
		   fread((*data)[s].next, sizeof(tran_node), num, in);

	   }

	   /* Read the vocal states */
	   s = 0L;
	   while (s != -1L) {
		   fread(&s, sizeof(INT_S), 1, in);
		   if (s == -1L) break;
		   fread(&vocal, sizeof(INT_V), 1, in);
		   (*data)[s].vocal = vocal;
	   }
	  
	   //Read the event labels
	    bUpdateLabel = false;
	   fread(&s, sizeof(INT_S), 1, in);
	   if(s == -1){
		   fread(&s_labellist, sizeof(INT_T), 1, in);
		   if(s_labellist > 0){
			   labellist = (event_label*)MALLOC(sizeof(event_label)*s_labellist);
			   for(i = 0; i < s_labellist; i ++){
				   fread(&(labellist[i].intlabel), sizeof(INT_T), 1, in);
				   fread(&labellength, sizeof(INT_T), 1, in);
				   fread(&(labellist[i].strlabel), sizeof(char), labellength, in);
				   labellist[i].strlabel[labellength] = '\0';
			   }
			   //fread(&labellist, sizeof(event_label), s_labellist, in);
			   bChangeStatus = true;
			   update_global_event_list(s_labellist, labellist, &s_sp, &sp, &s_conflictlist, &conflictlist);
			   if(s_conflictlist !=0){
				   println();
				   printw("The events listed below has different control status with the global events: "); println();
				   println();
				   tab(5);
				   for(i = 0; i < s_conflictlist; i ++){
					   row = _wherey();
					   col = _wherex();
					   printw("%10s", labellist[conflictlist[i]].strlabel);  
					   if(_wherex() > 70){
						   println();
					   }
					   move(row, col + 10);
				   }
				   println();
				   println();
				   printw("Keep control status of these events be consistent with global events? (*y/n)");
				   refresh();
				   ch = read_key();
				   if (ch == CEsc) {
					   return false;
				   }

				   if ( ( ch == 'N') || (ch == 'n') ) {
					   println();
					    bChangeStatus = false;
				   } else {
					   if (ch != CEnter) {
						   printw("%c", ch);
					   }
					   println();
				   }
				   //printw("Use \"Edit\" to modify the events controllabilities of %s !", name); println();

			   }
				if(s_sp != 0 && bChangeStatus){
					eventmap_des(*data,*size, &t1,&s1,sp,s_sp,&list,&s_list,&ok);

					if (s_list != 0) {
						project0(&s1,&t1,s_list,list);
						free(list);
					}
					free(sp);
					freedes(*size, data); *size = 0; *data = NULL;
					export_copy_des(size, data, s1, t1);
					bUpdateLabel = true;
					freedes(s1, &t1);
				}
			}
	   }
	   

   }else{
	   fread(size, sizeof(INT_OS), 1, in);
	   fread(init, sizeof(INT_OS), 1, in);

	   if (ferror(in)) {
		   fclose(in);
		   return false;
	   }

	   *data = newdes(*size);
	   if ((*size != 0) && (*data == NULL)) {
		   mem_result = 1;
		   fclose(in);
		   return false;
	   }

	   if (*size > 0L) (*data)[0L].reached = true;

	   /* Read the marked states */
	   mark = 0L;
	   while (mark != 0xFFFFFFFF) {
		   fread(&mark, sizeof(INT_OS), 1, in);
		   if (mark != 0xFFFFFFFF)
			   (*data)[mark].marked = true;
	   }

	   /* Read the transitions */
	   s = 0L;
	   while (s != 0xFFFFFFFF) {
		   fread(&s, sizeof(INT_OS), 1, in);

		   if (s == 0xFFFFFFFF) break;

		   fread(&num, sizeof(INT_T), 1, in);
		   (*data)[s].next = (tran_node*) MALLOC(sizeof(tran_node)*num);
		   if ( (*data)[s].next == NULL ) {
			   mem_result = 1;
			   fclose(in);
			   return false;
		   }

		   (*data)[s].numelts = num;
		   for (z=0; z < num; z++) {
			   yy = 0;
			   fread(&yy, sizeof(INT_OS), 1, in);
			   (*data)[s].next[z].data1 = (INT_T) ((unsigned long) yy >> 22);
			   (*data)[s].next[z].data2 = (yy & 0x003FFFFF);
		   }

	   }

	   /* Read the vocal states */
	   s = 0L;
	   while (s != 0xFFFFFFFF) {
		   fread(&s, sizeof(INT_OS), 1, in);
		   if (s == 0xFFFFFFFF) break;
		   fread(&vocal, sizeof(INT_V), 1, in);
		   (*data)[s].vocal = vocal;
	   }

   }
  
#else
if(!bFormat){
	fread(size, sizeof(INT_S), 1, in);
	fread(init, sizeof(INT_S), 1, in);

	if (ferror(in)) {
		fclose(in);
		return false;
	}

	*data = newdes(*size);
	if ((*size != 0) && (*data == NULL)) {
		mem_result = 1;
		fclose(in);
		return false;
	}

	if (*size > 0L) (*data)[0L].reached = true;

	/* Read the marked states */
	mark = 0L;
	while (mark != -1L) {
		fread(&mark, sizeof(INT_S), 1, in);
		if (mark != -1L)
			(*data)[mark].marked = true;
	}

	/* Read the transitions */
	s = 0L;
	while (s != -1L) {
		fread(&s, sizeof(INT_S), 1, in);

		if (s == -1L) break;

		fread(&num, sizeof(INT_T), 1, in);
		(*data)[s].next = (tran_node*) MALLOC(sizeof(tran_node)*num);
		if ( (*data)[s].next == NULL ) {
			mem_result = 1;
			fclose(in);
			return false;
		}

		(*data)[s].numelts = num;
		for (z=0; z < num; z++) {
			fread(&yy, sizeof(INT_S), 1, in);
			(*data)[s].next[z].data1 = (INT_T) ((unsigned long) yy >> 22);
			(*data)[s].next[z].data2 = (yy & 0x003FFFFF);
		}
	}

	/* Read the vocal states */
	s = 0L;
	while (s != -1L) {
		fread(&s, sizeof(INT_S), 1, in);
		if (s == -1L) break;
		fread(&vocal, sizeof(INT_V), 1, in);
		(*data)[s].vocal = vocal;
	}

}else{
	// read the first 4 byte (in litter endian)
	fread(size, sizeof(INT_S), 1, in); fread(&yy, sizeof(INT_S), 1, in); // discard the later 4 byte
	fread(init, sizeof(INT_S), 1, in); fread(&yy, sizeof(INT_S), 1, in);

	if (ferror(in)) {
		fclose(in);
		return false;
	}

	*data = newdes(*size);
	if ((*size != 0) && (*data == NULL)) {
		mem_result = 1;
		fclose(in);
		return false;
	}

	if (*size > 0L) (*data)[0L].reached = true;

	/* Read the marked states */
	mark = 0L;
	while (mark != -1L) {
		fread(&mark, sizeof(INT_S), 1, in); fread(&yy, sizeof(INT_S), 1, in);
		if (mark != -1L)
			(*data)[mark].marked = true;
	}

	/* Read the transitions */
	s = 0L;
	while (s != -1L) {
		fread(&s, sizeof(INT_S), 1, in); fread(&yy, sizeof(INT_S), 1, in);

		if (s == -1L) break;

		fread(&num, sizeof(INT_T), 1, in);
		// num = sizeof(tran_node);
		(*data)[s].next = (tran_node*) MALLOC(sizeof(tran_node)*num);
		if ( (*data)[s].next == NULL ) {
			mem_result = 1;
			fclose(in);
			return false;
		}

		(*data)[s].numelts = num;
		for (z=0; z < num; z++) {
			fread(&yy, sizeof(INT_S), 1, in); 
			(*data)[s].next[z].data2 = yy;
			fread(&yy, sizeof(INT_S), 1, in); // discard

			fread(&yy, sizeof(INT_S), 1, in);
			(*data)[s].next[z].data1 = (INT_T)(yy & 0xFFFF);
			fread(&yy, sizeof(INT_S), 1, in); // discard
		}

	}

	/* Read the vocal states */
	s = 0L;
	while (s != -1L) {
		fread(&s, sizeof(INT_S), 1, in); fread(&yy, sizeof(INT_S), 1, in);
		if (s == -1L) break;
		fread(&vocal, sizeof(INT_V), 1, in);
		(*data)[s].vocal = vocal;
	}

}
#endif

   /* We don't read the last block type because we don't know how to
      process anything else after this point */

   fclose(in);

   if(bUpdateLabel == true){ //If the labels are changed, update the des file
	   filedes(name, *size, *init, *data);
   }
   return true;
}

void export_copy_des( INT_S *s_dest,state_node **t_dest,
              INT_S s_src,state_node *t_src   )
{
    INT_S i, jj; 
    INT_T j, ee;
    INT_B  ok;

    *s_dest = s_src;
    *t_dest = newdes(s_src);

    if ((s_src !=0) && (*t_dest == NULL)) {
      mem_result = 1;
      return;
    }

    for (i=0; i < s_src; i++) {
      (*t_dest)[i].marked  = t_src[i].marked;
      (*t_dest)[i].reached = t_src[i].reached;
      (*t_dest)[i].coreach = t_src[i].coreach;
      (*t_dest)[i].vocal   = t_src[i].vocal;
      for (j=0; j < t_src[i].numelts; j++) {
         ee = t_src[i].next[j].data1;
         jj = t_src[i].next[j].data2;
         addordlist1(ee, jj, &(*t_dest)[i].next, (*t_dest)[i].numelts, &ok);
         if (ok) (*t_dest)[i].numelts++;
      }
    }
}
void reverse_des(INT_S *s_dest, state_node **t_dest, INT_S s_src, state_node *t_src)
{    
     INT_S i, jj;
     INT_T j, ee;
     INT_B  ok;

     *s_dest = s_src;
     *t_dest = newdes(s_src);

     if ((s_src !=0) && (*t_dest == NULL)) {
        mem_result = 1;
        return;
     }

     for (i=0; i < s_src; i++) {
        for (j=0; j < t_src[i].numelts; j++) {
           ee = t_src[i].next[j].data1;
           jj = t_src[i].next[j].data2;
           addordlist1(ee, i, &(*t_dest)[jj].next, (*t_dest)[jj].numelts, &ok);
           if (ok) (*t_dest)[jj].numelts++;
        }
     }     
}

/* Add transition,extrance state pair */
void addordlist1(INT_T e,
                 INT_S j,
                 tran_node **L,
                 INT_T size,
                 INT_B  *ok)
{
   INT_T pos;
   INT_T lower, upper;
   INT_B  found;

   *ok = false;

   /* Do a binary search. */
   found = false;
   pos = 0;
   if (size > 1) {
     lower = 1;
     upper = size;
     while ( (found == false) && (lower <= upper) ) {
       pos = (lower + upper) / 2;
       if (e == (*L)[pos-1].data1 && j == (*L)[pos-1].data2) {
          found = true;
       } else if (e > (*L)[pos-1].data1 || e == (*L)[pos-1].data1 && j > (*L)[pos-1].data2) {
          lower = pos+1;
       } else {
          upper = pos-1;
       }
     }

     if (found == false) {
        if ((e < (*L)[pos-1].data1) || ((e == (*L)[pos-1].data1) && j < (*L)[pos-1].data2))
           pos--;
     }
   } else if (size == 1) {
     if (e == (*L)[0].data1 && j == (*L)[0].data2) {
       found = true;
     } else if ((e > (*L)[0].data1) || ((e == (*L)[0].data1) && j > (*L)[0].data2)) {
       pos = 1;
     }
   }

   if (found == true) {
     return;
   }

   /* Make space for new element */
   *L = (tran_node*) REALLOC(*L, sizeof(tran_node)*(size+1));
   if (*L == NULL) {
      mem_result = 1;
      return;
   }

   /* Move over any elements down the list */
   if ((size-pos) > 0)
      memmove(&(*L)[pos+1], &(*L)[pos], sizeof(tran_node)*(size-pos));

   /* Insert the element into the list */
   (*L)[pos].data1 = e;
   (*L)[pos].data2 = j;

   *ok = true;
}

/* event in the transition, extrance state pair */
INT_B  inordlist1(INT_T e,             /* event to find */
                   tran_node *L,        /* list to search */
                   INT_T size)
{
   INT_T pos;
   INT_T lower, upper;
   INT_B  found;

   /* Do a binary search. */
   found = false;
   pos = 0;
   if (size > 1) {
     lower = 1;
     upper = size;
     while ( (found == false) && (lower <= upper) ) {
       pos = (lower + upper) / 2;
       if (e == L[pos-1].data1) {
          found = true;
       } else if (e > L[pos-1].data1) {
          lower = pos+1;
       } else {
          upper = pos-1;
       }
     }
   } else if (size == 1) {
     if (e == L[0].data1) {
       found = true;
     }
   }

   return found;                   
}                                                         

/* Add transition,extrance state pair */
INT_B inordlist2(INT_T e,
	INT_S j,
	tran_node *L,
	INT_T size)
{
	INT_T pos;
	INT_T lower, upper;
	INT_B  found;

	/* Do a binary search. */
	found = false;
	pos = 0;
	if (size > 1) {
		lower = 1;
		upper = size;
		while ( (found == false) && (lower <= upper) ) {
			pos = (lower + upper) / 2;
			if (e == L[pos-1].data1 && j == L[pos-1].data2) {
				found = true;
			} else if (e > L[pos-1].data1 || e == L[pos-1].data1 && j > L[pos-1].data2) {
				lower = pos+1;
			} else {
				upper = pos-1;
			}
		}

		if (found == false) {
			if ((e < L[pos-1].data1) || ((e == L[pos-1].data1) && j < L[pos-1].data2))
				pos--;
		}
	} else if (size == 1) {
		if (e == L[0].data1 && j == L[0].data2) {
			found = true;
		} else if ((e > L[0].data1) || ((e == L[0].data1) && j > L[0].data2)) {
			pos = 1;
		}
	}

	return found;
}
/* Add transition */
void addordlist(INT_T e,
                INT_T **L,
                INT_T size,
                INT_B  *ok)
{
   INT_T pos;
   INT_T lower, upper;
   INT_B  found;

   *ok = false;

   /* Do a binary search. */
   found = false;
   pos = 0;
   if (size > 1) {
     lower = 1;
     upper = size;
     while ( (found == false) && (lower <= upper) ) {
       pos = (lower + upper) / 2;
       if (e == (*L)[pos-1]) {
          found = true;
       } else if (e > (*L)[pos-1]) {
          lower = pos+1;
       } else {
          upper = pos-1;
       }
     }

     if (found == false) {
        if (e < (*L)[pos-1])
           pos--;
     }
   } else if (size == 1) {
     if (e == (*L)[0]) {
       found = true;
     } else if (e > (*L)[0]) {
       pos = 1;
     }
   }

   if (found == true) {
     return;
   }

   /* Make space for new element */
   *L = (INT_T*) REALLOC(*L, sizeof(INT_T)*(size+1));
   if (*L == NULL) {
      mem_result = 1;
      return;
   }

   /* Move over any elements down the list */
   if ((size-pos) > 0)
      memmove(&(*L)[pos+1], &(*L)[pos], sizeof(INT_T)*(size-pos));

   /* Insert the element into the list */
   (*L)[pos]= e;

   *ok = true;
}

/* Add state */
void addstatelist(INT_S e,
                  INT_S **L,
                  INT_S size,
                  INT_B  *ok)
{
   INT_S pos;
   INT_S lower, upper;
   INT_B  found;

   *ok = false;

   /* Do a binary search. */
   found = false;
   pos = 0;
   if (size > 1) {
     lower = 1;
     upper = size;
     while ( (found == false) && (lower <= upper) ) {
       pos = (lower + upper) / 2;
       if (e == (*L)[pos-1]) {
          found = true;
       } else if (e > (*L)[pos-1]) {
          lower = pos+1;
       } else {
          upper = pos-1;
       }
     }

     if (found == false) {
        if (e < (*L)[pos-1])
           pos--;
     }
   } else if (size == 1) {
     if (e == (*L)[0]) {
       found = true;
     } else if (e > (*L)[0]) {
       pos = 1;
     }
   }

   if (found == true) {
     return;
   }

   /* Make space for new element */
   *L = (INT_S*) REALLOC(*L, sizeof(INT_S)*(size+1));
   if (*L == NULL) {
      mem_result = 1;
      return;
   }

   /* Move over any elements down the list */
   if ((size-pos) > 0)
      memmove(&(*L)[pos+1], &(*L)[pos], sizeof(INT_S)*(size-pos));

   /* Insert the element into the list */
   (*L)[pos]= e;

   *ok = true;
}

/* Find a state in a list */
INT_B  instatelist(INT_S e,         /* element to find */
                    INT_S *L,        /* list to search */
                    INT_S size)
{
   INT_S pos;
   INT_S lower, upper;
   INT_B  found;

   /* Do a binary search. */
   found = false;
   pos = 0;
   if (size > 1) {
     lower = 1;
     upper = size;
     while ( (found == false) && (lower <= upper) ) {
       pos = (lower + upper) / 2;
       if (e == L[pos-1]) {
          found = true;
       } else if (e > L[pos-1]) {
          lower = pos+1;
       } else {
          upper = pos-1;
       }
     }

   } else if (size == 1) {
     if (e == L[0]) {
       found = true;
     }
   }

   return found;
}

/* Add state map */
void addstatemap(INT_S e1, INT_S e2,
                 state_map **L,
                 INT_S size,
                 INT_B  *ok)
{
   INT_S pos;
   INT_S lower, upper;
   INT_B  found, ok2;

   *ok = false;

   /* Do a binary search. */
   found = false;
   pos = 0;
   if (size > 1) {
     lower = 1;
     upper = size;
     while ( (found == false) && (lower <= upper) ) {
       pos = (lower + upper) / 2;
       if (e1 == (*L)[pos-1].state) {
          found = true;
       } else if (e1 > (*L)[pos-1].state) {
          lower = pos+1;
       } else {
          upper = pos-1;
       }
     }

     if (found == false) {
        if (e1 < (*L)[pos-1].state)
           pos--;
     }
   } else if (size == 1) {
     if (e1 == (*L)[0].state) {
       pos = 1;
       found = true;
     } else if (e1 > (*L)[0].state) {
       pos = 1;
     }
   }

   if (found == true) {
     addstatelist(e2, &(*L)[pos-1].next, (*L)[pos-1].numelts, &ok2);
     if (ok2) (*L)[pos-1].numelts++;
     return;
   }

   /* Make space for new element */
   *L = (state_map*) REALLOC(*L, sizeof(state_map)*(size+1));
   if (*L == NULL) {
      mem_result = 1;
      return;
   }

   /* Move over any elements down the list */
   if ((size-pos) > 0)
      memmove(&(*L)[pos+1], &(*L)[pos], sizeof(state_map)*(size-pos));

   /* Insert the element into the list */
   (*L)[pos].state = e1;
   (*L)[pos].numelts = 0;
   (*L)[pos].next = NULL;

   addstatelist(e2, &(*L)[pos].next, (*L)[pos].numelts, &ok2);
   if (ok2) (*L)[pos].numelts++;

   *ok = true;
}

/* Add State Pair */
void addstatepair(INT_S e,
                  INT_S j,
                  state_pair **L,
                  INT_S size,
                  INT_B  *ok)
{
   INT_S pos;
   INT_S lower, upper;
   INT_B  found;

   *ok = false;

   /* Do a binary search. */
   found = false;
   pos = 0;
   if (size > 1) {
     lower = 1;
     upper = size;
     while ( (found == false) && (lower <= upper) ) {
       pos = (lower + upper) / 2;
       if (e == (*L)[pos-1].data1 && j == (*L)[pos-1].data2) {
          found = true;
       } else if (e > (*L)[pos-1].data1 || e == (*L)[pos-1].data1 && j > (*L)[pos-1].data2) {
          lower = pos+1;
       } else {
          upper = pos-1;
       }
     }

     if (found == false) {
        if ((e < (*L)[pos-1].data1) || ((e == (*L)[pos-1].data1) && j < (*L)[pos-1].data2))
           pos--;
     }
   } else if (size == 1) {
     if (e == (*L)[0].data1 && j == (*L)[0].data2) {
       found = true;
     } else if ((e > (*L)[0].data1) || ((e == (*L)[0].data1) && j > (*L)[0].data2)) {
       pos = 1;
     }
   }

   if (found == true) {
     return;
   }

   /* Make space for new element */
   *L = (state_pair*) REALLOC(*L, sizeof(state_pair)*(size+1));
   if (*L == NULL) {
      mem_result = 1;
      return;
   }

   /* Move over any elements down the list */
   if ((size-pos) > 0)
      memmove(&(*L)[pos+1], &(*L)[pos], sizeof(state_pair)*(size-pos));

   /* Insert the element into the list */
   (*L)[pos].data1 = e;
   (*L)[pos].data2 = j;

   *ok = true;
}

/* Find state pair */
INT_B  instatepair(INT_S e, INT_S j,
                    state_pair **L,
                    INT_S size)
{
   INT_S pos;
   INT_S lower, upper;
   INT_B  found;

   /* Do a binary search. */
   found = false;
   pos = 0;
   if (size > 1) {
     lower = 1;
     upper = size;
     while ( (found == false) && (lower <= upper) ) {
       pos = (lower + upper) / 2;
       if (e == (*L)[pos-1].data1 && j == (*L)[pos-1].data2) {
          found = true;
       } else if (e > (*L)[pos-1].data1 || e == (*L)[pos-1].data1 && j > (*L)[pos-1].data2) {
          lower = pos+1;
       } else {
          upper = pos-1;
       }
     }

   } else if (size == 1) {
     if (e == (*L)[0].data1 && j == (*L)[0].data2) {
       found = true;
     }
   }

   return found;
}

void insertlist4(INT_S src,
                 INT_T tran,
                 INT_S dest,
                 INT_S *s,
                 state_node **t)
{
   INT_B  ok;
   INT_S i;
   state_node *temp;

   if (src < *s) {
     addordlist1(tran, dest, &(*t)[src].next, (*t)[src].numelts, &ok);
     if (ok) (*t)[src].numelts++;
   } else {
     /* Need to increase the size of the array */
     temp = (state_node*) REALLOC(*t, sizeof(state_node)*(src+1));

     if (temp == NULL) {
       mem_result = 1;
       return;
     }
     *t = temp;

     for (i=*s; i <= src; i++) {
       (*t)[i].marked       = false;
       (*t)[i].reached      = false;
       (*t)[i].coreach      = false;
       (*t)[i].vocal        = 0;
       (*t)[i].numelts      = 0;
       (*t)[i].next         = NULL;
    }

     *s = src+1;
     addordlist1(tran, dest, &(*t)[src].next, (*t)[src].numelts, &ok);
     if (ok) (*t)[src].numelts++;
   }
}


/* For triple, list of [i,e,j] */
void addtriple(INT_S i,
               INT_T e,
               INT_S j,
               triple **L,
               INT_S size,
               INT_B  *ok)
{
   INT_S pos;
   INT_S lower, upper;
   INT_B  found;

   *ok = false;

   /* Do a binary search. */
   found = false;
   pos = 0;
   if (size > 1) {
     lower = 1;
     upper = size;
     while ( (found == false) && (lower <= upper) ) {
       pos = (lower + upper) / 2;
       if (i == (*L)[pos-1].i && e == (*L)[pos-1].e && j == (*L)[pos-1].j) {
          found = true;
       } else if (i > (*L)[pos-1].i || (i == (*L)[pos-1].i && e > (*L)[pos-1].e ) ||
                  (i == (*L)[pos-1].i && e == (*L)[pos-1].e && j > (*L)[pos-1].j ) ) {
          lower = pos+1;
       } else {
          upper = pos-1;
       }
     }

     if (found == false) {
        if (
            (i < (*L)[pos-1].i) ||
            ((i == (*L)[pos-1].i) && (e < (*L)[pos-1].e)) ||
            ((i == (*L)[pos-1].i) && (e == (*L)[pos-1].e) && (j < (*L)[pos-1].j))
           )
           pos--;
     }
   } else if (size == 1) {
     if (i == (*L)[0].i && e == (*L)[0].e && j == (*L)[0].j) {
       found = true;
     } else if (
                (i > (*L)[0].i) ||
                ((i == (*L)[0].i) && (e > (*L)[0].e)) ||
                ((i == (*L)[0].i) && (e == (*L)[0].e) && (j > (*L)[0].j ))
               ) {
       pos = 1;
     }
   }

   if (found == true) {
     return;
   }

   /* Make space for new element */
   *L = (triple*) REALLOC(*L, sizeof(triple)*(size+1));
   if (*L == NULL) {
      mem_result = 1;
      return;
   }

   /* Move over any elements down the list */
   if ((size-pos) > 0)
      memmove(&(*L)[pos+1], &(*L)[pos], sizeof(triple)*(size-pos));

   /* Insert the element into the list */
   (*L)[pos].i = i;
   (*L)[pos].e = e;
   (*L)[pos].j = j;

   *ok = true;
}

/* Delete transition,extrance state pair */
void delete_ordlist1(INT_T e,
                     INT_S j,
                     tran_node **L,
                     INT_T size,
                     INT_B  *ok)
{
   INT_T pos;
   INT_T lower, upper;
   INT_B  found;

   *ok = false;

   /* Do a binary search. */
   found = false;
   pos = 0;
   if (size > 1) {
     lower = 1;
     upper = size;
     while ( (found == false) && (lower <= upper) ) {
       pos = (lower + upper) / 2;
       if (e == (*L)[pos-1].data1 && j == (*L)[pos-1].data2) {
          found = true;
       } else if (e > (*L)[pos-1].data1 || e == (*L)[pos-1].data1 && j > (*L)[pos-1].data2) {
          lower = pos+1;
       } else {
          upper = pos-1;
       }
     }

     if (found == false) {
        if ((e < (*L)[pos-1].data1) || ((e == (*L)[pos-1].data1) && j < (*L)[pos-1].data2))
           pos--;
     }
   } else if (size == 1) {
     if (e == (*L)[0].data1 && j == (*L)[0].data2) {
       pos = 1;
       found = true;
     } else if ((e > (*L)[0].data1) || ((e == (*L)[0].data1) && j > (*L)[0].data2)) {
       pos = 1;
     }
   }

   if (found == false) {
     return;
   }

   /* Move over any elements up the list */
   if ((size-pos) > 0 && pos > 0)
      memmove(&(*L)[pos-1], &(*L)[pos], sizeof(tran_node)*(size-pos));

   /* Remove space for element */
   *L = (tran_node*) REALLOC(*L, sizeof(tran_node)*(size-1));
   if (size > 1) {
     if (*L == NULL) {
        mem_result = 1;
        return;
     }
   } else {
     *L = NULL;
   }

   *ok = true;
}

/* Find an event in a list */
INT_B  inlist(INT_T e,         /* element to find */
               INT_T *L,        /* list to search */
               INT_T size)
{
   INT_T pos;
   INT_T lower, upper;
   INT_B  found;

   /* Do a binary search. */
   found = false;
   pos = 0;
   if (size > 1) {
     lower = 1;
     upper = size;
     while ( (found == false) && (lower <= upper) ) {
       pos = (lower + upper) / 2;
       if (e == L[pos-1]) {
          found = true;
       } else if (e > L[pos-1]) {
          lower = pos+1;
       } else {
          upper = pos-1;
       }
     }
   } else if (size == 1) {
     if (e == L[0]) {
       found = true;
     }
   }

   return found;
}

void add_quad(INT_S i, INT_T e, INT_S j, INT_V v,
              quad__t **L, INT_S slist, INT_B  *ok)
{
   INT_S pos;
   INT_S lower, upper;
   INT_B  found;

   *ok = false;

   /* Do a binary search. */
   pos = 0;
   found = false;
   if (slist > 1) {
      lower = 1;
      upper = slist;
      while ( (found == false) && (lower <= upper) ) {
         pos = (lower + upper) / 2;
         if ((i == (*L)[pos-1].a) &&
             (e == (*L)[pos-1].b) &&
             (j == (*L)[pos-1].c) &&
             (v == (*L)[pos-1].d) ) {
             found = true;
         } else if ((i > (*L)[pos-1].a) ||
                    ((i == (*L)[pos-1].a) && (e > (*L)[pos-1].b )) ||
                    ((i == (*L)[pos-1].a) && (e == (*L)[pos-1].b) && (j > (*L)[pos-1].c)) ||
                    ((i == (*L)[pos-1].a) && (e == (*L)[pos-1].b) && (j == (*L)[pos-1].c) && (v > (*L)[pos-1].d) ) ) {
             lower = pos+1;
         } else {
             upper = pos-1;
         }
      }

      if (found == false) {
         if ((i < (*L)[pos-1].a) ||
             ((i == (*L)[pos-1].a) && (e < (*L)[pos-1].b)) ||
             ((i == (*L)[pos-1].a) && (e == (*L)[pos-1].b) && (j < (*L)[pos-1].c)) ||
             ((i == (*L)[pos-1].a) && (e == (*L)[pos-1].b) && (j == (*L)[pos-1].c) && (v < (*L)[pos-1].d)) )
            pos--;
      }
   } else if (slist == 1) {
      if (i == (*L)[0].a && e == (*L)[0].b && j == (*L)[0].c && v == (*L)[0].d) {
         found = true;
      } else if ( 
                 (i > (*L)[0].a) ||
                 ((i == (*L)[0].a) && (e > (*L)[0].b)) ||
                 ((i == (*L)[0].a) && (e == (*L)[0].b) && (j > (*L)[0].c )) ||
                 ((i == (*L)[0].a) && (e == (*L)[0].b) && (j == (*L)[0].c) && (v > (*L)[0].d)) ) {
         pos = 1;
      }
   }

   if (found == true) {
      return;
   }

   /* Make space for new element */
   *L = (quad__t*) REALLOC(*L, sizeof(quad__t)*(slist+1));
   if (*L == NULL) {
      mem_result = 1;
      return;
   }

   /* Move over any elements down the list */
   if ((slist-pos) > 0)
      memmove(&(*L)[pos+1], &(*L)[pos], sizeof(quad__t)*(slist-pos));

   /* Insert the element into the list */
   (*L)[pos].a = i;
   (*L)[pos].b = e;
   (*L)[pos].c = j;
   (*L)[pos].d = v;

   *ok = true;
}

/* Determine if the DES files contains correct values */
INT_B  check_des_sanity(state_node *t, INT_S s)
{
   INT_S i, jj;
   INT_T j, ee;

   if ((t == NULL) || (s <= 0)) return true;

   for (i=0; i < s; i++) {
      for (j=0; j < t[i].numelts; j++) {
         ee = t[i].next[j].data1;
         jj = t[i].next[j].data2;
         if (ee > MAX_TRANSITIONS) return false;
         if (!((0 <= jj) && (jj < s))) return false;
      }
   }
   return true;
}

/* Return the number of mark states */
INT_S num_mark_states(state_node* t1, INT_S s1)
{
   INT_S i;
   INT_S num_mark;

   num_mark = 0L;

   for (i=0; i < s1; i++) {
     if (t1[i].marked)
        num_mark++;
   }
   return num_mark;
}

/* Return the number of vocal states */
INT_S num_vocal_output(state_node *t1, INT_S s1)
{
   INT_S i;
   INT_S num_vocal;

   num_vocal = 0;
   for (i=0; i < s1; i++) {
     if (t1[i].vocal > 0)
        num_vocal++;
   }
   return num_vocal;
}

void recode_min(INT_S s1,
                state_node *t1,
                INT_S s2,
                state_node *t2,
                INT_S *mapState)
{
   INT_S i,jj;
   INT_T ee,j;
   INT_S classlist;
   INT_B  ok;

   for (i=0; i < s1; i++) {
      classlist = mapState[i];
      t2[classlist].marked = t1[i].marked;
      t2[classlist].vocal  = t1[i].vocal;
      for (j=0; j< t1[i].numelts; j++) {
         ee = t1[i].next[j].data1;
         jj = mapState[t1[i].next[j].data2];
         addordlist1(ee, jj, &t2[classlist].next, t2[classlist].numelts, &ok);
         if (ok) {
            t2[classlist].numelts++;
         }
      }
   }
}

/////////////////////////////////////////////////////////////////////////////////
//Used to print the contents of the strings, tables ... 
static char tmp_result[_MAX_PATH];

void zprints(char * s)
{
     FILE *out;
//     INT_S i;
     
     strcpy(tmp_result, "");
     strcat(tmp_result, prefix);
     strcat(tmp_result, "Ouput.txt");
     out = fopen(tmp_result,"a");
     
     fprintf(out,"%s",s);
     
     fclose(out);
}
void zprintn(INT_S s)
{
     FILE *out;
     
     strcpy(tmp_result, "");
     strcat(tmp_result, prefix);
     strcat(tmp_result, "Ouput.txt");
     
     out = fopen(tmp_result,"a");
     fprintf(out,"%d",s);
     fclose(out);
}
void zprintsn(char * str, INT_S s)
{
     FILE *out;
     
     strcpy(tmp_result, "");
     strcat(tmp_result, prefix);
     strcat(tmp_result, "Ouput.txt");
     out = fopen(tmp_result,"a");
     
     fprintf(out,"%s%d\n",str,s);
     fclose(out);
}
void zprint_list(INT_S s, INT_S *list)
{
     FILE *out;
     INT_S i;
     
     strcpy(tmp_result, "");
     strcat(tmp_result, prefix);
     strcat(tmp_result, "Ouput.txt");
     out = fopen(tmp_result,"a");     
     
     for( i = 0; i < s; i ++){
          fprintf(out,"%d ", list[i]);
     }
     fprintf(out,"\n");
     fclose(out);
}
void zprint_list1(INT_T s, INT_T *list)
{
     INT_T i;
     FILE *out;
     
     strcpy(tmp_result, "");
     strcat(tmp_result, prefix);
     strcat(tmp_result, "Ouput.txt");
     out = fopen(tmp_result,"a");
     for( i = 0; i < s; i ++){
          fprintf(out,"%d ", list[i]);
     }
     fprintf(out,"\n");
     fclose(out);
}
void zprint_par(INT_S s, part_node *par)
{
     FILE *out;
	 INT_S i; INT_S j;
     
     strcpy(tmp_result, "");
     strcat(tmp_result, prefix);
     strcat(tmp_result, "Ouput.txt");
     out = fopen(tmp_result,"a");
     
     
     for(i = 0; i < s; i ++){
         for(j = 0; j < par[i].numelts; j ++){
               fprintf(out,"%d ", par[i].next[j]);
         }
         fprintf(out,"\n");
     }
     fclose(out);
}
void zprint_tpar(INT_S s, t_part_node *tpar)
{
	FILE *out;
	INT_S i; INT_T j;

	strcpy(tmp_result, "");
	strcat(tmp_result, prefix);
	strcat(tmp_result, "Ouput.txt");
	out = fopen(tmp_result,"a");


	for(i = 0; i < s; i ++){
		for(j = 0; j < tpar[i].numelts; j ++){
			fprintf(out,"%d ", tpar[i].next[j]);
		}
		fprintf(out,"\n");
	}
	fclose(out);
}
void zprint_btpar(INT_S s, bt_part_node *btpar)
{
	FILE *out;
	INT_S i; INT_T j;

	strcpy(tmp_result, "");
	strcat(tmp_result, prefix);
	strcat(tmp_result, "Ouput.txt");
	out = fopen(tmp_result,"a");


	for(i = 0; i < s; i ++){
		for(j = 0; j < btpar[i].numelts; j ++){
			fprintf(out,"%d ", btpar[i].next[j]);
		}
		fprintf(out,"\n");
	}
	fclose(out);
}
void zprint_map(INT_S s, state_map *map)
{
     FILE *out;
	 INT_S i,j;
     
     strcpy(tmp_result, "");
     strcat(tmp_result, prefix);
     strcat(tmp_result, "Ouput.txt");
     out = fopen(tmp_result,"a");
     
     
     for(i = 0; i < s; i++){
         for(j = 0; j < map[i].numelts; j ++)
             fprintf(out,"%d ", map[i].next[j]);
             fprintf(out,"\n");
     }
     fclose(out);
}
void zprint_pair(INT_S s, state_pair *pair)
{
    INT_S i;
    FILE *out;
    
    strcpy(tmp_result, "");
    strcat(tmp_result, prefix);
    strcat(tmp_result, "Ouput.txt");
    out = fopen(tmp_result,"a");
    
    for(i = 0; i < s; i ++){
       fprintf(out,"%d  %d \n",pair[i].data1,pair[i].data2);
    }
    fprintf(out,"\n");
    fclose(out);
}
void zprint_triple(INT_S s, triple * trip)
{
    INT_S i;
    FILE *out;
    
    strcpy(tmp_result, "");
    strcat(tmp_result, prefix);
    strcat(tmp_result, "Ouput.txt");
    out = fopen(tmp_result,"a");
    
    for(i = 0; i < s; i ++)
       fprintf(out, "%d  %d   %d\n", trip[i].i,trip[i].e,trip[i].j);
    
    fprintf(out,"\n");
    fclose(out);
}
void zprint_check_table(INT_S size, cc_check_table *data)
{
	FILE *out;
	INT_S i; INT_T j;
	char tmp_result[_MAX_PATH];

	strcpy(tmp_result, "");
	strcat(tmp_result, prefix);
	strcat(tmp_result, "Ouput.txt");
	out = fopen(tmp_result,"a");


	for(i = 0; i < size; i ++){
		for(j = (INT_T)data[i].numelts - 1; j >=0 && j < data[i].numelts  ; j --){
			fprintf(out,"%10d ", data[i].next[j].flag);
		}
		fprintf(out,"\n");
	}
	fclose(out);
}

#ifdef __cplusplus
}
#endif
