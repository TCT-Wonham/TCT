static int *dir_stack;
static int size_dir_stack;
static int total_dir;
static INT_BOOL multiPage;
static ii;
static INT_BOOL quit;

void directory_output_page_control(INT_BOOL lastPage)
{
   char ch;

   multiPage = true;
   continue_page("Press <Enter> to page directory or <ESC> to cancel  ");
   do {
      refresh();
      ch = read_key();

      switch(ch) {
         case CEsc:
            quit = true;
            free(dir_stack);
            return;
         case CPgDn:
            if (lastPage == true) {
               ch = 0;
               ring_bell();
            } else {
               size_dir_stack++;
               dir_stack = (int*) realloc(dir_stack,
                                          sizeof(int)* size_dir_stack);
               dir_stack[size_dir_stack-1] = ii;
            }
            break;
         case CEnter:
            if (lastPage == false) {
               size_dir_stack++;
               dir_stack = (int*) realloc(dir_stack,
                                  sizeof(int)* size_dir_stack);
               dir_stack[size_dir_stack-1] = ii;
            } else{
               clear();
               directory_header(path);
               return;
            }
            break;
         case CPgUp:
            if (size_dir_stack == 0) {
               ch = 0;
               ring_bell();
            } else {
               if (size_dir_stack >= 2) {
                  ii = dir_stack[size_dir_stack-2];
                  size_dir_stack -= 2;
                  dir_stack = (int*) realloc(dir_stack,
                                     sizeof(int) * size_dir_stack);

                  /* Put back the last pop */
                  size_dir_stack++;
                  dir_stack = (int*) realloc(dir_stack,
                                     sizeof(int) * size_dir_stack);
                  dir_stack[size_dir_stack-1] = ii;
               } else {
                  ii = 0;
                  size_dir_stack = 0;
                  free(dir_stack); dir_stack = NULL;
               }
               total_dir = 0;
            }
            break;
      }
   } while ( ( ch != CEnter) && (ch != CEsc) && (ch != CPgUp) && (ch != CPgDn) );

   directory_header(path);
}

INT_BOOL display_directory_output(struct ffblk *namelist, int num_entries)
{
   char buf[20];

   multiPage = false;
   total_dir = 0;
   dir_stack = NULL; size_dir_stack = 0;
   ii = 0;

   do {
      while (ii < num_entries) {
        if (namelist[ii].ff_attrib == FA_DIREC) {
           sprintf(buf, "[%s]", namelist[ii].ff_name);
           printw("%-12s    ", buf);
        } else {
           printw("%-12s    ", namelist[ii].ff_name);
        }
        size_dir_stack++;

        if (_wherey() >= 23) {
           directory_output_page_control(false)
           if (quit) return true;
        }
        ii++;
     }
     if (multiPage) directory_output_page_control(true)
   } while ( (ch != CEnter) && (ch != CPgDn) && (multiPage == true) &&
             (quit == false) );

   return quit;
}

void directory_p()
{
   struct ffblk *namelist;
   int num_entries;
   char dir[100];
   char ch;

   namelist = NULL;
   quit = false;

   strcpy(dir, path);
   strcat(dir, "\\*.*");

   num_entries = scandir(dir, &namelist);

   clear();
   directory_header(path);

   if (num_entries) {
      display_directory_output(namelist, num_entries);
      free(namelist);
   } else {
      move(7,0);
      printw("NO FILES IN %s", dos_uppercase(path));

      move(23,0); clrtoeol();
      printw("Press <Enter> to return to CTCT Procedures  ");
      refresh();
      do {
        ch = read_key();
      } while (ch != CEnter);
   }
}

