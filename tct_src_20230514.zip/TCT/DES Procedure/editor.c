/* CTCT Editor */

#include "tct_io.h"
#include "editor.h"
#include "curses.h"
#include "des_data.h"
#include "des_proc.h"
#include "tct_proc.h"
#include "display.h"
#include "setup.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mymalloc.h"
#include "cl_tct.h"
#include "higen.h"

#ifdef __cplusplus
extern "C" {
#endif

static state_node *t1;
static INT_S s1;
static INT_B  quit;

static INT_S original_s1;

/* Need to keep track of the following information for MAKEIT.TXT file:

   new name
   new states added
   old states deleted
   new marker states added
   old marker states deleted
   new vocal states added
   old vocal states deleted
   new transitions added
   old transitions deleted
   reachability operation performed.
 */

static INT_S *old_state_list; static INT_S s_old_state_list;
static INT_S *new_mark_list; static INT_S s_new_mark_list;
static INT_S *old_mark_list; static INT_S s_old_mark_list;
static state_pair *vocal_list; static INT_S s_vocal_list;
static state_pair *map_list; static INT_S s_map_list;
static triple *new_tran_list; static INT_S s_new_tran_list;
static triple *old_tran_list; static INT_S s_old_tran_list;
static INT_B  reach_operation;
static INT_B  allstatemarked, allstateunmarked;

static filename name1, name2;

void add_des(state_node **t1,
             INT_S *s1,
             INT_S new_size)         /* New size */
{
   INT_S j;

   new_size++;
   if (new_size > *s1) {
      *t1 = (state_node*) realloc(*t1, sizeof(state_node)*(new_size));

      if (*t1 == NULL) {
         mem_result = 1;
         printf("Out of memory\n");
         exit(1);
      }

      /* Remember to initial the states */
      for (j=*s1; j < new_size; j++) {
         (*t1)[j].marked       = false;
         (*t1)[j].reached      = false;
         (*t1)[j].coreach      = false;
         (*t1)[j].vocal        = 0;
         (*t1)[j].numelts      = 0;
         (*t1)[j].next         = NULL;
      }

      *s1 = new_size;
   }
}

void edit_header()
{
   printw("EDIT"); println();
   println();
   printw("DES2 = EDIT (DES1)"); println();
   println();
}

void printmark1(INT_S s,
                state_node *t,
                INT_B  *empty)
{
   INT_S i;
   INT_OS col, row;
   char ch;

   *empty = true;
   for (i=0; i < s; i++) {
     if (t[i].marked) {
        col = _wherex();
        row = _wherey();
        if (_wherey() > 22) {
           move(23,0);
           printw("Press <Enter> to page marker state table  ");
           refresh();
           do {
             ch = read_key();
           } while (ch != CEnter);
           clear();
           esc_footer();
           move(1,5);
           row = 1;
        }
        printw("%d", i);
        *empty = false;
        if (col < 65) {
          move(row, col+7);
        } else {
          println();
          printw("     ");
        }
     }
   }
}

void printmark(INT_S s,
               state_node *t)
{
   INT_B  empty;

   printw("     ");
   printmark1(s,t,&empty);
   if (empty)
      printw(" empty");
}

void printvocal1(INT_S s,
                 state_node *t,
                 INT_B  *empty)
{
   INT_S i;
   INT_OS col, row;
   char ch;

   *empty = true;
   for (i=0; i < s; i++) {
     if ( t[i].vocal > 0) {
        col = _wherex();
        row = _wherey();
        if (_wherey() > 21) {
           move(23,0);
           printw("  Press <Enter> to page state output table  ");
           refresh();
           do {
              ch = read_key();
           } while (ch != CEnter);
           clear();
           move(1,3);
           row = 1;
        }
        printw("[%5d,%3d] ", i, t[i].vocal);
        *empty = false;
        if (col < 62) {
           move(row, col+15);
        } else {
           println();
           printw("   ");
        }
      }
   }
}

void printvocal(INT_S s,
                state_node *t)
{
   INT_B  empty;

   printw("   ");
   printvocal1(s,t,&empty);
   if (empty)
      printw(" none");
}

void trim_endstates(INT_S *s,
                    state_node **t)
{
   INT_S size, i;

   if (*s <= 0) return;

   /* Mark all the reachable states */
   /* Remove all end states that are not referenced */
   for (i=0; i < *s; i++) {
      (*t)[i].reached = false;
   }
   (*t)[0].reached = true;
   b_reach((*t)[0].next, 0L, t, *s);

   size = *s;
   for (i=*s-1; i >= 0; i--) {
     if ( ((*t)[i].reached == false) &&
          ((*t)[i].vocal == 0) &&
          ((*t)[i].numelts == 0) &&
          ((*t)[i].marked == 0) ) {
       size = i+1;
     } else {
       break;
     }
   }

   if (size != *s) {
     *t = (state_node*) realloc(*t, sizeof(state_node)*(size));
     *s = size;
   }
}

void vocalmap_des(state_node *t1, INT_S s1,
                  state_pair *mlist, INT_S s_mlist)
{
    INT_S i, j;
    INT_V v;

    for (i=0; i < s1; i++) {
      v = t1[i].vocal;

      /* Do a linear search - assume the list is short */
      for (j = 0; j < s_mlist; j++)
      {
         if ( ((INT_V) mlist[j].data1) == v )
         {
            t1[i].vocal = (INT_V) mlist[j].data2;
            break;
         }
      }
    }
}
/* Regular reach containing set new initial state to 0*/
void n_reach(INT_S *s1,
           state_node **t1, INT_S init)
{
   INT_S s2, state;
   recode_node *recode_states;
   INT_S num_reachable;

   if (*s1 <= 0) return;

   /* Zero all the reach variables */
   for (state=0; state < *s1; state++)
      (*t1)[state].reached = false;

   (*t1)[init].reached = true;
   b_reach((*t1)[init].next, init, t1, *s1);

   s2 = 0;
   for (state = *s1-1L; state >= 0; state--) {
     if ((*t1)[state].reached)
       s2++;
   }
   if (s2 == *s1) {
     return;
   }

   /* Remove all "unreachable states" */
   /* Allocate tempory data structure for new recorded names */
   recode_states = (recode_node*) CALLOC(*s1,sizeof(recode_node));

   /* Re-name all reached states to the new state names */
   num_reachable = 0;
   recode_states[init].recode = 0;
   recode_states[init].reached = true;
   num_reachable ++;
   for (state=0; state < *s1; state++) {
     if ( (*t1)[state].reached && state != init) {
        recode_states[state].recode  = num_reachable;
        recode_states[state].reached = true;
        num_reachable++;
     }
   }

   /* Purge dead transitions followed by purging states */
   recode(*s1, t1, recode_states);

   *t1 = (state_node*) REALLOC(*t1, sizeof(state_node)*num_reachable);
   *s1 = num_reachable;

   free(recode_states);
}
void edit_r()
{
   INT_S init, i, k;
   INT_OS col, row, a;
   char ch;
   INT_B  ok;
   INT_S nTransitions;
   short sign_j, new_sign_j;
   INT_T j;
   INT_V v;
   INT_B  allstate;

   char strlabel[WIDTH_EVENT];
   INT_T index;
#if defined (_x64_)
   INT_S s_sp = 0;
   state_pair *sp = NULL;
   INT_S s2 = 0;
   state_node *t2 = NULL;
   INT_T s_list = 0;
   INT_T *list = NULL;
#endif


   clear();
   edit_header();

   quit = getname("Enter DES1 to be edited ....  ", EXT_DES, name1, false);
   if (quit) return;

   if (getdes(name1, &s1, &init, &t1) == false) {
      quit = true;
      return;
   }

   if (init == -1) {
      printw("%s IS A CONTROL DATA FILE, AND CANNOT BE EDITED!", name1); println();
      user_pause();
      quit = true;
      return;
   }

   init = 0;   /* Assume the initial state is zero */
   original_s1 = s1;

   strcpy(name2, name1);
   printw("Save DES2 under new name (or else overwrite %s)?  (*y/n)   ", name1);
   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( ( ch == 'N') || (ch == 'n') ) {
      println();
   } else {
      if (ch != CEnter) {
         printw("%c", ch);
      }
      println();
      println();
      quit = getname("Enter new name of DES2 ....  ",
                     EXT_DES, name2, true);
      if (quit) return;
   }

   println();
   printw("# states assigned to %s is %d.", name2, s1); println();
   println();

   /* PROCEDURE TO MODIFY MARKED STATES */
   if (_wherey() > 17)
      clear();

   printw("List of marker states of %s is currently: ", name2); println();
   println();
   printmark(s1,t1);
   println();
   println();
   printw("OK?  (*y/n)  ");
   esc_footer();

   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( (ch == 'N') || (ch == 'n') ) {
      if (ch != CEnter) {
         printw("%c", ch);
      }
      println();
      println();
      if (_wherey() > 16) {
         clear();
         esc_footer();
      }
      printw("Enter states of %s to be newly marked.  New states not in", name2); println();
      printw("current structure may be listed if required (type -1 to quit)."); println();
      printw("To mark all states, enter '*':"); println();
      println(); printw("     ");
      i = 0;
      while (i != -1) {
         if (_wherey() > 20) {
             clear();
             printw("     ");
             esc_footer();
         }

         col = _wherex();
         row = _wherey();
         if (col >= 75) {
            move(row+1,5);
            col = 5;
            row++;
         }

         i = (INT_S) readintall(&ch, -1, MAX_STATES-1);
         if (ch == CEsc) {
             quit = true; return;
         }

         if (ch == '*') {
             for (k=0; k < s1; k++) {
                t1[k].marked = true;
                addstatelist(k, &new_mark_list, s_new_mark_list, &ok);
                if (ok) s_new_mark_list++;
             }
             allstatemarked = true;
         }
         else
         {
            if (i != -1) {
               add_des(&t1, &s1, i);
               t1[i].marked = true;
               addstatelist(i, &new_mark_list, s_new_mark_list, &ok);
               if (ok) s_new_mark_list++;
            }
         }
         move(row, col+8);
      } /* while */

      println(); println();
      if (_wherey() > 17)
         clear();
      printw("Enter old marker states to be unmarked (type -1 to quit)."); println();
      printw("To unmark all states, enter '*':"); println();
      println(); tab(5);
      col = _wherex();
      i = 0;
      while (i != -1) {
         if (_wherey() > 20) {
            clear();
            tab(5);
         }

         i = (INT_S) readintall(&ch, -1, MAX_STATES-1);
         if (ch == CEsc) {
             quit = true; return;
         }

         if (ch == '*') {
            for (k=0; k < s1; k++) {
                t1[k].marked = false;
                addstatelist(k, &old_mark_list, s_old_mark_list, &ok);
                if (ok) s_old_mark_list++;
            }
            allstateunmarked = true;
            i = -1; /* All states now unmarked. */
         }
         
         if (i != -1) {
            if (i >= s1) {
               println();
               ring_bell();
               if (_wherey() > 20) clear();
               printw("Marker state %d is illegal, please reenter!", i); println();
               println(); tab(5);
               col = -3;
            } else {
               t1[i].marked = false;
               addstatelist(i, &old_mark_list, s_old_mark_list, &ok);
               if (ok) s_old_mark_list++;
            }
         }
         row = _wherey();
         if (col < 65) {
            move(row, col+8);
         } else {
            println(); tab(5);
         }
         col = _wherex(); row = _wherey();
      } /* while */
      println();
      println();
   }

   /* PROCEDURE TO MODIFY TRANSITIONS */
   clear();
   esc_footer();
   println();

   nTransitions = count_tran(t1, s1);
   printw("# transitions in %s is currently %d", name2, nTransitions); println();
   println();
   printw("Current transition list OK?  (*y/n)  ");

   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }
   if ( (ch == 'n') || (ch == 'N') ) {
      clear();
      println();
      printw("Enter new transitions to adjoin."); println();
      printw("To add multiple transitions, enter * for Exit state."); println();
      printw("New exit or entrance states may be introduced as needed;"); println();
      printw("type -1 to quit:"); println(); println();
      esc_footer();
      do {
         if (_wherey() > 21) {
            col = _wherex(); row = _wherey()-1;
            move(23,0); clrtoeol();
            move(24,0);
            scroll_line();

            for (a=0; a < 6; a++) {
               move(a,0); clrtoeol();
            }

            move(0,0);
            println();
            printw("Enter new transitions to adjoin."); println();
            printw("To add multiple transitions, enter * for Exit state."); println();
            printw("New exit or entrance states may be introduced as needed;"); println();
            printw("type -1 to quit:"); println(); println();
            esc_footer();
            move(row,col);
         }

         allstate = false;
         printw(" Exit state:  ");
         i = (INT_S) readintall(&ch, -1, MAX_STATES-1);
         if (ch == CEsc) {
            quit = true; return;
         }
         if (ch == '*') allstate = true;
         if (i == -1) break;

         tab(25);
         printw("Event label:  ");
#if defined(_x64_)
		 ch = read_string(strlabel, 1, WIDTH_EVENT);
		 if (ch == CEsc) {
			 quit = true; return;
		 }
		 sign_j = (short) generate_integer_label(strlabel, 1, &index);
#else
		 sign_j = (short) readint_and_e(&ch, -1, MAX_TRANSITIONS);
		 if (ch == CEsc) {
			 quit = true; return;
		 }
#endif

         if (sign_j == -1) break;
         j = (INT_T) sign_j;

         tab(50);
         printw("Entrance state:  ");
         k = (short) readint(&ch, -1, MAX_STATES-1);
         if (ch == CEsc) {
            quit = true; return;
         }
         if (k == -1) break;
         println();

         add_des(&t1, &s1, i);
         add_des(&t1, &s1, k);

         if (allstate) {
            INT_S ii;

            for (ii=0; ii < original_s1; ii++)
            {
               addordlist1(j,k,&(t1[ii].next), t1[ii].numelts, &ok);
               if (ok) t1[ii].numelts++;

               /* record new state added for MAKEIT.TXT */
               addtriple(ii,j,k,&new_tran_list, s_new_tran_list, &ok);
               if (ok) s_new_tran_list++;
            }
         } else {
            addordlist1(j, k, &(t1[i].next), t1[i].numelts, &ok);
            if (ok) t1[i].numelts++;

            /* record new state added for MAKEIT.TXT */
            addtriple(i,j,k,&new_tran_list, s_new_tran_list, &ok);
            if (ok) s_new_tran_list++;
         }
      } while (i != -1);

      /* Delete transitions */
      clear();
/*      println(); println();
      if (_wherey() > 19) clear();
*/
      println();
      printw("Enter old transitions to delete."); println();
      printw("To delete multiple transitions, enter * for Exit state (type -1 to quit):");
      println(); println();
      esc_footer();
      i = 0;
      while (i != -1) {
         if (_wherey() > 21) {
            row = _wherey()-1;  col = _wherex();
            move(23,0); clrtoeol();
            move(24,0);
            scroll_line();

            for (a=0; a < 4; a++) {
               move(a,0);  clrtoeol();
            }

            move(0,0);
            println();
            printw("Enter old transitions to delete."); println();
            printw("To delete multiple transitions, enter * for Exit state (type -1 to quit):");
            println(); println();
            esc_footer();
            move(row,col);
         }

         allstate = false;
         printw(" Exit state:  ");
         i = (INT_S) readintall(&ch, -1, MAX_STATES-1);
         if (ch == CEsc) {
            quit = true; return;
         }
         if (ch == '*') allstate = true;
         if (i == -1) break;

         tab(25);
         printw("Event label:  ");
#if defined(_x64_)
		 ch = read_string(strlabel, 1, WIDTH_EVENT);
		 if (ch == CEsc) {
			 quit = true; return;
		 }
		 sign_j = (short) get_integer_label(strlabel, &index);
#else
		 sign_j = (short) readint_and_e(&ch, -1, MAX_TRANSITIONS);
		 if (ch == CEsc) {
			 quit = true; return;
		 }
#endif

         if (sign_j == -1) break;
         j = (INT_T) sign_j;

         tab(50);
         printw("Entrance state:  ");
         k = (short) readint(&ch, -1, MAX_STATES-1);
         if (ch == CEsc) {
            quit = true; return;
         }
         if (k == -1) break;
         println();

         if (i >= s1) {
            println();
            ring_bell();
            printw("Exit state %d is illegal, please reenter!", i); println();
            println();
            if (_wherey() > 19) {
               println();
               println();
               move(22,0);
            }
            continue;
         }

		 if(sign_j == START_INTLABEL - 1){
			 println();
			 ring_bell();
			 printw("Event %s does not exist, please reenter!", global_labellist[index].strlabel); println();
			 println();
			 if (_wherey() > 19) {
				 println();
				 println();
				 move(22,0);
			 }
			 continue;
		 }

         if (k >= s1) {
            println();
            ring_bell();
            printw("Entrance state %d is illegal, please reenter!", k); println();
            println();
            if (_wherey() > 19) {
               println();
               println();
               move(22,0);
            }
            continue;
         }

         if (allstate) {
            INT_S ii;

            for (ii=0; ii < s1; ii++) {
               delete_ordlist1(j, k, &(t1[ii].next), t1[ii].numelts, &ok);
               if (ok) t1[ii].numelts--;

               /* record old triple deleted into MAKEIT.TXT */
               addtriple(ii,j,k,&old_tran_list, s_old_tran_list, &ok);
               if (ok) s_old_tran_list++;
            }
         } else {
            delete_ordlist1(j, k, &(t1[i].next), t1[i].numelts, &ok);
            if (ok) t1[i].numelts--;

            /* record old triple deleted into MAKEIT.TXT */
            addtriple(i,j,k,&old_tran_list, s_old_tran_list, &ok);
            if (ok) s_old_tran_list++;
        }
      }
   }

   // PROCEDURE TO MODIFY control status of events;
#if defined(_x64_)
   clear();
   esc_footer();
   println();

   printw("# Modify control status of events in %s? (y/*n)  ", name2); //println();
   esc_footer();

   refresh();
   ch = read_key();
   if (ch == CEsc) {
	   quit = true;
	   return;
   }

   if ( (ch == 'Y') || (ch == 'y') ) {
	   //clear();
	   println();
	   println();
	   printw("Enter the event whose control status is to be modified."); println();
	   printw("type -1 to quit:"); println(); println();
	   esc_footer();
	   do {
		   if (_wherey() > 21) {
			   col = _wherex(); row = _wherey()-1;
			   move(23,0); clrtoeol();
			   move(24,0);
			   scroll_line();

			   for (a=0; a < 6; a++) {
				   move(a,0); clrtoeol();
			   }

			   move(0,0);
			   println();
			   printw("Enter the event whose control status is to be modified."); println();
			   printw("type -1 to quit:"); println(); println();
			   esc_footer();
			   move(row,col);
		   }

		   printw("Event label:  ");
		   ch = read_string(strlabel, 1, WIDTH_EVENT);
		   if (ch == CEsc) {
			   quit = true; return;
		   }
		   sign_j = (short) get_integer_label(strlabel,  &index);

		    println(); println();

			if (sign_j == -1) break;

		   if(sign_j == START_INTLABEL - 1){
			   printw("Event [%s] does not exist.", strlabel);println();
			   printw("Re-enter the event whose control status is to be modified.", strlabel);println();
			   printw("type -1 to quit:"); println(); println();
			   esc_footer();
			   move(row,col);
			   continue;
		   }else if(sign_j < START_INTLABEL-1){
			   printw("Event %d is numerical and in [0,9999]; its control status cannot be changed.", sign_j);println();
			   printw("Re-enter the event whose control status is to be modified.", strlabel);println();
			   printw("type -1 to quit:"); println(); println();
			   esc_footer();
			   move(row,col);
			   continue;
		   }		   

		   if(sign_j %2 == 0){
			   printw("%s is uncontrollable; change it to be controllable (y/*n) ", strlabel);
		   }else{
			   printw("%s is controllable; change it to be uncontrollable (y/*n) ", strlabel);
		   }
		   refresh();
		   ch = read_key();
		   if (ch == CEsc) {
			   quit = true;
			   return;
		   }

		   println();

		   if ( (ch == 'Y') || (ch == 'y') ) {
			   if(sign_j %2 == 0){
					new_sign_j = sign_j + 1;
				}else{
					new_sign_j = sign_j - 1;
				}
			   global_labellist[index].intlabel = new_sign_j;
			   addstatepair(sign_j, new_sign_j, &sp, s_sp, &ok);
			   if(ok) s_sp ++;
		   }
		   println();
	   } while(1);

	   if(s_sp != 0){
		   eventmap_des(t1,s1, &t2,&s2,sp,s_sp,&list,&s_list,&ok);

		   if (s_list != 0) {
			   project0(&s2,&t2,s_list,list);
			   free(list);
		   }
		   free(sp);
		   freedes(s1, &t1); s1 = 0; t1 = NULL;
		   export_copy_des(&s1, &t1, s2, t2);
		   freedes(s2, &t2);
	   }
	   println();
	   println();
   }
#endif
   /* PROCEDURE FOR EDITING VOCAL STATES IN DES */
   clear();
   esc_footer();
   println();
   printw("List of vocal states of %s is currently:", name2); println();
   println();
   printvocal(s1, t1);
   println();
   println();
   printw("OK?  (*y/n)  ");

   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( (ch == 'N') || (ch == 'n') ) {
      if (ch != CEnter) {
         printw("%c", ch);
      }
      println();
      println();

      /* Uniform vocal output relabelling. */
      println();
      printw("Make uniform alteration in a vocal state output?  (y/*n)  ");

      refresh();
      ch = read_key();
      if (ch == CEsc) {
        quit = true;
        return;
      }

      if (ch != CEnter) {
         printw("%c", ch);
      }
      println();
      println();

      if ( (ch == 'Y') || (ch == 'y') ) {

         printw("Enter list of vocal state output pairs."); println();
         printw("To make all states with Old output silent, enter 0 for New output."); println();
         printw("Type -1 to quit:"); println();
         println();
         i = 0;
         while (i != -1) {
           if (_wherey() > 19) clear();
           println();
           printw("Old output:  ");
           row = _wherey();
           i = (INT_V) readint(&ch, -1, MAX_VOCAL_OUTPUT);
           if (ch == CEsc) {
              quit = true;
              return;
           }
           if (i == -1) break;

           move(row, 40);
           printw("New output:  ");
           v = (INT_V) readint(&ch, -1, MAX_VOCAL_OUTPUT);
           if (ch == CEsc) {
              quit = true;
              return;
           }
           if (v == -1) break;

           if ( ( (i < 0) || ((i >= 1) && (i <= 9)) || (i > MAX_VOCAL_OUTPUT) ) ||
                ( (v < 0) || ((v >= 1) && (v <= 9)) || (v > MAX_VOCAL_OUTPUT) ) ) {
              println();
              if (_wherey() > 17) clear();
              printw("This vocalization is illegal; please reenter"); println();
           } else {
              addstatepair((INT_S) i, (INT_S) v, &map_list, s_map_list, &ok);
              if (ok) s_map_list++;
           }
         } /* while */

         vocalmap_des(t1,s1,map_list,s_map_list);

         clear();
      }

      printw("For each state output to be altered, enter state and new output."); println();
      printw("To make state silent, enter output 0."); println();
      printw("Type -1 to quit:"); println();
      println();
      i = 0;
      while (i != -1) {
         if (_wherey() > 19)
            clear();
         println();
         printw(" State:  ");
         row = _wherey();
         i = (INT_S) readint(&ch, -1, MAX_STATES-1);
         if (ch == CEsc) {
            quit = true;
            return;
         }
		 if(i == 0){
			 println();
			 println();
			 printw(" Direct vocalization of initial state is illegal! Please reenter."); println();
			 continue;
		 }

         if (i == -1) break;

         move(row, 30);
         printw("Vocal Output:  ");
         v = (INT_V) readint(&ch, -1, MAX_VOCAL_OUTPUT);
         if (ch == CEsc) {
            quit = true;
            return;
         }
         if (v == -1) break;

         if ( (v < 0) || ((v >= 1) && (v <= 9)) || (v > MAX_VOCAL_OUTPUT) ) {
            println();
            if (_wherey() > 17) clear();
            printw("This vocalization is illegal; please reenter"); println();
		 } else {
            add_des(&t1, &s1, i);
            t1[i].vocal = v;
            addstatepair(i, (INT_S) v, &vocal_list, s_vocal_list, &ok);
            if (ok) s_vocal_list++;
         }
      }

   }

   /* PROCEDURE TO DELETE STATES */
   clear();
   esc_footer();
   println();
   printw("Delete any states from %s?  (y/*n)  ", name2);

   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }
   init = 0;
   if ( (ch == 'Y') || (ch == 'y') ) {
      if (ch != CEnter) {
         printw("%c", ch);
      }
      println();
      println();
      printw("Enter states of %s to delete", name2); println();
      printw("To quit, enter -1"); println();
      println(); tab(5);
      i = 0;
      while (i != -1) {
         col = _wherex(); row = _wherey();
         if ( (row < 20) && (col >= 75) ) {
            move(row+1, 5);
            col = 5;
            row = row+1;
         }

         if (_wherey() > 19) {
            clear();
            move(1,0);
            printw("Continue to enter states of %s to delete (type -1 to quit):", name2); println();
            move(3,4);
            col = 4;
            row = 3;
         }

         i = (INT_S) readint(&ch, -1, MAX_STATES-1);
         if (ch == CEsc) {
            quit = true; return;
         }
         if (i == -1) break;

         if ( (i >= 0) && (i < s1) ) {
            addstatelist(i, &old_state_list, s_old_state_list, &ok);
            if (ok) s_old_state_list++;
            move(row, col+7);
         }

         if (i == 0) {
            init = 1;
            /*println();
            printw("Former initial state 0 will be deleted."); println();
            println();
            printw("Please enter the new initial state ....  ");
            init = (INT_S) readint(&ch, -1, MAX_STATES-1);
            if (ch == CEsc) {
               quit = true; return;
            }
            println();
            println(); tab(5);*/
         }

         if (i >= s1) {
            println(); println();
            if (_wherey() > 17) clear();
            printw("State %d is not in %s!", i, name2); println();
            println(); tab(5);
         }
      }
   } else {
      println();
   }
   if (init == 1) {
      println();
      println();
      printw("Former initial state 0 will be deleted."); println();
      println();
      printw("Please enter the new initial state ....  ");
      init = (INT_S) readint(&ch, -1, MAX_STATES-1);
      if (ch == CEsc) {
         quit = true; return;
      }
   }
   /* Remove all reference to the deleted states.
      Make the states values to initial created states.
      No states are deleted but these state will be isolated.
      It is up to the user to purge the isolated states by
      doing a reach.

      Remember to fix initial state to zero.
   */

   /* Mark states to remove reference to as unreached */
   for (i=0; i < s1; i++)
      t1[i].reached = true;
   for (i=0; i < s_old_state_list; i++)
      t1[ old_state_list[i] ].reached = false;
   purgebadstates(s1, &t1);
   trim_endstates(&s1, &t1);
   
   /* CHECK FOR DETERMINISTISM */
   check_determinism(t1,s1,name2,&quit,true);
   if (quit == true) return;

   clear();
   esc_footer();
   if (init != 0) {
       /* Just warn user that the initial state has been recoded to zero */
      move(1,0);
      printw("%s will be recoded with initial state relabelled to 0.", name2);
      move(3,0);
   } else {
      move(1,0);
   }
/*   printw("Do you want the edited DES reachable?  (y/ *n)  "); */
   printw("Remove any unreachable state from %s and recode state set?   (y/*n)  ", name2);
   //init = 0;
   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( (ch == 'Y') || (ch == 'y') ) {
      reach_operation = true;
      n_reach(&s1, &t1, init);
   }

   if (ch == CEnter) {
      println();
   } else {
      printw("%c",ch);
   }
   println(); println();
   refresh();

   if (mem_result != 1)
      if (filedes(name2, s1, init, t1) != 0) {
          quit = true;
          move(22,0); clrtoeol();
          printw("Error writing file: %s%s%s", prefix, name2, EXT_DES);
          user_pause();
      }
}


void edit_makeit()
{
   FILE *out;
   INT_S i;
   INT_B  openingComma;
   INT_T intLabel;
   char strLabel[WIDTH_EVENT];

   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;

   fprintf(out, "%s = Edit(%s", name2, name1);

   openingComma = false;

   /* Mark and unmark list */
   if (allstatemarked)
   {
      fprintf(out, ","); openingComma = true;
      fprintf(out, "[mark +[all]");
   } else {     
      if (s_new_mark_list > 0) {
         fprintf(out, ","); openingComma = true;
         fprintf(out, "[mark ");
         for (i=0; i < s_new_mark_list; i++) {
            fprintf(out, "+[%ld]", new_mark_list[i]);
            if (i < (s_new_mark_list-1) )
               fprintf(out, ",");
         }
      }
   }

   if (allstateunmarked) {
      if (s_new_mark_list == 0) {
         fprintf(out, ","); openingComma = true;
         fprintf(out, "[mark ");
      } else {
         fprintf(out, ",");
      }
      
      fprintf(out, "-[all]");
      fprintf(out, "]");         
   } else {          
      if (s_old_mark_list > 0) {
         if (s_new_mark_list == 0) {
            fprintf(out, ","); openingComma = true;
            fprintf(out, "[mark ");
         } else {
            fprintf(out, ",");
         }

         for (i=0; i < s_old_mark_list; i++) {
            fprintf(out, "-[%ld]", old_mark_list[i]);
            if (i < (s_old_mark_list-1) )
               fprintf(out, ",");
         }
         fprintf(out, "]");
      } else {
         if (s_new_mark_list > 0) fprintf(out, "]");
      }
   }

   /* States that are deleted */
   if (s_old_state_list > 0) {
      if (openingComma == false) openingComma = true;
      fprintf(out, ",");
      fprintf(out, "[states ");
      for (i=0; i < s_old_state_list; i++) {
         fprintf(out, "-[%ld]", old_state_list[i]);
         if (i < (s_old_state_list-1) ) fprintf(out, ",");
      }
      fprintf(out, "]");
   }

   /* Transitions */
   if (s_new_tran_list > 0) {
      if (openingComma == false) openingComma = true;
      fprintf(out, ",");
      fprintf(out, "[trans ");
      for (i=0; i < s_new_tran_list; i++) {
		  intLabel = new_tran_list[i].e;
		  if(intLabel < START_INTLABEL){
				if (intLabel == EEE)
					fprintf(out, "+[%ld,e,%ld]", new_tran_list[i].i,new_tran_list[i].j);
				else 
					fprintf(out, "+[%ld,%d,%ld]", new_tran_list[i].i,intLabel,new_tran_list[i].j);
		  }else{
				get_strlabel_by_intlabel(intLabel, strLabel);
				fprintf(out, "+[%ld,%s,%ld]", new_tran_list[i].i,strLabel,new_tran_list[i].j);
		  }
         if (i < (s_new_tran_list-1) ) fprintf(out, ",");
      }
   }

   if (s_old_tran_list > 0) {
      if (s_new_tran_list <= 0) {
         if (openingComma == false) openingComma = true;
         fprintf(out, ",");
         fprintf(out, "[trans ");
      } else {
         fprintf(out, ",");
      }

      for (i=0; i < s_old_tran_list; i++) {
		  intLabel = old_tran_list[i].e;
		  if(intLabel < START_INTLABEL){
			  if (intLabel == EEE)
				  fprintf(out, "+[%ld,e,%ld]", old_tran_list[i].i,old_tran_list[i].j);
			  else 
				  fprintf(out, "+[%ld,%d,%ld]", old_tran_list[i].i,intLabel,old_tran_list[i].j);
		  }else{
			  get_strlabel_by_intlabel(intLabel, strLabel);
			  fprintf(out, "+[%ld,%s,%ld]", old_tran_list[i].i,strLabel,old_tran_list[i].j);
		  }
         if (i < (s_old_tran_list-1) ) fprintf(out, ",");
      }
      fprintf(out, "]");
   } else {
      if (s_new_tran_list > 0) fprintf(out, "]");
   }

   /* Vocal */
   if (s_vocal_list > 0) {
      openingComma = true;
      fprintf(out, ",");
      fprintf(out, "[voc ");
      for (i=0; i < s_vocal_list; i++) {
         fprintf(out, "[%ld,%ld]", vocal_list[i].data1,
                                   vocal_list[i].data2);
         if (i < (s_vocal_list-1) ) fprintf(out, ",");
      }
      fprintf(out, "]");
   }

   /* Vocal uniform */
   if (s_map_list > 0) {
      openingComma = true;
      fprintf(out, ",");
      fprintf(out, "[unif ");
      for (i=0; i < s_map_list; i++) {
         fprintf(out, "[%ld,%ld]", map_list[i].data1,
                                   map_list[i].data2);
         if (i < (s_map_list-1) ) fprintf(out, ",");
      }
      fprintf(out, "]");
   }

   if (reach_operation)
      fprintf(out, ",rch");

   fprintf(out, ")");
   fprintf(out, "  (%ld,%ld)\n\n", s1, count_tran(t1,s1));
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop((INT_OS)strlen(name2)+3);
}

void edit_p()
{
   t1 = NULL; s1 = 0;
   quit = false;

   old_state_list = NULL; s_old_state_list = 0;
   new_mark_list = NULL; s_new_mark_list = 0;
   old_mark_list = NULL; s_old_mark_list = 0;
   vocal_list = NULL; s_vocal_list = 0;
   map_list = NULL; s_map_list = 0;
   new_tran_list = NULL; s_new_tran_list = 0;
   old_tran_list = NULL; s_old_tran_list = 0;
   reach_operation = false;
   allstatemarked = allstateunmarked = false;

   edit_r();

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;         /* Reset memory function to zero */
   } else {
      if (!quit) {
        edit_makeit();
        clear();
        move(7,0);
        printw("EDITING COMPLETE"); println();
        user_pause();
      }
   }

   freedes(s1, &t1);
   free(old_state_list);
   free(new_mark_list);
   free(old_mark_list);
   free(vocal_list);
   free(map_list);
   free(new_tran_list);
   free(old_tran_list);
}

#ifdef __cplusplus
}
#endif

