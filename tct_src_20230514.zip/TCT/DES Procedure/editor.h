#ifndef _EDITOR_H
#define _EDITOR_H

#ifdef __cplusplus
extern "C" {
#endif

extern void edit_p();

#ifdef __cplusplus
}
#endif

#endif

