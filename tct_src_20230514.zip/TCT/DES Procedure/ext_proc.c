#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <sys/stat.h>
#include <process.h>
#include <conio.h>
#include <windows.h>
//#include <unistd.h>

#include "tct_io.h"
#include "curses.h"
#include "display.h"
#include "tct_proc.h"
#include "cl_tct.h"
#include "des_supp.h"
#include "mymalloc.h"

#include "ext_proc.h"
//#include "execute.h"
#include "ext_des_proc.h"
#include "localize.h"
#include "obs_check.h"
#include "canqc.h"

#define ImageCommandSet "NnIiDd"
#define NULLCommandSet "NnIi"
#define ConCommandSet "AaCc"

static filename   name1, name2, name3, name4, name5, imagename, names1[MAX_DESS],names2[MAX_DESS], group_imagename[MAX_DESS];

static long_filename long_name1;
static long_filename long_name2;
static long_filename long_name3;
static long_filename long_name4;
static long_filename long_name5;
static long_filename long_names1[MAX_DESS];
static long_filename long_names2[MAX_DESS];
static long_filename long_group_imagename[MAX_DESS];

static INT_B  quit = false;

//////////////////////////////////////////////////////////////////////////////////////
void sup_rel_coobs_header();
void ext_image_header(INT_S oper)
{
	switch(oper){
	case 1: sup_rel_coobs_header();		break;
	}
}
void ext_get_imagelist(INT_T *s_imagelist, INT_T**imagelist, INT_T *slist, INT_T **list, INT_S *mode, INT_S oper, INT_S index)
{
	INT_S	s2; 
	state_node *t2;
	INT_S      init;
	INT_T      i,j;
	short      sign_i;
	INT_B    ok;
	char       ch;
	int        row, col;
	char tmp1[80];  
	char tmp2[80]; 

	s2 = 0; 	t2 = NULL;

	strcpy(tmp1, "");
	switch(oper){
	case 0: strcat(tmp1, "erased by projection");		break;
	case 3: strcat(tmp1, "erased by supscop");			break;
	case 4: strcat(tmp1, "erased by supnorm");			break;

	case 1: 
	case 2:
	case 5:
	case 6:
	case 7:
	case 8: strcat(tmp1, "erased");						break;
	}

	strcpy(tmp2, "");
	switch(oper){
	case 0: strcat(tmp2, "nulled by projection");		break;
	case 3: strcat(tmp2, "nulled by supscop");			break;
	case 4: strcat(tmp2, "nulled by supnorm");			break;

	case 1: 
	case 2: 
	case 5:
	case 6:
	case 7: 
	case 8: strcat(tmp2, "nulled");						break;
	}

	println();
	printw("Enter either"); println();
	println();
	printw("  NULL (list of event labels %s)", tmp1); println();
	println();
	printw("or"); println();
	println();
	printw("  IMAGE (event labels retained)"); println();
	println();
	printw("or"); println();
	println();
	printw("  IMAGE_DES (single-state, marked, selflooped) DES representing list"); println(); 
	printw("	   of event labels retained)"); println();
	println();


	do {
		if (_wherey() > 20)
		{
			clear();
			ext_image_header(oper);
			esc_footer();
		}    

		printw("NULL/IMAGE/IMAGE_DES ? (n/i/d) ");
		refresh();
		ch = read_key();
		if (ch == CEsc) {
			quit = true;
			return;
		}   

		if (ch != CEnter) {
			printw("%c", ch);
		}
		println();
		println();
	} while (strchr(ImageCommandSet, ch) == NULL);

	if ((ch == 'N') || (ch == 'n'))
		mode[index] = 1;
	else if((ch == 'I') || (ch == 'i'))
		mode[index] = 2;
	else
		mode[index] = 3;

	if (mode[index] == 1)
	{
		printw("Enter list of event labels to be %s;", tmp2); println();
		printw("terminate list with -1."); println();
		println();  tab(5);
		sign_i = 0;
		while (sign_i != -1) {
			col = _wherex();
			row = _wherey();
			if (col >= 75) {
				move(row+1,5);
				col = 5;
				row++;
			}
			if (_wherey() > 21) {
				clear();
				printw("Enter list of event labels to be %s;", tmp2); println();
				printw("terminate list with -1."); println();
				println(); tab(5);
				esc_footer();
				col = _wherex();
				row = _wherey();
			}

			sign_i = (short) readint_and_e(&ch, -1, MAX_TRANSITIONS);
			if (ch == CEsc) {
				quit = true;
				return;
			}
			if (sign_i != -1) {
				i = (INT_T) sign_i;
				addordlist(i, list, *slist, &ok);
				if (ok) (*slist)++;
			}
			move(row, col+7);
		}
		println(); println();

	}
	else if(mode[index] == 2)
	{
		printw("Enter list of event labels to be retained;"); println();
		printw("terminate list with -1."); println();
		println();  tab(5);
		sign_i = 0;
		while (sign_i != -1) {
			col = _wherex();
			row = _wherey();
			if (col >= 75) {
				move(row+1,5);
				col = 5;
				row++;
			}
			if (_wherey() > 21) {
				clear();
				printw("Enter list of event labels to be retained;"); println();
				printw("terminate list with -1."); println();
				println(); tab(5);
				esc_footer();
				col = _wherex();
				row = _wherey();
			}

			sign_i = (short) readint_and_e(&ch, -1, MAX_TRANSITIONS);
			if (ch == CEsc) {
				quit = true;
				return;
			}
			if (sign_i != -1) {
				i = (INT_T) sign_i;
				addordlist(i, imagelist, *s_imagelist, &ok);
				if (ok) (*s_imagelist)++;
			}
			move(row, col+7);
		}
		println(); println();

	}else{
		quit = getname("Enter name of IMAGE_DES  .........  ", 
			EXT_DES, group_imagename[index], false);
		if (quit) return;

		init = 0L;
		if(!getdes(group_imagename[index], &s2, &init, &t2))
			return;
		for(i = 0; i < s2; i ++){
			for(j = 0; j < t2[i].numelts; j ++){
				addordlist(t2[i].next[j].data1, imagelist, *s_imagelist, &ok);
				if(ok) (*s_imagelist) ++;
			}
		}
		freedes(s2, &t2);
	}
}
void ext_get_parlist(INT_T *s_conlist, INT_T**conlist, INT_S index)
{
	INT_T      i, ee;
	short      sign_i;
	INT_B    ok;
	char       ch;
	int        row, col;
	INT_S s1, init; state_node *t1;
	INT_S j,k;

	s1 = 0;
	t1 = NULL;
	
	printw("Enter list of controllable events of %dth decentralized supervisor;", index + 1); println();
	printw("to list all controllable events, enter '*'");println();
	println();
	printw("to quit, enter -1."); println();
	println();  tab(5);
	sign_i = 0;
	while (sign_i != -1) {
		col = _wherex();
		row = _wherey();
		if (col >= 75) {
			move(row+1,5);
			col = 5;
			row++;
		}
		if (_wherey() > 21) {
			clear();
			printw("Enter list of controllable events of %dth decentralized supervisor;", index + 1); println();
			printw("to list all controllable events, enter '*'");println();
			println();
			printw("to quit, enter -1."); println();
			println(); tab(5);
			esc_footer();
			col = _wherex();
			row = _wherey();
		}

		sign_i = (short) readintall(&ch, -1, MAX_TRANSITIONS);
		if (ch == CEsc) {
			quit = true;
			goto FREE_LABEL;
		}
		if(ch == '*'){
			init = 0L;
			if(!getdes(name1, &s1, &init, &t1))
				goto FREE_LABEL;
			for(j = 0; j < s1; j ++ ){
				for(k = 0; k < t1[j].numelts; j ++ ){
					ee = t1[j].next[k].data1;
					if(ee %2 == 1){
						addordlist(ee, conlist, *s_conlist, &ok);
						if (ok) (*s_conlist)++;
					}
				}
			}
			break;
		}
		if (sign_i != -1) {
			i = (INT_T) sign_i;
			addordlist(i, conlist, *s_conlist, &ok);
			if (ok) (*s_conlist)++;
		}
		move(row, col+7);
	}
	println(); println();

FREE_LABEL:
	freedes(s1, &t1);

}
void ext_get_conlist(INT_T *s_conlist, INT_T**conlist)
{
	INT_T      i, ee;
	short      sign_i;
	INT_B    ok;
	char       ch;
	int        row, col;
	INT_S s1, init; state_node *t1;
	INT_S j,k;

	s1 = 0;
	t1 = NULL;

	printw("Enter list of controllable events:"); println();
	printw("to list all controllable events, enter '*'");println();
	println();
	printw("to quit, enter -1."); println();
	println();  tab(5);
	sign_i = 0;
	while (sign_i != -1) {
		col = _wherex();
		row = _wherey();
		if (col >= 75) {
			move(row+1,5);
			col = 5;
			row++;
		}
		if (_wherey() > 21) {
			clear();
			printw("Enter list of controllable events:"); println();
			printw("to list all controllable events, enter '*'");println();
			println();
			printw("to quit, enter -1."); println();
			println(); tab(5);
			esc_footer();
			col = _wherex();
			row = _wherey();
		}

		sign_i = (short) readintall(&ch, -1, MAX_TRANSITIONS);
		if (ch == CEsc) {
			quit = true;
			goto FREE_LABEL;
		}
		if(ch == '*'){
			init = 0L;
			if(!getdes(name1, &s1, &init, &t1)){
				goto FREE_LABEL;
			}
			for(j = 0; j < s1; j ++ ){
				for(k = 0; k < t1[j].numelts; k ++ ){
					ee = t1[j].next[k].data1;
					if(ee %2 == 1){
						addordlist(ee, conlist, *s_conlist, &ok);
						if (ok) (*s_conlist)++;
					}
				}
			}
			break;
		}
		if (sign_i != -1) {
			i = (INT_T) sign_i;
			addordlist(i, conlist, *s_conlist, &ok);
			if (ok) (*s_conlist)++;
		}
		move(row, col+7);
	}
	println(); println();

FREE_LABEL:
	freedes(s1, &t1);

}

/////////////////////////////////////////////////////////////////////////////////////////
//Operations added on part_node

void insertelem_part(INT_S row, INT_S col, INT_T elem, INT_S *s_par, part_node **par)
{
   INT_S i, j;
   
   if(row < 0 || col < 0)
      return;
   else if(row > *s_par - 1){
      *par = (part_node*)REALLOC(*par, (row + 1) * sizeof(part_node));
      if(*par == NULL){
         mem_result = 1;
         return;
      }
      for(i = *s_par; i< row + 1; i ++){
         (*par)[i].next = NULL;
         (*par)[i].numelts = 0;
      }
      *s_par = row + 1;
   }
   if((*par)[row].numelts == 0 && (*par)[row].next != NULL){
      free((*par)[row].next);
      (*par)[row].next = NULL;
   }
   if(col > (*par)[row].numelts - 1){
      (*par)[row].next = (INT_S*)REALLOC((*par)[row].next, (col + 1) * sizeof(INT_S));
      if((*par)[row].next == NULL){
         mem_result = 1;
         return;
      } 
      for(j = (*par)[row].numelts; j < col + 1; j ++)  
         (*par)[row].next[j] = -1;   
      (*par)[row].numelts = col + 1;
   }
   
   /*Fill new elment in (row, col) of par*/
   (*par)[row].next[col] = elem;
}

void addelem_part(INT_S row, INT_T elem, INT_S *s_par, part_node **par)
{
   INT_S i;
   INT_B  ok;
   
   if(row < 0 )
      return;
   else if(row > *s_par - 1){
      *par = (part_node*)REALLOC(*par, (row + 1) * sizeof(part_node));
      if(*par == NULL){
         mem_result = 1;
         return;
      }
      for(i = *s_par; i< row + 1; i ++){
         (*par)[i].next = NULL;
         (*par)[i].numelts = 0;
      }
      *s_par = row + 1;
   }
   if((*par)[row].numelts == 0 && (*par)[row].next != NULL){
      free((*par)[row].next);
      (*par)[row].next = NULL;
   }
   
   addstatelist(elem, &(*par)[row].next, (*par)[row].numelts, &ok);
   if(ok) (*par)[row].numelts ++;
   
}

////////////////////////////////////////////////////////
void path2block_header()
{
	printw("PATH-TO-BLOCK");println();
	println();
	printw("DES2 = PATH-TO-BLOCK (DES1)");println();
	println();
}
void subdes_proc(INT_S s1, state_node **t1, INT_S *s2, state_node **t2, INT_S start, INT_S end);
static INT_S i, total_block;
static INT_B ch, option, option_check, multiPage;
static INT_S s_block_stack, *block_stack;
void block_states_page_control(INT_B  lastPage, INT_S *list)
{    
	multiPage = true;
	block_stack = NULL;
	s_block_stack = 0;

   continue_page(" D(own)  U(p)  H(ead)  Esc (Exit Show)  ");

   do {
      refresh();
      ch = read_key();

      switch(ch) {
         case 'h':
         case 'H':
            option = ch;
            option_check = true;
            free(block_stack);   block_stack = NULL;
            return;

         case CEsc:
            quit = true;
            free(block_stack);   block_stack = NULL;
            return;
         case CPgDn:
            if (lastPage == true) {
               ch = 0;
               ring_bell();
            } else {
               s_block_stack++;
               block_stack = (INT_S*) realloc(block_stack,
                                       sizeof(INT_S)* s_block_stack);
               block_stack[s_block_stack-1] = list[i];
            }
            break;
         case CEnter:
            if (lastPage == false) {
               s_block_stack++;
               block_stack = (INT_S*) realloc(block_stack,
                                       sizeof(INT_S)* s_block_stack);
               block_stack[s_block_stack-1] = list[i];
            } else{
				clear();
               path2block_header();
               return;
            }
            break;
         case CPgUp:
            if (s_block_stack == 0) {
               ch = 0;
               ring_bell();
            } else {
               if (s_block_stack >= 2) {
                  i = block_stack[s_block_stack-2];
                  s_block_stack -= 2;
                  block_stack = (INT_S*) realloc(block_stack,
                                       sizeof(INT_S)* s_block_stack);

                  /* Put back the last pop */
                  s_block_stack++;
                  block_stack = (INT_S*) realloc(block_stack,
                                          sizeof(INT_S)* s_block_stack);
                  block_stack[s_block_stack-1] = list[i];
               } else {
                  i = 0;
                  i--;  /* Main loop will increment it by one. */
                  s_block_stack = 0;
                  free(block_stack); block_stack = NULL;
               }
               total_block = 0;
            }
            break;
      }
   } while ( ( ch != CEnter) && (ch != CEsc) && (ch != CPgUp) && (ch != CPgDn) );

   clear();
   path2block_header();
   println();
   printw("Block states:       "); println();
   println();
}

INT_B  display_block_states(INT_S s_list, INT_S *list)
{
   i = 0;
   multiPage = false;
   option_check = false;
   total_block = 0;

   do {
      while (i < s_list) {
          printw("%7d  ", list[i]);
		  total_block++;
          if (total_block % 8 == 0) {
              println();
          }

          if (_wherey() > 19) {
              block_states_page_control(false,list);
              if (quit) return true;
              if (option_check) return false;
          }
		  i++;
          
      }
      if (multiPage) block_states_page_control(true, list);
      i++;

   } while ( (ch != CEnter) && (ch != CPgDn) && (multiPage == true) &&
             (quit == false) && (option_check == false) );


   free(block_stack);  block_stack = NULL;
   return quit;
}
void path2block_r(INT_S *s1, state_node **t1, INT_S *state, INT_B *reprot_flag, INT_S *s_blocklist, INT_S ** blocklist)
{
	INT_OS col, row;
	INT_OS result;
	INT_S init;
	INT_S *list, s_list, i;
	INT_S s2; state_node *t2;
	INT_B ok, block_type;
	char ch;

	result = 0;
	s_list = 0; list = NULL;
	s2 = 0; t2 = NULL;

	clear();
	path2block_header();
	refresh();

	quit = getname("Enter name of DES1 .......... ", EXT_DES, name1, false);
	if(quit)  return;

	quit = getname("Enter name of DES2 ...........", EXT_DES, name2, true);
	if(quit) return;

	if(_wherey()> 19){
		clear();
		path2block_header();
		esc_footer();
	}
 
	printw("Find deadlock states or livelock states ? (*d/l) ");
	refresh();
	ch = read_key();
	if (ch == CEsc) {
		quit = true;
		return;
	}   
	if (ch != CEnter) {
		printw("%c", ch);
	}
	println();

	if ((ch == 'l') || (ch == 'L'))
		block_type = 1;
	else
		block_type = 0;


	//find the block states
	init = 0L;
	if(!getdes(name1, s1, &init, t1)){
		result = -1;
		goto FINISH;
	}
	if(block_type == 1){
		if(*s1 != 0){
			for (i=0; i < *s1; i++){
				(*t1)[i].reached = false;
			}

			(*t1)[0].reached = true;
			b_reach((*t1)[0].next, 0L, t1, *s1);
			local_coreach2(*s1, t1);

			for (i = 0; i < *s1; i ++) {
				if ((*t1)[i].reached && (*t1)[i].coreach){}
				//size++;
				else{
					addstatelist(i, &list, s_list, &ok);
					if(ok) s_list ++;
				}
			}
		}
	}else{
		for (i=0; i < *s1; i++){
			(*t1)[i].reached = false;
		}

		(*t1)[0].reached = true;
		b_reach((*t1)[0].next, 0L, t1, *s1);

		for(i = 0; i < *s1; i ++){
			if((*t1)[i].reached){
				if((*t1)[i].numelts == 0 && (*t1)[i].marked == false){
					addstatelist(i, &list, s_list, &ok);
					if(ok) s_list ++;
				}
			}
		}
	}
	if (s_list == 0) {
		result = 1;
		goto FINISH;
	}

	if(_wherey()> 17){
		clear();
		path2block_header();
		esc_footer();
	}

	println();
	printw("Block states:       "); println();
	println();
	display_block_states(s_list, list);	
	println();

	quit = false;

	while(true){
		
		if(_wherey()> 20){
			clear();
			path2block_header();
			esc_footer();
		}		
		println();
		printw("Enter one of block states ... ", *s1 - 1);
		*state = (INT_S)readint(&ch, 0, *s1 - 1);
		println();
		if(ch == CEsc){
			quit = true;
			free(list);
			return;
		}
		if(instatelist(*state, list, s_list)){
			break;
		}else{			
			if(_wherey()> 17){
				clear();
				path2block_header();
				esc_footer();
			}			
			println();
			printw("State %d is nonblocking; select the block state from block state list:", *state); 	println();
			println();
			display_block_states(s_list, list);
			println();
		}
	}

	if(_wherey()> 19){
		clear();
		path2block_header();
		esc_footer();
	}
	println();
	println();
	printw("Report block state list in MAKEIT.TXT? (y/n*) ");
	refresh();
	ch = read_key();
	if (ch == CEsc) {
		quit = true;
		return;
	}   
	if (ch != CEnter) {
		printw("%c", ch);
	}
	println();

	if ((ch == 'y') || (ch == 'Y')){
		*reprot_flag = 1;
		*s_blocklist = s_list;
		*blocklist = (INT_S*)CALLOC(*s_blocklist, sizeof(INT_S));
		memcpy(*blocklist, list, s_list * sizeof(INT_S));
		free(list);
	}
	else
		*reprot_flag = 0;


	col = _wherex();
	row = _wherey();
	move(22,0); clrtoeol();
	move(23,0); clrtoeol();
	printw("Processing: Please wait...");
	refresh();

	mark_start_time();

	subdes_proc(*s1, t1, &s2, &t2, 0, *state);
	//t2[*state].marked = true;
	
	init = 0L;
	filedes(name2, s2, init, t2);
	freedes(*s1, t1); *s1 = 0; *t1 = NULL;
	freedes(s2, &t2); s2 = 0; t2 = NULL;
	//result = path2block_proc(name2, name1);

	//path2deadlock_p();

	mark_stop_time();

	move(row, col);

FINISH:
	
	if(result == 0){
		strcpy(long_name2, "");
		make_filename_ext(long_name2, name2, EXT_DES);
		if(!exist(long_name2)){
			quit = true;
			return;
		}else{
			init = 0L;
			if(!getdes(name2, s1, &init, t1)){
				quit = true;
				return;
			}
		}
	}else if(result == 1){
		freedes(*s1, t1); *s1 = 0; *t1 = NULL;
		println();
		printw("There does not exist blocked state in %s", name1);
	}
	if(mem_result == 1){
		quit = true;
		return;
	}

}
void path2block_makeit(INT_S s1, state_node *t1, INT_S state, INT_B report_flag, INT_S s_blocklist, INT_S * blocklist)
{
	FILE* out;
	INT_S i;

	out = fopen("tmp.$$$", "w");
	if (out == NULL) return;

	fprintf(out, "%s = Path-to-block(%s,%d)", name2, name1, state);
	fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1));

	if(report_flag){
		fprintf(out, "  Block states = ");
		if(s_blocklist == 0)
			fprintf(out, "None");
		else{
			fprintf(out, "[");
			for (i=0; i < s_blocklist; i++) {
				fprintf(out, "%d", blocklist[i]);
				if (i+1 < s_blocklist)
					fprintf(out, ",");
			}
			fprintf(out, "]  ");
		}
	}

	appendTime(out, (INT_OS)strlen(name2)+3);
	fprintf(out, "\n\n");
	fclose(out);

	mergeChop((INT_OS)strlen(name2)+3);
}
void path2block_p()
{
	INT_S s1; state_node *t1; INT_S state;
	INT_S s_blocklist, *blocklist;
	INT_B report_flag;

	s1 = 0; t1 = NULL;
	s_blocklist = 0; blocklist = NULL;
	report_flag = false;

	path2block_r(&s1, &t1, &state, &report_flag, &s_blocklist, &blocklist);

	if(mem_result == 1){
		mem_result = 0;
		OutOfMemoryMsg();
		user_pause();
	}else{
		if(!quit){
			if(s1 > 0){
				path2block_makeit(s1, t1, state, report_flag, s_blocklist, blocklist);
				move(20,0); clrtoeol();
				move(21,0); clrtoeol();
				move(22,0); clrtoeol();
				move(21,0);
				printw("Shortest path to selected block state is reported in %s%s", name2, EXT_DES);
			}
			user_pause();
		}else
			quit = 0;
	}
	echo_free();
	freedes(s1, &t1);
	free(blocklist);
}
////////////////////////////////////////////////////////
void path2deadlock_header()
{
	printw("PATH-TO-DEADLOCK");println();
	println();
	printw("DES2 = PATH-TO-DEADLOCK (DES1)");println();
	println();
}
void path2deadlock_r(INT_S *s1, state_node **t1)
{
	INT_OS col, row;
	INT_OS result;
	INT_S init;

	result = 0;

	clear();
	path2deadlock_header();
	refresh();

	quit = getname("Enter name of DES1 .......... ", EXT_DES, name1, false);
	if(quit)  return;

	quit = getname("Enter name of DES2 ...........", EXT_DES, name2, true);
	if(quit) return;

	col = _wherex();
	row = _wherey();
	move(22,0); clrtoeol();
	move(23,0); clrtoeol();
	printw("Processing: Please wait...");
	refresh();

	mark_start_time();

	result = path2deadlock_proc(name2, name1);

	mark_stop_time();

	move(row, col);

	if(result == 0){
		strcpy(long_name2, "");
		make_filename_ext(long_name2, name2, EXT_DES);
		if(!exist(long_name2)){
			quit = true;
			return;
		}else{
			init = 0L;
			if(!getdes(name2, s1, &init, t1)){
				quit = true;
				return;
			}
		}
	}
	if(mem_result == 1){
		quit = true;
		return;
	}

}
void path2deadlock_makeit(INT_S s1, state_node *t1)
{
	FILE* out;

	out = fopen(get_makeit(), "a");
	if (out == NULL) return;
	fprintf(out, "%s = Path-to-deadlock(%s)", name2, name1);
	fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1));
	appendTime(out, (INT_OS)strlen(name2)+3);
	fprintf(out, "\n\n");
	fclose(out);
}
void path2deadlock_p()
{
	INT_S s1; state_node *t1;

	s1 = 0; t1 = NULL;

	path2deadlock_r(&s1, &t1);

	if(mem_result == 1){
		mem_result = 0;
		OutOfMemoryMsg();
		user_pause();
	}else{
		if(!quit){
			path2deadlock_makeit(s1, t1);
			move(20,0); clrtoeol();
			move(21,0); clrtoeol();
			move(22,0); clrtoeol();
			move(21,0);
			printw("Shortest paths to deadlock states are reported in %s%s", name2, EXT_DES);
			user_pause();
		}else
			quit = 0;
	}
	echo_free();
	freedes(s1, &t1);
}
///////////////////////////////////////////////////////
void attach_header()
{
	printw("ATTACH"); println();
	println();
	printw("DES3 = ATTACH (DES1, [STATE1], DES2)"); println();
	println();
}
void attach_makeit(INT_S s1, state_node *t1, INT_S state, INT_B  is_det)
{
	FILE* out;
	//    INT_S i;
	//    INT_OS   offset;

	/*Write to a tempory file*/
	out = fopen("tmp.$$$","w");
	if(out == NULL) return;

	fprintf(out, "%s = Attach(%s,[%ld], %s)", name3,  name1, state, name2);

	fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1));

	if(is_det)
		fprintf(out, "  Deterministic.");
	else
		fprintf(out, "  Nondeterministic.");

	appendTime(out, (INT_OS)strlen(name3) + 3);
	fprintf(out,"\n\n");
	fclose(out);
	mergeChop((INT_OS)strlen(name3) + 3);

}
void attach_p()
{
	INT_S state;
	INT_S s1, s2;
	state_node *t1, *t2;
	INT_S init;
	char ch;
	INT_B  is_det;
	INT_OS result;

	s1 = s2 = 0;
	t1 = t2 = NULL;

	state = -1;
	is_det = false;
	result = 0;

	clear();
	attach_header();
	refresh();

	quit = getname("Enter name of DES1 ............. ", EXT_DES, name1, false);
	if(quit)  return;


	quit = getname("Enter name of DES2 ............. ", EXT_DES, name2, false);
	if(quit)  return;

	quit = getname("Enter name of DES3 ............. ", EXT_DES, name3, true);
	if(quit)  return;


	init = 0L;
	if(!getdes(name1, &s1, &init, &t1)){
		goto ATTACH_LABEL;
	}

	printw("Enter state of %s to which state [0] of %s should be attached", name1, name2);println();
	printw("                                    (between 0 and %d) ................ ", s1 - 1);
	state = readint(&ch, 0, s1 - 1); println();
	if(ch == CEsc){
		goto ATTACH_LABEL;
	}
	freedes(s1, &t1);
	s1 = 0; t1 = NULL;

	mark_start_time();

	result = attach_proc(name3, name1, name2, state);

	mark_stop_time();

	if(result == 0){
		strcpy(long_name3, "");
		make_filename_ext(long_name3, name3, EXT_DES);   
		if (exist(long_name3))
		{
			init = 0;
			if(!getdes(name3, &s1, &init, &t1)){
				quit = true;
				goto ATTACH_LABEL;
			}

			is_det = is_deterministic(t1, s1);

			move(20,0); clrtoeol();
			move(21,0); clrtoeol();
			move(22,0); clrtoeol();
			move(21,0);
			if (is_det)
				printw("%s is DETERMINISTIC.", name3);
			else
				printw("%s is NONDETERMINISTIC.", name3);                           
		}      
	} else 
		quit = true;

	if(mem_result == 1){
		mem_result = 0;
		OutOfMemoryMsg();
		user_pause();
	}
	else{
		if(!quit){
			attach_makeit(s1, t1, state, is_det);
			user_pause();
		}            
	}
	echo_free();

ATTACH_LABEL:
	freedes(s1, &t1);
	freedes(s2, &t2);     

}
///////////////////////////////////////////////////////
void ext_obs_header()
{
     printw("NATURAL OBSERVER"); println();
     println();
     printw("(DES3,DES4) = NATOBS (DES1, DES2/DAT2/[EVENTLIST])");println();
     println();
}

void ext_obs_header1()
{
	printw("NATURAL OBSERVER"); println();
	println();
	printw("(DES3,DES4) = NATOBS (%s, DES2/DAT2/[EVENTLIST])", name1);println();
	println();
}
void ext_obs_header2(INT_OS entry_type)
{
	printw("NATURAL OBSERVER"); println();
	println();
	switch(entry_type){
	case 1:  printw("(DES3,DES4) = NATOBS (%s, %s)", name1, name2); break;
	case 2:  printw("(DES3,DES4) = NATOBS (%s, %s)", name1, name2); break;
	case 3:  printw("(DES3,DES4) = NATOBS (%s, [EVENTLIST])", name1); break;
	}	
	println();
	println();
}

void ext_obs_header3(INT_OS entry_type)
{
	printw("NATURAL OBSERVER"); println();
	println();
	switch(entry_type){
	case 1:  printw("(%s,%s) = NATOBS (%s, %s)", name3, name4, name1, name2); break;
	case 2:  printw("(%s,%s) = NATOBS (%s, %s)", name3, name4, name1, name2); break;
	case 3:  printw("(%s,%s) = NATOBS (%s, [EVENTLIST])", name3, name4, name1); break;
	}	
	println();
	println();
}

boolean natobs_getname(char *prompt,
	char *ext,
	char *name,
	boolean newflag, 
	INT_B *existing)
{
	boolean quit;
	char ch;
	char longfilename[100];
	//boolean existing;

	*existing = false;
	quit = false;
	strcpy(name, "");

	//do {
	if ( _wherey() > MAXSCREENY ) {
		clear();
		println();
	}
	printw("%s", prompt);
	esc_footer();
	refresh();
	ch = read_filename(name, 1, MAX_DES_NAME_LEN);
	println();
	if (ch == CEsc) {
		quit = true;
	} else {
		make_filename_ext(longfilename, name, ext);
		if (newflag) {
			if ( exist(longfilename) ) {
				ring_bell();
				overwriteYN(name);
				refresh();
				ch = read_key();
				if (ch == CEnter) {
					println();
				} else {
					printw("%c", ch);
					println();
				}
				println();
				if (ch == CEsc) quit = true;
				if ( (ch == 'Y') || (ch == 'y') || (ch == CEnter) ) *existing = true;
				refresh();
			} else {
				*existing = true;
			}
		} else {
			if (! exist(longfilename) ) {
				ring_bell();
				doesNotExist(name);
				println();
				refresh();
				*existing = false;
			} else {
				*existing = true;
			}
		}
	}
	//} while ( (quit == false) && (existing == false));
	println();
	refresh();

	return quit;
}


void ext_obs_r(INT_S *s1, state_node **t1,
	INT_T *slist, INT_T **list,
	INT_T *s_imagelist, INT_T **imagelist,
	INT_T *s_ext_imagelist, INT_T ** ext_imagelist,               
	INT_B  *null_flag,
	INT_B  *report_qc,
	INT_S *s_statemap, INT_S **statemap,
	INT_OS *mode,
	INT_OS *entry_type)
{
	INT_S init;
	INT_S i,j;
	short sign_i;
	INT_B  ok, existing;
	char ch;
	INT_OS row, col;
	INT_OS result;
	INT_T s_tmp_imagelist, *tmp_imagelist, s_tmp_list, *tmp_list;
	INT_S s2; 
	state_node *t2;
	INT_B print_flag;
	INT_T index;
	char strLabel[WIDTH_EVENT];

	s_tmp_imagelist = s_tmp_list = 0;
	tmp_imagelist = tmp_list  = NULL;
	s2 = 0; t2 = NULL;

	print_flag = true;
	result = 0;

	clear();
	ext_obs_header();
	refresh();

	//printw("Enter name of DES1 for which"); println();
	quit = getname("Enter name of DES1 to be projected by\n  natural observer ............................... ", EXT_DES, name1, false);
	if(quit)  return;

	printw("Select DES2 (to seed all events occurring in existing DES2)");println();
	printw("or DAT2 (to seed all events tabled in existing Condat file DAT2)"); println();
	printw("or EVENTLIST (to seed list of events entered by user):"); println();
	println();

START:		
	if (_wherey() > 20)
	{
		clear();
		ext_obs_header1();
		esc_footer();
	}    


	printw("DES2/DAT2/EVENTLIST?  (*d/a/e) ... ");
	refresh();
	ch = read_key();
	if (ch == CEsc) {
		quit = true;
		return;
	}   

	if (ch != CEnter) {
		printw("%c", ch);
	}
	println();
	println();

	if((ch == 'A') || (ch == 'a')){
		*entry_type = 2;
		quit = natobs_getname("Enter name of DAT2 (Condat) file to be searched .....  ",
			EXT_DAT, name2, false, &existing);
		if (quit) return;
		if(!existing)
			goto START;

	}else if((ch == 'E') || (ch == 'e')){
		*entry_type = 3;
		printw("Enter desired event list; terminate list with -1."); println();
		println();  tab(5);
		sign_i = 0;
		while (sign_i != -1) {
			col = _wherex();
			row = _wherey();
			if (col >= 75) {
				move(row+1,5);
				col = 5;
				row++;
			}
			if (_wherey() > 21) {
				clear();
				printw("Enter desired event list; terminate list with -1."); println();
				println(); tab(5);
				esc_footer();
				col = _wherex();
				row = _wherey();
			}
#if defined(_x64_)
			ch = read_string(strLabel, 1, WIDTH_EVENT);
			if (ch == CEsc) {
				quit = true; return;
			}
			sign_i = (short) generate_integer_label(strLabel, 1, &index);
			if (ch == CEsc) {
				quit = true;
				return;
			}
			if (sign_i != -1) {
				i = (INT_S)sign_i;
				addordlist((INT_T)i, imagelist, *s_imagelist, &ok);
				if (ok) (*s_imagelist)++;
			}
			move(row, col+10);
#else
			sign_i = (short) readint_and_e(&ch, -1, MAX_TRANSITIONS);
			if (ch == CEsc) {
				quit = true;
				return;
			}
			if (sign_i != -1) {
				i = (INT_S)sign_i;
				addordlist((INT_T)i, imagelist, *s_imagelist, &ok);
				if (ok) (*s_imagelist)++;
			}
			move(row, col+7);
#endif
		}
		println(); println();

	}else{
		*entry_type = 1;
		quit = natobs_getname("Enter name of DES2 to be searched .....  ",
			EXT_DES, name2, false, &existing);
		if (quit) return;
		if(!existing)
			goto START;	
	}

	if (_wherey() > 18)
	{
		clear();
		ext_obs_header2(*entry_type);
		esc_footer();
	} 

	println();

	quit = getname("Enter name of DES3 for projection of DES1 ........ ", EXT_DES, name3, true);
	if(quit)  return;

	quit = getname("Enter name of DES4 representing natural\n  observer's Image event list .................... ", EXT_DES, name4, true);
	if(quit)  return;

	init = 0L;
	if(getdes(name1,s1,&init, t1) == false){
		quit = true;
		return;
	}

	if(*entry_type != 3){
		if(*entry_type == 1)
			init = 0L;
		else
			init = -1L;
		if(getdes(name2,&s2,&init, &t2) == false){
			quit = true;
			return;
		}
		for(i = 0; i < s2; i ++){
			for(j = 0; j < t2[i].numelts; j ++){
				addordlist(t2[i].next[j].data1, imagelist, *s_imagelist, &ok);
				if(ok) (*s_imagelist) ++;
			}
		}
	}

	gen_complement_list(*t1, *s1, *imagelist, *s_imagelist, list, slist);
	if(mem_result == 1){
		quit = true;
		goto FREE_LABEL;
	}

	s_tmp_imagelist = *s_imagelist;
	tmp_imagelist = (INT_T*)CALLOC(s_tmp_imagelist, sizeof(INT_T));
	if(tmp_imagelist == 0 && s_tmp_imagelist != 0){
		mem_result = 1;
		quit = true;
		goto FREE_LABEL;
	}
	for(i = 0; i < s_tmp_imagelist; i ++)
		tmp_imagelist[i] = (*imagelist)[i];
	s_tmp_list = *slist;
	tmp_list = (INT_T*)CALLOC(s_tmp_list, sizeof(INT_T));
	if(tmp_list == 0 && s_tmp_list != 0){
		mem_result = 1;
			quit = true;
		goto FREE_LABEL;
	}
	for(i = 0; i < s_tmp_list; i ++)
		tmp_list[i] = (*list)[i];
	freedes(*s1,t1);
	*s1 = 0; *t1 = NULL;

	if(_wherey() > 20){
		clear();
		ext_obs_header3(*entry_type);
		esc_footer();
	}     
	col = _wherex();
	row = _wherey();
	move(22,0); clrtoeol();
	move(23,0); clrtoeol();
	printw("Processing: Please wait...");
	refresh();
	move(row,col);

	mark_start_time();

	*mode = 1;
	result = ext_obs_proc(name3, name4, name1, name2, &s_tmp_list, &tmp_list, &s_tmp_imagelist, &tmp_imagelist,
		s_ext_imagelist, ext_imagelist, s_statemap, statemap, *mode, print_flag, *entry_type);

	mark_stop_time(); 

	//   move(row,col); 

	if(result == CR_OK){
		*s1 = 1;
		*t1 = newdes(*s1);
		(*t1[0]).marked = true;
		for(i = 0; i < *s_ext_imagelist; i ++){
			addordlist1((*ext_imagelist)[i],0, &(*t1)[0].next, (*t1)[0].numelts, &ok);
			if(ok) (*t1)[0].numelts ++;
		}
		if (mem_result != 1)
		{
			init = 0L;
			filedes(name4, *s1, init, *t1); 
		}

	} else{
		if(result == CR_OUT_OF_MEMORY)
			mem_result = 1;
		else
			quit = true;
	}
FREE_LABEL:
	free(tmp_imagelist);
	free(tmp_list);
	freedes(s2, &t2);

}
void ext_obs_makeit(INT_S s1, state_node *t1, INT_S s2, state_node *t2, INT_OS mode, INT_OS entry_type, INT_T s_imagelist, INT_T *imagelist)
{   
	FILE* out;
	INT_T i;
	INT_T intLabel;
	char strLabel[WIDTH_EVENT];

	/* Write to a tempory file */
	out = fopen("tmp.$$$", "w");
	if (out == NULL) return;

	fprintf(out, "(%s,%s) = Natobs(%s,", name3,name4, name1);
	if(entry_type == 1){
		fprintf(out, "%s.DES", name2);
	}else if(entry_type == 2){
		fprintf(out, "%s.DAT", name2);
	}else{
		fprintf(out, "[");
		for(i = 0; i < s_imagelist; i ++){
			intLabel = imagelist[i];
			if(intLabel < START_INTLABEL)
				fprintf(out, "%d", intLabel);
			else{
				get_strlabel_by_intlabel(intLabel, strLabel);
				fprintf(out, "%s", strLabel);
			}
			if(i < s_imagelist - 1)
				fprintf(out, ",");
		}
		fprintf(out, "]");
	}


	fprintf(out, ")  ((%ld,%ld);(%ld,%ld))", s2, count_tran(t2, s2), s1, count_tran(t1, s1));    

	appendTime(out, (INT_OS)strlen(name3) + (INT_OS)strlen(name4) + 6);
	fprintf(out, "\n\n");
	fclose(out);

	/* Merge file into MAKEIT.TXT */
	mergeChop((INT_OS)strlen(name3) + (INT_OS)strlen(name4) + 6);
}
void ext_obs_p()
{
	INT_S s1, s2, init;
	state_node *t1, *t2;
	INT_T slist, *list;
	INT_T s_imagelist, *imagelist;
	INT_T s_ext_imagelist, *ext_imagelist;
	INT_B  null_flag = true;
	INT_B  report_qc = false;
	INT_S s_statemap, *statemap;
	INT_OS entry_type;
	INT_OS mode = 1;

	s1 = s2 = 0;  t1 = t2 = NULL;
	slist = s_imagelist = s_ext_imagelist = 0;
	list = imagelist = ext_imagelist = NULL;
	s_statemap = 0; statemap = NULL;

	ext_obs_r(&s1, &t1, &slist, &list, &s_imagelist, &imagelist, 
		&s_ext_imagelist, &ext_imagelist, &null_flag, &report_qc, &s_statemap, &statemap, &mode, &entry_type);

	if (mem_result == 1) {
		mem_result = 0;
		OutOfMemoryMsg();
		user_pause();
	} else {
		if (!quit) {
			init = 0L;
			if(getdes(name3,&s2, &init, &t2) == true){
				ext_obs_makeit(s1,t1,s2,t2,mode,entry_type,s_imagelist, imagelist);
			}
			user_pause();
		}
	}

	freedes(s1,&t1);
	freedes(s2,&t2);

	free(list);
	free(imagelist);
	free(ext_imagelist);
	free(statemap);
}


//////////////////////////////////////////////////////
void ext_occ_header()
{
     printw("EXTEND OUTPUT CONTROL CONSISTENCY EVENT SET"); println();
     println();
     printw("EXTIMAGE = EXTENDOCC (DES1, NULL [or IMAGE])");println();
     println();
}
void ext_occ_r(INT_T *slist, INT_T **list,
               INT_T *s_imagelist, INT_T **imagelist,
               INT_T *s_ext_imagelist, INT_T ** ext_imagelist,               
               INT_B  *null_flag)
{
     INT_S s1, init; 
     state_node *t1;
     INT_T i;
     short sign_i;
     INT_B  ok;
     char ch;
     INT_OS row, col;
     INT_OS result;
     
     s1 = 0; t1 = NULL;
     
     clear();
     ext_occ_header();
     refresh();
     
     quit = getname("Enter name of DES1 .......... ", EXT_DES, name1, false);
     if(quit)  return;
     
     //quit = getname("Enter name of DES2 ...........", EXT_DES, name2, true);
     //if(quit) return;
     
     if(_wherey() > 12){
         clear();
         ext_occ_header();
         esc_footer();
     }
     
     println();
     printw("Enter either"); println();
     println();
     printw(" NULL (list of event labels erased)"); println();
     println();
     printw("or"); println();
     println();
     printw(" IMAGE (event labels retained)"); println();
     println();
     
     do{
        if(_wherey() > 20){
           clear();
           ext_occ_header();
           esc_footer();
        }
        printw("NULL/IMAGE ? (n/i) ");
        refresh();
        ch = read_key();
        if(ch != CEnter)
           printw("%c",ch);
        println();
        println();
     } while(strchr(NULLCommandSet,ch) == NULL);
     
     if(ch == 'N' || ch == 'n')
        *null_flag = true;
     else 
        *null_flag = false;
     
     if(*null_flag){
        printw("Enter list of event labels to be nulled;"); println();
        printw("terminate list with -1."); println();
        println(); tab(5);
        sign_i = 0;
        while(sign_i != -1){
           col = _wherex();
           row = _wherey();
           if(col > 75){
              move(row + 1, 5);
              col = 5;
              row ++;
           }
           if(_wherey() > 21){
              clear();
              printw("Enter list of event labels to be nulled;"); println();
              printw("terminate list with -1."); println();
              println();tab(5);
              esc_footer();
              col = _wherex();
              row = _wherey();
           }
           
           sign_i = (short)readint(&ch, -1, MAX_TRANSITIONS);
           if(ch == CEsc){
              quit = true;
              return;
           }
           if(sign_i != -1){
              i = (INT_T)sign_i;
              addordlist(i,list,*slist,&ok);
              if(ok) (*slist)++;
           }
           move(row, col + 7);
        }
        println();
        println();        
     } else{
        printw("Enter list of event labels to be retained;"); println();
        printw("terminate list with -1."); println();
        println(); tab(5);
        sign_i = 0;
        while(sign_i != -1){
           col = _wherex();
           row = _wherey();
           if(col > 75){
              move(row + 1, 5);
              col = 5;
              row ++;
           }
           if(_wherey() > 21){
              clear();
              printw("Enter list of event labels to be retained;"); println();
              printw("terminate list with -1."); println();
              println(); tab(5);
              esc_footer();
              col = _wherex();
              row = _wherey();
           }
           
           sign_i = (short)readint(&ch, -1, MAX_TRANSITIONS);
           if(ch == CEsc){
              quit = true;
              return;
           }
           if(sign_i != -1){
              i = (INT_T)sign_i;
              addordlist(i, imagelist, *s_imagelist,&ok);
              if(ok) (*s_imagelist) ++;
           }
           move(row, col + 7);
        }
        println();
        println();
     }
    
     init = 0L;
     if(getdes(name1,&s1,&init, &t1) == false){
        quit = true;
        return;
     }
     if(*null_flag){
        gen_complement_list(t1,s1,*list,*slist,imagelist, s_imagelist);
     }
     //freedes(s1,&t1);
     
     if(_wherey() > 20){
        clear();
        ext_occ_header();
        esc_footer();
     }     
     col = _wherex();
     row = _wherey();
     move(22,0); clrtoeol();
     move(23,0); clrtoeol();
     printw("Processing: Please wait...");
     refresh();
     
     mark_start_time();
     
     result = ext_occ_proc(s1, t1, *s_imagelist, *imagelist, s_ext_imagelist, ext_imagelist);
     

     mark_stop_time(); 
     
     move(row,col); 
     
     if(result == CR_OK){
           println();
           printw("Extended event label list is:"); println();
           println(); tab(5);         
           for(i = 0; i< *s_ext_imagelist; i++){
              col = _wherex();
              row = _wherey();
              if(col > 75){
                 move(row + 1, 5);
                 col = 5;
                 row ++;
              }
              if(_wherey()> 20){
                 printw("Extended event label list is:"); println();
                 println(); tab(5);                 
                 col = _wherex();
                 row = _wherey();
              }
              printw("%d", (*ext_imagelist)[i]);
              move(row, col + 7);
           }
        //}else
        //   quit = true;
     } else{
        if(result == CR_OUT_OF_MEMORY)
           mem_result = 1;
        else
           quit = true;
     }
          
}
void ext_occ_makeit(INT_T slist, INT_T *list,
                    INT_T s_imagelist, INT_T *imagelist,
                    INT_T s_ext_imagelist, INT_T * ext_imagelist,               
                    INT_B  null_flag)
{   
     FILE* out;
     INT_T i;
//     INT_S ii, jj;
//     INT_B  elem, prev;

     /* Write to a tempory file */
     out = fopen("tmp.$$$", "w");
     if (out == NULL) return;
     
     fprintf(out, "ExtImage = Extendocc(%s,", name1);

     if (null_flag)
     {
        fprintf(out, "Null[");
        for (i=0; i < slist; i++) {
           fprintf(out, "%d", list[i]);
           if (i+1 < slist)
              fprintf(out, ",");
        }
     }
     else
     {
        fprintf(out, "Image[");
        for (i=0; i < s_imagelist; i++) {
           fprintf(out, "%d", imagelist[i]);
           if (i+1 < s_imagelist)
              fprintf(out, ",");
        }
     }
     fprintf(out, "])  ");
     fprintf(out, "ExtImage: [");
     for(i = 0; i < s_ext_imagelist; i ++){
        fprintf(out, "%d", ext_imagelist[i]);
        if(i + 1 < s_ext_imagelist)
           fprintf(out,",");
     }
     fprintf(out,"]");
   
    // fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1));    
   
     appendTime(out, 11);
     fprintf(out, "\n\n");
     fclose(out);

     /* Merge file into MAKEIT.TXT */
     mergeChop(11);
}
void ext_occ_p()
{
     INT_S s1;
     state_node *t1;
     INT_T slist, *list;
     INT_T s_imagelist, *imagelist;
     INT_T s_ext_imagelist, *ext_imagelist;
     INT_B  null_flag = true;
//     INT_B  report_qc = false;
//     INT_S s_statemap, *statemap;
//     INT_OS mode = 1;
     
     s1 = 0;  t1 = NULL;
     slist = s_imagelist = s_ext_imagelist = 0;
     list = imagelist = ext_imagelist = NULL;
//     s_statemap = 0; statemap = NULL;
     
     ext_occ_r(&slist, &list, &s_imagelist, &imagelist, 
                  &s_ext_imagelist, &ext_imagelist, &null_flag);
                  
     if (mem_result == 1) {
        mem_result = 0;
        OutOfMemoryMsg();
        user_pause();
     } else {
        if (!quit) {
        ext_occ_makeit(slist,list,s_imagelist,imagelist,
                        s_ext_imagelist,ext_imagelist,null_flag);
        user_pause();
        }
     }
     
    // freedes(s1,&t1);
     
     free(list);
     free(imagelist);
     free(ext_imagelist);
}
///////////////////////////////////////////////////////////////
void ext_eventset_header(INT_OS mode)
{
     printw("EXTEND EVENT SET"); println();
     println();
     printw("DES2 = EXTOBSERVER (DES1, NULL [or IMAGE], EXTIMAGE)");println();
     println();
}
void extend_eventset_p()
{
     INT_OS mode;
     char ch;
     
     clear();
     printw("EXTEND EVENT SET"); println();
     println();
     refresh();
     
     println();
     printw("1. Extend Natural Observerable Event Set;"); println();
     println();
     printw("2. Extend Output Control Consistency Event Set."); println();
     println();
     println();
     
     printw("Please choose option 1 or 2 ... ");
     mode = (INT_OS)readint(&ch, 1, 2);
     if(ch == CEsc){
        return;
     }
     
     if(mode == 1)
        ext_obs_p();
     else
        ext_occ_p();
     //clear();
     //ext_eventset_header(mode);
     //refresh();
     
     //user_pause();

}
///////////////////////////////////////////////////////////////
//
void supcon_comb_header()
{
	printw("SUPCON"); println();
	println();
	printw("SUPER = SUPCON ((PLANT1, PLANT2, ...), SPEC)"); println();
	println();
}
void supcon_comb_r(state_node **t3, INT_S *s3)
{
	INT_S  init,i,j,k;
	INT_S  *macro_ab, *macro_c, *macro_d, s_macro_c;
	INT_OS    result;
	INT_OS num_plant;
	char prompt[100], condat_result[MAX_PATH];
	INT_S s1,s2,s4; state_node *t1,*t2,*t4;
	INT_S s_pn, s_tmpn; part_node *pn, *tmpn;
	INT_T s_event_list, *event_list;
	INT_S state1, state2;
	char ch;
	INT_B ok;
	FILE *out;

	macro_ab = macro_c  = macro_d = NULL;
	s_macro_c = 0;

	s1 = s2 = s4 = 0; t1 = t2 = t4 = NULL;
	s_pn = s_tmpn = 0; pn = tmpn = NULL;
	s_event_list = 0; event_list = NULL;

	out = NULL;

	clear();
	supcon_comb_header();
	refresh();
	result = 0;

	quit = getname("Enter name of PLANT ......... ",EXT_DES,name1,true);
	if(quit) return;

	printw("Enter number of independent plant components ... (between 1 and %d) ", MAX_DESS);
	num_plant = (INT_OS)readint(&ch,1,MAX_DESS); println();
	if(ch == CEsc){
		quit = true;
		return;
	}
	println();
	for(i = 0; i < num_plant; i ++){
		strcpy(prompt,"");
		sprintf(prompt,"Enter name of PLANT%d ........ ",i + 1);
		if(_wherey() > 19){
			clear();
			supcon_comb_header();
			esc_footer();
		}
		quit = getname(prompt,EXT_DES,names1[i],false);
		if(quit) return;
		init = 0L;
		if(getdes(names1[i],&s1,&init,&t1) == true){
			for(j = 0; j < s1; j ++){
				for(k = 0; k < t1[j].numelts; k ++){
					addordlist(t1[j].next[k].data1,&event_list, s_event_list,&ok);
					if(ok) s_event_list ++;
				}
			}
		}
		freedes(s1,&t1);
		s1 = 0; t1 = NULL;
	}
	if(_wherey() > 19){
		clear();
		supcon_comb_header();
		esc_footer();
	}
	//quit = getname("Enter name of plant generator DES1 .............  ",
	//	EXT_DES, name1, false);
	//if (quit) return;

	quit = getname("Enter name of legal language generator DES2 ....  ",
		EXT_DES, name2, false);
	if (quit) return;

	printw("Enter name of supremal"); println();
	quit = getname("  controllable sublanguage generator DES3 ......  ",
		EXT_DES, name3, true);
	if (quit) return;

	move(22,0); clrtoeol();
	move(23,0); clrtoeol();
	printw("Processing:  Please wait...");
	refresh();

	/* Pass to command line version of this program */
	mark_start_time(); 
	for(i = 0; i < num_plant - 1; i ++){
		if(i == 0){
			strcpy(name4, names1[0]);
			init = 0L;
			if(!getdes(name4, &s1, &init, &t1))
				goto FREE_LABEL;
			if(!getdes(names1[i + 1], &s2, &init, &t2))
				goto FREE_LABEL;

			sync3(s1,t1,s2,t2,&s4,&t4, 0, s_event_list, event_list, &macro_ab,&macro_c); 
			s_macro_c = s4;

			filedes(name1, s4, init, t4);

			freedes(s1, &t1); s1 = 0; t1 = NULL;
			freedes(s2, &t2); s2 = 0; t2 = NULL;
			freedes(s4, &t4); s4 = 0; t4 = NULL;

			//result = sync2_runProgram(name1, name4, names1[i + 1], 0, s_event_list, event_list, &s_macro_c, &macro_c);
			for(j = 0; j < s_macro_c; j ++){
				insertelem_part(j, 0, (INT_T)(macro_c[j] % s1), &s_pn, &pn);
				insertelem_part(j, 1, (INT_T)(macro_c[j] / s1), &s_pn, &pn);
			} 

			if(mem_result == 1){
				goto FREE_LABEL;
			}        
		}else{
			init = 0L;
			getdes(name1, &s1, &init, &t1);
			getdes(names1[i + 1], &s2, &init, &t2);

			sync3(s1,t1,s2,t2,&s4,&t4, 1, s_event_list, event_list, &macro_ab,&macro_c); 
			s_macro_c = s4;

			filedes(name1, s4, init, t4);

			freedes(s1, &t1); s1 = 0; t1 = NULL;
			freedes(s2, &t2); s2 = 0; t2 = NULL;
			freedes(s4, &t4); s4 = 0; t4 = NULL;

			//result = sync2_runProgram(name1, name1, names1[i + 1], 1, s_event_list, event_list,&s_macro_c, &macro_c); 
			ext_copy_part(&s_tmpn, &tmpn, s_pn, pn);
			free_part(s_pn, &pn);
			s_pn = 0; pn = NULL;
			for(j = 0; j < s_macro_c; j ++){
				state1 = macro_c[j] % s1;
				state2 = macro_c[j] / s1;
				for(k = 0; k < tmpn[state1].numelts; k ++){
					insertelem_part(j, k, (INT_T)tmpn[state1].next[k], &s_pn, &pn);
				}
				insertelem_part(j, i + 1, (INT_T)state2, &s_pn, &pn);
			}    
			if(mem_result == 1){
				goto FREE_LABEL;
			}   
			free_part(s_tmpn, &tmpn);  
			s_tmpn = 0; tmpn = NULL;  
		}
		free(macro_ab); macro_ab = NULL;
		free(macro_c); 	s_macro_c = 0; macro_c = NULL;
	}
	init = 0L;   
	getdes(name1, &s1, &init, &t1);
	getdes(name2, &s2, &init, &t2);

	meet2(s1,t1,s2,t2,s3,t3,&macro_ab,&macro_c); 
	freedes(s2,&t2); t2 = NULL;
	trim2(s3,t3,macro_c);
	shave1(s1,t1,s3,t3,macro_c);
	if (mem_result != 1){
		init = 0L;
		filedes(name3, *s3, init, *t3);  
	} else {
		goto FREE_LABEL;
	}
	freedes(s2,&t2); s2 = 0; t2 = NULL;
	free(macro_ab); macro_ab = NULL;

	meet2(s1,t1,*s3,*t3,&s2,&t2,&macro_ab,&macro_d); 

	condat1(t1,s1,*s3,s2,t2,&s4,&t4,macro_d);

	if(mem_result != 1){
		init = -1L;
		filedes(name3, s4, init, t4);
	}else
		goto FREE_LABEL;
  
	mark_stop_time();

	strcpy(condat_result, "");
	strcat(condat_result, prefix);
	strcat(condat_result, name3);
	strcat(condat_result, EXT_TXT);
	out = fopen(condat_result, "w");
	if (out == NULL) return;

	//read supervisor from name2
	
	//store the transition diagram of supervisor in condat_result.text file
	//for(i = 0; i < *s3; i ++){
	//	fprintf(out, "Transition number on state %d: %d\n",i, (*t3)[i].numelts);   
	//	for(j = 0; j < (*t3)[i].numelts; j ++){
	//		fprintf(out, "%d-%d-%d ", i, (*t3)[i].next[j].data1, (*t3)[i].next[j].data2);
	//		fprintf(out, "\n");
	//	}		 
	//}
	//fprintf(out, "------------------------------------\n");
	for(i = 0; i < s4; i ++){
		if(t4[i].numelts > 0){
			state1 = macro_c[i] % s1;
			state2 = macro_c[i] / s1;
			//fprintf(out, "State of Components :");
			fprintf(out, "(");
			for(j = 0; j < pn[state1].numelts; j ++){
				fprintf(out, "%5d ", pn[state1].next[j]);
			}	
			fprintf(out, "), (");
			fprintf(out, "%5d ", state2);
			fprintf(out, ") -- ");
			fprintf(out, "--%5d: ", i);
			//fprintf(out, "The events to be disabled: ", state2);
			for(j = 0; j < t4[i].numelts; j ++){
				fprintf(out, "%5d ", t4[i].next[j].data1);
			}
			fprintf(out, "\n");
		}
	}
	fclose(out);

	if (result == 0) {
		strcpy(long_name3, "");
		make_filename_ext(long_name3, name3, EXT_DES);
		init = 0;
		if (exist(long_name3))
			getdes(name3, s3, &init, t3);   
		else
			quit = true;
	}
	else 
	{
		if (result == CR_OUT_OF_MEMORY)
			mem_result = 1;
		else
			quit = true;
	}
FREE_LABEL:
	free_part(s_pn, &pn);
	freedes(s1, &t1);
	freedes(s2, &t2);
	freedes(s4, &t4);
	free(macro_ab);
	free(macro_c);
	free(macro_d);
}

void supcon_comb_makeit(state_node *t3,
	INT_S s3)
{
	FILE* out;

	out = fopen(get_makeit(), "a");
	if (out == NULL) return;
	fprintf(out, "%s = Supcon(%s,%s)", name3, name1, name2);
	fprintf(out, "  (%ld,%ld)", s3, count_tran(t3, s3));
	appendTime(out, (INT_OS)strlen(name3)+3);
	fprintf(out, "\n\n");
	fclose(out);
}

void supcon_comb_p()
{
	state_node *t1;
	INT_S s1;

	t1 = NULL;
	s1 = 0;

	supcon_comb_r(&t1, &s1);

	if (mem_result == 1) {
		mem_result = 0;
		OutOfMemoryMsg();
		user_pause();
	} else {
		if (!quit) {
			supcon_comb_makeit(t1, s1);
			user_pause();
		}
	}

	echo_free();
	freedes(s1, &t1);
}
//////////////////////////////////////////////////////////////
void ehmeet_header()
{
    printw("EHMEET"); println();
    println();
    printw("DES3 = EHMEET (DES1, DES2)");println();
}
void printlist2(INT_S s1, INT_S s3, INT_S *mapState)
{
   INT_S i,j;
   INT_OS   ytop1, ytop2, windowheight, temp;
   char  ch;
   INT_OS col, row;

   if (s3 == 0) return;

   ytop1 = _wherey();
   windowheight = 23 - ytop1;
   for (i = 0; i < s3; i++) {
       j = mapState[i];
       ytop2 = _wherey() - ytop1 - 1;
       if (ytop2 > windowheight - 3) {
          move(windowheight+ytop1, 0);
          printw("Press <Enter> to page corresponding states or <ESC> to return  ");
          refresh();
          do {
             ch = read_key();
             if (ch == CEsc) {
                quit = true;
                return;
             }
          } while ( (ch != CEnter) && (ch != CEsc) );

          for (temp=ytop1; temp < 25; temp++) {
             move(temp, 0);
             clrtoeol();
          }

          move(1 + ytop1, 0);
       }
       col = _wherex();
       row = _wherey();
       
       if(col > 40){
          col = 0;
          row ++;
          move(row, col);
       }
       
       if (s3 <= 100000)
          printw("%5d:  [ %5d, %5d ]  ",i, j % s1, j / s1);
       else if (s3 <= 1000000)
          printw("%6d: [ %6d, %6d ] ", i, j % s1, j / s1);
       else 
          printw("%7d [%7d,%7d]  ", i, j % s1, j / s1);
       
       col = _wherex();
       row = _wherey();
       move(row, col + 7);
   }
   println();
}
void ehsync_header()
{
   printw("SYNC"); println();
   println();
   printw("DES = SYNC (DES1, DES2, ..., DESk, k)"); println();
   println();
}
void ehsync_blockevents_display(
         state_node *t1,   INT_S s1,
         state_node *t2,   INT_S s2,
         state_node *t3,   INT_S s3,
         INT_T **be, INT_T *s_be)
{
   INT_T *e1 = NULL; INT_T s_e1 = 0;
   INT_T *e3 = NULL; INT_T s_e3 = 0;
   INT_S i;  INT_T j;
   INT_B  ok;

   /* Collect all events of t1 = L1 */
   for (i=0; i < s1; i++)
     for (j=0; j < t1[i].numelts; j++)
     {
        addordlist(t1[i].next[j].data1, &e1, s_e1, &ok);
        if (ok) s_e1++;
     }

   /* Collect all events for t2+t1 = L1+L2 = L12 */
   for (i=0; i < s2; i++)
      for (j=0; j < t2[i].numelts; j++)
      {
         addordlist(t2[i].next[j].data1, &e1, s_e1, &ok);
         if (ok) s_e1++;
      }

   /* Collect all events for t3 = L3 */
   for (i=0; i < s3; i++)
      for (j=0; j < t3[i].numelts; j++)
      {
         addordlist(t3[i].next[j].data1, &e3, s_e3, &ok);
         if (ok) s_e3++;
      }

   /* D = L12-L3 */
   for (j=0; j < s_e1; j++)
     if (!inlist(e1[j], e3, s_e3))
     {
        addordlist(e1[j], be, *s_be, &ok);
        if (ok) (*s_be)++;
     }

   move(20, 0); clrtoeol();
   move(21, 0);
   printw("Events blocked in %s: ", name3);
   if (*s_be == 0)
   {
      printw("None.\n");
   }
   else if (*s_be >= 8)
   {
      printw("See MAKEIT.TXT file.\n");
   }
   else
   {
      printw("[");
      for (j=0; j < *s_be; j++)
      {
         printw("%3d", (*be)[j]);
         if (j+1 < *s_be)
            printw(",");
      }
      printw("]");
   }

   free(e1);
   free(e3);
}
void ehsync_blockevents(
         state_node *t1,   INT_S s1,
         state_node *t2,   INT_S s2,
         state_node *t3,   INT_S s3,
         INT_T **be, INT_T *s_be)
{
   INT_T *e1 = NULL; INT_T s_e1 = 0;
   INT_T *e3 = NULL; INT_T s_e3 = 0;
   INT_S i;  INT_T j;
   INT_B  ok;

   /* Collect all events of t1 = L1 */
   for (i=0; i < s1; i++)
     for (j=0; j < t1[i].numelts; j++)
     {
        addordlist(t1[i].next[j].data1, &e1, s_e1, &ok);
        if (ok) s_e1++;
     }

   /* Collect all events for t2+t1 = L1+L2 = L12 */
   for (i=0; i < s2; i++)
      for (j=0; j < t2[i].numelts; j++)
      {
         addordlist(t2[i].next[j].data1, &e1, s_e1, &ok);
         if (ok) s_e1++;
      }

   /* Collect all events for t3 = L3 */
   for (i=0; i < s3; i++)
      for (j=0; j < t3[i].numelts; j++)
      {
         addordlist(t3[i].next[j].data1, &e3, s_e3, &ok);
         if (ok) s_e3++;
      }

   /* D = L12-L3 */
   for (j=0; j < s_e1; j++)
     if (!inlist(e1[j], e3, s_e3))
     {
        addordlist(e1[j], be, *s_be, &ok);
        if (ok) (*s_be)++;
     }

   free(e1);
   free(e3);
}

/*Used to compute synchronous product of agents 
whose number are more than 2*/
void ehsync1_r(INT_S *sfile,
             state_node **t3,
            INT_S *s3,
            INT_T **be,
            INT_T *s_be,
            INT_S *s_pn,
            part_node **pn)
{
   INT_S s1, s2, s4;
   state_node *t1, *t2, *t4;
   INT_S  init;
   INT_T  *tranlist, s_tranlist;
   INT_S i,j,k, num;
   INT_B  ok;
   char ch, prompt[512];
   INT_OS    result;
   INT_S s_macro_c, *macro_c, *macro_ab;
   INT_S s_tmpn;
   part_node *tmpn;
   INT_S state1, state2;
   
   s1 = s2 = s4 = 0;
   t1 = t2 = t4 = NULL;
   tranlist = NULL;  s_tranlist  = 0;
   num = 0;
   s_macro_c = 0;
   macro_c = macro_ab = NULL;
   s_tmpn = 0;
   tmpn = NULL;

   result = 0;

   clear();
   ehsync_header();
   
   printw("Enter value of k ....... (between 2 and 30) ");
   num = readint(&ch,1,MAX_DESS); println();
   *sfile = num;
   if(ch == CEsc){
        quit = true;
        return;
   }
   println();
   for(i = 0; i < num; i ++){
        strcpy(prompt,"");
        sprintf(prompt,"Enter name of DES%d ........ ",i + 1);
        if(_wherey() > 19){
           clear();
           ehsync_header();
           esc_footer();
        }
        quit = getname(prompt,EXT_DES,names1[i],false);
        if(quit) goto SYNC_LABEL;
        init = 0L;
        getdes(names1[i],&s1,&init,&t1);
        if(mem_result == 1)
           goto SYNC_LABEL;
        for(j = 0; j < s1; j ++){
           for(k = 0; k < t1[j].numelts; k ++){
              addordlist(t1[j].next[k].data1,&tranlist, s_tranlist,&ok);
              if(ok) s_tranlist ++;
           }
        }
        freedes(s1,&t1);
        s1 = 0; t1 = NULL;
   }
   if(_wherey() > 19){
      clear();
      ehsync_header();
      esc_footer();
   }

   quit = getname("Enter name of DES ......... ", EXT_DES, name3, true);
   if (quit) goto SYNC_LABEL;

   move(22,0); clrtoeol(); refresh();
   move(23,0); clrtoeol(); refresh();
   printw("Processing:  Please wait...");
   refresh();

   /* Pass to command line version of this program */
   mark_start_time(); 
   for(i = 0; i < num - 1; i ++){
      if(i == 0){
         strcpy(name1, names1[0]);
         init = 0L;
         getdes(name1, &s1, &init, &t1);
		 getdes(names1[i + 1], &s2, &init, &t2);

		 sync3(s1,t1,s2,t2,&s4,&t4, 0, s_tranlist, tranlist, &macro_ab, &macro_c); 
		 s_macro_c = s4;

		 filedes(name3, s4, init, t4);

         //result = sync2_runProgram(name3, name1, names1[i + 1], 0, s_tranlist, tranlist, &s_macro_c, &macro_c);
         for(j = 0; j < s_macro_c; j ++){
			//insertelem_part(j, 0, (INT_T)(0 % s1), s_pn, pn);
            insertelem_part(j, 0, (INT_T)(macro_c[j] % s1), s_pn, pn);
            insertelem_part(j, 1, (INT_T)(macro_c[j] / s1), s_pn, pn);
         } 
		 freedes(s1, &t1); s1 = 0; t1 = NULL;
		 freedes(s2, &t2); s2 = 0; t2 = NULL;
		 freedes(s4, &t4); s4 = 0; t4 = NULL;

         if(mem_result == 1){
            goto SYNC_LABEL;
         }        
      }else{
         init = 0L;
         getdes(name3, &s1, &init, &t1);

		 getdes(names1[i + 1], &s2, &init, &t2);

		 sync3(s1,t1,s2,t2,&s4,&t4, 1, s_tranlist, tranlist, &macro_ab,&macro_c); 
		 s_macro_c = s4;

		 filedes(name3, s4, init, t4);


        // result = sync2_runProgram(name3, name3, names1[i + 1], 1, s_tranlist, tranlist,&s_macro_c, &macro_c); 

         ext_copy_part(&s_tmpn, &tmpn, *s_pn, *pn);
         free_part(*s_pn, pn);
         *s_pn = 0; *pn = NULL;
         for(j = 0; j < s_macro_c; j ++){
            state1 = macro_c[j] % s1;
            state2 = macro_c[j] / s1;
            for(k = 0; k < tmpn[state1].numelts; k ++){
               insertelem_part(j, k, (INT_T)tmpn[state1].next[k], s_pn, pn);
            }
            insertelem_part(j, i + 1, (INT_T)state2, s_pn, pn);
         }    
		 freedes(s1, &t1); s1 = 0; t1 = NULL;
		 freedes(s2, &t2); s2 = 0; t2 = NULL;
		 freedes(s4, &t4); s4 = 0; t4 = NULL;
         if(mem_result == 1){
            goto SYNC_LABEL;
         }   
         free_part(s_tmpn, &tmpn);  
         s_tmpn = 0; tmpn = NULL;  
      }
      if(result == CR_OK){
         strcpy(long_name3, "");
         make_filename_ext(long_name3, name3, EXT_DES);
         if(exist(long_name3)){
            init = 0L;
            getdes(names1[i + 1], &s2, &init, &t2);
            getdes(name3, s3, &init, t3);
            if(mem_result != 1){
                ehsync_blockevents(t1, s1, t2, s2, *t3, *s3,
                                 be, s_be);
            }
            freedes(s1,&t1);
            freedes(s2,&t2);
            freedes(*s3,t3);
            s1 = s2 = *s3 = 0;
            t1 = t2 = *t3 = NULL;
         }
         else
            break;
      } else{
         break;
      }
	  free(macro_ab); macro_ab = NULL;
	  free(macro_c);  s_macro_c = 0; macro_c = NULL;
   }    
   
   mark_stop_time();

   if (result == CR_OK) {
      strcpy(long_name3, "");
      make_filename_ext(long_name3, name3, EXT_DES);
      if (exist(long_name3))
      {
         getdes(name3, s3, &init, t3);
         move(20, 0); clrtoeol();
         move(21, 0);
         printw("Events blocked in %s: ", name3);
         if (*s_be == 0)
         {
            printw("None.\n");
         }
         else if (*s_be >= 8)
         {
            printw("See MAKEIT.TXT file.\n");
         }
         else
         {
            printw("[");
            for (j=0; j < *s_be; j++)
            {
               printw("%3d", (*be)[j]);
               if (j+1 < *s_be)
                  printw(",");
            }
            printw("]");
         }
      }
      else
         quit = true;
   }
   else 
   {
       if (result == CR_OUT_OF_MEMORY)
          mem_result = 1;
       else
          quit = true;
   }
SYNC_LABEL:
   free(tranlist);
   freedes(s1, &t1);
   freedes(s2, &t2);
   freedes(s4, &t4);
   free_part(s_tmpn, &tmpn);
   free(macro_c);
   free(macro_ab);
   return;
}

void ehsync1_makeit(INT_S sfile, state_node *t3, INT_S s3,
                 INT_T *be, INT_T s_be,
                 INT_S s_pn, part_node *pn)
{
   FILE* out;
   INT_S i,j;

   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;
   
   fprintf(out, "%s = Sync(", name3);
   for(i = 0; i < sfile; i ++){
      if(i < sfile - 1)
         fprintf(out, "%s,", names1[i]);
      else
         fprintf(out, "%s", names1[i]);
   }
   fprintf(out, ";[");
   for(i = 0; i < s_pn; i ++){
      fprintf(out, "[%ld: ", i);
      for(j = 0; j < pn[i].numelts; j ++){
         fprintf(out, "<%ld> %ld", j, pn[i].next[j]);
         if(j < pn[i].numelts - 1)
           fprintf(out, ",");
      }
      fprintf(out, "]");
      if(i < s_pn - 1)
         fprintf(out, ",");
   }
   fprintf(out, "])  (%ld,%ld)  ", s3, count_tran(t3, s3));

   fprintf(out, "Blocked_events = ");
   if (s_be == 0)
   {
      fprintf(out, "None  ");
   }
   else
   {
      fprintf(out, "[");
      for (i=0; i < s_be; i++) {
         fprintf(out, "%d", be[i]);
         if (i+1 < s_be)
            fprintf(out, ",");
      }
      fprintf(out, "]  ");
   }

   appendTime(out, (INT_OS)strlen(name3)+3);
   fprintf(out, "\n\n");
   fclose(out);
   
   mergeChop((INT_OS)strlen(name3)+3);
   
}
void ehsync_p()
{
   state_node *t1, *t2, *t3;
   INT_S s1, s2, s3;
   INT_T s_blockevents, *blockevents;
   INT_S sfile;
   INT_S s_pn;
   part_node *pn;
   INT_S i,j;
   char str[MAX_PATH];
   FILE *out;

   t1 = t2 = t3 = NULL;
   s1 = s2 = s3 = 0;
   s_blockevents = 0;  blockevents = NULL;
   s_pn = 0; pn = NULL;


   ehsync1_r(&sfile, &t3, &s3,
          &blockevents, &s_blockevents, &s_pn, &pn);
   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        if(_wherey() > 5){
           clear();
           ehsync_header();
           esc_footer();
           refresh();
        }
        println();
        printw("DESs synchronize at the following corresponding states:"); println();
        for(i = 0; i < s_pn; i ++){
            if(_wherey() > 20){
               break;
            }
            printw("%ld: ", i);
            for(j = 0; j < pn[i].numelts; j ++){
               if(_wherex() > 55){
                  println();
               }
               if(_wherey() > 20){
                  break;
               }
               printw("<%ld> %ld    ", j, pn[i].next[j]);
            }
            println();
        }
        println();
        printw("All detailed relations are reported in %s.TXT.", name3);
        strcpy(str, "");
		make_filename_ext(str, name3, EXT_TXT);
        
        out = fopen(str, "w");
        for(i = 0; i < s_pn; i ++){
            fprintf(out, "%ld: ", i);
            for(j = 0; j < pn[i].numelts; j ++){
               fprintf(out, "<%ld> %ld    ", j, pn[i].next[j]);
            }
            fprintf(out, "\n");
        }
        fclose(out);
        ehsync1_makeit(sfile, t3, s3,
                    blockevents, s_blockevents, s_pn, pn);
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
   freedes(s2, &t2);
   freedes(s3, &t3);
   free(blockevents);
   free_part(s_pn, &pn);
}
//////////////////////////////////////////////////////
void ehmeet1_header()
{
   printw("MEET"); println();
   println();
   printw("DES = MEET (DES1, DES2, ..., DESk, k)"); println();
   println();
}
void ehmeet1_r(INT_OS *num, state_node **t3, INT_S *s3,
               INT_S *s_pn, part_node **pn)
{
   INT_S  init, i, j, k;
   INT_S  *macro_c, s_macro_c, *macro_ab;
   INT_OS    result;
   char prompt[512], ch;
   INT_S s_tmpn;
   part_node *tmpn;
   INT_S state1, state2;
   INT_S s1, s2, s4;
   state_node *t1, *t2, *t4;

   macro_c  = macro_ab = NULL;
   s_macro_c = 0;
   s1 = 0; t1 = NULL;
   s_tmpn = 0; tmpn = NULL;
   s1 = s2 = s4 = 0;
   t1 = t2 = t4 = NULL;

   result = 0;

   clear();
   ehmeet1_header();
   refresh();
   
   printw("Enter value of k ...... (between 2 and 30) ");
   *num = (INT_OS)readint(&ch, 1, MAX_DESS); println();
   if(ch == CEsc){
      quit = true;
      return;
   }
   println();
   for(i = 0; i < *num; i ++){
      strcpy(prompt,"");
      sprintf(prompt,"Enter name of DES%d ........ ",i + 1);
      if(_wherey() > 19){
           clear();
           ehmeet1_header();
           esc_footer();
      }
      quit = getname(prompt,EXT_DES,names1[i],false);
      if(quit) return;
   }

   quit = getname("Enter name of DES ......... ", EXT_DES, name3, true);
   if (quit) return;

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();
   
   /* Pass to command line version of this program */
   mark_start_time();  
   for(i = 0; i < *num - 1; i ++){   
      if(i == 0){
         strcpy(name1, names1[0]);
         init = 0L;
         getdes(name1, &s1, &init, &t1);
		 getdes(names1[i + 1], &s2, &init, &t2);

		 meet2(s1,t1,s2,t2,&s4,&t4,&macro_ab,&macro_c);
		 s_macro_c = s4;

		 filedes(name3, s4, init, t4);

        // result = meet1_runProgram(name3, name1, names1[i + 1], &s_macro_c, &macro_c);
         for(j = 0; j < s_macro_c; j ++){
            insertelem_part(j, 0, (INT_T)(macro_c[j] % s1), s_pn, pn);
            insertelem_part(j, 1, (INT_T)(macro_c[j] / s1), s_pn, pn);
         }  

		 freedes(s1, &t1); s1 = 0; t1 = NULL;
		 freedes(s2, &t2); s2 = 0; t2 = NULL;
		 freedes(s4, &t4); s4 = 0; t4 = NULL;
         if(mem_result == 1){
            goto MEET_LABEL;
         }       
      }else{
         init = 0L;
         getdes(name3, &s1, &init, &t1);
		 getdes(names1[i + 1], &s2, &init, &t2);

		 meet2(s1,t1,s2,t2,&s4,&t4,&macro_ab,&macro_c);
		 s_macro_c = s4;

		 filedes(name3, s4, init, t4);

		 freedes(s1, &t1); s1 = 0; t1 = NULL;
		 freedes(s2, &t2); s2 = 0; t2 = NULL;
		 freedes(s4, &t4); s4 = 0; t4 = NULL;
         //result = meet1_runProgram(name3, name3, names1[i + 1],&s_macro_c, &macro_c);
         ext_copy_part(&s_tmpn, &tmpn, *s_pn, *pn);
         free_part(*s_pn, pn);
         *s_pn = 0; *pn = NULL;
         for(j = 0; j < s_macro_c; j ++){
            state1 = macro_c[j] % s1;
            state2 = macro_c[j] / s1;
            for(k = 0; k < tmpn[state1].numelts; k ++){
               insertelem_part(j, k, (INT_T)tmpn[state1].next[k], s_pn, pn);
            }
            insertelem_part(j, i + 1, (INT_T)state2, s_pn, pn);
         }   
         if(mem_result == 1){
            goto MEET_LABEL;
         }    
         free_part(s_tmpn, &tmpn);  
         s_tmpn = 0; tmpn = NULL;  
      }
      
      if(result == CR_OK){
         strcpy(long_name3, "");
         make_filename_ext(long_name3, name3, EXT_DES);
         if(!exist(long_name3)){
            quit = true;
            goto MEET_LABEL;
         }
      }
      freedes(s1, &t1);
      s1 = 0; t1 = NULL;
	  free(macro_c);
	  s_macro_c = 0; macro_c = NULL; 
      
   }
   mark_stop_time();

   if (result == CR_OK) {
      strcpy(long_name3, "");
      make_filename_ext(long_name3, name3, EXT_DES);
      init = 0;
      if (exist(long_name3))
         getdes(name3, s3, &init, t3);   
      else
         quit = true;
   }
   else 
   {
       if (result == CR_OUT_OF_MEMORY)
          mem_result = 1;
       else
          quit = true;
   }
MEET_LABEL:
   free(macro_c);
   free(macro_ab);
   free_part(s_tmpn, &tmpn);
   freedes(s1, &t1);
   freedes(s2, &t2);
   freedes(s4, &t4);

}
void ehmeet1_makeit(INT_OS num, state_node *t3,
                 INT_S s3, INT_S s_pn, part_node *pn)
{
   FILE* out;
   INT_S i,j;

   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;
   fprintf(out, "%s = Meet(", name3);
   for(i = 0; i < num; i ++){
      if(i < num - 1)
         fprintf(out, "%s,", names1[i]);
      else
         fprintf(out, "%s", names1[i]);
   }
   
   fprintf(out, ";[");
   for(i = 0; i < s_pn; i ++){
      fprintf(out, "[%ld: ", i);
      for(j = 0; j < pn[i].numelts; j ++){
         fprintf(out, "<%ld> %ld", j, pn[i].next[j]);
         if(j < pn[i].numelts - 1)
           fprintf(out, ",");
      }
      fprintf(out, "]");
      if(i < s_pn - 1)
         fprintf(out, ",");
   }
   
   fprintf(out, "])  (%ld,%ld)", s3, count_tran(t3, s3));
   appendTime(out, (INT_OS)strlen(name3)+3);
   fprintf(out, "\n\n");
   fclose(out);
   
   mergeChop((INT_OS)strlen(name3) + 3);
}
void ehmeet_p()
{
   state_node *t1, *t2, *t3;
   INT_S s1, s2, s3;
   INT_OS num = 0;
   INT_S s_pn;
   part_node *pn;
   INT_S i,j;
   FILE *out;
   char str[MAX_PATH];

   t1 = t2 = t3 = NULL;
   s1 = s2 = s3 = 0;
   s_pn = 0;
   pn = NULL;
   
   //meet_r(&t1, &s1, &t2, &s2, &t3, &s3);
   ehmeet1_r(&num, &t3, &s3, &s_pn, &pn);
   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        //meet_makeit(t3, s3);
        if(_wherey() > 5){
           clear();
           ehmeet_header();
           esc_footer();
           refresh();
        }
        println();
        printw("DESs meet at the following corresponding states:"); println();
        for(i = 0; i < s_pn; i ++){
            if(_wherey() > 20){
               break;
            }
            printw("%ld: ", i);
            for(j = 0; j < pn[i].numelts; j ++){
               if(_wherex() > 55){
                  println();
               }
               if(_wherey() > 20){
                  break;
               }
               printw("<%ld> %ld    ", j, pn[i].next[j]);
            }
            println();
        }
        println();
        printw("All detailed relations are reported in %s.TXT.", name3);
        
		strcpy(str, "");
		make_filename_ext(str, name3, EXT_TXT);
        out = fopen(str, "w");
        for(i = 0; i < s_pn; i ++){
            fprintf(out, "%ld: ", i);
            for(j = 0; j < pn[i].numelts; j ++){
               fprintf(out, "<%ld> %ld    ", j, pn[i].next[j]);
            }
            fprintf(out, "\n");
        }
        fclose(out);
        ehmeet1_makeit(num, t3, s3, s_pn, pn);
        user_pause();
      }
   }
   
   echo_free();
   freedes(s1, &t1);
   freedes(s2, &t2);
   freedes(s3, &t3);
   free_part(s_pn, &pn);
}
//////////////////////////////////////////////////////
void subdes_header()
{
   printw("SHORTESTPATH"); println();
   println();
   printw("DES2 = SHORTESTPATH (DES1, START [p], END [q])");println();
   println();
}
void sub_reversetran(INT_S src,
                 state_node *t1,
                 state_node **t2)
{
   INT_T cur;
   INT_B  ok;
   INT_S target;

   cur = 0;
   while (cur < t1[src].numelts) {
      target = t1[src].next[cur].data2;
      addordlist1(t1[src].next[cur].data1, src,
                  &(*t2)[target].next, (*t2)[target].numelts, &ok);
      if (ok) (*t2)[target].numelts++;
      cur++;
   }
}
void subdes_proc(INT_S s1, state_node **t1, 
                 INT_S *s2, state_node **t2, 
                 INT_S start, INT_S end)
{
    INT_S i;
    
    for(i = 0; i < s1; i ++)
       (*t1)[i].reached = false;
    
    (*t1)[start].reached = true;
    
    
    
    *s2 = s1;
    *t2 = newdes(*s2);
    
    //Search the shortest rountine
    sr_search(start, t1, t2, s1, end);
    freedes(s1, t1);
    *t1 = NULL;
    
    for(i = 0; i < *s2; i ++){
       (*t2)[i].reached = false;
    }
    
    (*t2)[end].reached = true;
    
    b_reach((*t2)[end].next, end, t2, *s2);    
    
    *t1 = newdes(s1);
    for(i = 0; i < *s2; i ++){
       sub_reversetran(i, *t2, t1);
       (*t1)[i].reached = (*t2)[i].reached;
          
    }
    purgebadstates(s1, t1);
    freedes(*s2, t2);
    *s2 = 0; *t2 = NULL;
    export_copy_des(s2, t2, s1, *t1);
}
void subdes_makeit(INT_S s2, state_node *t2, 
                   INT_S start, INT_S end)
{
    FILE* out;
//    INT_S i,j;
    INT_OS   offset;
    
   /* Write to a tempory file */
   out = fopen("tmp.$$$", "w");

   if (out == NULL) return;

   fprintf(out, "%s = Shortestpath(%s,", name2, name1);
   fprintf(out, "start [%d], end [%d])", start, end);   
   
   fprintf(out, "  (%ld,%ld)  ", s2, count_tran(t2, s2));
   
   offset = (INT_OS)strlen(name2) + 3;
   appendTime(out, offset);
   fprintf(out, "\n\n");
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop(offset);
}
void subdes_p()
{
    INT_S start, end, init;
    char ch;
    INT_S s1, s2;
    state_node *t1, *t2;
    
    s1 = s2 = 0;
    t1 = t2 = NULL;
        
    clear();
    subdes_header();
    esc_footer();
    refresh();
    
    quit = getname("Enter name of DES1 .... ", EXT_DES, name1, false);
    if(quit) return;
    
    quit = getname("Enter name of DES2 .... ", EXT_DES, name2, true);
    if(quit) return;
    
    init = 0L;
    if(getdes(name1, &s1, &init, &t1) == false)
       goto SUB_LABEL;
    
    printw("Enter start state p of DES2 ... (between 0 and %d) ", s1 - 1);
    start = (INT_S)readint(&ch, 0, s1 - 1);
    if(ch == CEsc){
       goto SUB_LABEL;
    }
    
    println();
    println();
    printw("Enter end state q of DES2 ... (between 0 and %d) ", s1 - 1);
    end = (INT_S) readint(&ch, 0, s1 - 1);
    if(ch == CEsc)
       goto SUB_LABEL;
    
    mark_start_time();
    
    subdes_proc(s1, &t1, &s2, &t2, start, end);
    
    mark_stop_time();
    
    println();
    println();
    
    if(mem_result == 1){
       mem_result = 0;
       OutOfMemoryMsg();
    }else{
       init = 0L;
       filedes(name2, s2, init, t2);
	   if(count_tran(t2, s2) == 0){
		   println();
		   if(start == end){
			   printw("State [%d] is not reachable from itself along a nonempty path", end);
		   }else{
			   printw("State [%d] is not reachable from state [%d]", end, start);
		   }

	   }else
           subdes_makeit(s2, t2, start, end);
    }
    user_pause();

SUB_LABEL:
    freedes(s1, &t1);
    freedes(s2, &t2);
}
/////////////////////////////////////////////////////////
void rendez_header()
{
   printw("RENDEZ"); println();
   println();
   printw("DES = RENDEZ ({DES1, DES2, ...}, RENDEZ_STATE_LIST)"); println();
   println();
}
void rendez_r(state_node **t1,
             INT_S *s1,
             INT_S *sfile,
             part_node **sp,
             INT_S *s_sp)
{
   INT_S  init;
   char   ch;
   INT_S  *macro_ab, *macro_c;
   INT_S  i, j, k;
   short sign_i;
   INT_B  ok;
   INT_OS    result, size;
   char prompt[100];
   INT_OS col, row;
   INT_S s_list, *list;
   INT_S s_statelist, *statelist;
   INT_T s_tranlist, *tranlist;

   macro_ab = NULL;  macro_c  = NULL;
   size = 0;
   s_list = s_statelist = 0; 
   list = statelist = NULL;
   s_tranlist = 0; tranlist = NULL;

   clear();
   rendez_header();
   refresh();
   result = 0;
   
   printw("Enter the number of generators ... (between 2 and %d) ", MAX_DESS);
   size = (INT_OS)readint(&ch,1,MAX_DESS); println();
   if(ch == CEsc){
      quit = true;
      return;
   }
   println();
   
   statelist = (INT_S*)REALLOC(statelist, size * sizeof(INT_S));
   if(statelist == NULL && size != 0)
      return;
   s_statelist = size;
   *sfile = size;
   for(i = 0; i < size; i ++){
      strcpy(prompt,"");
      sprintf(prompt,"Enter name of generator%d ........ ",i + 1);
      if(_wherey() > 19){
         clear();
         rendez_header();
         esc_footer();
      }
      quit = getname(prompt,EXT_DES,names1[i],false);
      if(quit) goto FREE;
      
      init = 0L;
      if(getdes(names1[i], s1, &init, t1) != false){
         statelist[i] = *s1;
         for(j = 0; j < *s1; j++){
            for(k = 0; k < (*t1)[j].numelts; k ++){
               addordlist((*t1)[j].next[k].data1, &tranlist, s_tranlist, &ok);
               if(ok) s_tranlist ++;
            }
         }
      }
      if(mem_result == 1)
         goto FREE;
      
      freedes(*s1, t1);
      *s1 = 0; *t1 = NULL;
   }
   
   if(_wherey() > 19){
      clear();
      rendez_header();
      esc_footer();
   }
   quit = getname("Enter name of final generator DES......... ",EXT_DES,name1,true);
   if(quit) goto FREE;


   println();
   printw("Enter list of rendezvous states;"); println();
   printw("<i> represents ith generator."); println();
   printw("Press <Enter> after each element and quit with -1:"); println();
   println();
   
   sign_i = 0;
   while (sign_i != -1) {
      for(j = 0; j < size; j ++){         
         if (_wherey() > 21) {
            clear();
            rendez_header();
            printw("Continue to enter list of rendezvous states."); println();
            printw("<i> represents ith generator."); println();
            printw("Press <Enter> after each element and quit with -1:"); println();
            println();
            esc_footer();
         }
         row = _wherey();
         if(_wherex()> 75 ){
            col = 0;
            row ++;
            move(row, col);
         }
         printw("<%d>: ",j);
         sign_i = (short) readint(&ch, -1, statelist[j] - 1);
         if (ch == CEsc) {
             quit = true;
             return;
         }
         
         if (sign_i == -1) break;
         
         list = (INT_S*)REALLOC(list, (s_list + 1) * sizeof(INT_S));
         if(list == NULL){
             mem_result = 1;
             return;
         }
         list[s_list] = sign_i;
         s_list ++;
         
         row = _wherey();
         col = _wherex();
         move(row, col + 7);
      }
      
      if(s_list == size){
         i = *s_sp;         
         *sp = (part_node*)REALLOC(*sp, (i + 1) * sizeof(part_node));
         (*sp)[i].numelts = s_list;
         (*sp)[i].next = NULL;
         (*sp)[i].next = (INT_S*)CALLOC(s_list, sizeof(INT_S));
         for(j = 0; j < s_list; j ++){
            (*sp)[i].next[j] = list[j];
         }
         (*s_sp) ++;
      }
      
      row ++;
      col = 0;
      move(row, col);
      
      free(list); 
      list = NULL; s_list = 0;
      
   }

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();
   
   mark_start_time();
   //result = mutex_runProgram(name3, name1, name2, *sp, *s_sp);  
   result = rendez_proc(name1, size, names1, tranlist, s_tranlist, *sp, *s_sp); 
   mark_stop_time();

   if (result == 0) {
      strcpy(long_name1, "");
      make_filename_ext(long_name1, name1, EXT_DES);
      init = 0;
      if (exist(long_name1))
         getdes(name1, s1, &init, t1);   
      else
         quit = true;
   }
   else 
   {
       if (result == CR_OUT_OF_MEMORY)
          mem_result = 1;
       else
          quit = true;
   }
FREE:   
   free(list);
   free(statelist);
   free(tranlist);
}
void rendez_makeit(state_node *t1,
                  INT_S s1,
                  INT_S size,
                  part_node* sp,
                  INT_S s_sp)
{
   FILE* out;
   INT_S i,j;

   /* Write to a tempory file */
   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;
   fprintf(out, "%s = Rendez((", name1);
   
   for(i = 0; i < size; i ++){
      fprintf(out, "%s", names1[i]);
      if(i < size - 1)
         fprintf(out, ",");
   }
   fprintf(out, "),[");
   for (i=0; i < s_sp; i++) {
     fprintf(out, "[");
     for(j = 0; j < sp[i].numelts; j ++){
        fprintf(out, "%ld", sp[i].next[j]);
        if (j < sp[i].numelts - 1)
           fprintf(out, ",");
     }
     
     fprintf(out, "]");
     if(i < s_sp - 1)
        fprintf(out, ",");
   }
   fprintf(out, "])");
   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1));
   appendTime(out, (INT_OS)strlen(name1)+3);
   fprintf(out, "\n\n");
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop((INT_OS)strlen(name1)+3);
}
void rendez_p()
{
   state_node *t1;
   INT_S s1;
   part_node *sp;
   INT_S s_sp;
   INT_S size;

   t1 = NULL;
   s1 = 0;
   s_sp = 0; sp = NULL;
   size = 0;

   rendez_r(&t1, &s1, &size, &sp, &s_sp);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        rendez_makeit(t1, s1, size, sp, s_sp);
        user_pause();
      }
   }

   echo_free();
   free_part(s_sp, &sp);
   freedes(s1, &t1);

}
/////////////////////////////////////////////////////////
void exlocalize_header()
{
     printw("EXLOCALIZE");println();
     println();
     printw("DES3 = EXLOCALIZE (DES1, DES2, EVENT_LIST)");println();
     println();
}
void exlocalize_makeit(INT_S s1, state_node*t1, INT_T s_tlist, INT_T *tlist, INT_OS mode)
{
     FILE* out;
     INT_S i;
     
     out = fopen(get_makeit(), "a");
     if (out == NULL) return;
     
     if(mode == 1)
        fprintf(out,"%s = Localize(%s,%s,[", name3,name1,name2);
     else if(mode == 2)
        fprintf(out,"%s = NewLocalize(%s,%s,[", name3,name1,name2);
     else if(mode == 3)
        fprintf(out,"%s = NewLocalize(%s,%s,[", name3,name1,name2);
     for(i = 0; i < s_tlist; i ++){
        fprintf(out, "%ld", tlist[i]);
        if(i < s_tlist - 1)
           fprintf(out, ",");
     }
     fprintf(out, "]");
     fprintf(out, ")  (%ld,%ld)", s1, count_tran(t1, s1)); 

	 if(is_deterministic(t1,s1)){
		  fprintf(out, "  deterministic");
	 }else{
		 fprintf(out, "  nondeterministic");
	 }

     appendTime(out, sizeof(name3 + 3));
     
     fprintf(out, "\n\n");

     fclose(out);
}
void exlocalize_makeit1(INT_S s1, state_node*t1, INT_T s_tlist, INT_T *tlist, INT_OS mode, INT_B null_flag, INT_T s_imagelist, INT_T *imagelist, INT_T s_nullist, INT_T *nullist)
{
	FILE* out;
	INT_S i;

	out = fopen(get_makeit(), "a");
	if (out == NULL) return;

	if(mode == 1)
		fprintf(out,"%s = Localize(%s,%s,[", name3,name1,name2);
	else if(mode == 2)
		fprintf(out,"%s = NewLocalize(%s,%s,[", name3,name1,name2);
	else if(mode == 3)
		fprintf(out,"%s = NewLocalize(%s,%s,[", name3,name1,name2);
	for(i = 0; i < s_tlist; i ++){
		fprintf(out, "%ld", tlist[i]);
		if(i < s_tlist - 1)
			fprintf(out, ",");
	}
	fprintf(out, "]");
	if(mode == 2){
		fprintf(out, ",");
		if(null_flag){
			fprintf(out, "NULL[");
			for(i = 0; i < s_nullist; i ++){
				fprintf(out, "%ld", nullist[i]);
				if(i < s_nullist - 1)
					fprintf(out, ",");
			}
			fprintf(out, "]");
		}else {
			fprintf(out, "Image[");
			for(i = 0; i < s_imagelist; i ++){
				fprintf(out, "%ld", imagelist[i]);
				if(i < s_imagelist - 1)
					fprintf(out, ",");
			}
			fprintf(out, "]");
		}
	}


	fprintf(out, ")  (%ld,%ld)", s1, count_tran(t1, s1)); 

	if(is_deterministic(t1,s1)){
		fprintf(out, "  deterministic");
	}else{
		fprintf(out, "  nondeterministic");
	}

	appendTime(out, sizeof(name3 + 3));

	fprintf(out, "\n\n");

	fclose(out);
}
void exlocalize_p()
{    
     INT_S init;
     INT_OS x,y; 
     INT_B   ok;
     INT_OS result, mode, loc_mode;
     short sign_i;
     INT_OS col, row;
     char ch;
     INT_T i, *tlist, s_tlist;
     INT_S *slist, s_slist;
     state_node *t1;
     INT_S s1, endstate;
	 INT_T *imagelist, s_imagelist, *nullist, s_nullist;
	 INT_B null_flag;

     mode = 0;
     tlist = NULL; s_tlist = 0;
     slist = NULL; s_slist = 0;
     s1 = 0; t1 = NULL;

	 imagelist = nullist = NULL;
	 s_imagelist = s_nullist = 0;
     
     clear();
     printw("EXLOCALIZE");println();
     println();
     //exlocalize_header();
     refresh();
     result = 0;
     
     println();
     printw("1. Original Supervisor Localization");println();
     println();
     printw("2. Supervisor Localization under Partial Observation"); println();
     println();
     printw("3. New Localization Algorithm with Quadratic Complexity"); println();
     //println();
    // printw("4. Efficient algorithm of Localization with O(nlogn) complexity"); println();
     println();
     println();
     
     printw("Please choose Option 1, 2, 3, ... ");
     mode = (INT_OS)readint(&ch, 1, 3);
     if (ch == CEsc)
     {
        quit = true;
        return;
     }
     
     clear();
     exlocalize_header();
     refresh();
     
     if(mode != 5){
     quit = getname("Enter name of plant generator DES1 ......... ",EXT_DES,name1,false);
     if(quit) return;
     }
          
     quit = getname("Enter name of legal language generator DES2 .... ",EXT_DES,name2,false);
     if(quit) return;
     
     quit = getname("Enter name of localized controller DES3 .... ",EXT_DES,name3,true);
     if(quit) return;
     
     if(_wherey() > 12){
        clear();
        exlocalize_header();
        esc_footer();
     }
	 if(mode != 5){
		 printw("Enter list of event labels to be checked by localize;"); println();
		 printw("terminate list with -1."); println();
		 println(); tab(5);
		 sign_i = 0;
		 while(sign_i != -1){
			 col = _wherex();
			 row = _wherey();
			 if(col > 75){           
				 col = 5; row ++;
				 move(row, col);
			 }
			 if (_wherey() > 21) {
				 clear();
				 printw("Enter list of event labels to be checked by localize;"); println();
				 printw("terminate list with -1."); println();
				 println(); tab(5);
				 esc_footer();
				 col = _wherex();
				 row = _wherey();
			 }
			 sign_i = (short)readint_and_e(&ch, -1, MAX_TRANSITIONS);
			 if(ch == CEsc){
				 quit = 1;
				 goto EXLOCALIZE_LABEL;
			 }
			 if(sign_i != -1){
				 i = (INT_T)sign_i;
				 addordlist(i, &tlist, s_tlist, &ok);
				 if(ok) s_tlist ++;
			 }
			 move(row, col + 7);
		 }
	 } 

	 if(mode == 2){
		 if (_wherey() > 12)
		 {
			 clear();
			 exlocalize_header();
			 esc_footer();
		 }       

		 println();
		 println();
		 printw("Enter either"); println();
		 println();
		 printw("  NULL (list of event labels erased by projection)"); println();
		 println();
		 printw("or"); println();
		 println();
		 printw("  IMAGE (event labels retained)"); println();
		 println();


		 do {
			 if (_wherey() > 20)
			 {
				 clear();
				 exlocalize_header();
				 esc_footer();
			 }    

			 printw("NULL/IMAGE ? (n/i) ");
			 refresh();
			 ch = read_key();
			 if (ch == CEsc) {
				 quit = true;
				 return;
			 }   

			 if (ch != CEnter) {
				 printw("%c", ch);
			 }
			 println();
			 println();
		 } while (strchr(NULLCommandSet, ch) == NULL);

		 if ((ch == 'N') || (ch == 'n'))
			 null_flag = true;
		 else
			 null_flag = false;

		 if (null_flag)
		 {
			 printw("Enter list of event labels to be nulled by projection;"); println();
			 printw("terminate list with -1."); println();
			 println();  tab(5);
			 sign_i = 0;
			 while (sign_i != -1) {
				 col = _wherex();
				 row = _wherey();
				 if (col >= 75) {
					 move(row+1,5);
					 col = 5;
					 row++;
				 }
				 if (_wherey() > 21) {
					 clear();
					 printw("Enter list of event labels to be nulled by projection;"); println();
					 printw("terminate list with -1."); println();
					 println(); tab(5);
					 esc_footer();
					 col = _wherex();
					 row = _wherey();
				 }

				 sign_i = (short) readint_and_e(&ch, -1, MAX_TRANSITIONS);
				 if (ch == CEsc) {
					 quit = true;
					 return;
				 }
				 if (sign_i != -1) {
					 i = (INT_T) sign_i;
					 addordlist(i, &nullist, s_nullist, &ok);
					 if (ok) (s_nullist)++;
				 }
				 move(row, col+7);
			 }
			 println(); println();

		 }
		 else
		 {

			 printw("Enter list of event labels to be retained;"); println();
			 printw("terminate list with -1."); println();
			 println();  tab(5);
			 sign_i = 0;
			 while (sign_i != -1) {
				 col = _wherex();
				 row = _wherey();
				 if (col >= 75) {
					 move(row+1,5);
					 col = 5;
					 row++;
				 }
				 if (_wherey() > 21) {
					 clear();
					 printw("Enter list of event labels to be retained;"); println();
					 printw("terminate list with -1."); println();
					 println(); tab(5);
					 esc_footer();
					 col = _wherex();
					 row = _wherey();
				 }

				 sign_i = (short) readint_and_e(&ch, -1, MAX_TRANSITIONS);
				 if (ch == CEsc) {
					 quit = true;
					 return;
				 }
				 if (sign_i != -1) {
					 i = (INT_T) sign_i;
					 addordlist(i, &imagelist, s_imagelist, &ok);
					 if (ok) (s_imagelist)++;
				 }
				 move(row, col+7);
			 }
			 println(); println();

		 }

		 init = 0L;
		 if (getdes(name1, &s1, &init, &t1) == false) {
			 quit = true;
			 return;
		 }

		 if (!null_flag)
		 {
			 gen_complement_list(t1, s1,
				 imagelist, s_imagelist,
				 &nullist, &s_nullist);
		 }
		 freedes(s1, &t1);
		 s1 = 0; t1 = NULL;
	 }
     
     println();
     x = _wherex();
     y = _wherey();
     move(22,0); clrtoeol();
     move(23,0); clrtoeol();
     printw("Processing:  Please wait... ");
     refresh();
         
     move(y,x);
     refresh();
     
     mark_start_time();     
     
     if(mode == 1){
        result = exlocalize_proc1(name1,name2,name3,s_tlist, tlist, true);
     }else if(mode == 2){
        result = exlocalize_proc2(name1,name2,name3,s_tlist, tlist,s_nullist, nullist);
     }else if (mode  == 3){
        result = exlocalize_proc_new(name1,name2,name3,s_tlist, tlist, true);   
     //}else if (mode == 4){
	//	result = exlocalize_proc_nlogn(name1,name2,name3,s_tlist, tlist);  
		//result = exlocalize_proc_filltab(name1,name2,name3,s_tlist, tlist); 
     }else{
        quit = 1;
        goto EXLOCALIZE_LABEL;
     }

     mark_stop_time();
     
     if(result == CR_OK){
        init = 0;
        getdes(name3, &s1, &init, &t1);           
     
     }else{
        quit = 1;
     }
	 loc_mode = 0;
	 endstate = 0;

EXLOCALIZE_LABEL:
     if(mem_result == 1){
        mem_result = 0;
        OutOfMemoryMsg();
     } else{
        if(!quit){
			if(mode != 2)
				exlocalize_makeit(s1, t1, s_tlist, tlist, mode);   
			else
				exlocalize_makeit1(s1, t1, s_tlist, tlist, mode, null_flag, s_imagelist, imagelist, s_nullist, nullist);
		   
        } 
     } 
     user_pause();   
     
     free(tlist);
     free(slist);
     freedes(s1, &t1);
	 free(imagelist);
	 free(nullist);

}

///////////////////////////////////////////////////////
void splitevent_header()
{
     printw("SPLITEVENT"); println();
     println();
     printw("DES2 = SPLITEVENT (DES1, EVENT, EVENT_SPLIT_LIST)"); println();
     println();
}
void splitevent_r(INT_S *s1, state_node **t1, 
                        INT_T *s_el, INT_T **el,
                        INT_S *s_ep, part_node **ep)
{
     INT_S i,j;
     char ch;
     INT_OS row, col;
     INT_OS result;
     INT_S init;
     
     result = 0;
     
     clear();
     splitevent_header();
     refresh();
     
     quit = getname("Enter name of DES1 ......... ",EXT_DES,name1,false);
     if(quit) return;
     
     quit = getname("Enter name of DES2 ......... ",EXT_DES,name2,true);
     if(quit) return;
     
     clear();
     splitevent_header();
     esc_footer();
     
     i = 0;
     while(i != -1){
        if(_wherey() > 19){
           clear();
           splitevent_header();
           esc_footer();
        }
        println();
        printw("Enter event to be splitted and quit with -1 ... "); 
        i = (INT_S) readint_and_e(&ch, -1, MAX_TRANSITIONS);
        if (ch == CEsc) {
          quit = true;
          return;
        }
        if (i == -1) break; 
        
        println(); println();
        printw("Enter list of new events corresponding to %ld", i); println();
        printw("Press <Enter> after each element and terminate with -1"); println();
        println(); tab(5);
        j = 0;
        while(j != -1){
           if(_wherey() > 21){
              clear();
              splitevent_header();              
              
              printw("Continue to enter list of new events corresponding to %ld", i); println();
              printw("Press <Enter> after each element and terminate with -1"); println();
              println(); tab(5);
              
              esc_footer();
           }
           row = _wherey();
           col = _wherex();
           if(col > 75){
              move(row + 1, 5);
              row ++;
              col = 5;
           }
           j = (INT_S) readint_and_e(&ch, -1, MAX_TRANSITIONS);
           if (ch == CEsc) {
              quit = true;
              return;
           }
           if(j != -1){
              addelem_part(*s_el, (INT_T)j, s_ep, ep);
           }
           if(mem_result == 1)
              return;
           move(row, col + 7);
           
        }     
        if((*ep)[*s_el].numelts != 0){
           *el = (INT_T*)REALLOC(*el, *s_ep * sizeof(INT_T));
           if(*el == NULL && *s_ep != 0){
              mem_result = 1;
              return;
           } 
           (*el)[*s_el] = (INT_T)i;
           (*s_el) ++;
           if(*s_el != *s_ep){
              quit = 1;
              return;
           }
        }
        println();  
     
     }
     
     mark_start_time();
     
     result = splitevent_proc(name1, name2, *s_el, *el, *s_ep, *ep);
     
     mark_stop_time();
     
     if (result == CR_OK) {
        strcpy(long_name2, "");
        make_filename_ext(long_name2, name2, EXT_DES);
        init = 0;
        if (exist(long_name2))
           getdes(name2, s1, &init, t1);   
        else
           quit = true;
     } else{
       if (result == CR_OUT_OF_MEMORY)
          mem_result = 1;
       else
          quit = true;
     }
     
}
void splitevent_makeit(INT_S s1, state_node *t1, INT_T s_el, INT_T *el, INT_S s_ep, part_node *ep)
{
     FILE* out;
     INT_S i,j;
     
     out = fopen(get_makeit(), "a");
     if (out == NULL) return;
     
     fprintf(out,"%s = Splitevent(%s,", name2,name1);
     
     fprintf(out, "[");
     
     for(i = 0; i < s_el; i ++){
        fprintf(out, "[%d:", el[i]);
        for(j = 0; j < ep[i].numelts; j ++){
           fprintf(out, "%d", ep[i].next[j]);
           if(j < ep[i].numelts - 1)
              fprintf(out, ",");
        }
        fprintf(out, "]");
        if(i < s_el - 1)
           fprintf(out, ",");
     }
     
     
     fprintf(out, "])  (%ld,%ld)", s1, count_tran(t1, s1)); 

     appendTime(out, sizeof(name2 + 3));
     
     fprintf(out, "\n\n");

     fclose(out);
}
void splitevent_p()
{
     INT_S s1;
     state_node *t1;
     INT_T s_el, *el;
     INT_S s_ep;
     part_node *ep;
     
     s1 = 0;
     t1 = NULL;
     
     s_el = 0;
     el = NULL;
     
     s_ep = 0; ep = NULL;
     
     splitevent_r(&s1, &t1, &s_el, &el, &s_ep, &ep);
     
     if (mem_result == 1) {
        mem_result = 0;
        OutOfMemoryMsg();
        user_pause();
     } else {
        if (!quit) {
           splitevent_makeit(s1, t1, s_el, el, s_ep, ep);
           user_pause();
        }
     }     
     
     echo_free();
     
     freedes(s1, &t1);
     free(el);
     free_part(s_ep, &ep);
}
////////////////////////////////////////////////////////
void augment_header() {
   printw("AUGMENT"); println();
   println();
   printw("DES2 = AUGMENT (DES1, EVENT_LIST)"); println();
   println();
}
void augment_r(state_node **t1,
                INT_S *s1,
                INT_T **list,
                INT_T *slist)
{
   INT_S      init;
   INT_T      i;
   short      sign_i;
   INT_B     ok;
   char       ch;
   INT_OS        row, col;
   INT_OS        result;

   clear();
   augment_header();
   quit = getname("Enter name of DES1 to be augmented ....  ",
                  EXT_DES, name1, false);
   if (quit) return;

   printw("Assign new name to %s?   (*y/n)   ", name1);
   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( (ch == 'N') || (ch == 'n') ) {
      strcpy(name2, name1);
      println();  println();
   } else {
      if (ch != CEnter) {
         printw("%c", ch);
      }
      println();
      println();
      quit = getname("Enter new name for DES2 ...............  ",
                     EXT_DES, name2, true);
      if (quit) return;
   }

   printw("Enter list of events to be adjoined.  Terminate list with -1.");
   println();  println();  tab(5);
   sign_i = 0;
   while (sign_i != -1) {
      col = _wherex();
      row = _wherey();
      if (col >= 75) {
         move(row+1,5);
         col = 5;
         row++;
      }
      if (_wherey() > 21) {
         clear();
         printw("Continue to enter list of events to be adjoined.  ");
         printw("Terminate list with -1.");
         println();
         println(); tab(5);
         esc_footer();
         col = _wherex();
         row = _wherey();
      }

      sign_i = (short) readint_and_e(&ch, -1, MAX_TRANSITIONS);
      if (ch == CEsc) {
          quit = true;
          return;
      }
      if (sign_i != -1) {
         i = (INT_T) sign_i;
         addordlist(i, list, *slist, &ok);
         if (ok) (*slist)++;
      }
      move(row, col+7);
   }

   move(22,0); clrtoeol(); refresh();
   move(23,0); clrtoeol(); refresh();
   printw("Processing:  Please wait...");
   refresh();

   /* Pass to command line version of this program */
   mark_start_time();         
   result = augment_proc(name2, name1, *slist, *list);    
   mark_stop_time();

   if (result == 0) {
      strcpy(long_name2, "");
      make_filename_ext(long_name2, name2, EXT_DES);
      init = 0;
      if (exist(long_name2))
         getdes(name2, s1, &init, t1);   
      else
         quit = true;
   }
   else 
   {
       if (result == CR_OUT_OF_MEMORY)
          mem_result = 1;
       else
          quit = true;
   }
}
void augment_makeit(state_node *t1,
                     INT_S s1,
                     INT_T *list,
                     INT_T slist)
{
   FILE* out;
   INT_T i;

   /* Write to a tempory file */
   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;
   fprintf(out, "%s = Augment(%s,[", name2, name1);
   for (i=0; i < slist; i++) {
     if (list[i] == EEE)
       fprintf(out, "e");
     else   
       fprintf(out, "%d", list[i]);
     if (i+1 < slist)
       fprintf(out, ",");
   }
   fprintf(out, "])");
   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1));
   appendTime(out, (INT_OS)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop((INT_OS)strlen(name2)+3);
   
}

void augment_p()
{
   state_node *t1;
   INT_S s1;
   INT_T *list, slist;

   t1 = NULL; s1 = 0;
   list = NULL; slist = 0;

   augment_r(&t1, &s1, &list, &slist);

   if (mem_result == 1) {
      mem_result = 0;   /* Reset memory result counter */
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        augment_makeit(t1, s1, list, slist);
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
   free(list);
}

//////////////////////////////////////////////////
void supqc_cc_header()
{
     printw("QUASI-CONGRUENCE & CONTROL CONSISTENCY"); println();
     println();
     printw("DES3 = SupQC&CC (DES1, DES2, NULL [or IMAGE])");println();
     println();
}
void supqc_cc_r(state_node **t1,
             INT_S *s1,
             INT_T **list,
             INT_T *slist,
             INT_T **imagelist,
             INT_T *s_imagelist,
             INT_S **statemap,
             INT_S *s_statemap,
             INT_B  *null_flag,
             INT_B  *is_det,
             INT_B  *report_qc,
             INT_OS *mode)
{
   INT_S      init;
   INT_T      i;
   short      sign_i;
   INT_B     ok;
   char       ch;
   INT_OS        row, col;
   INT_OS        result;

   clear();
   supqc_cc_header();
   refresh();

   //quit = getqc("Select supqc/supsqc .................... qc/sqc? ", mode);
   //if (quit) return;   

   quit = getname("Enter name of DES1 ...........................  ",
                  EXT_DES, name1, false);
   if (quit) return;
   
   quit = getname("Enter name of DES2 [control data of DES1]......  ",
                  EXT_DAT, name2, false);
   if (quit) return;

   quit = getname("Enter name of DES3 ...........................  ",
                  EXT_DES, name3, true);                                                
   if (quit) return;

   if (_wherey() > 12)
   {
       clear();
       //if (*mode == 1)
       //  CanQC_header();
       //else 
       //  CanSQC_header(); 
       supqc_cc_header();     
       esc_footer();
   }       

   println();
   printw("Enter either"); println();
   println();
   printw("  NULL (list of event labels erased)"); println();
   println();
   printw("or"); println();
   println();
   printw("  IMAGE (event labels retained)"); println();
   println();
/*   printw("NULL ? (*y/n)  ");

   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }
   if (ch != CEnter) {
      printw("%c", ch);
   }
   println();
   println();
   if ( (ch == 'n') || (ch == 'N') ) {
      *null_flag = false;
   }
*/

   do {
      if (_wherey() > 20)
      {
         clear();
         //if (*mode == 1)
         //  CanQC_header();
         //else 
         //  CanSQC_header();   
         supqc_cc_header();    
         esc_footer();
      }    
      
      printw("NULL/IMAGE ? (n/i) ");
      refresh();
      ch = read_key();
      if (ch == CEsc) {
         quit = true;
         return;
      }   
      
      if (ch != CEnter) {
         printw("%c", ch);
      }
      println();
      println();
   } while (strchr(NULLCommandSet, ch) == NULL);

   if ((ch == 'N') || (ch == 'n'))
      *null_flag = true;
   else
      *null_flag = false;

   if (*null_flag)
   {
      printw("Enter list of event labels to be nulled;"); println();
      printw("terminate list with -1."); println();
      println();  tab(5);
      sign_i = 0;
      while (sign_i != -1) {
        col = _wherex();
        row = _wherey();
        if (col >= 75) {
           move(row+1,5);
           col = 5;
           row++;
        }
        if (_wherey() > 21) {
           clear();
           printw("Enter list of event labels to be nulled;"); println();
           printw("terminate list with -1."); println();
           println(); tab(5);
           esc_footer();
           col = _wherex();
           row = _wherey();
        }

        sign_i = (short) readint(&ch, -1, MAX_TRANSITIONS);
        if (ch == CEsc) {
            quit = true;
            return;
        }
        if (sign_i != -1) {
           i = (INT_T) sign_i;
           addordlist(i, list, *slist, &ok);
           if (ok) (*slist)++;
        }
        move(row, col+7);
     }
     println(); println();

   }
   else
   {

      printw("Enter list of event labels to be retained;"); println();
      printw("terminate list with -1."); println();
      println();  tab(5);
      sign_i = 0;
      while (sign_i != -1) {
        col = _wherex();
        row = _wherey();
        if (col >= 75) {
           move(row+1,5);
           col = 5;
           row++;
        }
        if (_wherey() > 21) {
           clear();
           printw("Enter list of event labels to be retained;"); println();
           printw("terminate list with -1."); println();
           println(); tab(5);
           esc_footer();
           col = _wherex();
           row = _wherey();
        }

        sign_i = (short) readint(&ch, -1, MAX_TRANSITIONS);
        if (ch == CEsc) {
           quit = true;
           return;
        }
        if (sign_i != -1) {
           i = (INT_T) sign_i;
           addordlist(i, imagelist, *s_imagelist, &ok);
           if (ok) (*s_imagelist)++;
         }
        move(row, col+7);
     }
     println(); println();

   }
   
   if (_wherey() > 20)
   {
       clear();
       supqc_cc_header();
       esc_footer();
   }       

   println();
   //if (*mode == 1)
      printw("Report QC state partition in MAKEIT.TXT?  (y/*n)  ");
   //else
   //   printw("Report SQC state partition in MAKEIT.TXT?  (y/*n)  ");   

   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }
   if (ch != CEnter) {
      printw("%c", ch);
   }
   println();
   println();
   if ( (ch == 'y') || (ch == 'Y') ) {
      *report_qc = true;
   }

   init = 0L;
   if (getdes(name1, s1, &init, t1) == false) {
      quit = true;
      return;
   }

   if (*null_flag)
   {
      gen_complement_list(*t1, *s1,
                          *list, *slist,  
                          imagelist, s_imagelist);
   }
   else
   {
      gen_complement_list(*t1, *s1,
                          *imagelist, *s_imagelist,
                          list, slist);
   }
    
   freedes(*s1, t1);

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();
/*     result = CanQC_proc1(name2, name1, *slist, *list, *s_imagelist, *imagelist,
                        s_statemap, statemap, mode);   */
   result = supqc_cc_proc(name3, name1, name2, *slist, *list, *s_imagelist, *imagelist,
                                 s_statemap, statemap, *mode);   
   mark_stop_time();

   if (result == CR_OK) {
      strcpy(long_name3, "");
      make_filename_ext(long_name3, name3, EXT_DES);   
      if (exist(long_name3))
      {
         init = 0;
         getdes(name3, s1, &init, t1);  
         
         *is_det = is_deterministic(*t1, *s1);
         
         move(20,0); clrtoeol();
         move(21,0); clrtoeol();
         move(22,0); clrtoeol();
         move(21,0);
         if (*is_det)
            printw("%s is DETERMINISTIC.", name3);
         else
            printw("%s is NONDETERMINISTIC.", name3);                           
      }      
      else
         quit = true;   
   } else {
      if (result == CR_OUT_OF_MEMORY)
         mem_result = 1;
      else
         quit = true;
   }
}
void supqc_cc_makeit(state_node *t1,
                  INT_S s1,
                  INT_T *list,
                  INT_T slist,
                  INT_T *imagelist,
                  INT_T s_imagelist,
                  INT_S *statemap,
                  INT_S s_statemap,
                  INT_B  null_flag,
                  INT_B  is_det,
                  INT_B  report_qc,
                  INT_OS mode)
{
   FILE* out;
   INT_T i;
   INT_S ii, jj;
   INT_B  elem, prev;

   /* Write to a tempory file */
   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;

   //if (mode == 1)   
      fprintf(out, "%s = Supqc&cc(%s,%s,", name3, name1, name2);
   //else
    //  fprintf(out, "%s = Supsqc(%s,", name2, name1);

   if (null_flag)
   {
      fprintf(out, "Null[");
      for (i=0; i < slist; i++) {
        fprintf(out, "%d", list[i]);
        if (i+1 < slist)
          fprintf(out, ",");
      }
   }
   else
   {
      fprintf(out, "Image[");
      for (i=0; i < s_imagelist; i++) {
        fprintf(out, "%d", imagelist[i]);
        if (i+1 < s_imagelist)
          fprintf(out, ",");
      }
   }
   fprintf(out, "]");
      
   if (report_qc) {
      /* Dump QC */
      if (mode == 1)
         fprintf(out, ",QC[");
      else
         fprintf(out, ",SQC[");
         
      prev = FALSE;
      for (ii=0; ii < (s_statemap-1); ii++) {
         elem = FALSE; 
         for (jj=ii+1; ((jj < s_statemap) && (statemap[ii] == ii)); jj++) {
            if (ii == statemap[jj])
            {
               if (!elem) 
               {
                  if (prev == TRUE)
                     fprintf(out,","); 
                  fprintf(out, "[%d,%d", ii, jj);
                  elem = TRUE;
               }  
               else
                  fprintf(out, ",%d", jj);
            }      
         }          
         if (elem)
         {
            fprintf(out, "]");
            prev = TRUE;
         }  
      }    
      
      fprintf(out, "]");
   } else {
          
      if (mode == 1)
         fprintf(out, ",QC[omitted]");
      else    
         fprintf(out, ",SQC[omitted]");    
   }
   fprintf(out, ")");
   
   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1));
   
   if (is_det)
      fprintf(out, "  Deterministic.");
   else
      fprintf(out, "  Nondeterministic.");      
   
   appendTime(out, (INT_OS)strlen(name3)+3);
   fprintf(out, "\n\n");
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop((INT_OS)strlen(name3)+3);

}


void supqc_cc_p()
{
   state_node *t1;
   INT_S s1;
   INT_T *list, slist;
   INT_B  null_flag = true;
   INT_B  is_det = true;
   INT_B  report_qc = false;
   INT_T *imagelist, s_imagelist;
   INT_S *statemap, s_statemap;
   INT_OS mode = 1;

   t1 = NULL; s1 = 0;
   list = NULL; slist = 0;
   imagelist = NULL; s_imagelist = 0;
   statemap = NULL; s_statemap = 0;

   supqc_cc_r(&t1, &s1, &list, &slist, &imagelist, &s_imagelist, &statemap,
           &s_statemap, &null_flag, &is_det, &report_qc, &mode);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        supqc_cc_makeit(t1, s1, list, slist, imagelist, s_imagelist, 
                     statemap, s_statemap, null_flag, is_det, report_qc, mode);
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
   free(list);
   free(imagelist);
   free(statemap);
}
//////////////////////////////////////////////////
// supqc&lcc
void supqc_lcc_header()
{
     printw("QUASI-CONGRUENCE & LOCAL CONTROL CONSISTENCY"); println();
     println();
     printw("DES2 = SupQC&LCC (DES1, NULL [or IMAGE])");println();
     println();
}
void supqc_lcc_r(state_node **t1,
             INT_S *s1,
             INT_T **list,
             INT_T *slist,
             INT_T **imagelist,
             INT_T *s_imagelist,
             INT_S **statemap,
             INT_S *s_statemap,
             INT_B  *null_flag,
             INT_B  *is_det,
             INT_B  *report_qc,
             INT_OS *mode)
{
   INT_S      init;
   INT_T      i;
   short      sign_i;
   INT_B     ok;
   char       ch;
   INT_OS        row, col;
   INT_OS        result = 0;

   clear();
   supqc_lcc_header();
   refresh();

   //quit = getqc("Select supqc/supsqc .................... qc/sqc? ", mode);
   //if (quit) return;   
   *mode = 1;

   quit = getname("Enter name of DES1 ...........................  ",
                  EXT_DES, name1, false);
   if (quit) return;
   
  // quit = getname("Enter name of DES2 [control data of DES1]......  ",
  //                EXT_DAT, name2, false);
   //if (quit) return;

   quit = getname("Enter name of DES2 ...........................  ",
                  EXT_DES, name2, true);                                                
   if (quit) return;

   if (_wherey() > 12)
   {
       clear();
       //if (*mode == 1)
       //  CanQC_header();
       //else 
       //  CanSQC_header(); 
       supqc_lcc_header();     
       esc_footer();
   }       

   println();
   printw("Enter either"); println();
   println();
   printw("  NULL (list of event labels erased)"); println();
   println();
   printw("or"); println();
   println();
   printw("  IMAGE (event labels retained)"); println();
   println();
/*   printw("NULL ? (*y/n)  ");

   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }
   if (ch != CEnter) {
      printw("%c", ch);
   }
   println();
   println();
   if ( (ch == 'n') || (ch == 'N') ) {
      *null_flag = false;
   }
*/

   do {
      if (_wherey() > 20)
      {
         clear();
         //if (*mode == 1)
         //  CanQC_header();
         //else 
         //  CanSQC_header();   
         supqc_lcc_header();    
         esc_footer();
      }    
      
      printw("NULL/IMAGE ? (n/i) ");
      refresh();
      ch = read_key();
      if (ch == CEsc) {
         quit = true;
         return;
      }   
      
      if (ch != CEnter) {
         printw("%c", ch);
      }
      println();
      println();
   } while (strchr(NULLCommandSet, ch) == NULL);

   if ((ch == 'N') || (ch == 'n'))
      *null_flag = true;
   else
      *null_flag = false;

   if (*null_flag)
   {
      printw("Enter list of event labels to be nulled;"); println();
      printw("terminate list with -1."); println();
      println();  tab(5);
      sign_i = 0;
      while (sign_i != -1) {
        col = _wherex();
        row = _wherey();
        if (col >= 75) {
           move(row+1,5);
           col = 5;
           row++;
        }
        if (_wherey() > 21) {
           clear();
           printw("Enter list of event labels to be nulled;"); println();
           printw("terminate list with -1."); println();
           println(); tab(5);
           esc_footer();
           col = _wherex();
           row = _wherey();
        }

        sign_i = (short) readint(&ch, -1, MAX_TRANSITIONS);
        if (ch == CEsc) {
            quit = true;
            return;
        }
        if (sign_i != -1) {
           i = (INT_T) sign_i;
           addordlist(i, list, *slist, &ok);
           if (ok) (*slist)++;
        }
        move(row, col+7);
     }
     println(); println();

   }
   else
   {

      printw("Enter list of event labels to be retained;"); println();
      printw("terminate list with -1."); println();
      println();  tab(5);
      sign_i = 0;
      while (sign_i != -1) {
        col = _wherex();
        row = _wherey();
        if (col >= 75) {
           move(row+1,5);
           col = 5;
           row++;
        }
        if (_wherey() > 21) {
           clear();
           printw("Enter list of event labels to be retained;"); println();
           printw("terminate list with -1."); println();
           println(); tab(5);
           esc_footer();
           col = _wherex();
           row = _wherey();
        }

        sign_i = (short) readint(&ch, -1, MAX_TRANSITIONS);
        if (ch == CEsc) {
           quit = true;
           return;
        }
        if (sign_i != -1) {
           i = (INT_T) sign_i;
           addordlist(i, imagelist, *s_imagelist, &ok);
           if (ok) (*s_imagelist)++;
         }
        move(row, col+7);
     }
     println(); println();

   }
   
   if (_wherey() > 20)
   {
       clear();
       supqc_lcc_header();
       esc_footer();
   }       

   println();
   //if (*mode == 1)
      printw("Report QC state partition in MAKEIT.TXT?  (y/*n)  ");
   //else
   //   printw("Report SQC state partition in MAKEIT.TXT?  (y/*n)  ");   

   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }
   if (ch != CEnter) {
      printw("%c", ch);
   }
   println();
   println();
   if ( (ch == 'y') || (ch == 'Y') ) {
      *report_qc = true;
   }

   init = 0L;
   if (getdes(name1, s1, &init, t1) == false) {
      quit = true;
      return;
   }

   if (*null_flag)
   {
      gen_complement_list(*t1, *s1,
                          *list, *slist,  
                          imagelist, s_imagelist);
   }
   else
   {
      gen_complement_list(*t1, *s1,
                          *imagelist, *s_imagelist,
                          list, slist);
   }
    
   freedes(*s1, t1);

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();

   result = supqc_lcc_proc(name2, name1, *slist, *list, *s_imagelist, *imagelist,
                                 s_statemap, statemap, *mode);   
   mark_stop_time();

   if (result == CR_OK) {
      strcpy(long_name2, "");
      make_filename_ext(long_name2, name2, EXT_DES);   
      if (exist(long_name2))
      {
         init = 0;
         getdes(name2, s1, &init, t1);  
         
         *is_det = is_deterministic(*t1, *s1);
         
         move(20,0); clrtoeol();
         move(21,0); clrtoeol();
         move(22,0); clrtoeol();
         move(21,0);
         if (*is_det)
            printw("%s is DETERMINISTIC.", name2);
         else
            printw("%s is NONDETERMINISTIC.", name2);                           
      }      
      else
         quit = true;   
   } else {
      if (result == CR_OUT_OF_MEMORY)
         mem_result = 1;
      else
         quit = true;
   }
}
void supqc_lcc_makeit(state_node *t1,
                  INT_S s1,
                  INT_T *list,
                  INT_T slist,
                  INT_T *imagelist,
                  INT_T s_imagelist,
                  INT_S *statemap,
                  INT_S s_statemap,
                  INT_B  null_flag,
                  INT_B  is_det,
                  INT_B  report_qc,
                  INT_OS mode)
{
   FILE* out;
   INT_T i;
   INT_S ii, jj;
   INT_B  elem, prev;

   /* Write to a tempory file */
   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;

   //if (mode == 1)   
      fprintf(out, "%s = Supqc&lcc(%s,", name2, name1);
   //else
    //  fprintf(out, "%s = Supsqc(%s,", name2, name1);

   if (null_flag)
   {
      fprintf(out, "Null[");
      for (i=0; i < slist; i++) {
        fprintf(out, "%d", list[i]);
        if (i+1 < slist)
          fprintf(out, ",");
      }
   }
   else
   {
      fprintf(out, "Image[");
      for (i=0; i < s_imagelist; i++) {
        fprintf(out, "%d", imagelist[i]);
        if (i+1 < s_imagelist)
          fprintf(out, ",");
      }
   }
   fprintf(out, "]");
      
   if (report_qc) {
      /* Dump QC */
      if (mode == 1)
         fprintf(out, ",QC[");
      else
         fprintf(out, ",SQC[");
         
      prev = FALSE;
      for (ii=0; ii < (s_statemap-1); ii++) {
         elem = FALSE; 
         for (jj=ii+1; ((jj < s_statemap) && (statemap[ii] == ii)); jj++) {
            if (ii == statemap[jj])
            {
               if (!elem) 
               {
                  if (prev == TRUE)
                     fprintf(out,","); 
                  fprintf(out, "[%d,%d", ii, jj);
                  elem = TRUE;
               }  
               else
                  fprintf(out, ",%d", jj);
            }      
         }          
         if (elem)
         {
            fprintf(out, "]");
            prev = TRUE;
         }  
      }    
      
      fprintf(out, "]");
   } else {
          
      if (mode == 1)
         fprintf(out, ",QC[omitted]");
      else    
         fprintf(out, ",SQC[omitted]");    
   }
   fprintf(out, ")");
   
   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1));
   
   if (is_det)
      fprintf(out, "  Deterministic.");
   else
      fprintf(out, "  Nondeterministic.");      
   
   appendTime(out, (INT_OS)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop((INT_OS)strlen(name2)+3);

}


void supqc_lcc_p()
{
   state_node *t1;
   INT_S s1;
   INT_T *list, slist;
   INT_B  null_flag = true;
   INT_B  is_det = true;
   INT_B  report_qc = false;
   INT_T *imagelist, s_imagelist;
   INT_S *statemap, s_statemap;
   INT_OS mode = 1;

   t1 = NULL; s1 = 0;
   list = NULL; slist = 0;
   imagelist = NULL; s_imagelist = 0;
   statemap = NULL; s_statemap = 0;

   supqc_lcc_r(&t1, &s1, &list, &slist, &imagelist, &s_imagelist, &statemap,
           &s_statemap, &null_flag, &is_det, &report_qc, &mode);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        supqc_lcc_makeit(t1, s1, list, slist, imagelist, s_imagelist, 
                     statemap, s_statemap, null_flag, is_det, report_qc, mode);
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
   free(list);
   free(imagelist);
   free(statemap);
}
/////////////////////////////////////////////////////////
//project without Nernode equivalence
void plain_project_header() {
   printw("PROJECT"); println();
   println();
   printw("DES2 = PROJECT (DES1, NULL [or IMAGE])"); println();
   println();
}

void plain_project_r(state_node **t1,
               INT_S *s1,
               INT_T **list,
               INT_T *slist,
               INT_T **imagelist,
               INT_T *s_imagelist,
               INT_B *null_flag
              )
{
   INT_S      init;
   INT_T      i;
   short      sign_i;
   INT_B    ok;
   char       ch;
   int        row, col;
   INT_S mode;

   clear();
   plain_project_header();
   refresh();

   quit = getname("Enter name of DES1 to project .........  ",
                  EXT_DES, name1, false);
   if (quit) return;

   quit = getname("Enter name of DES2 to project onto ....  ",
                   EXT_DES, name2, true);
   if (quit) return;

   println();     
   printw("Retain the unobservable selfloops?  (y/*n)");
   refresh();
   ch = read_key();
   if(ch == CEsc){
	   quit = 1;
	   return;
   }
   if(ch != CEnter)
	   printw("%c",ch);
   println(); println();
   mode = 0;
   if(ch == 'y' || ch == 'Y'){
	   mode = 1;
   }

   if (_wherey() > 12)
   {
       clear();
       plain_project_header();
       esc_footer();
   }       

   println();
   printw("Enter either"); println();
   println();
   printw("  NULL (list of event labels erased by projection)"); println();
   println();
   printw("or"); println();
   println();
   printw("  IMAGE (event labels retained)"); println();
   println();


   do {
      if (_wherey() > 20)
      {
         clear();
         plain_project_header();
         esc_footer();
      }    
      
      printw("NULL/IMAGE ? (n/i) ");
      refresh();
      ch = read_key();
      if (ch == CEsc) {
         quit = true;
         return;
      }   
      
      if (ch != CEnter) {
         printw("%c", ch);
      }
      println();
      println();
   } while (strchr(NULLCommandSet, ch) == NULL);

   if ((ch == 'N') || (ch == 'n'))
      *null_flag = true;
   else
      *null_flag = false;

   if (*null_flag)
   {
      printw("Enter list of event labels to be nulled by projection;"); println();
      printw("terminate list with -1."); println();
      println();  tab(5);
      sign_i = 0;
      while (sign_i != -1) {
        col = _wherex();
        row = _wherey();
        if (col >= 75) {
           move(row+1,5);
           col = 5;
           row++;
        }
        if (_wherey() > 21) {
           clear();
           printw("Enter list of event labels to be nulled by projection;"); println();
           printw("terminate list with -1."); println();
           println(); tab(5);
           esc_footer();
           col = _wherex();
           row = _wherey();
        }

        sign_i = (short) readint_and_e(&ch, -1, MAX_TRANSITIONS);
        if (ch == CEsc) {
            quit = true;
            return;
        }
        if (sign_i != -1) {
           i = (INT_T) sign_i;
           addordlist(i, list, *slist, &ok);
           if (ok) (*slist)++;
        }
        move(row, col+7);
     }
     println(); println();

   }
   else
   {

      printw("Enter list of event labels to be retained;"); println();
      printw("terminate list with -1."); println();
      println();  tab(5);
      sign_i = 0;
      while (sign_i != -1) {
        col = _wherex();
        row = _wherey();
        if (col >= 75) {
           move(row+1,5);
           col = 5;
           row++;
        }
        if (_wherey() > 21) {
           clear();
           printw("Enter list of event labels to be retained;"); println();
           printw("terminate list with -1."); println();
           println(); tab(5);
           esc_footer();
           col = _wherex();
           row = _wherey();
        }

        sign_i = (short) readint_and_e(&ch, -1, MAX_TRANSITIONS);
        if (ch == CEsc) {
           quit = true;
           return;
        }
        if (sign_i != -1) {
           i = (INT_T) sign_i;
           addordlist(i, imagelist, *s_imagelist, &ok);
           if (ok) (*s_imagelist)++;
         }
        move(row, col+7);
     }
     println(); println();

   }

   init = 0L;
   if (getdes(name1, s1, &init, t1) == false) {
      quit = true;
      return;
   }

   if (!(*null_flag))
   {
      gen_complement_list(*t1, *s1,
                          *imagelist, *s_imagelist,
                          list, slist);
   }
   //freedes(*s1, t1);

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   /* Pass to command line version of this program */
   mark_start_time();

   if(mode == 1){
	   project_proc_selfloop(s1, t1, *slist, *list);
   }else
		plain_project_proc(s1, t1, *slist, *list);
   //result = project_runProgram(name2, name1, *list, *slist);   
   mark_stop_time();

   if (mem_result != 1)
   {
	   filedes(name2, *s1, init, *t1);
   }else
	   quit = true;

}

void plain_project_makeit(state_node *t1,
                    INT_S s1,
                    INT_T *list,
                    INT_T slist,
                    INT_T *imagelist,
                    INT_T s_imagelist,
                    INT_B null_flag
                  )
{
   FILE* out;
   INT_T i;

   /* Write to a tempory file */
   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;
   fprintf(out, "%s = Project(%s,", name2, name1);

   if (null_flag)
   {
      fprintf(out, "Null[");
      for (i=0; i < slist; i++) {
        fprintf(out, "%d", list[i]);
        if (i+1 < slist)
          fprintf(out, ",");
      }
   }
   else
   {
      fprintf(out, "Image[");
      for (i=0; i < s_imagelist; i++) {
        fprintf(out, "%d", imagelist[i]);
        if (i+1 < s_imagelist)
          fprintf(out, ",");
      }
   }

   fprintf(out, "])");
   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1));
   appendTime(out, (INT_OS)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop((INT_OS)strlen(name2)+3);
}

void plain_project_p()
{
	state_node *t1;
	INT_S s1;
	INT_T *list, slist;
	INT_B null_flag = true;
	INT_T *imagelist;
	INT_T s_imagelist;

	t1 = NULL; s1 = 0;
	list = NULL; slist = 0;
	imagelist = NULL; s_imagelist = 0;

	plain_project_r(&t1, &s1, &list, &slist, &imagelist, &s_imagelist, &null_flag);

	if (mem_result == 1) {
		mem_result = 0;
		OutOfMemoryMsg();
		user_pause();
	} else {
		if (!quit) {
			plain_project_makeit(t1, s1, list, slist, imagelist, s_imagelist, null_flag);
			user_pause();
		}
	}

	echo_free();
	freedes(s1, &t1);
	free(list);
	free(imagelist);
}
/////////////////////////////////////////////////////////
//Conjunction of Project and f, denoted by Q
// This function computes InvQ*Q(C,K)
void project_f_header() {
	printw("INVQ*Q"); println();
	println();
	printw("DES3 = INVQ*Q (DES1, DES, NULL [or IMAGE])"); println();
	println();
}

void project_f_r(state_node **t2,
	INT_S *s2,
	INT_T **list,
	INT_T *slist,
	INT_T **imagelist,
	INT_T *s_imagelist,
	INT_B *null_flag
	)
{
	INT_S      init;
	INT_T      i;
	short      sign_i;
	INT_B    ok;
	char       ch;
	int        row, col;
	state_node *t1;
	INT_S s1;

	s1 = 0; t1 = NULL;

	clear();
	project_f_header();
	refresh();

	quit = getname("Enter name of ambient DES1 .........  ",
		EXT_DES, name1, false);
	if (quit) return;

	quit = getname("Enter name of DES2 to project .........  ",
		EXT_DES, name2, false);
	if (quit) return;

	quit = getname("Enter name of DES3 to project onto ....  ",
		EXT_DES, name3, true);
	if (quit) return;

	if (_wherey() > 12)
	{
		clear();
		project_f_header();
		esc_footer();
	}       

	println();
	printw("Enter either"); println();
	println();
	printw("  NULL (list of event labels erased by projection)"); println();
	println();
	printw("or"); println();
	println();
	printw("  IMAGE (event labels retained)"); println();
	println();


	do {
		if (_wherey() > 20)
		{
			clear();
			project_f_header();
			esc_footer();
		}    

		printw("NULL/IMAGE ? (n/i) ");
		refresh();
		ch = read_key();
		if (ch == CEsc) {
			quit = true;
			return;
		}   

		if (ch != CEnter) {
			printw("%c", ch);
		}
		println();
		println();
	} while (strchr(NULLCommandSet, ch) == NULL);

	if ((ch == 'N') || (ch == 'n'))
		*null_flag = true;
	else
		*null_flag = false;

	if (*null_flag)
	{
		printw("Enter list of event labels to be nulled by projection;"); println();
		printw("terminate list with -1."); println();
		println();  tab(5);
		sign_i = 0;
		while (sign_i != -1) {
			col = _wherex();
			row = _wherey();
			if (col >= 75) {
				move(row+1,5);
				col = 5;
				row++;
			}
			if (_wherey() > 21) {
				clear();
				printw("Enter list of event labels to be nulled by projection;"); println();
				printw("terminate list with -1."); println();
				println(); tab(5);
				esc_footer();
				col = _wherex();
				row = _wherey();
			}

			sign_i = (short) readint_and_e(&ch, -1, MAX_TRANSITIONS);
			if (ch == CEsc) {
				quit = true;
				return;
			}
			if (sign_i != -1) {
				i = (INT_T) sign_i;
				addordlist(i, list, *slist, &ok);
				if (ok) (*slist)++;
			}
			move(row, col+7);
		}
		println(); println();

	}
	else
	{

		printw("Enter list of event labels to be retained;"); println();
		printw("terminate list with -1."); println();
		println();  tab(5);
		sign_i = 0;
		while (sign_i != -1) {
			col = _wherex();
			row = _wherey();
			if (col >= 75) {
				move(row+1,5);
				col = 5;
				row++;
			}
			if (_wherey() > 21) {
				clear();
				printw("Enter list of event labels to be retained;"); println();
				printw("terminate list with -1."); println();
				println(); tab(5);
				esc_footer();
				col = _wherex();
				row = _wherey();
			}

			sign_i = (short) readint_and_e(&ch, -1, MAX_TRANSITIONS);
			if (ch == CEsc) {
				quit = true;
				return;
			}
			if (sign_i != -1) {
				i = (INT_T) sign_i;
				addordlist(i, imagelist, *s_imagelist, &ok);
				if (ok) (*s_imagelist)++;
			}
			move(row, col+7);
		}
		println(); println();

	}

	init = 0L;
	if (getdes(name1, &s1, &init, &t1) == false) {
		quit = true;
		return;
	}

	init = 0L;
	if (getdes(name2, s2, &init, t2) == false) {
		quit = true;
		return;
	}

	if (!(*null_flag))
	{
		gen_complement_list(*t2, *s2,
			*imagelist, *s_imagelist,
			list, slist);
	}
	//freedes(*s1, t1);

	move(22,0); clrtoeol();
	move(23,0); clrtoeol();
	printw("Processing:  Please wait...");
	refresh();

	/* Pass to command line version of this program */
	mark_start_time();

	project_f_proc(s1, t1, s2, t2, *slist, *list);
	//result = project_runProgram(name2, name1, *list, *slist);   
	mark_stop_time();

	if (mem_result != 1)
	{
		filedes(name3, *s2, init, *t2);
	}else
		quit = true;

	freedes(s1, &t1);
}

void project_f_makeit(state_node *t1,
	INT_S s1,
	INT_T *list,
	INT_T slist,
	INT_T *imagelist,
	INT_T s_imagelist,
	INT_B null_flag
	)
{
	FILE* out;
	INT_T i;

	/* Write to a tempory file */
	out = fopen("tmp.$$$", "w");
	if (out == NULL) return;
	fprintf(out, "%s = InvQ*Q(%s,%s,", name3, name1, name2);

	if (null_flag)
	{
		fprintf(out, "Null[");
		for (i=0; i < slist; i++) {
			fprintf(out, "%d", list[i]);
			if (i+1 < slist)
				fprintf(out, ",");
		}
	}
	else
	{
		fprintf(out, "Image[");
		for (i=0; i < s_imagelist; i++) {
			fprintf(out, "%d", imagelist[i]);
			if (i+1 < s_imagelist)
				fprintf(out, ",");
		}
	}

	fprintf(out, "])");
	fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1));
	appendTime(out, (INT_OS)strlen(name3)+3);
	fprintf(out, "\n\n");
	fclose(out);

	/* Merge file into MAKEIT.TXT */
	mergeChop((INT_OS)strlen(name3)+3);
}

void project_f_p()
{
	state_node *t1;
	INT_S s1;
	INT_T *list, slist;
	INT_B null_flag = true;
	INT_T *imagelist;
	INT_T s_imagelist;

	t1 = NULL; s1 = 0;
	list = NULL; slist = 0;
	imagelist = NULL; s_imagelist = 0;

	project_f_r(&t1, &s1, &list, &slist, &imagelist, &s_imagelist, &null_flag);

	if (mem_result == 1) {
		mem_result = 0;
		OutOfMemoryMsg();
		user_pause();
	} else {
		if (!quit) {
			project_f_makeit(t1, s1, list, slist, imagelist, s_imagelist, null_flag);
			user_pause();
		}
	}

	echo_free();
	freedes(s1, &t1);
	free(list);
	free(imagelist);
}

void rel_observ_header()
{
	printw("RELATIVELY OBSERVABLE"); println();
	println();
	printw("RELATIVELY OBSERVABLE (DES1, DES2, DES3, NULL [or IMAGE])"); println();
	println();
}
void rel_observ_makeit(INT_B  null_flag, INT_T s_list, INT_T *list, INT_T s_imagelist, INT_T *imagelist, INT_B obs_flag)
{
	FILE* out;
	INT_S i;
	INT_OS   offset;

	/*Write to a tempory file*/
	out = fopen("tmp.$$$","w");
	if(out == NULL) return;

	if(obs_flag){
		fprintf(out, "true");
		offset = 4;
	}
	else{
		fprintf(out, "false");
		offset = 5;
	}
	fprintf(out, " = RelObs(%s,%s,%s,", name1, name2, name3);

	if (null_flag)
	{
		fprintf(out, "Null[");
		for (i=0; i < s_list; i++) {
			fprintf(out, "%d", list[i]);
			if (i+1 < s_list)
				fprintf(out, ",");
		}
	}
	else
	{
		fprintf(out, "Image[");
		for (i=0; i < s_imagelist; i++) {
			fprintf(out, "%d", imagelist[i]);
			if (i+1 < s_imagelist)
				fprintf(out, ",");
		}
	}
	fprintf(out, "])");
	//fprintf(out, "  (%ld,%ld)", s, count_tran(t, s));
	appendTime(out, offset + 3);
	fprintf(out,"\n\n");
	fclose(out);

	mergeChop(offset + 3);

}
void rel_observ_r()
{
	INT_T *list, slist, *imagelist, s_imagelist, *contr_list, s_contr_list;
	INT_B  null_flag, obs_flag;
	INT_S      init;
	INT_T      i;
	short      sign_i;
	INT_B     ok;
	char       ch;
	INT_OS        row, col;//, x, y;
	INT_OS        result;

	state_node *t1, *t2;
	INT_S s1, s2;

	list = imagelist = contr_list = NULL;
	slist = s_imagelist = s_contr_list = 0;
	s1 = s2 = 0;
	t1 = t2 = NULL;
	result = 0;

	clear();
	rel_observ_header();
	refresh(); 

	quit = getname("Enter name of plant generator DES1 ................ ", EXT_DES, name1, false);
	if(quit) return;

	quit = getname("Enter name of ambient language generator DES2 ........ ", EXT_DES, name2, false);
	if(quit) return;

	quit = getname("Enter name of language generator DES3 to be checked ........ ", EXT_DES, name3, false);
	if(quit) return;

	//printw("Enter name of supremal"); println();
	//quit = getname("observable language generator DES3 ................ ", EXT_DES, name3, true);
	//if(quit) return;


	if(_wherey() > 16){
		clear();
		rel_observ_header();
		esc_footer();
	}

	printw("Enter list of controllable events:"); println();
	println();		
	ext_get_conlist(&s_contr_list, &contr_list);
	addordlist(MMM, &contr_list, s_contr_list, &ok);
	if(ok)  s_contr_list ++;
	//if(quit){
	//	goto FREE_LABEL;
	//}

	if(_wherey() > 12){
		clear();
		rel_observ_header();
		esc_footer();
	}

	println();
	printw("Enter either"); println();
	println();
	printw("  NULL (list of event labels erased)"); println();
	println();
	printw("or"); println();
	println();
	printw("  IMAGE (event labels retained)"); println();
	println();

	do {
		if (_wherey() > 20)
		{
			clear();
			rel_observ_header();      
			esc_footer();
		}    

		printw("NULL/IMAGE ? (n/i) ");
		refresh();
		ch = read_key();
		if (ch == CEsc) {
			quit = true;
			return;
		}   

		if (ch != CEnter) {
			printw("%c", ch);
		}
		println();
		println();
	} while (strchr(NULLCommandSet, ch) == NULL);

	if ((ch == 'N') || (ch == 'n'))
		null_flag = true;
	else
		null_flag = false;

	if (null_flag)
	{
		printw("Enter list of event labels to be nulled;"); println();
		printw("terminate list with -1."); println();
		println();  tab(5);
		sign_i = 0;
		while (sign_i != -1) {
			col = _wherex();
			row = _wherey();
			if (col >= 75) {
				move(row+1,5);
				col = 5;
				row++;
			}
			if (_wherey() > 21) {
				clear();
				printw("Enter list of event labels to be nulled;"); println();
				printw("terminate list with -1."); println();
				println(); tab(5);
				esc_footer();
				col = _wherex();
				row = _wherey();
			}

			sign_i = (short) readint(&ch, -1, MAX_TRANSITIONS);
			if (ch == CEsc) {
				quit = true;
				return;
			}
			if (sign_i != -1) {
				i = (INT_T) sign_i;
				addordlist(i, &list, slist, &ok);
				if (ok) slist++;
			}
			move(row, col+7);
		}
		println(); println();

	}
	else
	{

		printw("Enter list of event labels to be retained;"); println();
		printw("terminate list with -1."); println();
		println();  tab(5);
		sign_i = 0;
		while (sign_i != -1) {
			col = _wherex();
			row = _wherey();
			if (col >= 75) {
				move(row+1,5);
				col = 5;
				row++;
			}
			if (_wherey() > 21) {
				clear();
				printw("Enter list of event labels to be retained;"); println();
				printw("terminate list with -1."); println();
				println(); tab(5);
				esc_footer();
				col = _wherex();
				row = _wherey();
			}

			sign_i = (short) readint(&ch, -1, MAX_TRANSITIONS);
			if (ch == CEsc) {
				quit = true;
				return;
			}
			if (sign_i != -1) {
				i = (INT_T) sign_i;
				addordlist(i, &imagelist, s_imagelist, &ok);
				if (ok) s_imagelist++;
			}
			move(row, col+7);
		}
		println(); println();
	}
	//x = _wherex();
	//y = _wherey();
	move(22,0); clrtoeol();
	move(23,0); clrtoeol();
	printw("Processing:  Please wait... ");
	refresh();   


	mark_start_time();

	init = 0L;
	if(getdes(name1, &s1, &init, &t1) == false){
		quit = true;
		goto LABEL;
	}    

	if (null_flag)
	{
		gen_complement_list(t1, s1,
			list, slist,  
			&imagelist, &s_imagelist);
	}
	else
	{
		gen_complement_list(t1, s1,
			imagelist, s_imagelist,
			&list, &slist);
	}
	freedes(s1,&t1);
	s1 = 0; t1 = NULL;

	obs_flag = true;
	/*the main program of checking observability*/    
	result = rel_observ_proc(name1, name3, name2, s_contr_list, contr_list, slist,list,s_imagelist,imagelist, &obs_flag);

	mark_stop_time();

	if(result == 0){
		//strcpy(long_name3, "");
		//make_filename_ext(long_name3, name3, EXT_DES);
		//if(exist(long_name3)){
			//init = 0L;
			//getdes(name3, &s1, &init, &t1);
			move(19,0); clrtoeol();
			move(20,0); clrtoeol();
			move(21,0); clrtoeol();
			move(22,0); clrtoeol();
			move(20,0);
			if(obs_flag){
				printw("%s is %s-observable with respect to %s ", name3, name2, name1);
				strcpy(long_name3, "");
				make_filename_ext(long_name3, "Table", EXT_TXT);
				remove(long_name3);
			}else{
				printw("%s is not %s-observable with respect to %s.", name3, name2, name1);println();
				printw("Check Table.txt to find the states leading observability to failure.");
			}
			rel_observ_makeit(null_flag, slist, list,s_imagelist, imagelist, obs_flag);
		//}
	}else{
		quit = 1;
	}

LABEL:   
	free(list);
	free(imagelist);
	free(contr_list);
	freedes(s1,&t1);
	freedes(s2,&t2); 
}
void rel_observ_p()
{
	//state_node *t1; INT_S s1;

	//s1 = 0; t1 = NULL;

	rel_observ_r();
	if(mem_result == 1){
		mem_result = 0;
		OutOfMemoryMsg();
		user_pause();
	}
	else{
		if(!quit){
			user_pause();
		}    
	}
	echo_free();
}
/////////////////////////////////////////////

//Conjunction of Project and f, denoted by Q
// This function computes InvQ*Q(C,K)
void melt_e_header() {
	printw("MELT"); println();
	println();
	printw("DES2 = Melt (DES1, NULL [or IMAGE])"); println();
	println();
}

void melt_e_r(state_node **t2,
	INT_S *s2,
	INT_T **list,
	INT_T *slist,
	INT_T **imagelist,
	INT_T *s_imagelist,
	INT_B *null_flag
	)
{
	INT_S      init;
	INT_T      i;
	short      sign_i;
	INT_B    ok;
	char       ch;
	int        row, col;
	state_node *t1;
	INT_S s1;

	s1 = 0; t1 = NULL;

	clear();
	melt_e_header();
	refresh();

	quit = getname("Enter name of ambient DES1 .........  ",
		EXT_DES, name1, false);
	if (quit) return;

	quit = getname("Enter name of DES2 to project onto ....  ",
		EXT_DES, name2, true);
	if (quit) return;

	if (_wherey() > 12)
	{
		clear();
		melt_e_header();
		esc_footer();
	}       

	println();
	printw("Enter either"); println();
	println();
	printw("  NULL (list of event labels erased by projection)"); println();
	println();
	printw("or"); println();
	println();
	printw("  IMAGE (event labels retained)"); println();
	println();


	do {
		if (_wherey() > 20)
		{
			clear();
			melt_e_header();
			esc_footer();
		}    

		printw("NULL/IMAGE ? (n/i) ");
		refresh();
		ch = read_key();
		if (ch == CEsc) {
			quit = true;
			return;
		}   

		if (ch != CEnter) {
			printw("%c", ch);
		}
		println();
		println();
	} while (strchr(NULLCommandSet, ch) == NULL);

	if ((ch == 'N') || (ch == 'n'))
		*null_flag = true;
	else
		*null_flag = false;

	if (*null_flag)
	{
		printw("Enter list of event labels to be nulled by projection;"); println();
		printw("terminate list with -1."); println();
		println();  tab(5);
		sign_i = 0;
		while (sign_i != -1) {
			col = _wherex();
			row = _wherey();
			if (col >= 75) {
				move(row+1,5);
				col = 5;
				row++;
			}
			if (_wherey() > 21) {
				clear();
				printw("Enter list of event labels to be nulled by projection;"); println();
				printw("terminate list with -1."); println();
				println(); tab(5);
				esc_footer();
				col = _wherex();
				row = _wherey();
			}

			sign_i = (short) readint_and_e(&ch, -1, MAX_TRANSITIONS);
			if (ch == CEsc) {
				quit = true;
				return;
			}
			if (sign_i != -1) {
				i = (INT_T) sign_i;
				addordlist(i, list, *slist, &ok);
				if (ok) (*slist)++;
			}
			move(row, col+7);
		}
		println(); println();

	}
	else
	{

		printw("Enter list of event labels to be retained;"); println();
		printw("terminate list with -1."); println();
		println();  tab(5);
		sign_i = 0;
		while (sign_i != -1) {
			col = _wherex();
			row = _wherey();
			if (col >= 75) {
				move(row+1,5);
				col = 5;
				row++;
			}
			if (_wherey() > 21) {
				clear();
				printw("Enter list of event labels to be retained;"); println();
				printw("terminate list with -1."); println();
				println(); tab(5);
				esc_footer();
				col = _wherex();
				row = _wherey();
			}

			sign_i = (short) readint_and_e(&ch, -1, MAX_TRANSITIONS);
			if (ch == CEsc) {
				quit = true;
				return;
			}
			if (sign_i != -1) {
				i = (INT_T) sign_i;
				addordlist(i, imagelist, *s_imagelist, &ok);
				if (ok) (*s_imagelist)++;
			}
			move(row, col+7);
		}
		println(); println();

	}

	init = 0L;
	if (getdes(name1, &s1, &init, &t1) == false) {
		quit = true;
		return;
	}

	if (!(*null_flag))
	{
		gen_complement_list(t1, s1,
			*imagelist, *s_imagelist,
			list, slist);
	}
	//freedes(*s1, t1);

	move(22,0); clrtoeol();
	move(23,0); clrtoeol();
	printw("Processing:  Please wait...");
	refresh();

	mark_start_time();

	melt_e_proc(s1, t1, s2, t2, *slist, *list);

	mark_stop_time();

	if (mem_result != 1)
	{
		filedes(name2, *s2, init, *t2);
	}else
		quit = true;

	freedes(s1, &t1);
}

void melt_e_makeit(state_node *t1,
	INT_S s1,
	INT_T *list,
	INT_T slist,
	INT_T *imagelist,
	INT_T s_imagelist,
	INT_B null_flag
	)
{
	FILE* out;
	INT_T i;

	/* Write to a tempory file */
	out = fopen("tmp.$$$", "w");
	if (out == NULL) return;
	fprintf(out, "%s = Melt(%s,", name2, name1);

	if (null_flag)
	{
		fprintf(out, "Null[");
		for (i=0; i < slist; i++) {
			fprintf(out, "%d", list[i]);
			if (i+1 < slist)
				fprintf(out, ",");
		}
	}
	else
	{
		fprintf(out, "Image[");
		for (i=0; i < s_imagelist; i++) {
			fprintf(out, "%d", imagelist[i]);
			if (i+1 < s_imagelist)
				fprintf(out, ",");
		}
	}

	fprintf(out, "])");
	fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1));
	appendTime(out, (INT_OS)strlen(name2)+3);
	fprintf(out, "\n\n");
	fclose(out);

	/* Merge file into MAKEIT.TXT */
	mergeChop((INT_OS)strlen(name2)+3);
}

void melt_e_p()
{
	state_node *t1;
	INT_S s1;
	INT_T *list, slist;
	INT_B null_flag = true;
	INT_T *imagelist;
	INT_T s_imagelist;

	t1 = NULL; s1 = 0;
	list = NULL; slist = 0;
	imagelist = NULL; s_imagelist = 0;

	melt_e_r(&t1, &s1, &list, &slist, &imagelist, &s_imagelist, &null_flag);

	if (mem_result == 1) {
		mem_result = 0;
		OutOfMemoryMsg();
		user_pause();
	} else {
		if (!quit) {
			melt_e_makeit(t1, s1, list, slist, imagelist, s_imagelist, null_flag);
			user_pause();
		}
	}

	echo_free();
	freedes(s1, &t1);
	free(list);
	free(imagelist);
}
////////////////////////////////////////////////
//Supremal relative co-observablility
void sup_rel_coobs_header()
{
	printw("SUPRCOOBS"); println();
	println();
	printw("DES3 = SUPRCOOBS (DES1, DES2, (DEC1, DEC2,..., DECn)"); println();
	println();
}
void sup_rel_coobs_makeit(INT_S s, state_node *t, INT_S  *null_flag, INT_S P_num,  t_part_node* null_par, t_part_node * image_par)
{
	FILE* out;
	INT_S i,j;
	//    INT_OS   offset;

	/*Write to a tempory file*/
	out = fopen("tmp.$$$","w");
	if(out == NULL) return;

	fprintf(out, "%s = Suprcoobs(%s,%s,", name3, name1, name2);

	for(j = 0; j < P_num; j ++){
		fprintf(out, "DEC%d(", j + 1);
		if ( null_flag[j] == 1){		
			fprintf(out, "Null: [");
			for (i=0; i < null_par[j].numelts; i++) {
				fprintf(out, "%d", null_par[j].next[i]);
				if (i+1 <  null_par[j].numelts)
					fprintf(out, ",");
			}
			fprintf(out, "]");
		}
		else if(null_flag[j] == 2){		
			fprintf(out, "Image: [");
			for (i=0; i < image_par[j].numelts; i++) {
				fprintf(out, "%d", image_par[j].next[i]);
				if (i+1 < image_par[j].numelts)
					fprintf(out, ",");
			}
			fprintf(out, "]");
		}else{
			fprintf(out, "Image DES: %s", group_imagename[j]);
		}
		fprintf(out, ")");
		if(j < P_num -1 )
			fprintf(out, ",");
	}
	fprintf(out, ")");
	fprintf(out, "  (%ld,%ld)", s, count_tran(t, s));
	appendTime(out, (INT_OS)strlen(name3) + 3);
	fprintf(out,"\n\n");
	fclose(out);

	mergeChop((INT_OS)strlen(name3) + 3);

}
void sup_rel_coobs_r()
{
	INT_T *list, slist, *imagelist, s_imagelist;
	INT_S  *null_flag;
	INT_S      init, *mapState;
	char       ch;
	INT_OS        result; 
	INT_S P_num,i;
	t_part_node * image_par, *null_par;//, *con_par;
	INT_S s_macro_c, *macro_c, *macro_ab;

	state_node *t1, *t2, *t3, *t4, *t5;
	INT_S s1, s2, s3, s4, s5;
	INT_B fix_flag;//, ok;

	list = imagelist = NULL;
	slist = s_imagelist = 0;
	image_par = null_par = NULL;
	s1 = s2 = s3 = s4 = s5 = 0;
	t1 = t2 = t3 = t4 = t5 = NULL;
	s_macro_c = 0; macro_c = macro_ab = NULL;
	mapState = NULL;
	null_flag = NULL;

	result = 0;

	clear();
	sup_rel_coobs_header();
	refresh(); 

	quit = getname("Enter name of plant generator DES1 .................. ", EXT_DES, name1, false);
	if(quit) return;

	quit = getname("Enter name of legal language generator DES2 ......... ", EXT_DES, name2, false);
	if(quit) return;

	printw("Enter name of supremal"); println();
	quit = getname(" relatively co-observable sublanguage generator DES3 ... ", EXT_DES, name3, true);
	if(quit) return;

	if(_wherey() > 12){
		clear();
		sup_rel_coobs_header();
		esc_footer();
	}

	printw("Enter number of decentralized supervisors ....... (between 2 and %d) ", MAX_DESS);
	P_num = readint(&ch,2,MAX_DESS); println();
	if(ch == CEsc){
		quit = true;
		return;
	}

	//con_par = (t_part_node *)REALLOC(con_par, P_num * sizeof(t_part_node));
	//if(con_par == NULL){
	//	quit = true;
	//	goto FREE_LABEL;
	//}

	image_par = (t_part_node *)REALLOC(image_par, P_num * sizeof(t_part_node));
	if(image_par == NULL){
		quit = true;
		goto FREE_LABEL;
	}
	null_par = (t_part_node *)REALLOC(null_par, P_num * sizeof(t_part_node));
	if(null_par == NULL){
		quit = true;
		goto FREE_LABEL;
	}

	null_flag = (INT_S *) REALLOC(null_flag, P_num * sizeof(INT_S));
	if(null_flag == NULL){
		quit = true;
		goto FREE_LABEL;
	}

	for(i =0; i < P_num; i ++){
		clear();
		sup_rel_coobs_header();		
		esc_footer();

		if(_wherey() > 10){
			clear();
			sup_rel_coobs_header();
			esc_footer();
		}

		printw("Enter observable or unobservable events of %dth decentralized supervisor", i + 1); println();
		println();

		image_par[i].numelts = null_par[i].numelts = 0;
		image_par[i].next = null_par[i].next = NULL;
		ext_get_imagelist(&image_par[i].numelts, &image_par[i].next, &null_par[i].numelts, &null_par[i].next, null_flag,1, i);
		if(quit)
			goto FREE_LABEL;

	}
	move(22,0); clrtoeol();
	move(23,0); clrtoeol();
	printw("Processing:  Please wait... ");
	refresh();   


	mark_start_time();

	init = 0L;
	if(getdes(name1, &s1, &init, &t1) == false){
		quit = true;
		goto FREE_LABEL;
	} 

	init = 0L;
	if(getdes(name2, &s2, &init, &t2) == false){
		quit = true;
		goto FREE_LABEL;
	}  

	for(i = 0; i < P_num; i ++){
		if (null_flag[i] == 1)		
			gen_complement_list(t1, s1, null_par[i].next, null_par[i].numelts, &image_par[i].next, &image_par[i].numelts);
		else
			gen_complement_list(t1, s1, image_par[i].next, image_par[i].numelts, &null_par[i].next, &null_par[i].numelts);	
	}
	//freedes(s1,&t1);
	//s1 = 0; t1 = NULL;

	//strcpy(name4, "$$$$$$$$1");
	//result = supcon_runProgram(name4, name1, name2);
	//if(result != 0)
	//	goto FREE_LABEL;
	//init = 0L;
	//if(getdes(name4, &s4, &init, &t4) == false){
	//	quit = true;
	//	goto FREE_LABEL;
	//}  
	
	// Compute normal form of C = K0: NK = K0 || (||{Pi(K0)| i = 1,..., P_num})
	
	for(i = 0; i < P_num; i ++){	
		export_copy_des(&s3, &t3, s2, t2);
		export_copy_des(&s4, &t4, s2, t2);
		plain_project_proc(&s4, &t4, null_par[i].numelts, null_par[i].next);		
		sync2(s3, t3, s4, t4, &s5, &t5, &macro_ab, &macro_c);
		free(macro_ab); free(macro_c); macro_ab = macro_c = NULL;

		freedes(s2, &t2); s2 = 0; t2 = NULL;		
		export_copy_des(&s2, &t2, s5, t5);

		freedes(s3, &t3); s3 = 0; t3 = NULL;
		freedes(s4, &t4); s4 = 0; t4 = NULL;
		freedes(s5, &t5); s5 = 0; t5 = NULL;

	}
	strcpy(name4, "$$$$$$$$1");
	init = 0L;
	filedes(name4, s2, init, t2);

	strcpy(name5, "$$$$$$$$2");
	init = 0L;
	filedes(name5, s2, init, t2);

	//obs_meet(s1, t1, s2, t2, &s3, &t3, &s_macro_c, &macro_c);

	freedes(s1, &t1); s1 = 0; t1 = NULL;
	freedes(s2, &t2); s2 = 0; t2 = NULL;
	freedes(s3, &t3); s3 = 0; t3 = NULL;
	freedes(s4, &t4); s4 = 0; t4 = NULL;
	freedes(s5, &t5); s5 = 0; t5 = NULL;


	fix_flag = false;

	while(!fix_flag){
		// Obtain K_i to compare with K_i+1
		init = 0L;
		if(getdes(name4, &s2, &init, &t2) == false){
			quit = true;
			goto FREE_LABEL;
		}  

		//compute supremal relative observable sublanguage
		for(i = 0; i < P_num; i ++){
			result = supobs_proc5(name3, name1, name4, name5, null_par[i].numelts, null_par[i].next, image_par[i].numelts, image_par[i].next);
			init = 0L;
			getdes(name3, &s3, &init, &t3);			
			init = 0L;
			filedes(name4, s3, init, t3);
			freedes(s3, &t3); s3 = 0; t3 = NULL;
		}

		// compute supremal controllabel sublanguage
		//result = supcon_runProgram(name4, name1, name3);


		init = 0L;
		if(getdes(name3, &s3, &init, &t3) == false){
			quit = true;
			goto FREE_LABEL;
		}  

		if(s3 == 0)
			break;

		minimize(&s2, &t2);
		minimize(&s3, &t3);

		if(s2 == 0 && s3 == 0){
			fix_flag = true;
			break;
		}

		/* Need some memory here - Allocate map state */
		if(s2 != 0){
			mapState = (INT_S*) CALLOC(s2, sizeof(INT_S));
			memset(mapState, -1, sizeof(INT_S)*(s2));
			mapState[0] = 0;
		}
		iso1(s2, s3, t2, t3, &fix_flag, mapState);
		free(mapState); mapState = NULL;
		if(fix_flag){
			break;
		}/*else{
		// init = 0L;
		// filedes(name4, s3, init, t3);
		// }*/
		freedes(s2, &t2);
		freedes(s3, &t3);
		s2 = s3 = 0; 
		t2 = t3 = NULL;
	}


	strcpy(long_name4, "");
	make_filename_ext(long_name4, name4, EXT_DES);
	if(exist(long_name4)){
		//init = 0L;
		//getdes(name4, &s3, &init, &t3);

		remove(long_name4);
	}	

	strcpy(long_name5, "");
	make_filename_ext(long_name5, name5, EXT_DES);
	if(exist(long_name5)){
		remove(long_name5);
	}	

	mark_stop_time();

	if(result == CR_OK){
		strcpy(long_name3, "");
		make_filename_ext(long_name3, name3, EXT_DES);
		if(exist(long_name3)){
			init = 0L;
			getdes(name3, &s1, &init, &t1);
		
			sup_rel_coobs_makeit(s1,t1, null_flag, P_num, null_par, image_par);
		}
	}else{
		quit = 1;
	}

FREE_LABEL:   
	free(list);
	free(imagelist);
	freedes(s1,&t1);
	freedes(s2,&t2); 
	free_t_part(P_num, &image_par);
	free_t_part(P_num, &null_par);
	//free_t_part(P_num, &con_par);
	free(null_flag);
}
void sup_rel_coobs_p()
{
	//state_node *t1; INT_S s1;

	//s1 = 0; t1 = NULL;

	sup_rel_coobs_r();
	if(mem_result == 1){
		mem_result = 0;
		OutOfMemoryMsg();
		user_pause();
	}
	else{
		if(!quit){
			user_pause();
		}    
	}
	echo_free();
}

/////////////////////////////////////////////////////////
// Computing the supremal relatively observable sublanguage by generator-based or language-based algorithm
void ext_supobs_header(INT_S option)
{
	printw("SUPROBS"); println();
	println();
	if(option == 1){
		printw("DES4 = TRSUPROBS (DES1, DES2, DES3, NULL/IMAGE/IMAGE_DES)"); println();
	}else if(option == 2){
		printw("DES4 = LBSUPROBS (DES1, DES2, DES3, NULL/IMAGE/IMAGE_DES)"); println();
	}else{
		printw("DES4 = SUPROBS (DES1, DES2, DES3, NULL/IMAGE/IMAGE_DES)"); println();
	}
	
	println();
}

void ext_suprobs_makeit(INT_S s, state_node *t, INT_S  null_flag, INT_T s_list, INT_T *list, INT_T s_imagelist, INT_T *imagelist, INT_T s_contr_list, INT_T * contr_list, INT_S alg_flag)
{
	FILE* out;
	INT_S i;
	//    INT_OS   offset;

	/*Write to a tempory file*/
	out = fopen("tmp.$$$","w");
	if(out == NULL) return;

	if(alg_flag == 1){
		fprintf(out, "%s = TRsuprobs(%s,%s,%s,", name4, name1, name2, name3);
	}else if(alg_flag == 2){
		fprintf(out, "%s = LBsuprobs(%s,%s,%s,", name4, name1, name2, name3);
	}else{
		// do nothing
	}

	fprintf(out, "Controllable events[");
	for (i=0; i < s_contr_list; i++) {
		fprintf(out, "%d", contr_list[i]);
		if (i+1 < s_contr_list)
			fprintf(out, ",");
	}
	fprintf(out, "],");

	if ( null_flag == 1)
	{
		fprintf(out, "Null[");
		for (i=0; i < s_list; i++) {
			fprintf(out, "%d", list[i]);
			if (i+1 < s_list)
				fprintf(out, ",");
		}
		fprintf(out, "]");
	}
	else if( null_flag == 2)
	{
		fprintf(out, "Image[");
		for (i=0; i < s_imagelist; i++) {
			fprintf(out, "%d", imagelist[i]);
			if (i+1 < s_imagelist)
				fprintf(out, ",");
		}
		fprintf(out, "]");
	}else{
		fprintf(out, "%s", imagename);
	}
	fprintf(out, ")");
	fprintf(out, "  (%ld,%ld)", s, count_tran(t, s));
	appendTime(out, (INT_OS)strlen(name4) + 3);
	fprintf(out,"\n\n");
	fclose(out);

	mergeChop((INT_OS)strlen(name4) + 3);

}
void ext_suprobs_r()
{
	INT_T *list, slist, *imagelist, s_imagelist, *contr_list, s_contr_list;
	INT_S  null_flag;
	INT_S      init;
	char       ch;
	INT_OS        result; 
	INT_OS mode, mark_flag, alg_flag;

	state_node *t1, *t2;
	INT_S s1, s2;

	list = imagelist = contr_list = NULL;
	slist = s_imagelist = s_contr_list = 0;
	s1 = s2 = 0;
	t1 = t2 = NULL;
	result = 0;

	clear();
	ext_supobs_header(0);
	esc_footer();
	refresh();

	println();
	printw("1. Original transition-removing algorithm");println();
	println();
	printw("2. New language-based algorithm"); println();
	println();

	println();
	println();
	printw("Please choose Option 1 or 2 ....  ");

	alg_flag = (INT_OS)readint(&ch, 1, 2);
	if (ch == CEsc)
	{
		quit = true;
		return;
	}

	clear();
	ext_supobs_header(alg_flag);
	refresh(); 

	mode = 2;

	quit = getname("Enter name of plant generator DES1 .................. ", EXT_DES, name1, false);
	if(quit) return;

	quit = getname("Enter name of legal language generator DES2 ......... ", EXT_DES, name2, false);
	if(quit) return;

	quit = getname("Enter name of ambient language generator DES3 ......... ", EXT_DES, name3, false);
	if(quit) return;

	printw("Enter name of supremal"); println();
	quit = getname(" relatively observable sublanguage generator DES4 ... ", EXT_DES, name4, true);
	if(quit) return;

	if(_wherey() > 16){
		clear();
		ext_supobs_header(alg_flag);
		esc_footer();
	}

	mark_flag = 2;
	println();
	printw("Consider marking infomation? (y/*n) ");
    esc_footer();
    refresh();
    ch = read_key();
    if (ch == CEsc) {
        quit = true;
        return;
    }
    if (ch != CEnter) {
        printw("%c", ch);
    }
    if ( (ch == 'y') || (ch == 'Y') ) {
        mark_flag = 1;
    }else{
        mark_flag = 2;
    }
	println();


	println();
	printw("Specify list of controllable events? (y/*n) ");
    esc_footer();
    refresh();
    ch = read_key();
    if (ch == CEsc) {
        quit = true;
        return;
    }
    if (ch != CEnter) {
        printw("%c", ch);
    }
    if ( (ch == 'y') || (ch == 'Y') ) {
        mode = 1;
    }else{
        mode = 2;
    }

	if(mode == 1){
		println();
		printw("Enter list of controllable events:"); println();
		println();		
		ext_get_conlist(&s_contr_list, &contr_list);
		if(quit) goto LABEL;
	}

	if(_wherey() > 12){
		clear();
		ext_supobs_header(alg_flag);
		esc_footer();
	}
	get_imagelist(&s_imagelist, &imagelist, &slist, &list, &null_flag,7);
	if(quit) goto LABEL;

	if(_wherey() > 12){
		clear();
		ext_supobs_header(alg_flag);
		esc_footer();
	}

	move(22,0); clrtoeol();
	move(23,0); clrtoeol();
	printw("Processing:  Please wait... ");
	refresh();   


	mark_start_time();

	init = 0L;
	if(getdes(name1, &s1, &init, &t1) == false){
		quit = true;
		goto LABEL;
	}    

	if(mode == 2)
	{
		gentranlist(s1,t1,&s_contr_list,&contr_list);
	}
	if (null_flag == 1)
	{
		gen_complement_list(t1, s1,
			list, slist,  
			&imagelist, &s_imagelist);
	}
	else
	{
		gen_complement_list(t1, s1,
			imagelist, s_imagelist,
			&list, &slist);
	}
	freedes(s1,&t1);
	s1 = 0; t1 = NULL;

	/*the main program of checking observability*/  
	if(alg_flag == 1){
		result = transition_suprobs_proc(name4, name1, name2, name3, s_contr_list, contr_list, slist, list, s_imagelist, imagelist, mark_flag);
	}else if(alg_flag == 2){
		result = language_suprobs_proc(name4, name1, name2, name3, s_contr_list, contr_list, slist, list, s_imagelist, imagelist, mark_flag);
	}else
	{
		// do nothing
	}

	mark_stop_time();

	if(result == CR_OK){
		strcpy(long_name4, "");
		make_filename_ext(long_name4, name4, EXT_DES);
		if(exist(long_name4)){
			init = 0L;
			getdes(name4, &s1, &init, &t1);

			ext_suprobs_makeit(s1,t1, null_flag, slist, list,s_imagelist, imagelist, s_contr_list, contr_list, alg_flag);
		}
	}else{
		quit = 1;
	}

LABEL:   
	free(list);
	free(imagelist);
	free(contr_list);
	freedes(s1,&t1);
	freedes(s2,&t2); 
}
void ext_suprobs_p()
{
	ext_suprobs_r();
	if(mem_result == 1){
		mem_result = 0;
		OutOfMemoryMsg();
		user_pause();
	}
	else{
		if(!quit){
			user_pause();
		}    
	}
	echo_free();
}
/////////////////////////////////////////////////////////
//Construct supervisor under partial observation
void synsupobs_header()
{
	printw("UNCERTAINTYSET"); println();
	println();
	printw("DES2 = UNCERTAINTYSET (DES1, NULL/IMAGE/IMAGE_DES)"); println();
	println();
}
void synsupobs_makeit(INT_S s, state_node *t, INT_S  null_flag, INT_T s_list, INT_T *list, INT_T s_imagelist, INT_T *imagelist)
{
	FILE* out;
	INT_S i;
	//    INT_OS   offset;

	/*Write to a tempory file*/
	out = fopen("tmp.$$$","w");
	if(out == NULL) return;

	fprintf(out, "%s = Uncertaintyset(%s,", name2, name1);

	/*fprintf(out, "Controllable events[");
	for (i=0; i < s_contr_list; i++) {
		fprintf(out, "%d", contr_list[i]);
		if (i+1 < s_contr_list)
			fprintf(out, ",");
	}
	fprintf(out, "],");*/

	if ( null_flag == 1)
	{
		fprintf(out, "Null[");
		for (i=0; i < s_list; i++) {
			fprintf(out, "%d", list[i]);
			if (i+1 < s_list)
				fprintf(out, ",");
		}
		fprintf(out, "]");
	}
	else if( null_flag == 2)
	{
		fprintf(out, "Image[");
		for (i=0; i < s_imagelist; i++) {
			fprintf(out, "%d", imagelist[i]);
			if (i+1 < s_imagelist)
				fprintf(out, ",");
		}
		fprintf(out, "]");
	}else{
		fprintf(out, "%s", imagename);
	}
	fprintf(out, ")");
	fprintf(out, "  (%ld,%ld)", s, count_tran(t, s));
	appendTime(out, (INT_OS)strlen(name2) + 3);
	fprintf(out,"\n\n");
	fclose(out);

	mergeChop((INT_OS)strlen(name2) + 3);

}
void synsupobs_r()
{
	INT_T *list, slist, *imagelist, s_imagelist, *contr_list, s_contr_list;
	INT_S  null_flag;
	INT_S      init;
//	char       ch;
	INT_OS        result; 
	INT_OS mode;

	state_node *t1, *t2;
	INT_S s1, s2;
	state_map * macrosets; INT_S s_macrosets, ss, ee;
	INT_S  i, j, k;
	INT_B ok;

	list = imagelist = contr_list = NULL;
	slist = s_imagelist = s_contr_list = 0;
	s1 = s2 = 0;
	t1 = t2 = NULL;
	s_macrosets = 0; macrosets = NULL;
	result = 0;

	clear();
	synsupobs_header();
	refresh(); 

	mode = 2;

	quit = getname("Enter name of DES1 .................. ", EXT_DES, name1, false);
	if(quit) return;

	quit = getname("Enter name of DES2 .................. ", EXT_DES, name2, true);
	if(quit) return;

	if(_wherey() > 16){
		clear();
		synsupobs_header();
		esc_footer();
	}

	get_imagelist(&s_imagelist, &imagelist, &slist, &list, &null_flag,7);
	if(quit) goto LABEL;

	if(_wherey() > 12){
		clear();
		synsupobs_header();
		esc_footer();
	}

	move(22,0); clrtoeol();
	move(23,0); clrtoeol();
	printw("Processing:  Please wait... ");
	refresh();   


	mark_start_time();

	init = 0L;
	if(getdes(name1, &s1, &init, &t1) == false){
		quit = true;
		goto LABEL;
	}    

	if (null_flag == 1)
	{
		gen_complement_list(t1, s1,
			list, slist,  
			&imagelist, &s_imagelist);
	}
	else
	{
		gen_complement_list(t1, s1,
			imagelist, s_imagelist,
			&list, &slist);
	}

	export_copy_des(&s2, &t2, s1, t1);
	obs_project(&s2, &t2, slist, list, &s_macrosets, &macrosets);
	for(i = 0; i < s_macrosets; i ++){
		for(j = 0; j < macrosets[i].numelts; j ++){
			ss = macrosets[i].next[j];
			for(k = 0; k < t1[ss].numelts; k ++){
				ee = t1[ss].next[k].data1;
				if(inlist((INT_T)ee, list, slist)){
					addordlist1((INT_T)ee,i,&t2[i].next, t2[i].numelts,&ok);
					if(ok) t2[i].numelts ++;
				}
			}
		}
	}

	filedes(name2, s2, 0, t2);
	freedes(s2, &t2); freedes(s1, &t1); s1 = 0; t1 = NULL;

	mark_stop_time();

	if(result == CR_OK){
		strcpy(long_name2, "");
		make_filename_ext(long_name2, name2, EXT_DES);
		if(exist(long_name2)){
			init = 0L;
			getdes(name2, &s1, &init, &t1);

			synsupobs_makeit(s1,t1, null_flag, slist, list,s_imagelist, imagelist);
		}
	}else{
		quit = 1;
	}

LABEL:   
	free(list);
	free(imagelist);
	//free(contr_list);
	freedes(s1,&t1);
	freedes(s2,&t2); 
	free_map(s_macrosets, &macrosets);
}
void synsupobs_p()
{

	synsupobs_r();
	if(mem_result == 1){
		mem_result = 0;
		OutOfMemoryMsg();
		user_pause();
	}
	else{
		if(!quit){
			user_pause();
		}    
	}
	echo_free();
}
/////////////////////////////////////////////////////////
//Relabel the states of a DES
void statemap_header()
{
   printw("STATEMAP"); println();
   println();
   printw("DES2 = STATEMAP (DES1, STATE_MAP_PAIR_LIST)"); println();
   println();
}

void statemap_r(state_node **t1,
                INT_S *s1,
                state_node **t2,
                INT_S *s2,
                state_pair **sp,
                INT_S *s_sp)
{
   INT_S  init;
   char   ch;
   INT_S i, j;
   INT_B  ok;
   INT_T *list;
   INT_T s_list;
   INT_OS   row, col, a;
   INT_OS   result;
   state_node *t3;
   INT_S s3;

   list = NULL; s_list = 0;
   s3 = 0; t3 = NULL;

   clear();
   statemap_header();
   quit = getname("Enter name of DES1 ....  ", EXT_DES, name1, false);
   if (quit) return;

   quit = getname("Enter name of DES2 ....  ", EXT_DES, name2, true);
   if (quit) return;

   init = 0L;
   if(getdes(name1, &s3, &init, &t3) == false){
	   quit = 1;
	   return;
   }

   clear();
   statemap_header();
   println();
   esc_footer();

   printw("Enter list of state map pairs."); println();
   printw("Press <Enter> after each element and quit with -1:"); println();
   println();
   i = 0;
   while (i != -1) {
      if (_wherey() > 21) {
/*         clear();
         eventmap_header();
         printw("Continue to enter list of event label pairs."); println();
         printw("Press <Enter> after each element and quit with -1:"); println();
         println();
         esc_footer();
 */
         col = _wherex(); row = _wherey()-1;
         move(23,0); clrtoeol();
         move(24,0);
         scroll_line();

         for (a=0; a < 7; a++) {
            move(a,0); clrtoeol();
         }

         move(0,0);
         statemap_header();
         printw("Continue to enter list of state map pairs."); println();
         printw("Press <Enter> after each element and quit with -1:"); println();
         println();
         esc_footer();
         move(row, col);
      }

      printw("Old value:  ");
      i = (INT_S) readint(&ch, -1, s3 - 1);
      if (ch == CEsc) {
          quit = true;
          return;
      }
      if (i == -1) break;

      tab(25);
      printw("New value:  ");
      j = (INT_S) readint(&ch, -1, s3 - 1);
      if (ch == CEsc) {
          quit = true;
          return;
      }
      if (j == -1) break;

      addstatepair(i, j, sp, *s_sp, &ok);
      if (ok) (*s_sp)++;

      println();
   }

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   /* Pass to command line version of this program */
   mark_start_time();
   result = statemap_proc(name2, name1, *s_sp, *sp);   
   mark_stop_time();

   if (result == CR_OK) {
      strcpy(long_name2, "");
      make_filename_ext(long_name2, name2, EXT_DES);   
      if (exist(long_name2))
      {
         init = 0;
         getdes(name2, s2, &init, t2);           
      }      
      else
         quit = true;
   } else {
         quit = true;
   }
}
void statemap_makeit(state_node *t3, INT_S s3, state_pair* sp, INT_S s_sp)
{
	FILE* out;
	INT_S i;

	/* Write to a tempory file */
	out = fopen("tmp.$$$", "w");
	if (out == NULL) return;
	fprintf(out, "%s = Statemap(%s,[", name2, name1);
	for (i=0; i < s_sp; i++) {
		fprintf(out, "[%ld,%ld]", sp[i].data1, sp[i].data2);
		if (i+1 < s_sp)
			fprintf(out, ",");
	}
	fprintf(out, "])");
	fprintf(out, "  (%ld,%ld)", s3, count_tran(t3, s3));
	appendTime(out, (INT_OS)strlen(name2)+3);
	fprintf(out, "\n\n");
	fclose(out);

	/* Merge file into MAKEIT.TXT */
	mergeChop((INT_OS)strlen(name2)+3);

}

void statemap_p()
{
   state_node *t1, *t2;
   INT_S s1, s2;
   state_pair *sp;
   INT_S s_sp;

   t1 = t2 = NULL;
   s1 = s2 = 0;
   s_sp = 0; sp = NULL;

   statemap_r(&t1, &s1, &t2, &s2, &sp, &s_sp);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        statemap_makeit(t2, s2, sp, s_sp);
        user_pause();
      }
   }

   echo_free();
   free(sp);
   freedes(s1, &t1);
   freedes(s2, &t2);
}
///////////////////////////////////////////////////////////////////////
// suprr : generalization of normality definition by relabel function

void suprr_header()
{
	printw("SUPRR"); println();
	println();
	printw("DES3 = SUPRR (DES1, DES2, EVENT_MAP_PAIR_LIST)"); println();
	println();
}

void suprr_r(state_node **t1,
               INT_S *s1,
               state_node **t2,
               INT_S *s2,
               state_node **t3,
               INT_S *s3,
               state_pair **sp,
			   INT_S *s_sp)
{
   INT_S  init;
   char   ch;
 //  short  sign_i;
   INT_S  i, j;
   INT_OS    row, col, a;
   INT_B  ok;
   INT_OS    result;

   clear();
   suprr_header();
   refresh();

   quit = getname("Enter name of plant generator DES1 .............  ",
                  EXT_DES, name1, false);
   if (quit) return;

   quit = getname("Enter name of legal language generator DES2 ....  ",
	   EXT_DES, name2, false);
   if (quit) return;

   quit = getname("Enter name of DES3 ....  ",
                   EXT_DES, name3, true);
   if (quit) return;

   clear();
   suprr_header();
   println();
   esc_footer();

   printw("Enter list of event label pairs."); println();
   printw("Press <Enter> after each element and quit with -1:"); println();
   println();
   i = 0;
   while (i != -1) {
      if (_wherey() > 21) {
         col = _wherex(); row = _wherey()-1;
         move(23,0); clrtoeol();
         move(24,0);
         scroll_line();

         for (a=0; a < 7; a++) {
            move(a,0); clrtoeol();
         }

         move(0,0);
         suprr_header();
         printw("Continue to enter list of event label pairs."); println();
         printw("Press <Enter> after each element and quit with -1:"); println();
         println();
         esc_footer();
         move(row, col);
      }

      printw("Old value:  ");
      i = (INT_S) readint_and_e(&ch, -1, MAX_TRANSITIONS);
      if (ch == CEsc) {
          quit = true;
          return;
      }
      if (i == -1) break;

      tab(25);
      printw("New value:  ");
      j = (INT_S) readint_and_e(&ch, -1, MAX_TRANSITIONS);
      if (ch == CEsc) {
          quit = true;
          return;
      }
      if (j == -1) break;

      addstatepair(i, j, sp, *s_sp, &ok);
      if (ok) (*s_sp)++;

      println();
   }
   
   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   /* Pass to command line version of this program */
   mark_start_time();
   result = suprr_proc(name3, name1, name2, *s_sp, *sp);
   mark_stop_time();

   if (result == CR_OK) {
      strcpy(long_name3, "");
      make_filename_ext(long_name3, name3, EXT_DES);   
      if (exist(long_name3))
      {
         init = 0;
         getdes(name3, s3, &init, t3);           
      }      
      else
         quit = true;
   } else {
      if (result == CR_OUT_OF_MEMORY)
         mem_result = 1;
      else
         quit = true;
   }
}

void suprr_makeit(state_node *t3, INT_S s3,	state_pair *sp, INT_S s_sp)
{
	FILE* out;
	INT_S i;

	/* Write to a tempory file */
	out = fopen("tmp.$$$", "w");
	if (out == NULL) return;
	fprintf(out, "%s = SupRR(%s,%s,", name3, name1, name2);

	for (i=0; i < s_sp; i++) {
		fprintf(out, "[%ld,%ld]", sp[i].data1, sp[i].data2);
		if (i+1 < s_sp)
			fprintf(out, ",");
	}
	fprintf(out, "])");

	fprintf(out, "  (%ld,%ld)", s3, count_tran(t3, s3));
	appendTime(out, (INT_OS)strlen(name3)+3);
	fprintf(out, "\n\n");
	fclose(out);

	/* Merge file into MAKEIT.TXT */
	mergeChop((INT_OS)strlen(name3)+3);
}

void suprr_p()
{
	state_node *t1, *t2, *t3;
	INT_S s1, s2, s3;
	INT_S s_sp;
	state_pair *sp;

	t1 = t2 = t3 = NULL;
	s1 = s2 = s3 = 0;
	s_sp = 0; sp = NULL;

	suprr_r(&t1, &s1, &t2, &s2, &t3, &s3, &sp, &s_sp);

	if (mem_result == 1) {
		mem_result = 0;
		OutOfMemoryMsg();
		user_pause();
	} else {
		if (!quit) {
			suprr_makeit(t3, s3, sp, s_sp);
			user_pause();
		}
	}

	echo_free();
	freedes(s1, &t1);
	freedes(s2, &t2);
	freedes(s3, &t3);
	free(sp);
}

/////////////////////////////////////////////////////////
//Relabel the states of a DES
void inv_relabel_header()
{
   printw("INVRELABEL"); println();
   println();
   printw("DES2 = INVRELABEL (DES1, RELABEL_EVENT_MAP)"); println();
   println();
}

void inv_relabel_r(state_node **t1,
                INT_S *s1,
                state_map **sm,
                INT_S *s_sm)
{
   INT_S  init;
   char   ch;
   INT_S i, j, k;
   INT_B  ok;
   INT_S *list;
   INT_S s_list;
   INT_OS   row, col, a;
   INT_OS   result;

   list = NULL; s_list = 0;

   clear();
   inv_relabel_header();
   quit = getname("Enter name of DES1 ....  ", EXT_DES, name1, false);
   if (quit) return;

   quit = getname("Enter name of DES2 ....  ", EXT_DES, name2, true);
   if (quit) return;

   clear();
   inv_relabel_header();
   println();
   esc_footer();

   printw("Enter list of event label maps."); println();
   //printw("Press <Enter> after each element and quit with -1:"); println();
   println();

   i = 0;
   while (i != -1) {
      if (_wherey() > 21) {
         col = _wherex(); row = _wherey()-1;
         move(23,0); clrtoeol();
         move(24,0);
         scroll_line();

         for (a=0; a < 7; a++) {
            move(a,0); clrtoeol();
         }

         move(0,0);
         inv_relabel_header();
         printw("Continue to enter list of event label maps."); println();
        // printw("Press <Enter> after each element and quit with -1:"); println();
         println();
         esc_footer();
         move(row, col);
      }

      printw("Enter old event to be relabeled and quit with -1:  ");
      i = (INT_S) readint_and_e(&ch, -1, MAX_TRANSITIONS);
      if (ch == CEsc) {
          quit = true;
          return;
      }
      if (i == -1) break;

	  println(); 
	  println();

      //tab(25);
      //printw("New event list:  ");

	  printw("Enter list of new event labels to be mapped to;"); println();
	  printw("terminate list with -1."); println();
	  println();  tab(5);
	  j = 0;
	  while (j != -1) {
		  col = _wherex();
		  row = _wherey();
		  if (col >= 75) {
			  move(row+1,5);
			  col = 5;
			  row++;
		  }
		  if (_wherey() > 21) {
			  clear();
			  inv_relabel_header();
			  esc_footer();
			  printw("Enter list of new event labels to be mapped to;"); println();
			  printw("terminate list with -1."); println();
			  println(); tab(5);
			  esc_footer();
			  col = _wherex();
			  row = _wherey();
		  }

		  j = (INT_S) readint_and_e(&ch, -1, MAX_TRANSITIONS);
		  if (ch == CEsc) {
			  quit = true;
			  return;
		  }
		  if (j != -1) {
			  addstatelist(j, &list, s_list, &ok);
			  if (ok) (s_list)++;
		  }
		  move(row, col+7);
	  }

	  for(k = 0; k < s_list; k ++){
		  addstatemap(i,list[k], sm, *s_sm, &ok);
		  if(ok) (*s_sm) ++;
	  }

	  println(); println();

	  if (_wherey() > 21) {
		  clear();
		  inv_relabel_header();
		  esc_footer();
	  }

	  printw("Continue to enter new event maps? (*y/n) ");
	  esc_footer();
	  refresh();
	  ch = read_key();
	  if (ch == CEsc) {
		  quit = true;
		  return;
	  }
	  if (ch != CEnter) {
		  printw("%c", ch);
	  }
	  if ( (ch == 'n') || (ch == 'N') ) {
		  break;
	  }

      println();
	  println();
   }


   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   /* Pass to command line version of this program */
   mark_start_time();
   result = inv_relabel_proc(name2, name1, *s_sm, *sm);   
   mark_stop_time();

   if (result == CR_OK) {
      strcpy(long_name2, "");
      make_filename_ext(long_name2, name2, EXT_DES);   
      if (exist(long_name2))
      {
         init = 0;
         getdes(name2, s1, &init, t1);           
      }      
      else
         quit = true;
   } else {
         quit = true;
   }
}
void inv_relabel_makeit(state_node *t3, INT_S s3, state_map* sm, INT_S s_sm)
{
	FILE* out;
	INT_S i,j;

	/* Write to a tempory file */
	out = fopen("tmp.$$$", "w");
	if (out == NULL) return;
	fprintf(out, "%s = InvRelabel(%s,[", name2, name1);
	for (i=0; i < s_sm; i++) {
		fprintf(out, "[%ld,(", sm[i].state);
		for (j = 0; j < sm[i].numelts; j ++){
			fprintf(out, "%ld", sm[i].next[j]);
			if(j < sm[i].numelts - 1)
				fprintf(out, ",");
		}
		fprintf(out, ")]");
		if (i+1 < s_sm)
			fprintf(out, ",");
	}
	fprintf(out, "])");
	fprintf(out, "  (%ld,%ld)", s3, count_tran(t3, s3));
	appendTime(out, (INT_OS)strlen(name2)+3);
	fprintf(out, "\n\n");
	fclose(out);

	/* Merge file into MAKEIT.TXT */
	mergeChop((INT_OS)strlen(name2)+3);

}

void inv_relabel_p()
{
   state_node *t1;
   INT_S s1;
   state_map *sm;
   INT_S s_sm;

   t1 = NULL;
   s1 = 0;
   s_sm = 0; sm = NULL;

   inv_relabel_r(&t1, &s1, &sm, &s_sm);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        inv_relabel_makeit(t1, s1, sm, s_sm);
        user_pause();
      }
   }

   echo_free();
   free_map(s_sm, &sm);
   freedes(s1, &t1);
}