#ifndef _EXT_PROC_H
#define _EXT_PROC_H

#include "des_data.h"

#ifdef __cplusplus
extern "C" {
#endif

extern void path2block_p();
extern void execute_p();
extern void ehmeet_p();
extern void supcon_comb_p();
extern void ehsync_p();
extern void subdes_p();
extern void rendez_p();
extern void exlocalize_p();
extern void splitevent_p();
extern void augment_p();
extern void syncondat_p();
extern void eq_obs_p();
extern void attach_p();
extern void supqc_cc_p();
extern void plain_project_p();
extern void project_f_p();
extern void rel_observ_p();
extern void path2deadlock_p();
extern void ext_obs_p();
extern void ext_obs_p1();
extern void ext_occ_p();
extern void supqc_lcc_p();
extern void sup_rel_coobs_p();
extern void ext_suprobs_p();
extern void synsupobs_p();
extern void statemap_p();
extern void suprr_p();
extern void inv_relabel_p();

#ifdef __cplusplus
}
#endif

#endif
