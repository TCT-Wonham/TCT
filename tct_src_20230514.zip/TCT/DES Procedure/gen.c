/* Program to generate the example files */

#include <stdio.h>
#include <string.h>
#include "des_data.h"
#include "setup.h"

void a_main()
{
   INT_S s;         /* Size of DES */
   state_node *t;
   INT_S i;         /* Counter */
   INT_B  ok;
   char name[100];

   /* For A(n) = () */
   printf("Enter the number of states: ");
   scanf("%ld", &s);
   printf("%ld\n", s);

   t = newdes(s);

   t[0].marked = true;

   /* Transitions */
   addordlist1(0,0,&t[0].next,t[0].numelts,&ok);
   if (ok) t[0].numelts++;

   addordlist1(1,0,&t[0].next,t[0].numelts,&ok);
   if (ok) t[0].numelts++;

   for (i=1; i < s; i++) {
     if ((i % 1000) == 0)
        printf("%ld\n", i);
     addordlist1(0,i-1,&t[i].next,t[i].numelts,&ok);
     if (ok) t[i].numelts++;

     addordlist1(1,i,&t[i].next,t[i].numelts,&ok);
     if (ok) t[i].numelts++;
   }

   /* Save it into a file */
   strcpy(name, "An");
   filedes(name, s, 0L, t);
}

/* To generate B() */
void b_main()
{
   /* The number of states must be even */

   INT_S s;         /* Size of DES */
   state_node *t;
   INT_S i;         /* Counter */
   INT_B  ok;
   char name[100];

   /* For A(n) = () */
   printf("Enter the number of states: ");
   scanf("%ld", &s);

   t = newdes(s);

   for (i=0; i < s/2; i++) {
      t[i].marked = true;
   }

   /* Transitions */
   for (i=0; i < s/4; i++) {
     addordlist1(0, s/2 + 2*i ,&t[i].next,t[i].numelts, &ok);
     printf("aa %d %d %d\n", i, 0, s/2 + 2*i);
     if (ok) t[i].numelts++;

     addordlist1(1, s/2 + 2*i ,&t[i].next,t[i].numelts, &ok);
     printf("aa %d %d %d\n", i, 1, s/2 + 2*i);
     if (ok) t[i].numelts++;
   }

   for (i=0; i < s/4; i++) {
     addordlist1(0, 2*i, &t[s/4+i].next, t[s/4+i].numelts, &ok);
     printf("bb %d %d %d\n", s/4+i, 0, 2*i);
     if (ok) t[i].numelts++;

     addordlist1(1, 2*i, &t[s/4+i].next, t[s/4+i].numelts, &ok);
     printf("bb %d %d %d\n", s/4+i, 1, 2*i);
     if (ok) t[i].numelts++;
   }

   for (i=s/2; i < s; i++) {
     addordlist1(0, 2*i, &t[s/2+i].next, t[s/2+i].numelts, &ok);
     printf("cc %d %d %d\n", s/2+i, 0, 2*i);
     if (ok) t[i].numelts++;

     addordlist1(1, 2*i, &t[s/2+i].next, t[s/2+i].numelts, &ok);
     printf("cc %d %d %d\n", s/2+i, 1, 2*i);
     if (ok) t[i].numelts++;
   }

   strcpy(name, "Bn");
   filedes(name, s, 0L, t);
}

void c_main()
{
   INT_S s;         /* Size of DES */
   state_node *t;
   INT_S i;         /* Counter */
   INT_B  ok;
   char name[100];

   /* For A(n) = () */
   printf("Enter the number of states: ");
   scanf("%ld", &s);
   printf("%ld\n", s);

   t = newdes(s);

   for (i=0; i < s-1; i++) {
     if ((i % 1000) == 0)
        printf("%ld\n", i);
     addordlist1(0,i+1,&t[i].next,t[i].numelts,&ok);
     if (ok) t[i].numelts++;

     addordlist1(1,i+1,&t[i].next,t[i].numelts,&ok);
     if (ok) t[i].numelts++;
   }

   /* Last state self-looped */
/*   i = s-1;
   addordlist1(0,i,&t[i].next, t[i].numelts,&ok);
   if (ok) t[i].numelts++;

   addordlist1(1,i,&t[i].next, t[i].numelts,&ok);
   if (ok) t[i].numelts++;
*/
   /* Save it into a file */
   strcpy(name, "Cn");
   filedes(name, s, 0L, t);
}
