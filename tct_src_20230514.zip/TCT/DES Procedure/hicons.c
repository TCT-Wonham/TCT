#include <stdio.h>
#include <stdlib.h>
#include "hicons.h"
#include "outcon.h"
#include "des_supp.h"
#include "des_data.h"
#include "mymalloc.h"
#include "setup.h"
#include "curses.h"

#ifdef __cplusplus
extern "C" {
#endif

/* static INT_V max_vocal; */
static INT_V min_vocal;
static INT_B  error_no_more_vocal;
static INT_OS version;

/* Determine whether "blocking_set" is a subset of "dedicated_set" */
INT_B  subset(INT_S* blocking_set, INT_S* dedicated_set) {
   INT_S i,j;
   INT_B  is_subset;
   INT_B  blockPresent;

   is_subset = true;

   if (blocking_set[0] == -1)
     return false;

   i = 0;
   while ( (blocking_set[i] != -1) && (is_subset == true) ) {
      j = 0;
      blockPresent = false;
      while ( (dedicated_set[j] != -1) && (blockPresent == false) ) {
         if ( blocking_set[i] == dedicated_set[j] ) {
             blockPresent = true;
         } else {
             j++;
         }
      }

      if (blockPresent == false) {
         is_subset = false;
      }
      i++;
   }

   return is_subset;
}

/* Vocalize silent state with next vocal state output */
/* void vocalize(state_node **t, INT_S i) {
   max_vocal++;
   (*t)[i].vocal = max_vocal;
}
*/

void vocalize(state_node **t, INT_S i, INT_B  *freelist) {
   /* Vocalize silent state with next vocal state output */
   INT_V v;

   if (version == 1)
   {
       (*t)[i].vocal = min_vocal*10+1;
       return;
   }

   (*t)[i].vocal = min_vocal*10+1;

   /* Find next free vocal in list */
   freelist[min_vocal] = false;
   for (v= (min_vocal+1); v < 100; v++) {
     if (freelist[v] == true) {
       min_vocal = v;
       break;
     }
   }

   if (v >= 100) {
      error_no_more_vocal = true;
   }
}

static INT_B  uncont(INT_T e)
{
   return ((e % 2) == 0);  /* Even */
}

/* Determine if the state is a vocal state */
INT_B  is_vocal_state(state_node *t, INT_S i)
{
    return (t[i].vocal > 0);
}

INT_B  agent(state_node** t, INT_S *s, INT_S i, tran_node *tr)
{
   INT_S ii, jj;
   INT_T ee, j;
   INT_B  agentFlag;
   INT_B  ok;
   t_stack ts;

   if (uncont(tr->data1)) {
      return false;
   } else if (is_vocal_state(*t, tr->data2)) {
      return true;
   } else {
      pstack_Init(&ts);

      /* Set "reach" field of state to false */
      for (i=0; i < *s; i++)
         (*t)[i].reached = false;

      jj = tr->data2;
      (*t)[jj].reached = true;
      agentFlag = false;
      j = 0;
      do {
          if (j < (*t)[jj].numelts) {
             ee = (*t)[jj].next[j].data1;
             ii = (*t)[jj].next[j].data2;
             if (uncont(ee) && !(*t)[ii].reached) {
                 if (is_vocal_state(*t,ii)) {
                     agentFlag = true;
                 } else {
                     pstack_Push(&ts, j, jj);
                     (*t)[ii].reached = true;
                     jj = ii;
                     j = 0;
                 }
             } else {
                 j++;
             }
          } else {
             if (! pstack_IsEmpty(&ts)) {
                pstack_Pop(&ts, &j, &jj, &ok);
                j++;
             }
          }
      } while ( ((j < (*t)[jj].numelts) || !pstack_IsEmpty(&ts))
                && (agentFlag != true) );
      pstack_Done(&ts);
   }

   return agentFlag;
}

/* Get the blocking set for the state and event.  See notes
   for details of the definitions of a blocking set. */
void getblocking_set(state_node** t, INT_S *s,
                     INT_S i, tran_node *tr, INT_S *blocking_set)
{
   INT_S nBlockingSet;  /* Number of elements in blocking set */
   INT_B  *ra;
   INT_S ii, jj;
   INT_T j;
   INT_B  ok;
   t_stack ts;

   nBlockingSet = 0;
   if ( uncont(tr->data1) ) {
   } else if (is_vocal_state(*t, tr->data2)) {
      blocking_set[nBlockingSet] = tr->data2;
      nBlockingSet++;
   } else {
      pstack_Init(&ts);

      /* Allocate memory for reachability array */
      ra = (INT_B *) CALLOC(*s, sizeof(INT_B )); /* Set values to false */
      if (ra == NULL) {
        pstack_Done(&ts);
        mem_result = 1;
        return;
      }

      ii = tr->data2;
      (*t)[ii].reached = true;
      j = 0;
      do {
        if (j < (*t)[ii].numelts) {
           jj = (*t)[ii].next[j].data2;
           if (!ra[jj]) {
              if (is_vocal_state(*t, jj)) {
                  blocking_set[nBlockingSet] = jj;
                  nBlockingSet++;
                  ra[jj] = true;
                  j++;
              } else {
                  pstack_Push(&ts,j,ii);
                  ra[jj] = true;
                  j = 0;
                  ii = jj;
              }
           } else {
              j++;
           }
        } else {
           if (!pstack_IsEmpty(&ts)) {
              pstack_Pop(&ts,&j,&ii,&ok);
              j++;
           }
        }
      } while ( (j < (*t)[ii].numelts) || !pstack_IsEmpty(&ts));

      free(ra);
      pstack_Done(&ts);
   }

   blocking_set[nBlockingSet] = -1;
}

/* Get the dedicated set for the "state".  See notes for more details */
void getdedicated_set(state_node **t, INT_S *s,
                      INT_S i, INT_S *dedicated_set)
{
   INT_S nDedicatedSet;
   INT_S *bs;
   INT_B  *ra, isAgent, ok, isUnary, dedicatedFlag;
   INT_S size;
   t_stack ts;
   INT_T j, ee, eee;
   INT_S ii, jj, iii;
   INT_S s_index;

   bs = NULL;
   ra = NULL;
   nDedicatedSet = 0;
   size = *s;

   pstack_Init(&ts);

   /* Allocate local memory */
   bs = (INT_S*)   CALLOC(size+1, sizeof(INT_S));
   ra = (INT_B *) CALLOC(size, sizeof(INT_B ));  /* Set all values to false */

   if ( (bs == NULL) || (ra == NULL) ) {
       mem_result = 1;
       return;
   }

   j = 0;
   jj = i;
   do {
      if (j < (*t)[jj].numelts) {
         ee = (*t)[jj].next[j].data1;
         ii = (*t)[jj].next[j].data2;
         if (! ra[ii]) {
            if (is_vocal_state(*t,ii)) {
                pstack_Push(&ts, j, jj);

                /* Start examining transitions */
                s_index = ts.head_size;
                do {
                   eee = ts.head[s_index-1].data1;
                   iii = ts.head[s_index-1].data2;

                   isAgent = agent(t,s,0,&(*t)[iii].next[eee]);
                   getblocking_set(t,s,0,&(*t)[iii].next[eee],bs);

                   if ((bs[1] == -1) && (bs[0] == ii)) {
                      isUnary = true;
                   } else {
                      isUnary = false;
                   }

                   if ( (! isAgent) || isUnary ) {
                      dedicatedFlag = true;
                   } else {
                      dedicatedFlag = false;
                   }
                   s_index--;
                } while ((s_index > 0) && (dedicatedFlag == true));

                /* Include the state if it is a dedicated s.p.s */
                if (dedicatedFlag) {
                    dedicated_set[nDedicatedSet] = ii;
                    nDedicatedSet++;
                    ra[ii] = true;
                }

                pstack_Pop(&ts, &j, &jj, &ok);
                j++;
            } else {
                pstack_Push(&ts, j, jj);
                ra[ii] = true;
                j = 0;
                jj = ii;
            }
         } else {
            j++;
         }
      } else {
         if (!pstack_IsEmpty(&ts)) {
            pstack_Pop(&ts, &j, &jj, &ok);
            j++;
         }
      }
   } while ( (j < (*t)[jj].numelts) || !pstack_IsEmpty(&ts) );

   pstack_Done(&ts);

   /* Free local memory */
   free(bs);
   free(ra);

   dedicated_set[nDedicatedSet] = -1;
}

void hcc(state_node **t1, INT_S *s1)
{
   INT_S *dedicated_set;
   INT_S *blocking_set;
   INT_V temp_vocal;
   INT_S i, size;
   INT_B  flag;
   INT_T j;
   INT_B  in_freevocal[100];
   INT_OS num_hits = 0;

   error_no_more_vocal = false;
   size = *s1;

   /* Allocate memory for 'dedicated_set' and 'blocking_set' */
   dedicated_set = (INT_S*) CALLOC(*s1+1, sizeof(INT_S));
   blocking_set  = (INT_S*) CALLOC(*s1+1, sizeof(INT_S));

   if ( (dedicated_set == NULL) || (blocking_set == NULL) ) {
      mem_result = 1;
      return;
   }

   for (i=0; i < 100; i++)
      in_freevocal[i] = true;   /* All vocal output is available */

   for (i=0; i < *s1; i++) {
      temp_vocal = (*t1)[i].vocal;
      if ( temp_vocal > 0) {
         if ( temp_vocal <= MAX_VOCAL_OUTPUT) {
            in_freevocal[temp_vocal] = false;
         } else {
            temp_vocal = temp_vocal / 10;
            in_freevocal[temp_vocal] = false;
         }
      }
   }

   for (i=10; i < 100; i++) {
      if (in_freevocal[i] == true) {
         min_vocal = (INT_T)i;
         break;
      }
   }

   if (i >= 100) {
      error_no_more_vocal = true;
      return;
   }

   /* Get the maximum vocal state */
/*   max_vocal = 0;
   for (i=0; i < *s1; i++) {
      if ( (*t1)[i].vocal > 0) {
         if ( (*t1)[i].vocal <= MAX_VOCAL_OUTPUT) {
            max_vocal = max(max_vocal, (*t1)[i].vocal);
         } else {
            temp_vocal = (*t1)[i].vocal / 10;
            max_vocal = max(max_vocal, temp_vocal);
         }
      }
   }
*/

   do {
      flag = true;
      for (i=0; i < size; i++) {
         for (j=0; j < (*t1)[i].numelts; j++) {
            if (agent(t1, s1, i, &(*t1)[i].next[j])) {
                getdedicated_set(t1, s1, i, dedicated_set);
                getblocking_set(t1, s1, i, &(*t1)[i].next[j], blocking_set);
                if (! subset(blocking_set, dedicated_set)) {
                   flag = false;  /* agent is inadmissible */
                   vocalize(t1, (*t1)[i].next[j].data2, in_freevocal);
                }

                /* Error - ran out of vocal states to assign */
                if (error_no_more_vocal)
                {
                    free(dedicated_set);
                    free(blocking_set);
                    return;
                }
            }
         }
         
         if (debug_mode) {
            if (num_hits % 10L == 0L) {
               move(23,0); clrtoeol();
               printw("HCC: %ld %ld %ld", size, num_hits, (int) flag);
               refresh();
            }
            num_hits++;
         }
      }
               
   } while (flag == false);   /* All agents are admissible */

   free(dedicated_set);
   free(blocking_set);
}

INT_B  hiconsis_des(state_node** t1, INT_S* s1)
{
   version = 0;        
   outcon_des(t1, s1);
   
   hcc(t1,s1);
   if (error_no_more_vocal == false)
      outcon_des(t1, s1);

   return error_no_more_vocal;
}

INT_B  hiconsis_1_des(state_node** t1, INT_S* s1)
{
   version = 1;      
   outcon_des(t1, s1);
   hcc(t1,s1);
   if (error_no_more_vocal == false)
      outcon_des(t1, s1);
      
   return error_no_more_vocal;      
}        

#ifdef __cplusplus
}
#endif

