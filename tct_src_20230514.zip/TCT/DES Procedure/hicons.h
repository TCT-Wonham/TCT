#ifndef _HICONS_H
#define _HICONS_H

#include "des_data.h"

#ifdef __cplusplus
extern "C" {
#endif

extern INT_B  hiconsis_des(state_node **t1, INT_S *s1);
extern INT_B  hiconsis_1_des(state_node **t1, INT_S *s1);

#ifdef __cplusplus
}
#endif

#endif
