/*
    Program: ISO.
             This is a stand alone program that determines if the
             two DES files are isomorphic.

             The program is limited to the following output:

                isomorphic
                not isomorphic

             Also, the DOS Error level has meaning.

             0 = Is isomophic
             1 = Is not isomophic
             ? = Error running this program.

     Syntax: iso <des1> <des2>

     Designed to run in DOS32 or UNIX.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "des_data.h"
#include "des_proc.h"
#include "setup.h"

static INT_B  is_iso;

/* Remove the extension */
void iso_file_split(char* path, char *name, char *ext) {
   char *ptr;
   INT_P  pos;

   strcpy(name, path);
   ptr = strrchr(name, '.');
   if (ptr == NULL) {   /* No extension */
      ext = NULL;
      return;
   }

   pos = ptr-name;
   name[pos] = '\0';

   strcpy(ext, &(path[pos]));
}

void isom(char *fullname1, char *fullname2) {
   INT_S   *mapState;
   INT_S   init;
   char name1[80], name2[80];
   char ext1[4], ext2[4];

   state_node *t1, *t2;
   INT_S s1, s2;

   t1 = t2 = NULL;
   s1 = s2 = 0;

   iso_file_split(fullname1, name1, ext1);
   iso_file_split(fullname2, name2, ext2);

   init = 0L;
   if (getdes(name1, &s1, &init, &t1) == false) {
      return;
   }

   if (getdes(name2, &s2, &init, &t2) == false) {
      return;
   }

   is_iso = false;

   if ( (strcmp(name1,name2) == 0) || ((s1 == 0) && (s2 == 0)) ) {
     is_iso   = true;
   } else {
     /* Need some memory here - Allocate map state */
     mapState = (INT_S*) calloc(s1, sizeof(INT_S));
     if (mapState == NULL) {
       mem_result = 1;
       return;
     }
     memset(mapState, -1, sizeof(INT_S)*(s1));

     is_iso = true;
     iso1(s1, s2, t1, t2, &is_iso, mapState);
   }

   freedes(s1, &t1);
   freedes(s2, &t2);
}
