#ifndef _OUTCON_H
#define _OUTCON_H

#include "des_data.h"

#ifdef __cplusplus
extern "C" {
#endif

extern void outcon_des(state_node**, INT_S*);

#ifdef __cplusplus
}
#endif

#endif
