/* Convert "ASCII" DES file to 32-bit DES file version
   "ASCII" DES file format:

  <DES name>  # states: <number of states>  state set: 0..<num states-1>  initial state: <init>
  \n
  marker states:    <a list of marker states>
  \n
  vocal states: <"none" or blank>
  <[0,10]>
  \n
  # transitions: <number of transitions>
  \n
  transitions:
  [ <#>, <#>, <#>]
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>
#include <ctype.h>
#include "des_data.h"
#include "setup.h"


   #include <io.h>
   #define EXT_DES   ".DES"
   #define EXT_PDS   ".PDS"


static state_node *t1;
static INT_S s1;
static INT_S nTransitions;

char pds_filename[100];
char des_filename[100];
char temp_filename[100];

INT_OS mode;
INT_OS status;

FILE *from;
char ch;

void pds2des_file_split(char* path, char *name, char *ext) {
   char *ptr;
   INT_P  pos;

   strcpy(name, path);
   ptr = strrchr(name, '.');
   if (ptr == NULL) {   /* No extension */
      ext = NULL;
      return;
   }

   pos = ptr-name;
   name[pos] = '\0';

   strcpy(ext, &(path[pos]));
}

void add_suffix(char *path, const char *suffix)
{
   char name[_MAX_PATH];
   char ext[_MAX_EXT];

   pds2des_file_split(path, name, ext);
   if (strcmp(ext, "") == 0)
      strcat(path, suffix);
}



void pds_readint(INT_S *n, char c)
{
   char numStr[20], cc[2];

   sprintf(numStr, "%c", c);
   do {
     c = fgetc(from);
     if (isdigit(c))
     {
       sprintf(cc, "%c", c);
       strcat(numStr, cc);
     }
     else if (c == ' ')
     {
       if (strcmp(numStr, "") == 0)
         c = '0';
     }
   } while ( isdigit(c) && !feof(from) );
   *n = (INT_S)atoi(numStr);
}

void readint2(INT_S *n)
{
   char numStr[20], cc[2];
   char c;

   strcpy(numStr, "");
   do {
     c = fgetc(from);
     if (isdigit(c))
     {
       sprintf(cc, "%c", c);
       strcat(numStr, cc);
     }
     else if (c == ' ')
     {
       if (strcmp(numStr, "") == 0)
         c = '0';
     }
   } while ( isdigit(c) && !feof(from) );
   *n = (INT_S)atoi(numStr);
}

void readlongint(INT_S *n, char c)
{
   char numStr[20], cc[2];

   sprintf(numStr, "%c", c);
   do {
     c = fgetc(from);
     if (isdigit(c))
     {
       sprintf(cc, "%c", c);
       strcat(numStr, cc);
     }
     else if (ch == ' ')
     {
       if (strcmp(numStr, "") == 0)
         c = '0';
     }
   } while ( isdigit(c) && !feof(from) );
   *n = (INT_S)atoi(numStr);
}

void read_header()
{
   char des_name[100];
   /* Read the filename */
   fscanf(from, "%s", des_name);

   /* Eatup characters until ":" */
   do {
      ch = fgetc(from);
   } while ((ch != ':') && !feof(from));

   s1 = 0;
   fscanf(from, "%ld", &s1);

   t1 = newdes(s1);
   if (t1 == NULL) {
      status = 1;
      return;
   }

   /* Eatup character until end of line */
   do {
      ch = fgetc(from);
   } while ( (ch != 10) && !feof(from) );


   ch = fgetc(from);  /* Read 10 */
}

void read_marker()
{
   /* Read the marker states until we have blank line break */
   char numstr[100], cc[2];
   char ch;
   INT_OS  count;
   INT_B  escape;
   INT_S n;

   escape = false;
   count = 1;
   strcpy(numstr, "");
   do {
      ch = fgetc(from);
      if (isdigit(ch)) {
         sprintf(cc, "%c", ch);
         strcat(numstr, cc);
      } else if (ch == ' ') {
         if (strcmp(numstr, "") != 0) {
            count++;
            n = (INT_S)atoi(numstr);
            strcpy(numstr, "");
            t1[n].marked = true;
         }
      } else if (ch == 10) {
         if (count == 0) {
            escape = true;
         } else {
            count = 0;
         }
      }
   } while ( (escape != true) && !feof(from) );
}

void read_marker_states()
{
   INT_S n;

   /* Look for the ":" */
   do {
      ch = fgetc(from);
   } while (  (ch != ':') && !feof(from) );

   /* Now we can have either a number or word "none" */
   do {
      ch = fgetc(from);
   } while ( (ch == ' ') && !feof(from) );

   if (isdigit(ch)) {
      /* We have a number */
      pds_readint(&n, ch);
      if (n < s1) {
         t1[n].marked = true;
         read_marker();
      } else{
         printf("Range error in marker state\n");
      }
   } else {
      /* We have "none" text - read to end of line */
      do {
         ch = fgetc(from);
      } while ( (ch != 10) && !feof(from) );


      /* Read the "LF" = 10 */
      ch = fgetc(from);

   }
}

void readline()
{
   char c;

   do {
     c = fgetc(from);
   } while ( (c != 10) && !feof(from) );
}

void read_vocal_states()
{
   char numStr[100], cc[2];
   char ch;
   INT_OS count;
   INT_B  escape;
   INT_S n1, n2;
   INT_B  first;

   first = false;
   escape = false;
   count = 0;
   strcpy(numStr, "");

   do {
     ch = fgetc(from);
     if (isdigit(ch)) {
        sprintf(cc, "%c", ch);
        strcat(numStr, cc);
     } else if (ch == 10) {
        if (count == 0) {
           escape = true;
        } else {
           count = 0;
        }
     } else {
        if (strcmp(numStr, "") != 0) {
           if (first == false) {
              first = true;
              n1 = (INT_S)atoi(numStr);
              strcpy(numStr, "");
           } else {
              first = false;
              count++;
              n2 = (INT_S)atoi(numStr);
              strcpy(numStr, "");
              t1[n1].vocal = (INT_V)n2;
           }
        }
      }
   } while ( (escape != true) && !feof(from) );
}

void read_vocal()
{
   INT_B  no_vocal_state;

   /* Look for the ":" character */
   do {
     ch = fgetc(from);
   } while ( (ch != ':') && !feof(from));

   no_vocal_state = false;
   do {
     ch = fgetc(from);
     if ( (ch != ' ') && (ch != 10) )
        no_vocal_state = true;
   } while ( (ch != 10) && !feof(from));

   if (no_vocal_state == true) return;

   /* Read in the vocal states */
   /* Read the blank line */
/*   readline(); */
   read_vocal_states();
}

void read_num_tran()
{
   /* Look for the ":" */
   do {
     ch = fgetc(from);
   } while ( (ch != ':') && !feof(from) );

   /* Now we can have either a number or the work "none" */
   do {
     ch = fgetc(from);
   } while ( (ch == ' ') && !feof(from) );

   if (isdigit(ch)) {
     readlongint(&nTransitions, ch);
     readline();
     readline();
     readline();
   } else {
     nTransitions = 0;
   }
}

void set_trans(INT_S i, INT_S e, INT_S j)
{
   INT_B  ok;

   /* Verify the numbers make sense */
   if (i >= s1) {
     printf("Error: invalid exit state - %d\n", i);
     exit(1);
   }

   if (j >= s1) {
     printf("Error: invalid entrance state - %d\n", j);
     exit(1);
   }

   addordlist1((INT_T) e, (INT_S) j, &t1[i].next, t1[i].numelts, &ok);
   if (ok) t1[i].numelts++;
}

void read_transitions()
{
   INT_S i;
   INT_S exit_state, trans_label, entr_state;

   if (nTransitions < 1) return;

   ch = fgetc(from);
   for (i=0; i < nTransitions; i++) {
     readint2(&exit_state);
     readint2(&trans_label);
     readint2(&entr_state);
     set_trans(exit_state, trans_label, entr_state);
     ch = fgetc(from);
     if (i < nTransitions) {
        while ((ch != '[') && !feof(from))
          ch = fgetc(from);
     }
  }
}
