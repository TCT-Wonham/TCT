#include <stdio.h>
#include <string.h>
#include <time.h>
#include "printer.h"
#include "display.h"
#include "des_data.h"

#ifdef __cplusplus
extern "C" {
#endif

char header[10000] = {"\
/$ppedict 100 dict def\n\
$ppedict begin\n\
%% Initialize page description variables.\n\
/inch {72 mul} bind def\n\
/landscape %s def\n\
/twinpage %s def\n\
/doubleside %s def\n\
/sheetheight %g inch def\n\
/sheetwidth %g inch def\n\
/page_margin %g inch def\n\
/bind_margin %g inch def\n\
/col_margin %g inch def\n\
/noborder %s def\n\
/borderwidth 0.3 def\n\
/noheader false def\n\
/headersize %g inch def\n\
/bodyfontwidth %g def\n\
/bodyfontheight %g def\n\
/columns %g def\n\
/lines %g def\n\
/date (%s) def\n\
\n\
%% General macros.\n\
/xdef {exch def} bind def\n\
/getfont {exch findfont exch scalefont} bind def\n\
/getscaledfont {matrix scale exch findfont exch makefont} bind def\n\
\n\
%% Page description variables and inch function are defined by ppe program.\n\
\n\
%% Character size for differents fonts.\n\
   landscape twinpage or\n\
   { /filenamefontsize 12 def }\n\
   { /filenamefontsize 12 def }\n\
ifelse\n\
/datefontsize filenamefontsize 0.8 mul def\n\
/headermargin filenamefontsize 0.25 mul def\n\
/bodymargin bodyfontheight 0.7 mul def\n\
\n\
%% Font assignment to differents kinds of \"objects\"\n\
/filenamefontname /Helvetica-Bold def\n\
/stdfilenamefont filenamefontname filenamefontsize getfont def\n\
/datefont /Helvetica datefontsize getfont def\n\
/bodyfont /Courier bodyfontwidth bodyfontheight getscaledfont def\n\
/bodyfontbold /Courier-Bold bodyfontwidth bodyfontheight getscaledfont def\n\
/bodyfontitalic /Courier-Oblique bodyfontwidth bodyfontheight getscaledfont def\n\
/bodyfontbolditalic /Courier-BoldOblique bodyfontwidth bodyfontheight getscaledfont def\n\
\n\
%%L%% Additional rendering functions\n\
/Normal     { bodyfont setfont } bind def\n\
/Bold       { bodyfontbold setfont } bind def\n\
/Italic     { bodyfontitalic setfont } bind def\n\
/BoldItalic { bodyfontbolditalic setfont } bind def\n\
/B  { Bold show Normal } bind def\n\
/I  { Italic show Normal } bind def\n\
/BI { BoldItalic show Normal } bind def\n\
/s  { show } bind def\n\
/bodyfontwidth Normal (0) stringwidth pop def\n\
/b  { bodyfontwidth mul neg 0 rmoveto } bind def\n\
/c  { grestore gsave } bind def\n\
/n  { grestore 0 bodyfontheight neg rmoveto gsave } bind def\n\
/N  { show n } bind def\n\
/U  { dup show save exch\n\
         length dup bodyfontwidth mul neg 0 rmoveto\n\
         -1 1 {pop (_) show} for\n\
      restore } bind def\n\
/BU  { Bold U Normal } bind def\n\
\n\
%% Logical page attributes (a half of a real page or sheet).\n\
/pagewidth\n\
   Normal (0) stringwidth pop columns mul bodymargin dup add add\n\
   def\n\
/pageheight\n\
   bodyfontheight lines mul bodymargin dup add add headersize add\n\
   def\n\
\n\
%% Coordinates for upper corner of a logical page and for sheet number.\n\
%% Coordinates depend on format mode used.\n\
%% In twinpage mode, coordinate x of upper corner is not the same for left\n\
%% and right pages: upperx is an array of two elements, indexed by sheetside.\n\
%% same holds true for coordinate y of upper corner for portrait sheets\n\
/rightmargin page_margin 2 div def\n\
/leftmargin rightmargin bind_margin add def\n\
/topmargin rightmargin def\n\
landscape\n\
{  %% Landscape format\n\
   /uppery [ rightmargin pageheight add bodymargin add dup\n\
             leftmargin  pageheight add bodymargin add dup ] def\n\
   /sheetnumbery [ sheetwidth leftmargin  pageheight add datefontsize add sub\n\
                   sheetwidth rightmargin pageheight add datefontsize add sub ] def\n\
   twinpage\n\
   {  %% Two logical pages\n\
      /upperx [ topmargin			  %% upperx for left page\n\
		dup col_margin add pagewidth add  %% upperx for right page\n\
		2 copy\n\
	      ] def\n\
      /sheetnumberx [ sheetheight topmargin sub dup ] def\n\
      /offsetx [ 1 1 ] def\n\
   }\n\
   {  /upperx [ topmargin dup dup dup ] def\n\
      /sheetnumberx [ sheetheight topmargin sub datefontsize sub dup ] def\n\
      /offsetx [ 1 1 ] def\n\
   }\n\
   ifelse\n\
}\n\
{  %% Portrait format\n\
   /upperx [ leftmargin dup rightmargin dup ] def\n\
   /sheetnumberx [ sheetwidth rightmargin sub datefontsize sub\n\
                              rightmargin     datefontsize add ] def\n\
   /offsetx [ 1 0 ] def\n\
   twinpage\n\
   {  %% Two logical pages\n\
      /uppery [ pageheight 2 mul topmargin add\n\
                   col_margin add                %% upper y of 1st page\n\
		 pageheight topmargin add         %% upper y of 1st page\n\
		 2 copy\n\
	      ] def\n\
      /sheetnumbery [\n\
	    topmargin\n\
	    datefontsize headermargin add\n\
	 sub dup ]\n\
	 def\n\
   }\n\
   {\n\
      /uppery [ topmargin pageheight add dup dup dup ] def\n\
      /sheetnumbery [\n\
	    sheetheight \n\
	    topmargin pageheight add datefontsize add headermargin add\n\
	 sub dup ]\n\
	 def\n\
   }\n\
   ifelse\n\
}\n\
ifelse\n\
\n\
%% Strings used to make easy printing numbers\n\
/pnum 12 string def\n\
/empty 12 string def\n\
\n\
%% Other initializations.\n\
/datewidth date stringwidth pop def\n\
/filenameroom\n\
         pagewidth\n\
	 filenamefontsize 4 mul datewidth add (Page 999) stringwidth pop add\n\
      sub\n\
   def\n\
\n\
\n\
%% Function startdoc: initializes printer and global variables.\n\
/startdoc\n\
    { /sheetside 0 def			%% sheet side that contains current page\n\
      /pageside 0 def                   %% front=0, back=1\n\
      /offset 0 def                     %% 2*pageside + sheetside\n\
      /sheet 1 def			%% sheet number\n\
   } bind def\n\
\n\
%% Function newfile: init file name and reset page number for each new file.\n\
/newfile\n\
    { /filename xdef\n\
      /filenamewidth filename stringwidth pop def\n\
      /filenamefont\n\
	 filenamewidth filenameroom gt\n\
	 {\n\
	       filenamefontname\n\
	       filenamefontsize filenameroom mul filenamewidth div\n\
	    getfont\n\
	 }\n\
	 {  stdfilenamefont }\n\
	 ifelse\n\
	 def\n\
      /pagenum 1 def\n\
    } bind def\n\
\n\
%% Function printpage: Print a physical page.\n\
/printpage\n\
    { /sheetside 0 def\n\
      twinpage\n\
      {  noborder not\n\
	    { sheetnumber }\n\
	 if\n\
      }\n\
      {  noheader noborder not and\n\
	    { sheetnumber }\n\
	 if\n\
      }\n\
      ifelse\n\
      showpage \n\
      pagenum\n\
        pagesave restore\n\
      /pagenum exch def\n\
      /sheet sheet 1 add def\n\
    } bind def\n\
\n\
%% Function cleanup: terminates printing, flushing last page if necessary.\n\
/cleanup\n\
    { twinpage sheetside 1 eq and\n\
         { printpage\n\
	  doubleside\n\
	     { /pageside 1 pageside sub def }\n\
	  if\n\
	 }\n\
      if\n\
      doubleside pageside 1 eq and\n\
	 { showpage }\n\
      if\n\
      /pageside 0 def\n\
      /offset 0 def\n\
    } bind def\n\
\n\
%%\n\
%% Function startpage: prints page header and page border and initializes\n\
%% printing of the file lines.\n\
/startpage\n\
    { sheetside 0 eq\n\
	{ /pagesave save def\n\
	  landscape\n\
	    { sheetwidth 0 inch translate	%% new coordinates system origin\n\
	      90 rotate				%% landscape format\n\
	    } if\n\
	} if\n\
      noborder not { printborder } if\n\
      noheader not { printheader } if\n\
	 upperx offset get  bodymargin  add\n\
	    uppery offset get\n\
	    bodymargin bodyfontheight add  noheader {0} {headersize} ifelse  add\n\
	 sub\n\
      moveto\n\
      Normal gsave\n\
    } bind def\n\
\n\
%% Function printheader: prints page header.\n\
/printheader\n\
    { upperx offset get  uppery offset get headersize sub 1 add  moveto\n\
      datefont setfont\n\
      gsave\n\
        datefontsize headermargin rmoveto\n\
	date show					%% date/hour\n\
      grestore\n\
      gsave\n\
	pagenum pnum cvs pop\n\
	   pagewidth (Page 999) stringwidth pop sub\n\
	   headermargin\n\
	rmoveto\n\
        (Page ) show pnum show				%% page number\n\
      grestore\n\
      empty pnum copy pop\n\
      gsave\n\
        filenamefont setfont\n\
	      filenameroom filename stringwidth pop sub 2 div datewidth add\n\
	      bodymargin 2 mul \n\
	   add \n\
	   headermargin\n\
	rmoveto\n\
        filename show						%% file name\n\
      grestore\n\
    } bind def\n\
\n\
%% Function printborder: prints border page.\n\
/printborder \n\
    { upperx offset get uppery offset get moveto\n\
      borderwidth setlinewidth\n\
      gsave					%% print the four sides\n\
        pagewidth 0 rlineto			%% of the square\n\
        0 pageheight neg rlineto\n\
        pagewidth neg 0 rlineto\n\
        closepath stroke\n\
      grestore\n\
      noheader not\n\
         { 0 headersize neg rmoveto pagewidth 0 rlineto stroke }\n\
      if\n\
    } bind def\n\
\n\
%%\n\
"};

char header2[1000] = {"\
%% Function endpage: adds a sheet number to the page (footnote) and prints\n\
%% the formatted page (physical impression). Activated at the end of each\n\
%% source page (lines reached or FF character).\n\
/endpage\n\
   { grestore /pagenum pagenum 1 add def\n\
     twinpage  sheetside 0 eq  and\n\
        { /sheetside 1 def }\n\
        { printpage\n\
	  doubleside\n\
	     { /pageside 1 pageside sub def }\n\
	  if\n\
	}\n\
     ifelse\n\
     /offset pageside 2 mul sheetside add def\n\
   } bind def\n\
\n\
%% Function sheetnumber: prints the sheet number.\n\
/sheetnumber\n\
    { sheetnumberx pageside get sheetnumbery pageside get moveto\n\
      datefont setfont\n\
      sheet pnum cvs\n\
      offsetx pageside get 1 eq\n\
	 { dup stringwidth pop (0) stringwidth pop sub neg 0 rmoveto }\n\
      if show\n\
      empty pnum copy pop\n\
    } bind def\n\
%%%%EndProlog\n\
\n\
/docsave save def\n\
startdoc\n\
"};

char header3[100] = {"\
cleanup\n\
(%s) newfile\n\
/sheet 1 def\n\
\n\
\n\
\n\
"};

char  mode_landscape[6];
char  mode_twinpage[6];
char  mode_doublesize[6];
float mode_sheetheight;
float mode_sheetwidth;
float mode_page_margin;
float mode_bind_margin;
float mode_col_margin;
char  mode_noborder[6];
float mode_headersize;
float mode_bodyfontwidth;
float mode_bodyfontheight;
float mode_columns;
float mode_lines;

INT_OS MODE_init()
{
  strcpy(mode_landscape, "false");
  strcpy(mode_twinpage, "false");
  strcpy(mode_doublesize, "false");
  mode_sheetheight   = 11;          /* In inches */
  mode_sheetwidth    = (float)8.5;         /* In inches */
  mode_page_margin   = (float)1.2;         /* In inches */
  mode_bind_margin   = (float)0.3;         /* In inches */
  mode_col_margin    = (float)0.2;         /* In inches */
  strcpy(mode_noborder, "false");
  mode_headersize    = (float)0.22;        /* In inches */
  mode_bodyfontwidth = (float)7.10234;
  mode_bodyfontheight = (float)7.98953; 
  mode_columns       = 80;
  mode_lines         = 66;

  return 0;
}

INT_OS PS_Header(FILE* fptr)
{
   time_t t1;
   struct tm *t2;
   char time_str[27];

   /* Get the current time and date */   
   t1 = time(&t1);
   t2 = localtime(&t1);
   strcpy(time_str, asctime(t2));
   time_str[strlen(time_str)-1] = '\0'; 

   fprintf(fptr, "%%! Generated by the %s 1.0 Program.\n", TCTNAME);
   fprintf(fptr, "\n");
   fprintf(fptr, header, 
                 mode_landscape,
                 mode_twinpage,
                 mode_doublesize,
                 mode_sheetheight,
                 mode_sheetwidth,
                 mode_page_margin,
                 mode_bind_margin,
                 mode_col_margin,
                 mode_noborder,
                 mode_headersize,
                 mode_bodyfontwidth,
                 mode_bodyfontheight,
                 mode_columns,
                 mode_lines,
                 time_str);
   fprintf(fptr, header2);

   return 0;
}
 
INT_OS PS_FileHeader(FILE* fptr, char* filename)
{
   fprintf(fptr, header3, filename);
   return 0;
}

INT_OS PS_SetFont(FILE* fptr, char* font)
{
   return 0;
}

INT_OS PS_StartPage(FILE* fptr)
{
   fprintf(fptr, "startpage\n");
   return 0;
}
 
INT_OS PS_EndPage(FILE* fptr)
{
   fprintf(fptr, "endpage\n");
   return 0;
}

INT_OS PS_Footer(FILE* fptr)
{
   fprintf(fptr, "\n");
   fprintf(fptr, "%%%%Trailer\n");
   fprintf(fptr, "cleanup\n");
   fprintf(fptr, "docsave restore end\n");
   return 0;
}

#ifdef __cplusplus
}
#endif

