#ifndef PRINTER_H
#define PRINTER_H

#include <stdio.h>
#include "des_data.h"

#ifdef __cplusplus
extern "C" {
#endif

extern INT_OS PS_Header(FILE* fptr);
extern INT_OS PS_FileHeader(FILE* fptr, char* filename);
extern INT_OS PS_SetFont(FILE* fptr, char* font);
extern INT_OS PS_StartPage(FILE* fptr);
extern INT_OS PS_EndPage(FILE* fptr);
extern INT_OS PS_Footer(FILE* fptr);
extern INT_OS MODE_init();

extern char  mode_landscape[6];
extern char  mode_twinpage[6];
extern char  mode_doublesize[6];
extern float mode_sheetheight;
extern float mode_sheetwidth;
extern float mode_page_margin;
extern float mode_bind_margin;
extern float mode_col_margin;
extern char  mode_noborder[6];
extern float mode_headersize;
extern float mode_bodyfontwidth;
extern float mode_bodyfontheight;
extern float mode_columns;
extern float mode_lines;

#ifdef __cplusplus
}
#endif

#endif
