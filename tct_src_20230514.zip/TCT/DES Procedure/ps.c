/* Postscript printing procedure */
#include "printer.h"
#include "des_data.h"
#include "des_proc.h"

#ifdef __cplusplus
extern "C" {
#endif

long int line_num;

void ps_newline(FILE* out)
{
   fprintf(out, "n\n");
   line_num++;
}

void line_check(FILE* out)
{
   line_num++;
   if (line_num >= mode_lines)
   {
      line_num = 0;
      PS_EndPage(out);
      PS_StartPage(out);
   }
}

void ps_des_stat_header(FILE *out,
                        char *name,
                        INT_S s)
{
   fprintf(out, "(%s    # states: %ld", name, s);
   if (s > 0) {
      fprintf(out, "    state set: 0 ... %ld", s-1);
      fprintf(out, "    initial state: %d)N\n", 0);
   } else {
      fprintf(out, "    state set: empty ");
      fprintf(out, "    initial state: none)N\n");
   }
   line_num++;
}

void ps_marker_states(FILE *out,
                      state_node *t1,
                      INT_S s1)
{
   INT_S i, total_marker;

   total_marker = 0;

   fprintf(out, "(marker states:       ");
   for (i=0; i < s1; i++) {
      if (t1[i].marked) {
         fprintf(out, "%7ld ", i);
         total_marker++;
         if ((total_marker % 7) == 0) {
            fprintf(out, ")N\n");
            line_check(out);

            fprintf(out, "(%-21s", " ");
         }
      }
   }

   fprintf(out, ")N\n"); line_check(out);
}

void ps_vocal_output(FILE *out,
                     state_node *t1,
                     INT_S s1)
{
   INT_S i, total_vocal;

   total_vocal = 0;

   fprintf(out, "n\n"); line_check(out);
   fprintf(out, "(vocal states:       )N\n"); line_check(out);
   for (i=0; i < s1; i++) {
      if (t1[i].vocal > 0) {
         /* Tempory format fix - for 7 digit numbers */
         if ((total_vocal % 5) == 0)
            fprintf(out, "(");

         if (s1 < 100000)
            fprintf(out, "[%5ld,%4d]   ", i, t1[i].vocal);
         else if (s1 < 1000000)
            fprintf(out, "[%6ld,%4d]  ", i, t1[i].vocal);
         else
            fprintf(out, "[%7ld,%4d] ", i, t1[i].vocal);

         total_vocal++;
         if ((total_vocal % 5) == 0) {
            fprintf(out, ")N\n"); line_check(out);
         }
      }
   }

   if ((total_vocal % 5) == 0) {
      fprintf(out, "n\n"); line_check(out);
   } else {
      fprintf(out, ")N\n"); line_check(out);
   }
}

void ps_transitions(FILE *out,
                    state_node *t1,
                    INT_S s1)
{
   INT_S i, total_tran;
   INT_T j;

   total_tran = 0;

   fprintf(out, "n\n"); line_check(out);
   fprintf(out, "(# transitions: %ld)N\n", count_tran(t1, s1)); line_check(out);
   fprintf(out, "n\n"); line_check(out);
   fprintf(out, "(transitions: )N\n"); line_check(out);
   fprintf(out, "n\n"); line_check(out);
   for (i=0; i < s1; i++) {
     for (j=0; j< t1[i].numelts; j++) {
       if ((total_tran % 4) == 0)
          fprintf(out, "(");

       fprintf(out, "[%5ld,%3d,%5d]  ", i, t1[i].next[j].data1, t1[i].next[j].data2);       total_tran++;
       if ((total_tran % 4) == 0) {
          fprintf(out, ")N\n"); line_check(out);
       }
     }
   }

   if ((total_tran % 4) == 0) {
      fprintf(out, "n\n"); line_check(out);
   } else {
      fprintf(out, ")N\n"); line_check(out);
   }
}

void postscript_outputfile(char *name,
                           FILE *out,
                           state_node *t1,
                           INT_S s1)
{
    INT_S nTransitions;

    MODE_init();   /* Reset default output configuration */
    line_num = 0;

    /* Postscript header */
    PS_Header(out);
    PS_FileHeader(out, name);
    PS_StartPage(out);

    /* Content */
    ps_des_stat_header(out, name, s1);
    ps_newline(out);

    if (num_mark_states(t1, s1) > 0) {
       ps_marker_states(out, t1, s1);
    } else {
       fprintf(out, "(marker states: none) N\n");  line_num++;
       fprintf(out, "n\n"); line_num++;
    }

    if (num_vocal_output(t1, s1) > 0) {
       ps_vocal_output(out, t1, s1);
    } else {
       fprintf(out, "n\n"); line_check(out);
       fprintf(out, "(vocal states: none)N\n"); line_check(out);
       fprintf(out, "n\n"); line_check(out);
    }

    nTransitions = count_tran(t1, s1);
    if (nTransitions > 0) {
       ps_transitions(out, t1, s1);
       fprintf(out, "n\n"); line_check(out);
    } else {
       fprintf(out, "(transition table : empty)N\n");
    }

    /* Footer */
    PS_EndPage(out);
    PS_Footer(out);
}

void ps_dat_header_stat(FILE *out, char *name1,INT_B  controllable)
{
    fprintf(out, "(%s)N\n", name1);
    fprintf(out, "n\n");
    fprintf(out, "n\n");
    fprintf(out, "(Control data are displayed as a list of supervisor states)N\n");
    fprintf(out, "(where disabling occurs, together with the events that must)N\n");
    fprintf(out, "(be disabled there.)N\n");    
    fprintf(out, "n\n");
    fprintf(out, "(%s is ", name1);
    if(controllable){
        fprintf(out,"CONTROLLABLE)N\n");
    } else{
        fprintf(out,"NOT CONTROLLABLE)N\n");
    }
    fprintf(out, "n\n");
    fprintf(out, "(control data:)N\n");
    line_num += 8;
}

void ps_dat(FILE *out,
            state_node *t1,
            INT_S s1)
{
   INT_S k, i, prevNumTran;
   INT_T j;
   INT_B  leftSide;
   INT_B  open_bracket = false;

   leftSide = false;
   prevNumTran = 0;

   ps_newline(out);
   for (i=0; i < s1; i++) {
     if (t1[i].numelts > 0) {
       if ((prevNumTran > 6) || (t1[i].numelts > 6) || (leftSide == false)) {
         if (open_bracket == true)
         {
            fprintf(out, ")N\n"); line_check(out);
         } else {
            fprintf(out, "n\n"); line_check(out);
         }
         open_bracket = true;
         fprintf(out, "(%4s", " ");
         leftSide = true;
       } else {
         for (k=prevNumTran; k <=6; k++)
            fprintf(out, "%5s", " ");
         leftSide = false;
       }
       fprintf(out, "%4ld:", i);
       prevNumTran = t1[i].numelts;
     }

     for (j=0; j< t1[i].numelts; j++) {
       if (t1[i].next[j].data1 == EEE)   
         fprintf(out, "e    ");
       else  
         fprintf(out, "%4d ", t1[i].next[j].data1);

       if ( (j != 0) && ((j % 12) == 0) && (j < prevNumTran-1) ) {
         if (open_bracket == true)
         {
            fprintf(out, ")N\n");line_check(out);
         } else {
            fprintf(out, "n\n"); line_check(out);
         }
         open_bracket = true;
         fprintf(out, "(%9s", " ");
       }
     }
   }

   if (open_bracket == true)
   {
      fprintf(out, ")N\n"); line_check(out);
   } else {
      fprintf(out, "n\n"); line_check(out);
   }
}

void postscript_dat_output(char *name,
                           FILE *out,
                           state_node *t1,
                           INT_S s1)
{
    INT_S nTransitions;
    INT_B  controllable;

    MODE_init();   /* Reset default output configuration */
    line_num = 0;

    /* Postscript header */
    PS_Header(out);
    PS_FileHeader(out, name);
    PS_StartPage(out);

    /* Content */
    controllable = compute_controllable(t1,s1);
    ps_dat_header_stat(out, name,controllable);
    nTransitions = count_tran(t1, s1);
    if (nTransitions > 0) {
       ps_dat(out, t1, s1);
       ps_newline(out);
    } else {
       fprintf(out, "(empty.)N\n");
    }

    /* Footer */
    PS_EndPage(out);
    PS_Footer(out);
}

#ifdef __cplusplus
}
#endif

