#ifndef _PS_H
#define _PS_H

#include <stdio.h>
#include "des_data.h"

#ifdef __cplusplus
extern "C" {
#endif

extern void postscript_outputfile(char *name,
                                  FILE *out,
                                  state_node *t1,
                                  INT_S s1);

extern void postscript_dat_output(char *name,
                                  FILE *out,
                                  state_node *t1,
                                  INT_S s1);

#ifdef __cplusplus
}
#endif

#endif
