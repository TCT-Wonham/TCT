#include <stdio.h>
#include <stdlib.h>
#include "curses.h"
#include "tct_io.h"
#include "des_data.h"
#include "des_proc.h"
#include "tct_proc.h"
#include "display.h"
#include "viewer.h"
#include "setup.h"
#include "cl_tct.h"

#ifdef __cplusplus
extern "C" {
#endif

static filename name1;
static INT_B   quit;
static char option;
static INT_B  option_check;

void show_des_header()
{
   printw("SHOW"); println();
   println();
   printw("SHOW(DES)"); println();
   println();
}

void show_des_stat_header(char *name,
                          INT_S s,
                          INT_S init)
{
   clear();
   printw("%s    # states: %d", name, s);
   if (s > 0) {
      printw("    state set: 0 ... %d", s-1);
      printw("    initial state: %d", init); println();
   } else {
      printw("    state set: empty ");
      printw("    initial state: none"); println();
   }
}

/* Display marker states related variables */
static state_node *t1;
static INT_S init, s1;
static INT_S i, total_marker;
static INT_S *marker_stack;
static INT_S s_marker_stack;
static char ch;
static INT_B  multiPage;

void marker_states_page_control(INT_B  lastPage)
{
   multiPage = true;
/*   continue_page("Press <Enter> to page marker state table or <ESC> to cancel  "); */

   continue_page(" D(own)  U(p)  H(ead)  V(ocal table)  T(ransition table)  Esc (Exit Show)  ");

   do {
      refresh();
      ch = read_key();

      switch(ch) {
         case 'h':
         case 'H':
         case 'v':
         case 'V':
         case 't':
         case 'T':
            option = ch;
            option_check = true;
            free(marker_stack);   marker_stack = NULL;
            return;

         case CEsc:
            quit = true;
            free(marker_stack);  marker_stack = NULL;
            return;
         case CPgDn:
            if (lastPage == true) {
               ch = 0;
               ring_bell();
            } else {
               s_marker_stack++;
               marker_stack = (INT_S*) realloc(marker_stack,
                                       sizeof(INT_S)* s_marker_stack);
               marker_stack[s_marker_stack-1] = i;
            }
            break;
         case CEnter:
            if (lastPage == false) {
               s_marker_stack++;
               marker_stack = (INT_S*) realloc(marker_stack,
                                       sizeof(INT_S)* s_marker_stack);
               marker_stack[s_marker_stack-1] = i;
            } else{
               show_des_stat_header(name1, s1, init);
               return;
            }
            break;
         case CPgUp:
            if (s_marker_stack == 0) {
               ch = 0;
               ring_bell();
            } else {
               if (s_marker_stack >= 2) {
                  i = marker_stack[s_marker_stack-2];
                  s_marker_stack -= 2;
                  marker_stack = (INT_S*) realloc(marker_stack,
                                       sizeof(INT_S)* s_marker_stack);

                  /* Put back the last pop */
                  s_marker_stack++;
                  marker_stack = (INT_S*) realloc(marker_stack,
                                          sizeof(INT_S)* s_marker_stack);
                  marker_stack[s_marker_stack-1] = i;
               } else {
                  i = 0;
                  i--;  /* Main loop will increment it by one. */
                  s_marker_stack = 0;
                  free(marker_stack); marker_stack = NULL;
               }
               total_marker = 0;
            }
            break;
      }
   } while ( ( ch != CEnter) && (ch != CEsc) && (ch != CPgUp) && (ch != CPgDn) );

   show_des_stat_header(name1, s1, init);
   println();
   printw("marker states:       "); println();
   println();
}

INT_B  display_marker_states(state_node *t1,
                              INT_S s1)
{
   multiPage = false;
   total_marker = 0;
   marker_stack = NULL;  s_marker_stack = 0;
   i = 0;

   printw("marker states:       "); println();
   println();
   do {
      while (i < s1) {
         if (t1[i].marked) {
            printw("%7d  ", i);
            total_marker++;
            if (total_marker % 8 == 0) {
               println();
            }

            if (_wherey() >= 22) {
               marker_states_page_control(false);
               if (quit) return true;
               if (option_check) return false;
            }
         }
         i++;
      }
      if (multiPage) marker_states_page_control(true);
      i++;

   } while ( (ch != CEnter) && (ch != CPgDn) && (multiPage == true) &&
             (quit == false) && (option_check == false) );
   println();
   refresh();

/*   for (i=0; i < s1; i++) {
      if (t1[i].marked) {
         printw("%5d   ", i);
         total_marker++;
         if ((total_marker % 7) == 0) {
            println();
            printw("%-21s", " ");
         }
      }
   }
   println();
   return false;
*/

   free(marker_stack);  marker_stack = NULL;
   return quit;
}

/* Display vocal output variables */
static INT_S *vocal_stack;
static INT_S s_vocal_stack;
static INT_S total_vocal;

void vocal_output_page_control(INT_B  lastPage)
{
   multiPage = true;
/*   continue_page("Press <Enter> to page vocal output table or <ESC> to cancel  "); */

   continue_page(" D(own)  U(p)  H(ead)  V(ocal table)  T(ransition table)  Esc (Exit Show)  ");

   do {
      refresh();
      ch = read_key();

      switch(ch) {
         case 'h':
         case 'H':
         case 'v':
         case 'V':
         case 't':
         case 'T':
            option = ch;
            option_check = true;
            free(vocal_stack);  vocal_stack = NULL;
            return;
         case CEsc:
            quit = true;
            free(vocal_stack);  vocal_stack = NULL;
            return;
         case CPgDn:
            if (lastPage == true) {
               ch = 0;
               ring_bell();
            } else {
               s_vocal_stack++;
               vocal_stack = (INT_S*) realloc(vocal_stack,
                                       sizeof(INT_S)* s_vocal_stack);
               vocal_stack[s_vocal_stack-1] = i;
            }
            break;
         case CEnter:
            if (lastPage == false) {
               s_vocal_stack++;
               vocal_stack = (INT_S*) realloc(vocal_stack,
                                       sizeof(INT_S)* s_vocal_stack);
               vocal_stack[s_vocal_stack-1] = i;
            } else{
               show_des_stat_header(name1, s1, init);
               return;
            }
            break;
         case CPgUp:
            if (s_vocal_stack == 0) {
               ch = 0;
               ring_bell();
            } else {
               if (s_vocal_stack >= 2) {
                  i = vocal_stack[s_vocal_stack-2];
                  s_vocal_stack -= 2;
                  vocal_stack = (INT_S*) realloc(vocal_stack,
                                       sizeof(INT_S)* s_vocal_stack);

                  /* Put back the last pop */
                  s_vocal_stack++;
                  vocal_stack = (INT_S*) realloc(vocal_stack,
                                          sizeof(INT_S)* s_vocal_stack);
                  vocal_stack[s_vocal_stack-1] = i;
               } else {
                  i = 0;
                  s_vocal_stack = 0;
                  free(vocal_stack); vocal_stack = NULL;
               }
               total_vocal = 0;
            }
            break;
      }
   } while ( ( ch != CEnter) && (ch != CEsc) && (ch != CPgUp) && (ch != CPgDn) );

   show_des_stat_header(name1, s1, init);
   println();
   printw("vocal states:       "); println();
   println();
}

INT_B  display_vocal_output(state_node *t1,
                             INT_S s1)
{
   total_vocal = 0;
   multiPage = false;
   vocal_stack = NULL;  s_vocal_stack = 0;
   i = 0;

   println();
   printw("vocal states:      "); println();
   if (_wherey() >= 22) {
      vocal_output_page_control(false);
      if (quit) return true;
      if (option_check) return false;
   } else {
      println();
   }

   do {
      while (i < s1) {
        if (_wherey() >= 22)
           vocal_output_page_control(false);
        if (quit) return true;
        if (option_check) return false;

        if (t1[i].vocal > 0) {
           /* Tempory format fix */
           if (s1 <= 100000)
              printw("[%5ld,%4d]   ", i, t1[i].vocal);
           else if (s1 <= 1000000)
              printw("[%6ld,%4d]  ", i, t1[i].vocal);
           else
              printw("[%7ld,%4d] ", i, t1[i].vocal);

           total_vocal++;
           if ((total_vocal % 5) == 0) {
             println();
           }
        }
        i++;
      }
      if (multiPage) vocal_output_page_control(true);
   } while ( (ch != CEnter) && (ch != CPgDn) && (multiPage != false) &&
             (quit != true) && (option_check != true));
   println();

   free(vocal_stack);  vocal_stack = NULL;

/*   println();
   printw("vocal states:       "); println();
   for (i=0; i < s1; i++) {
      if (t1[i].vocal > 0) {
         printw("[%5d,%4d]   ", i, t1[i].vocal);
         total_vocal++;
         if ((total_vocal % 5) == 0) {
            println();
         }
      }
   }
   println();
*/
   return false;
}

/* Display transitions variables */
static state_pair *tran_stack;
static INT_S s_tran_stack;
static INT_S total_tran;
static INT_S num_transitions;
static INT_T j;

void transition_page_control(INT_B  lastPage)
{
/* if (lastPage) {
      continue_page("Press <Enter> to return to CTCT Procedures  ");
   } else {
      continue_page("Press <Enter> to page transition table or <ESC> to cancel  ");
   }
*/

   continue_page(" D(own)  U(p)  H(ead)  V(ocal table)  T(ransition table)  Esc (Exit Show)  ");


   do {
      refresh();
      ch = read_key();

      switch(ch) {
         case 'h':
         case 'H':
         case 'v':
         case 'V':
         case 't':
         case 'T':
            option = ch;
            option_check = true;
            free(tran_stack); tran_stack = NULL;
            return;
         case CEsc:
            quit = true;
            free(tran_stack); tran_stack = NULL;
            return;
         case CPgDn:
            if (lastPage == true) {
               ch = 0;
               ring_bell();
            } else {
               s_tran_stack++;
               tran_stack = (state_pair*) realloc(tran_stack,
                                          sizeof(state_pair)*s_tran_stack);
               tran_stack[s_tran_stack-1].data1 = i;
               tran_stack[s_tran_stack-1].data2 = j;
            }
            break;
         case CEnter:
            if (lastPage == false) {
               s_tran_stack++;
               tran_stack = (state_pair*) realloc(tran_stack,
                                          sizeof(state_pair)*s_tran_stack);
               tran_stack[s_tran_stack-1].data1 = i;
               tran_stack[s_tran_stack-1].data2 = j;
            }
            break;
         case CPgUp:
            if (s_tran_stack == 0) {
               ch = 0;
               ring_bell();
            } else {
               if (s_tran_stack >= 2) {
                  i = tran_stack[s_tran_stack-2].data1;
                  j = (INT_T)tran_stack[s_tran_stack-2].data2;

                  s_tran_stack -= 2;
                  tran_stack = (state_pair*) realloc(tran_stack,
                                       sizeof(state_pair)*s_tran_stack);

                  /* Put back the last pop */
                  s_tran_stack++;
                  tran_stack = (state_pair*) realloc(tran_stack,
                                          sizeof(state_pair)*s_tran_stack);
                  tran_stack[s_tran_stack-1].data1 = i;
                  tran_stack[s_tran_stack-1].data2 = j;
               } else {
                  i = 0;
                  j = 0;
                  s_tran_stack = 0;
                  free(tran_stack); tran_stack = NULL;
               }
               total_tran = 0;
            }
            break;
      }
   } while ( ( ch != CEnter) && (ch != CEsc) && (ch != CPgUp) && (ch != CPgDn) );

   show_des_stat_header(name1, s1, init);
   println();
   printw("# transitions: %d", num_transitions); println();
   println();
   printw("transitions: "); println();
   println();
}

INT_B  display_transitions(state_node *t1,
                            INT_S s1)
{
   INT_T t;
   INT_S e;
   char eventlabel[WIDTH_EVENT];

   total_tran = 0;
   multiPage = false;
   tran_stack = NULL;  s_tran_stack = 0;
   i = 0; j = 0;

   num_transitions = count_tran(t1, s1);

   if (_wherey() > 19)
   {
      transition_page_control(false);
      if (quit) return true;
      if (option_check) return false;
   }
   else
   {
      println();
      printw("# transitions: %d", num_transitions); println();
      println();
      printw("transitions: "); println();
      println();

      if (_wherey() >= 22)
      {
         transition_page_control(false);
         if (quit) return true;
         if (option_check) return false;
      }
      else
         println();
   }

   if (s1 <= 100000)
   {

   do {
      while (i < s1) {
/*        j = 0; */
        while (j < t1[i].numelts) {
          if (_wherey() >= 22)
             transition_page_control(false);
          if (quit) return true;
          if (option_check) return false;
          
          t = t1[i].next[j].data1;
          e = t1[i].next[j].data2;

		  get_strlabel_by_intlabel(t, eventlabel);
          
		  if(t < 2000){
			if (t == EEE)
				printw("[%5ld,  e,%5ld]  ", i, e);
			 else
				printw("[%5ld,%5d,%5ld]  ", i, t, e);
		  }else
		  {
			  printw("[%5ld,%10s,%5ld]  ", i,eventlabel, e);
		  }

		 // tab(5);
          
          total_tran++;
          if (total_tran % 3 == 0)
            println();
          j++;
        }
        j = 0;
        i++;
      }
      transition_page_control(true);
      if (quit) return true;
      if (option_check) return false;
/*   } while ( (ch != CEnter) && (ch != CPgDn) ); */
   } while ( ch != CEnter );

   }
   else
   {
      /* > 100000 states */
   do {
      while (i < s1) {
/*        j = 0; */
        while (j < t1[i].numelts) {
          if (_wherey() >= 22)
             transition_page_control(false);
          if (quit) return true;
          if (option_check) return false;
          t = t1[i].next[j].data1;
          e = t1[i].next[j].data2;		  
          
		  if(t < START_INTLABEL){
			if (t == EEE)
				printf("[%7ld,  e,%7ld]  ", i, e);
			else
				printw("[%7ld,%4d,%7ld]  ", i, t, e);
		  }else
		  {
			  get_strlabel_by_intlabel(t, eventlabel);
			  printw("[%7ld,%10s,%7ld]  ", i,eventlabel, e);
		  }
             
          total_tran++;
          if (total_tran % 2 == 0)
            println();
          j++;
        }
        j = 0;
        i++;
      }
      transition_page_control(true);
      if (quit) return true;
      if (option_check) return false;
/*   } while ( (ch != CEnter) && (ch != CPgDn) ); */
   } while ( ch != CEnter );
   
   }
   
   println();

   free(tran_stack); tran_stack = NULL;

/*   for (i=0; i < s1; i++) {
     for (j=0; j< t1[i].numelts; j++) {
       printw("[%5d,%3d,%5d]  ", i, t1[i].next[j].data1, t1[i].next[j].data2);
       total_tran++;
       if ((total_tran % 4) == 0) {
          println();
       }
     }
   } */
   return true;
}

INT_B  display_empty_tran(void)
{
   total_tran = 0;
   multiPage = false;
   tran_stack = NULL;  s_tran_stack = 0;
   i = 0; j = 0;

   if (_wherey() > 19)
   {
      transition_page_control(false);
      if (quit) return true;
      if (option_check) return false;
   }

   printw("transition table : empty"); println();
   do {
      transition_page_control(true);
      if (quit) return true;
      if (option_check) return false;
   } while (ch != CEnter);

   return true;
}

void show_mark(state_node *t1, INT_S s1)
{
   INT_S num_mark;

   num_mark = num_mark_states(t1, s1);

   if ((num_mark == s1) && (s1 > 0)) {
      printw("marker states: all"); println();
      println();
   } else if (num_mark > 0L) {
      quit = display_marker_states(t1, s1);
      if (quit) return;
   } else {
      printw("marker states: none"); println();
      println();
   }
}

void show_vocal(state_node *t1, INT_S s1)
{
   if (num_vocal_output(t1, s1) > 0L) {
      quit = display_vocal_output(t1, s1);
      if (quit) return;
   } else {
      println();
      printw("vocal states: none"); println();
      println();
   }
}

void show_transitions(state_node *t1, INT_S s1)
{
   INT_S nTransitions;

   nTransitions = count_tran(t1, s1);
   if (nTransitions > 0) {
      quit = display_transitions(t1, s1);
      if (quit) return;
   } else {
      display_empty_tran();
/*      printw("transition table : empty"); println();
      continue_page("Press <Enter> to return to CTCT Procedures  ");
      refresh();
      do {
         ch = read_key();
      } while (ch != CEnter);
      quit = true;
*/
   }
}

void show_des_r(state_node** t1,
                INT_S *s1)
{
   clear();
   show_des_header();
   quit = getname("Enter name of DES ...  ", EXT_DES, name1, false);
   if (quit) return;

   if (getdes(name1, s1, &init, t1) == false) {
      quit = true;
	  user_pause();
      return;
   }

   /* Display DES to screen */
   clear();
   if (init == -1) {
     println();
     printw("This is a DAT file.");   println();
     printw("Use show DAT command."); println();
     refresh();
     user_pause();
     quit = true;
     return;
   }

   show_des_stat_header(name1, *s1, init);
   println();
   refresh();

   option = 'H';
   option_check = false;
   do {
     switch (option) {
       case 'h':
       case 'H':
            show_des_stat_header(name1, *s1, init);
            println();
            refresh();

            show_mark(*t1, *s1);
            if (quit) return;
            if (option_check) break;

            show_vocal(*t1, *s1);
            if (quit) return;
            if (option_check) break;

            show_transitions(*t1, *s1);
            if (quit) return;
            break;

       case 'v':
       case 'V':
            show_des_stat_header(name1, *s1, init);
            println();
            refresh();

            show_vocal(*t1, *s1);
            if (quit) return;
            if (option_check) break;

            show_transitions(*t1, *s1);
            if (quit) return;
            break;

       case 't':
       case 'T':
            show_des_stat_header(name1, *s1, init);
            println();
            refresh();

            show_transitions(*t1, *s1);
            if (quit) return;
            break;
     }
     option_check = false;
   } while (quit == false);
}

void show_des_p()
{
   t1 = NULL;

   show_des_r(&t1, &s1);

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   }

   freedes(s1, &t1);
}

/* Dat variables */
static INT_S prevNumTran;
static INT_B  leftSide;
static INT_B  controllable;

void show_dat_header()
{
   printw("SHOW"); println();
   println();
   printw("SHOW(DAT)"); println();
   println();
}

void dat_header()
{
    clear();
    printw("%s", name1); println();
    println();
    println();
    printw("Control data are displayed as a list of supervisor states"); println();
    printw("where disabling occurs, together with the events that must"); println();
    printw("be disabled there."); println();
    println();
    printw("%s is ", name1);
    if (controllable)
       printw("CONTROLLABLE");
    else
       printw("NOT CONTROLLABLE");
    println(); println();
    printw("control data: "); println();
}

void dat_header_empty()
{
    clear();
    printw("%s", name1); println();
    println();
    println();
    printw("Control data are displayed as a list of supervisor states"); println();
    printw("where disabling occurs, together with the events that must"); println();
    printw("be disabled there."); println();
    println();
    printw("%s is ", name1);
    printw("CONTROLLABLE");
    println(); println();
    printw("control data: "); println();
}


void dat_page_control(INT_B  lastPage)
{
   char msg[100];

   if (lastPage) {
      sprintf(msg, "Press <Enter> to return to %s Procedures  ", TCTNAME);
      continue_page(msg);
   } else {
      continue_page("Press <Enter> to page table or <ESC> to cancel  ");
   }

   do {
      refresh();
      ch = read_key();

      switch(ch) {
         case CEsc:
            quit = true;
            free(tran_stack); tran_stack = NULL;
            return;
         case CPgDn:
            if (lastPage == true) {
               ch = 0;
               ring_bell();
            } else {
               s_tran_stack++;
               tran_stack = (state_pair*) realloc(tran_stack,
                                          sizeof(state_pair)*s_tran_stack);
               tran_stack[s_tran_stack-1].data1 = i;
               tran_stack[s_tran_stack-1].data2 = j;
            }
            break;
         case CEnter:
            if (lastPage == false) {
               s_tran_stack++;
               tran_stack = (state_pair*) realloc(tran_stack,
                                          sizeof(state_pair)*s_tran_stack);
               tran_stack[s_tran_stack-1].data1 = i;
               tran_stack[s_tran_stack-1].data2 = j;
            }
            break;
         case CPgUp:
            if (s_tran_stack == 0) {
               ch = 0;
               ring_bell();
            } else {
               if (s_tran_stack >= 2) {
                  i = tran_stack[s_tran_stack-2].data1;
                  j = (INT_T)tran_stack[s_tran_stack-2].data2;

                  s_tran_stack -= 2;
                  tran_stack = (state_pair*) realloc(tran_stack,
                                       sizeof(state_pair)*s_tran_stack);

                  /* Put back the last pop */
                  s_tran_stack++;
                  tran_stack = (state_pair*) realloc(tran_stack,
                                          sizeof(state_pair)*s_tran_stack);
                  tran_stack[s_tran_stack-1].data1 = i;
                  tran_stack[s_tran_stack-1].data2 = j;
               } else {
                  i = 0;
                  j = 0;
                  s_tran_stack = 0;
                  free(tran_stack); tran_stack = NULL;
               }
               prevNumTran = 0;
               leftSide = false;
               total_tran = 0;
            }
            break;
      }
   } while ( ( ch != CEnter) && (ch != CEsc) && (ch != CPgUp) && (ch != CPgDn) );

   dat_header();
   println();
}

INT_B  display_dat(state_node *t1,
                    INT_S s1)
{
   INT_S k;
   INT_T t;
   char strLabel[WIDTH_EVENT];

   tran_stack = NULL; s_tran_stack = 0;

   total_tran = 0;
   leftSide = false;
   prevNumTran = 0;
   i = 0; j = 0;

   do {
      while (i < s1) {
         if (t1[i].numelts > 0) {
           if ((prevNumTran > 6) || (t1[i].numelts > 6) || (leftSide == false)) {
              println();
              if (_wherey() >= 22)
                 dat_page_control(false);
              if (quit) {
                 free(tran_stack);  tran_stack = NULL;
                 return true;
              }

              printw("%4s", " ");
              leftSide = true;
           } else {
              for (k=prevNumTran; k < 6; k++)
                 printw("%5s", " ");
              leftSide = false;
           }
           
           printw("%4d:", i);
           prevNumTran = t1[i].numelts;
         }

         while (j < t1[i].numelts) {
            if (_wherey() >= 23)
               dat_page_control(false);
            if (quit) {
               free(tran_stack);  tran_stack = NULL;
               return true;
            }

            t = t1[i].next[j].data1;
            if (t == EEE)
               printw("e    ");
            else if(t < START_INTLABEL){
               printw("%4d ", t);
			}else{
				get_strlabel_by_intlabel(t, strLabel);
				printw("%s", strLabel);
			}

            if ( (j != 0) && ((j % 12) == 0) && (j < prevNumTran-1) ) {
               println();
               printw("%9s", " ");
            }
            j++;
         }
         j = 0;
         i++;
      }
      dat_page_control(true);
      if (quit) {
         free(tran_stack); tran_stack = NULL;
         return true;
      }
   } while ( (ch != CEnter) && (ch != CPgDn) );
   println();
   free(tran_stack);  tran_stack = NULL;


   return false;
}

void show_dat_r(state_node** t1,
                INT_S *s1)
{
   INT_S init, nTransitions;
   char ch;

   clear();
   show_dat_header();
   quit = getname("Enter name of DAT ...  ", EXT_DAT, name1, false);
   if (quit) return;

   init = -1;
   if (getdes(name1, s1, &init, t1) == false) {
      quit = true;
      return;
   }

   nTransitions = count_tran(*t1, *s1);
   controllable = compute_controllable(*t1, *s1);

   if (nTransitions > 0) {
      dat_header();
      quit = display_dat(*t1, *s1);
      if (quit) return;
   } else {
      dat_header_empty();
      printw("empty."); println();
      move(23,0); clrtoeol();
      printw("Press <Enter> to return to %s Procedure  ", TCTNAME);
      refresh();
      do {
        ch = read_key();
      } while (ch != CEnter);
   }
}

void show_dat_p()
{
   t1 = NULL;

   show_dat_r(&t1, &s1);

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   }

   freedes(s1, &t1);
}

void show_ascii_header()
{
   printw("SHOW"); println();
   println();
   printw("SHOW(TXT)"); println();
   println();
}

void show_ascii_p()
{
   filename longname;

   clear();
   show_ascii_header();
   quit = getname("Enter name of TXT ...  ", EXT_TXT, name1, false);
   if (quit) return;

   sprintf(longname, "%s%s%s", prefix, name1, EXT_TXT);

   ascii_viewer(longname,name1);
}

#ifdef __cplusplus
}
#endif

