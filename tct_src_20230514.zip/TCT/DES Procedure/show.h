#ifndef _SHOW_H
#define _SHOW_H

#ifdef __cplusplus
extern "C" {
#endif

extern void show_des_p();
extern void show_dat_p();
extern void show_ascii_p();

#ifdef __cplusplus
}
#endif

#endif
