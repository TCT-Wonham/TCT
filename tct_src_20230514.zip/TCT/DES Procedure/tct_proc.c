#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <sys/stat.h>
#include <process.h>
#include <conio.h>
#include <windows.h>
#include <direct.h>


#include "tct_proc.h"
#include "tct_io.h"
#include "curses.h"
#include "des_proc.h"
#include "display.h"
#include "outcon.h"
#include "hicons.h"
#include "higen.h"
#include "cnorm.h"
#include "setup.h"
#include "minm.h"
#include "ps.h"
#include "supred.h"
#include "ex_supred.h"
#include "ads2des.h"
#include "cl_tct.h"
#include "canqc.h"
#include "obs_check.h"
#include "des_convert.h"
#include "localize.h"
#include "mymalloc.h"

#include <dos.h>

#ifdef __cplusplus
extern "C" {
#endif

#define ImageCommandSet "NnIiDd"
#define NULLCommandSet "NnIi"
#define ConCommandSet "AaCc"
#define	TYPECommandSet "DdAaEe"
#define YNCommandSet  "YyNn"

/* Module variables - local to this module. */
static filename   name1, name2, name3, name4, imagename, names1[MAX_DESS],names2[MAX_DESS];
static INT_B     quit;

static long_filename long_name1;
static long_filename long_name2;
static long_filename long_name3;
static long_filename long_name4;
static long_filename long_names1[MAX_DESS];
static long_filename long_names2[MAX_DESS];
INT_OS supreduce_flag;


static time_t start_time, stop_time;


long run_diff_time;

//static INT_T s_global_labellist = 0;
//static event_label *global_labellist = NULL;


INT_T get_integer_label(char *str_label, INT_T *index)
{
	INT_T i;

	if(strcmp(str_label, "-1") == 0)
		return -1;

	if(IsNumericalLabel(str_label, 4)){		
		return atoi(str_label);
	}

	//check if eventlabel is in the current labellist
	for(i = 0; i< s_global_labellist; i ++){
		if(strcmp(str_label, global_labellist[i].strlabel) == 0){
			*index = i;
			return global_labellist[i].intlabel;
		}
	}

	return START_INTLABEL - 1;
}


void add_label_to_labellist_file(INT_T newIntLabel, char *newStrLabel)
{
	char  global_labellist_file_txt[MAX_PATH];
	FILE *file;
	char TempPath[MAX_PATH];

	_getcwd(TempPath, MAX_PATH);
	_chdir(prefix);

	strcpy(global_labellist_file_txt,"");
	strcat(global_labellist_file_txt, "EVENTLIST.TXT");

//	if(_access(global_labellist_file_txt, 2) == -1){
//		_chdir(path);
//		return;
//	}

	file = fopen(global_labellist_file_txt, "a+"); 
	if(file == NULL){ 
		_chdir(TempPath);
		return;
	}

	fprintf(file, "%10.10s: %d\n", newStrLabel, newIntLabel);

	fclose(file);
	_chdir(TempPath);
	//clear();
}

INT_B IsNumericalLabel(char * strLabel, INT_T width)
{
	INT_T i;
	if(strlen(strLabel) > 4)
		return false;

	for(i = 0; i < strlen(strLabel); i ++){
		if(strLabel[i] >= 48 && strLabel[i] <= 57)
			continue;
		else 
			return false;
	}
	return true;
}

INT_T generate_integer_label(char *str_label, INT_B is_contrl, INT_T *index)
{
	INT_T i;
	INT_T newlabel;

	*index = -1;

	if(strcmp(str_label, "-1") == 0)
		return -1;

	if(IsNumericalLabel(str_label, 4)){		
		return atoi(str_label);
	}

	//check if eventlabel is in the current labellist
	for(i = 0; i< s_global_labellist; i ++){
		if(strcmp(str_label, global_labellist[i].strlabel) == 0){
			*index = i;
			return global_labellist[i].intlabel;
		}
	}

	global_labellist = (event_label *)REALLOC(global_labellist, sizeof(event_label) * (s_global_labellist + 1));
	if(global_labellist == NULL){
		mem_result = 1;
		return -1;
	}

	*index = s_global_labellist;

	strcpy(global_labellist[*index].strlabel, str_label);

	newlabel = START_INTLABEL + (*index)*2 + is_contrl; //Generate the new index automatically To be compatible with the old version (integer label from 0-9999)

	global_labellist[*index].intlabel = newlabel;

	s_global_labellist ++;

	add_label_to_labellist_file(newlabel, str_label);

	return newlabel;
}


void gen_global_labellist_from_file()
{
	char  global_labellist_file_txt[MAX_PATH];
	FILE *file;
	char oneline[30];
	char *tok;
	char strLabel[WIDTH_EVENT];
	INT_T intLabel;
	char TempPath[MAX_PATH];

	_getcwd(TempPath, MAX_PATH);
	_chdir(prefix);

	strcpy(global_labellist_file_txt,"");
	strcat(global_labellist_file_txt, "EVENTLIST.TXT");

	//if ((_access(global_labellist_file_txt, 0) ==0) && (_access(global_labellist_file_txt, 4) ==0)){
		file = fopen(global_labellist_file_txt, "r"); // If there does not exist the EVENTLIST.TXT, create and open it.
		if(file == NULL){ 
			_chdir(TempPath);
			return;
		}
		//skip the first two lines
		//fgets(oneline, 100, file); 
		//fgets(oneline, 100, file);

		while(fgets(oneline, 100, file) != NULL){
			tok = strtok(oneline, ":");
			strcpy(strLabel, tok);
			while(strLabel[0] == ' '){
				memcpy(strLabel, &(strLabel[1]), strlen(strLabel));
			}
			tok = strtok(NULL, ":");
			intLabel = atoi(tok);

			global_labellist = (event_label *)REALLOC(global_labellist, sizeof(event_label) * (s_global_labellist + 1));
			if(global_labellist == NULL){
				mem_result = 1;
				fclose(file);
				_chdir(TempPath);
				return;
			}
			strcpy(global_labellist[s_global_labellist].strlabel, strLabel);

			global_labellist[s_global_labellist].intlabel = intLabel;

			s_global_labellist ++;
		}
	//}

	fclose(file);
	_chdir(TempPath);
}

void update_labellist_file()
{
	char  global_labellist_file_txt[MAX_PATH];
	FILE *file;
	INT_T i;
	char TempPath[MAX_PATH];

	_getcwd(TempPath, MAX_PATH);
	_chdir(prefix);

	strcpy(global_labellist_file_txt,"");
	strcat(global_labellist_file_txt, "EVENTLIST.TXT");

//	if(_access(global_labellist_file_txt, 2) == -1){
//		_chdir(TempPath);
//		return;
//	}

	file = fopen(global_labellist_file_txt, "w+"); // If there does not exist the EVENTLIST.TXT, create and open it.
	if(file == NULL){ 
		_chdir(TempPath);
		return;
	}

	//fprintf(file, "Event name: Integer Label\n----------------------------\n");

	for(i = 0; i < s_global_labellist; i ++){
		fprintf(file, "%10.10s: %d\n", global_labellist[i].strlabel, global_labellist[i].intlabel);
	}

	fclose(file);
	_chdir(TempPath);
	//clear();
}

void fprintf_event(FILE *out, INT_T intLabel)
{
	char strLabel[WIDTH_EVENT];

#if defined(_x64_)
	if(intLabel < START_INTLABEL){
		if(intLabel == EEE)
			fprintf(out, "e");
		else
			fprintf(out, "%d", intLabel);	
	}
	else{
		get_strlabel_by_intlabel(intLabel, strLabel);
		fprintf(out, "%s", strLabel);
	}
#else
	if(intLabel == EEE)
		fprintf(out, "e");
	else
		fprintf(out, "%d", intLabel);
#endif
}


#define SEPC  '\\'
#define SEP   "\\"




void setuserpath(char *ini_file)
{
   FILE *in, *out;
   INT_B  use_default = false;
   char currentDir[256];
   INT_OS err;
   INT_OS clock;
   char clock_str[10];

   /* A defect in some version of Linux code dump if it is provided 
      with a non-existent file.   This is a workaround. */
   if (_access(ini_file, 0) != 0)
   {
      use_default = true;
   } 
   else
   {   
      in = fopen(ini_file, "rt");
      if (in == NULL)
      {
         use_default = true;
      }
      else
      {
/*         fscanf(in, "%s", path); */
         fgets(path, 255, in);
         if (path[strlen(path)-1] == '\n')
           path[strlen(path)-1] = '\0';

         _getcwd(currentDir, 255);
         if (_chdir(path) == -1)
            use_default = true;
         else
         {
            strcpy(prefix, path);
            strcat(prefix, SEP);
         }
         _chdir(currentDir);
         
         /* Attempt to read the clock setting if any */
         err = fscanf(in, "%s %d", clock_str, &clock);
         if (err > 0)
         {
            if (strcmp(clock_str, "CLOCK") == 0)
               timing_mode = clock;
         }      

         fclose(in);
       }
   }

   if (use_default)
   {
      _getcwd(path, 255);

      if (path[strlen(path)-1] != SEPC)
        strcat(path, SEP);
      strcat(path, "user");

      strcpy(prefix, path);
      strcat(prefix, SEP);
   }

   dos_uppercase(path);
   dos_uppercase(prefix);

   out = fopen(ini_file, "wt");
   if (out != NULL)
   {
      fprintf(out, "%s\n", path);
      fprintf(out, "CLOCK %d\n", timing_mode);
      fclose(out);
   }
}

void not_yet()
{
   clear();
   move(1,2); addstr("Not yet available! ");
   move(2,2); addstr("Press a key to continue ");
   refresh();

   read_key();
}

void user_pause()
{
   char ch;

   move(23,0); clrtoeol();
   printw("Press <Enter> to return to %s Procedures  ", TCTNAME);
   refresh();
   ring_bell();
   do {
     ch = read_key();
   } while (ch != CEnter);
}

void echo_save(char *name)
{
   INT_OS name_len, longname_len, msg_len, i, prefix_to_print;
   char msg[] = " has been filed as ";   
   INT_B  two_lines = false;
   
   name_len     = (INT_OS)strlen(name);
   longname_len = name_len + (INT_OS)strlen(prefix) + (INT_OS)strlen(EXT_DES);
   msg_len      = (INT_OS)strlen(msg);
   
   if ((name_len + longname_len + msg_len) >= SCREEN_WIDTH)
     two_lines = true;

   move(20,0); clrtoeol();
   move(21,0); clrtoeol();
   move(22,0); clrtoeol();
   move(21,0);
   
   printw("%s%s", name, msg);
   if (two_lines) 
      move(22,0);   
      
   if (longname_len >= SCREEN_WIDTH)
   {
      prefix_to_print = SCREEN_WIDTH - name_len - (INT_OS)strlen(EXT_DES) - 7;
      for (i=0; i < 3; i++)
        printw("%c", prefix[i]);
      printw("...");
      for (i=((INT_OS)strlen(prefix) - prefix_to_print); i < (INT_OS)strlen(prefix); i++)
         printw("%c", prefix[i]);
      printw("%s%s", name, EXT_DES);
   }
   else 
   {   
      printw("%s%s%s", prefix, name, EXT_DES);
   }
   
   refresh();
   user_pause();
}

void echo_free()
{
   //move(22,0); clrtoeol();
   //move(23,0); clrtoeol();
   //printw("Freeing memory:  Please wait...");
  // refresh();
}



void project_header_continue1() {
	printw("PROJECT"); println();
	println();
	printw("%s = PROJECT (%s, NULL/IMAGE/IMAGE_DES)", name2, name1); println();
	println();
}
void CanSQC_header_continue1() {
	printw("SUPREMAL STRONG QUASI-CONGRUENCE"); println();
	println();
	printw("%s = SUPSQC (%s, NULL/IMAGE/IMAGE_DES)", name2, name1); println();
	println();  
}     

void CanQC_header_continue1() {
	printw("SUPREMAL QUASI-CONGRUENCE"); println();
	println();
	printw("%s = SUPQC (%s, NULL/IMAGE/IMAGE_DES)", name2, name1); println();
	println();  
} 
void supnorm_header_continue1()
{
	printw("SUPNORM"); println();
	println();
	printw("%s = SUPNORM (%s, %s, NULL/IMAGE/IMAGE_DES)", name3, name1, name2); println();
	println();
}
void supscop_header_continue1() {
	printw("SUPSCOP"); println();
	println();
	printw("%s = SUPSCOP (%s, %s, NULL/IMAGE/IMAGE_DES)", name3, name1, name2); println();
	println();
}
void oc_header_continue1()
{
	printw("OBSERVABLILITY"); println();
	println();
	printw("OBS (%s, %s, NULL/IMAGE/IMAGE_DES)", name1, name2);println();
	println();
}
void soc_header_continue1()
{
	printw("STRONG OBSERVABLILITY"); println();
	println();
	printw("SOBS (%s, %s, NULL/IMAGE/IMAGE_DES)", name1, name2);println();
	println();
}
void supobs_header_continue1()
{
	printw("SUPROBS"); println();
	println();
	printw("%s = SUPROBS (%s, %s, NULL/IMAGE/IMAGE_DES)", name3, name1, name2); println();
	println();
}

void supconrobs_header_continue1()
{
	printw("SUPCONROBS"); println();
	println();
	printw("%s = SUPCONROBS (%s, %s, NULL/IMAGE/IMAGE_DES)", name3, name1, name2); println();
	println();
}
void uncertmod_header_continue1()
{
	printw("UNCERTMOD"); println();
	println();
	printw("%s = UNCERTMOD (%s, NULL/IMAGE/IMAGE_DES)", name2, name1); println();
	println();
}

void image_header(INT_S oper)
{
	switch(oper){
	case 0: project_header_continue1();		break;
	case 1: CanQC_header_continue1();		break;
	case 2: CanSQC_header_continue1();		break;
	case 3: supscop_header_continue1();		break;
	case 4: supnorm_header_continue1();		break;
	case 5: oc_header_continue1();			break;
	case 6: soc_header_continue1();			break;
	case 7: supobs_header_continue1();		break;
	case 8: supconrobs_header_continue1();	break;
	case 9: uncertmod_header_continue1();	break;
	default:						break;
	}
}

void project_header_continue2(INT_OS entry_type)
{
	printw("PROJECT"); println();
	println();
	printw("%s = PROJECT (%s, ", name2, name1); 
	switch(entry_type){
	case 1: printw("NULL");			break;
	case 2: printw("IMAGE");		break;
	case 3: printw("IMAGE_DES");		break;
	default:						break;
	}
	printw(")");
	println();
	println();
}
void CanSQC_header_continue2(INT_OS entry_type)
{
	printw("SUPREMAL STRONG QUASI-CONGRUENCE"); println();
	println();
	printw("%s = SUPSQC (%s, %s, ", name3, name1, name2); 
	switch(entry_type){
	case 1: printw("NULL");			break;
	case 2: printw("IMAGE");		break;
	case 3: printw("IMAGE_DES");		break;
	default:						break;
	}
	printw(")");
	println();
	println();
}
void CanQC_header_continue2(INT_OS entry_type)
{
	printw("SUPREMAL QUASI-CONGRUENCE"); println();
	println();
	printw("%s = SUPQC (%s, %s, ", name3, name1, name2); 
	switch(entry_type){
	case 1: printw("NULL");			break;
	case 2: printw("IMAGE");		break;
	case 3: printw("IMAGE_DES");		break;
	default:						break;
	}
	printw(")");
	println();
	println();
}
void supnorm_header_continue2(INT_OS entry_type)
{
	printw("SUPNORM"); println();
	println();
	printw("%s = SUPNORM (%s, %s, ", name3, name1, name2); 
	switch(entry_type){
	case 1: printw("NULL");			break;
	case 2: printw("IMAGE");		break;
	case 3: printw("IMAGE_DES");		break;
	default:						break;
	}
	printw(")");
	println();
	println();
}
void supscop_header_continue2(INT_OS entry_type)
{
	printw("SUPSCOP"); println();
	println();
	printw("%s = SUPSCOP (%s, %s, ", name3, name1, name2); 
	switch(entry_type){
	case 1: printw("NULL");			break;
	case 2: printw("IMAGE");		break;
	case 3: printw("IMAGE_DES");		break;
	default:						break;
	}
	printw(")");
	println();
	println();
}
void oc_header_continue2(INT_OS entry_type)
{
	printw("OBSERVABLILITY"); println();
	println();
	printw("OBS (%s, %s, ", name1, name2); 
	switch(entry_type){
	case 1: printw("NULL");			break;
	case 2: printw("IMAGE");		break;
	case 3: printw("IMAGE_DES");		break;
	default:						break;
	}
	printw(")");
	println();
	println();
}

void soc_header_continue2(INT_OS entry_type)
{
	printw("STRONG OBSERVABLILITY"); println();
	println();
	printw("SOBS (%s, %s, ", name1, name2); 
	switch(entry_type){
	case 1: printw("NULL");			break;
	case 2: printw("IMAGE");		break;
	case 3: printw("IMAGE_DES");		break;
	default:						break;
	}
	printw(")");
	println();
	println();
}

void supobs_header_continue2(INT_OS entry_type)
{
	printw("SUPROBS"); println();
	println();
	printw("%s = SUPROBS (%s, %s, ", name3, name1, name2); 
	switch(entry_type){
	case 1: printw("NULL");			break;
	case 2: printw("IMAGE");		break;
	case 3: printw("IMAGE_DES");		break;
	default:						break;
	}
	printw(")");
	println();
	println();
}

void supconrobs_header_continue2(INT_OS entry_type)
{
	printw("SUPCONROBS"); println();
	println();
	printw("%s = SUPCONROBS (%s, %s, ", name3, name1, name2); 
	switch(entry_type){
	case 1: printw("NULL");			break;
	case 2: printw("IMAGE");		break;
	case 3: printw("IMAGE_DES");		break;
	default:						break;
	}
	printw(")");
	println();
	println();
}
void uncertmod_header_continue2(INT_OS entry_type)
{
	printw("UNCERTMOD"); println();
	println();
	printw("%s = UNCERTMOD (%s, ", name2, name1); 
	switch(entry_type){
	case 1: printw("NULL");			break;
	case 2: printw("IMAGE");		break;
	case 3: printw("IMAGE_DES");		break;
	default:						break;
	}
	printw(")");
	println();
	println();
}
void image_header_entry(INT_S oper, INT_OS entry_type)
{
	switch(oper){
	case 0: project_header_continue2(entry_type);		break;
	case 1: CanQC_header_continue2(entry_type);			break;
	case 2: CanSQC_header_continue2(entry_type);		break;
	case 3: supscop_header_continue2(entry_type);		break;
	case 4: supnorm_header_continue2(entry_type);		break;
	case 5: oc_header_continue2(entry_type);			break;
	case 6: soc_header_continue2(entry_type);			break;
	case 7: supobs_header_continue2(entry_type);		break;
	case 8: supconrobs_header_continue2(entry_type);	break;
	case 9: uncertmod_header_continue2(entry_type);		break;
	default:						break;
	}
}
void get_imagelist(INT_T *s_imagelist, INT_T**imagelist, INT_T *slist, INT_T **list, INT_S *mode, INT_S oper)
{
	INT_S	s2; 
	state_node *t2;
	INT_S      init;
	INT_T      i,j;
	short      sign_i;
	INT_B    ok;
	char       ch;
	int        row, col;
	char tmp1[80];  
	char tmp2[80]; 
	char strlabel[WIDTH_EVENT];
	INT_T index;
	
	s2 = 0; 	t2 = NULL;

	strcpy(tmp1, "");
	switch(oper){
	case 0: strcat(tmp1, "erased by projection");		break;
	case 3: strcat(tmp1, "erased by supscop");			break;
	case 4: strcat(tmp1, "erased by supnorm");			break;

	case 1: 
	case 2:
	case 5:
	case 6:
	case 7:
	case 8: 
	case 9: strcat(tmp1, "erased");						break;
	default:											break;
	}

	strcpy(tmp2, "");
	switch(oper){
	case 0: strcat(tmp2, "nulled by projection");		break;
	case 3: strcat(tmp2, "nulled by supscop");			break;
	case 4: strcat(tmp2, "nulled by supnorm");			break;

	case 1: 
	case 2: 
	case 5:
	case 6:
	case 7: 
	case 8: 
	case 9: strcat(tmp2, "nulled");						break;
	default:											break;
	}

	if (_wherey() > 12)
	{
		clear();
		image_header(oper);
		esc_footer();
	}   

	println();
	printw("Enter either"); println();
	println();
	printw("  NULL (list of event labels %s)", tmp1); println();
	println();
	printw("or"); println();
	println();
	printw("  IMAGE (event labels retained)"); println();
	println();
	printw("or"); println();
	println();
	printw("  IMAGE_DES (single-state, marked, selflooped) DES representing list"); println(); 
	printw("	   of event labels retained)"); println();
	println();


	do {
		if (_wherey() > 20)
		{
			clear();
			image_header(oper);
			esc_footer();
		}    

		printw("NULL/IMAGE/IMAGE_DES ? (n/i/d) ");
		refresh();
		ch = read_key();
		if (ch == CEsc) {
			quit = true;
			return;
		}   

		if (ch != CEnter) {
			printw("%c", ch);
		}
		println();
		println();
	} while (strchr(ImageCommandSet, ch) == NULL);

	if ((ch == 'N') || (ch == 'n'))
		*mode = 1;
	else if((ch == 'I') || (ch == 'i'))
		*mode = 2;
	else
		*mode = 3;

	if (*mode == 1)
	{
		printw("Enter list of event labels to be %s;", tmp2); println();
		printw("terminate list with -1."); println();
		println();  tab(5);
		sign_i = 0;
		while (sign_i != -1) {
			col = _wherex();
			row = _wherey();
			if (col >= 75) {
				move(row+1,5);
				col = 5;
				row++;
			}
			if (_wherey() > 21) {
				clear();
				image_header_entry(oper, (INT_OS)*mode);
				esc_footer();
				printw("Enter list of event labels to be %s;", tmp2); println();
				printw("terminate list with -1."); println();
				println(); tab(5);
				esc_footer();
				col = _wherex();
				row = _wherey();
			}
#if defined(_x64_)
			ch = read_string(strlabel, 1, WIDTH_EVENT);
			if (ch == CEsc) {
				quit = true; return;
			}
			sign_i = (short) get_integer_label(strlabel, &index);

			if(sign_i == START_INTLABEL - 1){
				println(); println();
				printw("Event [%s] does not exist; please re-enter and continue the list:", strlabel);println();
				printw("terminate list with -1."); println();
				println(); tab(5);
				esc_footer();
			}else if (sign_i != -1) {
				i = (INT_T) sign_i;
				addordlist(i, list, *slist, &ok);
				if (ok) (*slist)++;

				move(row, col+10);
			}

#else
			sign_i = (short) readint_and_e(&ch, -1, MAX_TRANSITIONS);
			if (ch == CEsc) {
				quit = true;
				return;
			}			
			if (sign_i != -1) {
				i = (INT_T) sign_i;
				addordlist(i, list, *slist, &ok);
				if (ok) (*slist)++;
			}
			move(row, col+7);
#endif

		}
		println(); println();

	}
	else if(*mode == 2)
	{
		printw("Enter list of event labels to be retained;"); println();
		printw("terminate list with -1."); println();
		println();  tab(5);
		sign_i = 0;
		while (sign_i != -1) {
			col = _wherex();
			row = _wherey();
			if (col >= 75) {
				move(row+1,5);
				col = 5;
				row++;
			}
			if (_wherey() > 21) {
				clear();
				clear();
				image_header_entry(oper, (INT_OS)*mode);
				esc_footer();
				printw("Enter list of event labels to be retained;"); println();
				printw("terminate list with -1."); println();
				println(); tab(5);
				esc_footer();
				col = _wherex();
				row = _wherey();
			}
#if defined(_x64_)
			ch = read_string(strlabel, 1, WIDTH_EVENT);
			if (ch == CEsc) {
				quit = true; return;
			}
			sign_i = (short) get_integer_label(strlabel, &index);

			if(sign_i == START_INTLABEL - 1){
				println(); println();
				printw("Event [%s] does not exist; please re-enter and continue the list:", strlabel);println();
				println(); tab(5);
				esc_footer();
			}else if (sign_i != -1) {
				i = (INT_T) sign_i;
				addordlist(i, imagelist, *s_imagelist, &ok);
				if (ok) (*s_imagelist)++;

				move(row, col+10);
			}
#else

			sign_i = (short) readint_and_e(&ch, -1, MAX_TRANSITIONS);
			if (ch == CEsc) {
				quit = true;
				return;
			}
			if (sign_i != -1) {
				i = (INT_T) sign_i;
				addordlist(i, imagelist, *s_imagelist, &ok);
				if (ok) (*s_imagelist)++;
			}
			move(row, col+7);
#endif
		}
		println(); println();

	}else{
		quit = getname("Enter name of IMAGE_DES  .........  ", 
			EXT_DES, imagename, false);
		if (quit) return;

		init = 0L;
		if(getdes(imagename, &s2, &init, &t2)){
			for(i = 0; i < s2; i ++){
				for(j = 0; j < t2[i].numelts; j ++){
					addordlist(t2[i].next[j].data1, imagelist, *s_imagelist, &ok);
					if(ok) (*s_imagelist) ++;
				}
			}
		}
		freedes(s2, &t2);
	}
}

void print_eventlist(INT_T s_eventlist, INT_T * eventlist)
{
	INT_T i;
	int col, row;

	println(); tab(5);         
	for(i = 0; i< s_eventlist; i++){
		col = _wherex();
		row = _wherey();
		if(col > 75){
			move(row + 1, 5);
			col = 5;
			row ++;
		}
		if(_wherey()> 20){
			printw("Extended event label list is:"); println();
			println(); tab(5);                 
			col = _wherex();
			row = _wherey();
		}
		printw("%d", eventlist[i]);
		move(row, col + 7);
	}
}

static char makeit_filename[80];

char *get_makeit()
{
    strcpy(makeit_filename, prefix);
    strcat(makeit_filename, "MAKEIT.TXT");

    return makeit_filename;
}

void mergeChop(INT_OS offset)
{
   char tempstr[255];
   FILE *in, *out;
   INT_OS col;
   char ch;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;

   setvbuf(out, NULL, _IOFBF, 4000);

   memset(tempstr, ' ', offset);
   tempstr[offset] = '\0';

   in = fopen("tmp.$$$", "r");
   col = 0;
   while ( (ch = fgetc(in)) && (!feof(in)) ) {
      col++;
      if (ch == '\n') {
        col = 0;
      } else if (col >= 75) {
        if (ch != '\n') {
           fprintf(out, "\n");
           fprintf(out, "%s", tempstr);
           col = offset+1;
        }
     }
     fprintf(out, "%c", ch);
   }

   fclose(in);
   fclose(out);

   /* Remove tempory file */
   _unlink("tmp.$$$");
}

void mark_start_time()
{
   start_time = time(NULL);
}

void mark_stop_time()
{
   stop_time = time(NULL);
}


char *cdifftime(time_t s1, time_t s2)
{
   static char timestr[80];
   double diff_sec;
   long d_diff_sec;
   INT_OS d_sec;
   INT_OS d_min;
   INT_OS d_hour;
   INT_OS d_days;
   
   diff_sec = difftime(s2, s1);
   d_diff_sec = (long) diff_sec;
   
   d_sec  = (int) (long) (d_diff_sec) % 60;
   d_min  = (int) ((long) (d_diff_sec / 60)) % 60;
   d_hour = (int) ((long) (d_diff_sec / 60 / 60)) % 24;
   d_days = (int) ((long) (d_diff_sec / 60 / 60 / 24));
   
   /* difftime returns a double */
/*   sprintf(timestr, "%6.0f sec", difftime(s2,s1));  */

   if (d_days > 0)
   {
      sprintf(timestr, "%d (days) %02d:%02d:%02d", 
                       d_days, d_hour, d_min, d_sec);
   } 
   else          
   {
      sprintf(timestr, "%02d:%02d:%02d",
                       d_hour, d_min, d_sec); 
   }
   
   return timestr;
}

char *cdifftime1(time_t s1, time_t s2)
{
   static char timestr[80];
/*   double diff_sec; */
   long d_diff_sec;
   INT_OS d_sec;
   INT_OS d_min;
   INT_OS d_hour;
   INT_OS d_days;
   
   d_diff_sec = run_diff_time;
   
   d_sec  = (int) (long) (d_diff_sec) % 60;
   d_min  = (int) ((long) (d_diff_sec / 60)) % 60;
   d_hour = (int) ((long) (d_diff_sec / 60 / 60)) % 24;
   d_days = (int) ((long) (d_diff_sec / 60 / 60 / 24));

   if (d_days > 0)
   {
      sprintf(timestr, "%d (days) %02d:%02d:%02d", 
                       d_days, d_hour, d_min, d_sec);
   } 
   else          
   {
      sprintf(timestr, "%02d:%02d:%02d",
                       d_hour, d_min, d_sec); 
   }
   
   return timestr;
}

void snap_run_difftime()
{
   double diff_sec;
   
   diff_sec = difftime(stop_time, start_time);
   run_diff_time += (long) diff_sec;     
}

void appendTime1(FILE *out, INT_OS offset)
{
   char tempstr[40];

   if (timing_mode) {
      fprintf(out, "\n");

      memset(tempstr, ' ', offset);
      tempstr[offset] = '\0';
      fprintf(out, "%sComputing time = %s", tempstr,
         cdifftime1(start_time, stop_time));
   }
}


 
void appendTime(FILE *out, INT_OS offset)
{
   char tempstr[40];

   if (timing_mode) {
      fprintf(out, "\n");

      memset(tempstr, ' ', offset);
      tempstr[offset] = '\0';
      fprintf(out, "%sComputing time = %s", tempstr,
         cdifftime(start_time, stop_time));
   }
}

/* Update the string to uppercase if we are running in DOS */
char *dos_uppercase(char *string)
{
   INT_OS length, i;

   length = (INT_OS)strlen(string);
   for (i=0; i<length; i++) {
      string[i] = toupper(string[i]);
   }
   return string;
}

void FILEDES(char*       name,
             INT_S       size,
             INT_S       init,
             state_node *data)
{
   if (filedes(name, size, init, data) != 0) {
      quit = true;
      move(22,0); clrtoeol();
      if (init != -1L) {
         printw("Error writing file: %s%s%s", prefix, name, EXT_DES);
      } else {
         printw("Error writing file: %s%s%s", prefix, name, EXT_DAT);
      }
      user_pause();
   }
}

void display_conflict_tran(triple* list,
                           INT_S s_list,
                           INT_S size)
{
   INT_S i, count;
   char ch;
   short curLabel;
   INT_OS mod_factor;
   
   if (size > 100000)   /* Range of states is is 0..size-1 */
      mod_factor = 3;
   else
      mod_factor = 4;   

   println();
   printw("Nondeterministic transitions: ");

   curLabel = -1;
   i = 0; count = 0;
   do {
      if (_wherey() > 19) {
        move(23,0);
        printw("Press <Enter> to page transitions  ");
        refresh();
        do {
           ch = read_key();
        } while (ch != CEnter);
        clear();
        esc_footer();
        println();
        printw("Nondeterministic transitions: "); println();
      }

      if (((short) list[i].e) != curLabel) {
        if ( (count % mod_factor) != 0) println();
        count = 0;
        println();
        curLabel = (short) list[i].e;
      }

      if (mod_factor == 4) {
        if (list[i].e == EEE)
           printw("[%5ld,  e,%5ld]  ", list[i].i, list[i].j);
        else  
           printw("[%5ld,%3d,%5ld]  ", list[i].i, list[i].e, list[i].j);
      } else {
        if (list[i].e == EEE)
           printw("[%7ld,  e,%7ld]   ", list[i].i, list[i].j); 
        else
           printw("[%7ld,%3d,%7ld]   ", list[i].i, list[i].e, list[i].j);        
      }  
      count++;
      if ( (count % mod_factor) == 0 ) println();
      i++;

   } while (i < s_list);
   println();
}

void assign_event_control_status(state_node **t1, INT_S *s1, INT_T s_eventlist, INT_T *eventlist, INT_B * quit)
{
	INT_S i;
	INT_T cur;
	INT_B  ok, bUpdate;
	char ch;
	state_pair *sp;
	INT_S s_sp;

	state_node *t2;
	INT_S s2;

	INT_T s_list, *list;
		
	sp = NULL; s_sp = 0;
	t2 = NULL; s2 = 0;
	list = NULL; s_list = 0;

	clear();
   esc_footer();
   println();
   printw("Assign control status of new events with alphabetical labels?  (y/*n)  ");
   refresh();
   ch = read_key();
   if (ch == CEnter) {
      println();
   } else {
      printw("%c", ch);
   }

   println();
   if (ch == CEsc) {
     *quit = true;
     return;
   }

   bUpdate = 0;

   if ( (ch == 'Y') || (ch == 'y') ) {
	   for(i = 0; i < s_eventlist; i++)
	   {
		   cur = eventlist[i];
		   println();
		   printw("Assign event %s as controllable or uncontrollable (*c/u)", global_labellist[cur].strlabel);
		   refresh();
		   ch = read_key();
		   if (ch == CEnter) {
			  // println();
		   } else {
			   printw("%c", ch);
		   }
		   println();
		   if (ch == CEsc) {
			   *quit = true;
			   return;
		   }

		   if ( (ch == 'U') || (ch == 'u') ) {

			   global_labellist[cur].intlabel -= 1;  //The default intlabel is odd (controllable). If the event is changed as uncontrollable, the intlabel should be changed as even.
			   bUpdate = 1;

			   addstatepair(global_labellist[cur].intlabel+1, global_labellist[cur].intlabel, &sp, s_sp, &ok);
			   if (ok) s_sp++;
		   }
	   }

	   export_copy_des(&s2, &t2, *s1, *t1);

	   freedes(*s1, t1); *s1 = 0; *t1 = NULL;

	   eventmap_des(t2,s2,t1,s1,sp,s_sp,&list,&s_list,&ok);

	   if (s_list != 0) {
		   project0(s1,t1,s_list,list);
		   free(list);
	   }
	   
	   freedes(s2, &t2);
   }
   if(bUpdate == 1){
	   update_labellist_file();
   }
}

void check_determinism(state_node* t1, INT_S s1,
                       char* name, INT_B * quit, INT_B  flag)
{
   INT_S i, curEntrance;
   INT_T j, cur;
   INT_B  first, ok;
   triple *nonDetList;
   INT_S s_nonDetList;
   char ch;

   nonDetList = NULL; s_nonDetList = 0;
   cur = 0;

   clear();
   esc_footer();
   println();
   printw("Check %s for nondeterminism?  (y/*n)  ", name);
   refresh();
   ch = read_key();
   if (ch == CEnter) {
      println();
   } else {
      printw("%c", ch);
   }

   println();
   if (ch == CEsc) {
     *quit = true;
     return;
   }

   if ( (ch == 'Y') || (ch == 'y') ) {
      for (i=0; i< s1; i++) {
         first = true;
         if (t1[i].numelts > 0) {
             cur = t1[i].next[0].data1;
             curEntrance = t1[i].next[0].data2;
             
             if (cur == EEE) { /* "e" = EEE */
                 addtriple(i,cur,curEntrance, &nonDetList, s_nonDetList, &ok);
                 if (ok) s_nonDetList++;
             }             
         }
         for (j=1; j < t1[i].numelts; j++) {
            if (cur == t1[i].next[j].data1) {
               if (first) {
                  addtriple(i,cur,curEntrance, &nonDetList, s_nonDetList, &ok);
                  if (ok) s_nonDetList++;
               }
               first = false;
               addtriple(i,cur,t1[i].next[j].data2, &nonDetList, s_nonDetList, &ok);
               if (ok) s_nonDetList++;
            } else if (t1[i].next[j].data1 == EEE) {   
               addtriple(i,EEE,t1[i].next[j].data2, &nonDetList, s_nonDetList, &ok);
               if (ok) s_nonDetList++;    
            } else {
               first = true;
               cur = t1[i].next[j].data1;
               curEntrance = t1[i].next[j].data2;
            }
         }
      }

      println();
      if (s_nonDetList == 0) {
         printw("%s is OK.", name);
      } else {
         printw("WARNING: %s is nondeterministic!", name); println();
         display_conflict_tran(nonDetList, s_nonDetList, s1);
         if (_wherey() > 19) {
            clear();
            esc_footer();
         }
         println();
         printw("Please revise %s using the editor.", name); println();
      }

      /* Prompt user to continue? */
      if (flag) {
        move(23,0);
        printw("Press <Enter> to continue  ");
        refresh();
        do {
           ch = read_key();
        } while (ch != CEnter);
      }
   }

   if (nonDetList != NULL) free(nonDetList);
}

void create_header()
{
   printw("CREATE"); println();
   println();
}

void create_states()
{
   println();
   printw("States will be numbered 0,1,2,3,...."); println();
   printw("The initial state is 0."); println();
   println();
   printw("Enter total number of states...  ");
}

void create_name()
{
   printw("CREATE(%s)", name1); println();
   println();
}

void create_marker()
{
   println();
   printw("Enter list of marker states in {0,1,...,Size-1}"); println();
   printw("To mark all states, enter '*'"); println();
   println();
   printw("To quit, enter -1"); println();
   println();
}

void create_vocal()
{
   println();
   printw("Enter vocal states with output: integer in 10,...,99"); println();
   println();
   printw("To quit, enter -1 for State."); println();
   println();
}

void create_transitions()
{
    println();
    printw("Enter transitions using:"); println();
    println();
    printw("   States    : integers 0,1,2,...,Size-1"); println();
	printw("   Events    : even integers 0,2,4,... <= 9998 and e (uncontrollable events)"); println();
	printw("               odd integers 1,3,5,... <= 9999 (controllable events)"); println();
	printw("               or alphabetical labels (1-%d characters);",WIDTH_EVENT); println();

	
    println();
    printw("To quit, enter -1 for Exit State."); println();
    println();
}

void create_r(state_node **t1,
              INT_S *s1)
{
   INT_S   i,j;
   INT_T   e;
   INT_S   mark, state, init;
   INT_V   vocal_output;
   INT_B  ok;
   char    ch;
   INT_OS     row, col, a;
   short   sign_i;
   char eventlabel[WIDTH_EVENT];
   INT_T s_local_eventlist;
   INT_T* local_eventlist;
   INT_T index;

   clear();
   create_header();
   refresh();

   quit = getname("Enter name of DES ....  ", EXT_DES, name1, true);
   if (quit) return;

   create_states();
   esc_footer();
   refresh();
   *s1 = (INT_S) readint(&ch, 0, MAX_STATES);
   if (ch == CEsc) {
     quit = true;
     return;
   }

   *t1 = newdes(*s1);
   if ((*s1 != 0) && (*t1 == NULL)) {
      mem_result = 1;
      return;
   }

   println();

   /* Get marker states */
   create_marker();
   do {
      col = _wherex();
      row = _wherey();
      if (col >= 75) {
         move(row+1,0);
         col = 0;
         row++;
      }
      if (_wherey() > 21) {
         clear();
         create_name();
         create_marker();
         println();
         println();
         esc_footer();
         col = _wherex();
         row = _wherey();
      }

      mark = (INT_S) readintall(&ch, -1, (*s1)-1);
      if (ch == CEsc) {
          quit = true;
          return;
      }
      if (ch == '*')
      {
          for (i=0; i < *s1; i++)
             (*t1)[i].marked = true;
          break;
      }
      if (mark != -1) {
         (*t1)[mark].marked = true;
      }
      if (col+10 >= 75) {
         move(row+1,0);
         col = 0;
         row++;
      } else {
         move(row, col+10);
      }
   } while (mark != -1);

   /* Get Vocal states */
   clear();
   create_name();
   create_vocal();
   esc_footer();
   do {
      if (_wherey() > 21) {
         col = _wherex(); row = _wherey()-1;
         move(23, 0); clrtoeol();
         move(24, 0);
         scroll_line();

         for (a=0; a < 7; a++) {
            move(a,0); clrtoeol();
         }

         move(0,0);
         create_name();
         create_vocal();
         esc_footer();
         move(row, col);

/*       clear();
         create_vocal();
         println();
         println();
         esc_footer(); */
      }

      printw("State:  ");
      state = (INT_S) readint(&ch, -1, (*s1)-1);
      if (ch == CEsc) {
          quit = true; return;
      }
	  if(state == 0){
		  println();
		  println();
		  printw("Direct vocalization of initial state is illegal! Please reenter.");println();
		  println();
		  continue;
	  }
      if (state == -1) break;

      tab(20);
      printw("Output:  ");
      vocal_output = (INT_V) readint(&ch, 10, MAX_VOCAL_OUTPUT);
      if (ch == CEsc) {
         quit = true; return;
      }
      if (vocal_output == -1) break;
      println();

      (*t1)[state].vocal = vocal_output;
   } while (state != -1);

   /* Add the transitions */
   s_local_eventlist = 0;
   local_eventlist = NULL;
   clear();
   create_name();
   create_transitions();
   esc_footer();
   do {
      if (_wherey() > 21) {
         col = _wherex(); row = _wherey()-1;
         move(23,0); clrtoeol();
         move(24,0);     
         scroll_line();         

         for (a=0; a < 11; a++) {
            move(a,0); clrtoeol();
         }

         move(0,0);
         create_name();
         create_transitions();
         esc_footer();
         
         move(row,col);
      }

      printw("Exit State:  ");
      i = (INT_S) readint(&ch, -1, (*s1)-1);
      if (ch == CEsc) {
          quit = true; return;
      }
      if (i == -1) break;

      tab(25);
      printw("Event Label:  ");

#if defined(_x64_)

	  ch = read_string(eventlabel, 1, WIDTH_EVENT);
      if (ch == CEsc) {
         quit = true; return;
      }
	  sign_i = (short) generate_integer_label(eventlabel, 1, &index);
#else
	  sign_i = (short) readint_and_e(&ch, -1, MAX_TRANSITIONS);
	  if (ch == CEsc) {
		  quit = true; return;
	  }
#endif
      if (sign_i == -1) break;
      e = (INT_T) sign_i;

      tab(50);
      printw("Entrance State:  ");
      j = (INT_S) readint(&ch, -1, (*s1)-1);
      if (ch == CEsc) {
         quit = true; return;
      }
      if (j == -1) break;
      println();

      addordlist1(e, j, &(*t1)[i].next, (*t1)[i].numelts, &ok);
      if (ok) (*t1)[i].numelts++;
#if defined(_x64_)
	  if(index != (INT_T)-1){
		  addordlist(index, &local_eventlist, s_local_eventlist, &ok);
		  if(ok) s_local_eventlist ++;
	  }
#endif

   } while (i != -1);

#if defined(_x64_)
   if(s_local_eventlist > 0){
		assign_event_control_status(t1, s1, s_local_eventlist, local_eventlist, &quit);
		free(local_eventlist);
		s_local_eventlist = 0; local_eventlist = NULL;
		 if(quit) return;
   }
#endif

   /* Check for non-determinism */
   check_determinism(*t1, *s1, name1, &quit, false);
   if (quit) return;

   init = 0L;
   if (mem_result != 1)
      FILEDES(name1, *s1, init, *t1);

   if (!quit) {
      refresh();
      echo_save(name1);
   }
}

//used to generate standard command line

void create_makeit(state_node *t1,
                   INT_S s1)
{
   FILE* out;
   INT_S i, j, size;
   INT_T k;
   INT_T intLabel;
   char strLabel[WIDTH_EVENT];

   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;

   fprintf(out, "%s = Create(%s", name1, name1);

   /* Mark list */
   size = num_mark_states(t1, s1); 
   if ((size == s1) && (s1 > 0)) {
      fprintf(out, ",[mark all]");  
   } else if (size > 0) {
      fprintf(out, ",");
      fprintf(out, "[mark ");
      j = 0;
      for (i=0; i < s1; i++) {
         if (t1[i].marked) {
            fprintf(out, "%ld", i);
            j++;
            if (j < size)
               fprintf(out, ",");
         }
      }
      fprintf(out, "]");
   }

   size = num_vocal_output(t1, s1);
   if (size > 0) {
      fprintf(out, ",");
      fprintf(out, "[voc ");
      j = 0;
      for (i=0; i < s1; i++) {
         if (t1[i].vocal > 0) {
            fprintf(out, "[%ld,%d]", i, t1[i].vocal);
            j++;
            if (j < size)
               fprintf(out, ",");
         }
      }
      fprintf(out, "]");
   }

   size = count_tran(t1, s1);
   if (size > 0) {
      fprintf(out, ",");
      fprintf(out, "[tran ");
      j = 0;
      for (i=0; i < s1; i++) {
         for (k=0; k < t1[i].numelts; k++) {
			intLabel = t1[i].next[k].data1;
			if(intLabel < START_INTLABEL){
				if (t1[i].next[k].data1 == EEE)
					fprintf(out, "[%ld,e,%ld]", i, t1[i].next[k].data2);
					else  
				fprintf(out, "[%ld,%d,%ld]", i, t1[i].next[k].data1, t1[i].next[k].data2);
			}else
			{
				get_strlabel_by_intlabel(intLabel, strLabel);
				fprintf(out, "[%ld,%s,%ld]", i, strLabel ,t1[i].next[k].data2);
			}
            j++;
            if (j < size)
               fprintf(out, ",");
          }
      }
      fprintf(out, "]");
   }
   fprintf(out, ")");

   fprintf(out, "  (%ld,%ld)\n\n", s1, size);
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop((INT_OS)strlen(name1)+3);
}



INT_OS ask_create_r()
{
   INT_OS option;
   char ch;

   clear();
   create_header();
   esc_footer();
   refresh();

   println();
   printw("1. .DES file (prompts user to enter DES data fast and sequentially;"); println();
   printw("   any entry errors can be corrected later using Edit)"); println();
   println();
   printw("2. .ADS file (provides user with DES template for flexible ASCII"); println();
   printw("   text file editing)"); println();

   println();
   println();
   printw("Please choose Option 1 or 2 ....  ");

   option = (INT_OS)readint(&ch, 1, 2);
   if (ch == CEsc)
   {
     quit = true;
     return 1;
   }

   if (option == 1)
      return 0;

   println();
   println();
   printw("Generate ADS file with template"); println();
   println();

   quit = getname("Enter name of ADS ....  ", EXT_ADS, name1, true);
   if (quit) return 1;

   strcpy(long_name1, "");
   make_filename_ext(long_name1, name1, EXT_ADS);
   generate_ads_file(long_name1, name1);

   if (_wherey() > 17)
   {
      move(16,0); clrtoeol();
      move(17,0); clrtoeol();
      move(18,0); clrtoeol();
      move(19,0); clrtoeol();
      move(20,0); clrtoeol();
      move(21,0); clrtoeol();
      move(17,0);
   }
   println();
   printw("Now use your ASCII editor to complete the file"); println();
   print_fix_filename(long_name1, SCREEN_WIDTH); println();
   printw("return to %s, and use FD to convert", TCTNAME); println();
   printw("%s%s to %s%s", name1, EXT_ADS, name1, EXT_DES); println();
   user_pause();

   return 1;
}

void create_p()
{
   state_node *t1;
   INT_S s1;

   t1 = NULL;
   s1 = 0;

   if (ask_create_r()) {
       quit = true;
   } else {
       create_r(&t1, &s1);
   }

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   } else {
      if (!quit) {
        create_makeit(t1, s1);
      }
   }

   echo_free();
   freedes(s1, &t1);
}

void selfloop_header() {
   printw("SELFLOOP"); println();
   println();
   printw("DES2 = SELFLOOP (DES1, EVENT_LIST)"); println();
   println();
}

void selfloop_r(state_node **t1,
                INT_S *s1,
                INT_T **list,
                INT_T *slist)
{
   INT_S      init;
   INT_T      i;
   short      sign_i;
   INT_B     ok;
   char       ch;
   INT_OS        row, col;
   INT_OS        result;
   INT_T index;
   char strLabel[WIDTH_EVENT];

   clear();
   selfloop_header();
   quit = getname("Enter name of DES1 to be augmented ....  ",
                  EXT_DES, name1, false);
   if (quit) return;

   printw("Assign new name to %s?   (*y/n)   ", name1);
   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( (ch == 'N') || (ch == 'n') ) {
      strcpy(name2, name1);
      println();  println();
   } else {
      if (ch != CEnter) {
         printw("%c", ch);
      }
      println();
      println();
      quit = getname("Enter new name for DES2 ...............  ",
                     EXT_DES, name2, true);
      if (quit) return;
   }

   printw("Enter list of events to be adjoined.  Terminate list with -1.");
   println();  println();  tab(5);
   sign_i = 0;
   while (sign_i != -1) {
      col = _wherex();
      row = _wherey();
      if (col >= 75) {
         move(row+1,5);
         col = 5;
         row++;
      }
      if (_wherey() > 21) {
         clear();
         printw("Continue to enter list of events to be adjoined.  ");
         printw("Terminate list with -1.");
         println();
         println(); tab(5);
         esc_footer();
         col = _wherex();
         row = _wherey();
      }
#if defined(_x64_)
	  ch = read_string(strLabel, 1, WIDTH_EVENT);
	  if (ch == CEsc) {
		  quit = true; return;
	  }
	  sign_i = (short) generate_integer_label(strLabel, 1, &index);

	  if (sign_i != -1) {
		  i = (INT_T) sign_i;
		  addordlist(i, list, *slist, &ok);
		  if (ok) (*slist)++;

		  move(row, col+10);
	  }
#else
      sign_i = (short) readint_and_e(&ch, -1, MAX_TRANSITIONS);
      if (ch == CEsc) {
          quit = true;
          return;
      }

	  if (sign_i != -1) {
		  i = (INT_T) sign_i;
		  addordlist(i, list, *slist, &ok);
		  if (ok) (*slist)++;
	  }
	  move(row, col+7);
#endif
   }

   move(22,0); clrtoeol(); refresh();
   move(23,0); clrtoeol(); refresh();
   printw("Processing:  Please wait...");
   refresh();

   /* Pass to command line version of this program */
   mark_start_time();         
      result = selfloop_runProgram(name2, name1, *slist, *list);    
   mark_stop_time();

   if (result == 0) {
      strcpy(long_name2, "");
      make_filename_ext(long_name2, name2, EXT_DES);
      init = 0;
      if (exist(long_name2)){
		  if(!getdes(name2, s1, &init, t1))
			  quit = true;
	  }
      else
         quit = true;
   }
   else 
   {
       if (result == CR_OUT_OF_MEMORY)
          mem_result = 1;
       else
          quit = true;
   }
}

void selfloop_makeit(state_node *t1,
                     INT_S s1,
                     INT_T *list,
                     INT_T slist)
{
   FILE* out;
   INT_T i;

   /* Write to a tempory file */
   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;
   fprintf(out, "%s = Selfloop(%s,[", name2, name1);
   for (i=0; i < slist; i++) {
	   fprintf_event(out, list[i]);
     if (i+1 < slist)
       fprintf(out, ",");
   }
   fprintf(out, "])");
   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1));
   appendTime(out, (INT_OS)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop((INT_OS)strlen(name2)+3);
}

void selfloop_p()
{
   state_node *t1;
   INT_S s1;
   INT_T *list, slist;

   t1 = NULL; s1 = 0;
   list = NULL; slist = 0;

   selfloop_r(&t1, &s1, &list, &slist);

   if (mem_result == 1) {
      mem_result = 0;   /* Reset memory result counter */
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        selfloop_makeit(t1, s1, list, slist);
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
   free(list);
}

void trim_header() {
   printw("TRIM"); println();
   println();
   printw("DES2 = TRIM (DES1)"); println();
   println();
}

void trim_r(state_node **t1,
            INT_S *s1)
{
   INT_S      init;
   char       ch;
   INT_OS        result;

   clear();
   trim_header();
   quit = getname("Enter name of DES1 to be trimmed ....  ",
                  EXT_DES, name1, false);
   if (quit) return;

   printw("Assign new name to %s?   (*y/n)   ", name1);
   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( (ch == 'N') || (ch == 'n') ) {
      strcpy(name2, name1);
      println();  println();
   } else {
      if (ch != CEnter) {
         printw("%c", ch);
      }
      println();
      println();
      quit = getname("Enter new name for DES2 ....  ",
                     EXT_DES, name2, true);
      if (quit) return;
   }

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   /* Pass to command line version of this program */
   mark_start_time();
   result = trim_runProgram(name2, name1);   
   mark_stop_time();

   if (result == 0) {
      strcpy(long_name2, "");
      make_filename_ext(long_name2, name2, EXT_DES);
      init = 0;
      if (exist(long_name2)){
         if(!getdes(name2, s1, &init, t1))
			 quit = true;
	  }
      else
         quit = true;
   }
   else 
   {
       if (result == CR_OUT_OF_MEMORY)
          mem_result = 1;
       else
          quit = true;
   }
}

void trim_makeit(state_node *t1,
                 INT_S s1)
{
   FILE* out;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;
   fprintf(out, "%s = Trim(%s)", name2, name1);
   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1));
   appendTime(out, (INT_OS)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);
}

void trim_p()
{
   state_node *t1;
   INT_S s1;

   t1 = NULL;
   s1 = 0;

   trim_r(&t1, &s1);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        trim_makeit(t1, s1);
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
}

void sync_header()
{
   printw("SYNC"); println();
   println();
   printw("DES = SYNC (DES1, DES2, ..., DESk, k)"); println();
   println();
}

void sync_header_continue(INT_S sfile)
{
	INT_S i;
	printw("SYNC"); println();
	println();
	printw("DES = SYNC ("); 

	if(sfile <= 3){
		for(i = 0; i < sfile; i ++){
			printw("%s", names1[i]);
			if(i < sfile - 1)
				printw(",");
		}
	}else{
		for(i = 0; i < 3; i ++){
			printw("%s,", names1[i]);
		}
		printw("...,%s", names1[sfile - 1]);
	}
	printw(")");
	
	println();
	println();
}

void sync_blockevents_display(
         state_node *t1,   INT_S s1,
         state_node *t2,   INT_S s2,
         state_node *t3,   INT_S s3,
         INT_T **be, INT_T *s_be)
{
   INT_T *e1 = NULL; INT_T s_e1 = 0;
   INT_T *e3 = NULL; INT_T s_e3 = 0;
   INT_S i;  INT_T j;
   INT_B  ok;

   /* Collect all events of t1 = L1 */
   for (i=0; i < s1; i++)
     for (j=0; j < t1[i].numelts; j++)
     {
        addordlist(t1[i].next[j].data1, &e1, s_e1, &ok);
        if (ok) s_e1++;
     }

   /* Collect all events for t2+t1 = L1+L2 = L12 */
   for (i=0; i < s2; i++)
      for (j=0; j < t2[i].numelts; j++)
      {
         addordlist(t2[i].next[j].data1, &e1, s_e1, &ok);
         if (ok) s_e1++;
      }

   /* Collect all events for t3 = L3 */
   for (i=0; i < s3; i++)
      for (j=0; j < t3[i].numelts; j++)
      {
         addordlist(t3[i].next[j].data1, &e3, s_e3, &ok);
         if (ok) s_e3++;
      }

   /* D = L12-L3 */
   for (j=0; j < s_e1; j++)
     if (!inlist(e1[j], e3, s_e3))
     {
        addordlist(e1[j], be, *s_be, &ok);
        if (ok) (*s_be)++;
     }

   move(20, 0); clrtoeol();
   move(21, 0);
   printw("Events blocked in %s: ", name3);
   if (*s_be == 0)
   {
      printw("None.\n");
   }
   else if (*s_be >= 8)
   {
      printw("See MAKEIT.TXT file.\n");
   }
   else
   {
      printw("[");
      for (j=0; j < *s_be; j++)
      {
         printw("%3d", (*be)[j]);
         if (j+1 < *s_be)
            printw(",");
      }
      printw("]");
   }

   free(e1);
   free(e3);
}
void sync_blockevents(
         state_node *t1,   INT_S s1,
         state_node *t2,   INT_S s2,
         state_node *t3,   INT_S s3,
         INT_T **be, INT_T *s_be)
{
   INT_T *e1 = NULL; INT_T s_e1 = 0;
   INT_T *e3 = NULL; INT_T s_e3 = 0;
   INT_S i;  INT_T j;
   INT_B  ok;

   /* Collect all events of t1 = L1 */
   for (i=0; i < s1; i++)
     for (j=0; j < t1[i].numelts; j++)
     {
        addordlist(t1[i].next[j].data1, &e1, s_e1, &ok);
        if (ok) s_e1++;
     }

   /* Collect all events for t2+t1 = L1+L2 = L12 */
   for (i=0; i < s2; i++)
      for (j=0; j < t2[i].numelts; j++)
      {
         addordlist(t2[i].next[j].data1, &e1, s_e1, &ok);
         if (ok) s_e1++;
      }

   /* Collect all events for t3 = L3 */
   for (i=0; i < s3; i++)
      for (j=0; j < t3[i].numelts; j++)
      {
         addordlist(t3[i].next[j].data1, &e3, s_e3, &ok);
         if (ok) s_e3++;
      }

   /* D = L12-L3 */
   for (j=0; j < s_e1; j++)
     if (!inlist(e1[j], e3, s_e3))
     {
        addordlist(e1[j], be, *s_be, &ok);
        if (ok) (*s_be)++;
     }

   free(e1);
   free(e3);
}

/*Used to compute synchronous product of agents 
whose number are larger than 2 */
void sync_r(INT_S *sfile,
	state_node **t3,
	INT_S *s3,
	INT_T **be,
	INT_T *s_be)
{
	INT_S s1, s2;
	state_node *t1, *t2;
	INT_S  init;
	INT_T  *tranlist1, s_tranlist1, *tranlist2, s_tranlist2;
	INT_S i,j,k;
	INT_OS num;
	INT_B  ok;
	char ch, prompt[512];
	INT_OS    result;

	s1 = s2 = 0;
	t1 = t2 = NULL;
	tranlist1 = tranlist2 = NULL;  
	s_tranlist1 = s_tranlist2 = 0;
	num = 0;

	clear();
	sync_header();

	printw("Enter value of k ....... (between 2 and 30) ");
	num = (INT_OS)readint(&ch,2,MAX_DESS); println();
	*sfile = num;
	if(ch == CEsc){
		quit = true;
		return;
	}
	println();
	for(i = 0; i < num; i ++){
		strcpy(prompt,"");
		sprintf(prompt,"Enter name of DES%d ........ ",i + 1);
		if(_wherey() > 19){
			clear();
			sync_header();
			esc_footer();
		}
		quit = getname(prompt,EXT_DES,names1[i],false);
		if(quit) goto SYNC_LABEL;
		init = 0L;
		if(getdes(names1[i],&s1,&init,&t1) == false){
			goto SYNC_LABEL;
		}
		if(mem_result == 1)
			goto SYNC_LABEL;
		for(j = 0; j < s1; j ++){
			for(k = 0; k < t1[j].numelts; k ++){
				addordlist(t1[j].next[k].data1,&tranlist1, s_tranlist1,&ok);
				if(ok) s_tranlist1 ++;
			}
		}
		freedes(s1,&t1);
		s1 = 0; t1 = NULL;
	}
	if(_wherey() > 19){
		clear();
		sync_header();
		esc_footer();
	}

	quit = getname("Enter name of DES ......... ", EXT_DES, name3, true);
	if (quit) goto SYNC_LABEL;

	move(22,0); clrtoeol(); refresh();
	move(23,0); clrtoeol(); refresh();
	printw("Processing:  Please wait...");
	refresh();

	/* Pass to command line version of this program */
	mark_start_time(); 

	result = synck_runProgram(name3, num, names1);

	mark_stop_time();

	if (result == CR_OK) {
		strcpy(long_name3, "");
		make_filename_ext(long_name3, name3, EXT_DES);
		if (exist(long_name3))
		{
			init = 0L;
			if(!getdes(name3, s3, &init, t3))
				goto SYNC_LABEL;
			//Collect all events in name3
			for(j = 0; j < *s3; j ++){
				for(k = 0; k < (*t3)[j].numelts; k ++){
					addordlist((*t3)[j].next[k].data1, &tranlist2, s_tranlist2,&ok);
					if(ok) s_tranlist2 ++;
				}
			}
			for(j = 0; j < s_tranlist1; j ++){
				if(!inlist(tranlist1[j], tranlist2, s_tranlist2)){
					addordlist(tranlist1[j], be, *s_be, &ok);
					if(ok) (*s_be) ++;
				}
			}

			move(20, 0); clrtoeol();
			move(21, 0);
			printw("Events blocked in %s: ", name3);
			if (*s_be == 0)
			{
				printw("None.\n");
			}
			else if (*s_be >= 8)
			{
				printw("See MAKEIT.TXT file.\n");
			}
			else
			{
				printw("[");
				for (j=0; j < *s_be; j++)
				{
					printw("%3d", (*be)[j]);
					if (j+1 < *s_be)
						printw(",");
				}
				printw("]");
			}
		}
		else
			quit = true;
	}
	else 
	{
		if (result == CR_OUT_OF_MEMORY)
			mem_result = 1;
		else
			quit = true;
	}
SYNC_LABEL:
	free(tranlist1);
	free(tranlist2);
	freedes(s1, &t1);
	freedes(s2, &t2);
	return;
}

void sync_makeit(INT_S sfile, state_node *t3, INT_S s3,
                 INT_T *be, INT_T s_be)
{
   FILE* out;
   INT_T i;

   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;
   
   fprintf(out, "%s = Sync(", name3);
   for(i = 0; i < sfile; i ++){
      if(i < sfile - 1)
         fprintf(out, "%s,", names1[i]);
      else
         fprintf(out, "%s)", names1[i]);
   }
   fprintf(out, "  (%ld,%ld)  ", s3, count_tran(t3, s3));

   fprintf(out, "Blocked_events = ");
   if (s_be == 0)
   {
      fprintf(out, "None  ");
   }
   else
   {
      fprintf(out, "[");
      for (i=0; i < s_be; i++) {
         fprintf(out, "%d", be[i]);
         if (i+1 < s_be)
            fprintf(out, ",");
      }
      fprintf(out, "]  ");
   }

   appendTime(out, (INT_OS)strlen(name3)+3);
   fprintf(out, "\n\n");
   fclose(out);
   
   mergeChop((INT_OS)strlen(name3)+3);
  
}

void sync_p()
{
   state_node *t1, *t2, *t3;
   INT_S s1, s2, s3;
   INT_T s_blockevents, *blockevents;
   INT_S sfile;

   t1 = t2 = t3 = NULL;
   s1 = s2 = s3 = 0;
   s_blockevents = 0;  blockevents = NULL;

   sync_r(&sfile, &t3, &s3, &blockevents, &s_blockevents);
   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        sync_makeit(sfile, t3, s3,
                    blockevents, s_blockevents);
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
   freedes(s2, &t2);
   freedes(s3, &t3);
   free(blockevents);
}


void meet_header()
{
   printw("MEET"); println();
   println();
   printw("DES = MEET (DES1, DES2, ..., DESk, k)"); println();
   println();
}

void meet_header_inter(INT_S num)
{
	INT_S i;
	printw("MEET"); println();
	println();
	printw("DES = MEET ("); 

	for(i = 0; i < num; i ++){
		printw("%s,", names1[i]);
	}
	printw("...)");

	println();
	println();
}

void meet_r(INT_OS *num, state_node **t3,
            INT_S *s3)
{
   INT_S  init, i;
   INT_S  *macro_ab, *macro_c;
   INT_OS    result;
   char prompt[512], ch;

   macro_ab = NULL;  macro_c  = NULL;

   clear();
   meet_header();
   refresh();
   
   printw("Enter value of k ...... (between 2 and 30) ");
   *num = (INT_OS)readint(&ch, 2, MAX_DESS); println();
   if(ch == CEsc){
      quit = true;
      return;
   }
   println();
   for(i = 0; i < *num; i ++){
      strcpy(prompt,"");
      sprintf(prompt,"Enter name of DES%d ........ ",i + 1);
      if(_wherey() > 19){
           clear();
           meet_header();
           esc_footer();
      }
      quit = getname(prompt,EXT_DES,names1[i],false);
      if(quit) return;
   }

   quit = getname("Enter name of DES ......... ", EXT_DES, name3, true);
   if (quit) return;

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();
   
   /* Pass to command line version of this program */
   mark_start_time(); 
   result = meetk_runProgram(name3, *num, names1);
  
   mark_stop_time();

   if (result == CR_OK) {
      strcpy(long_name3, "");
      make_filename_ext(long_name3, name3, EXT_DES);
      init = 0;
      if (exist(long_name3)){
         if(!getdes(name3, s3, &init, t3))
			 quit = true;
	  }
      else
         quit = true;
   }
   else 
   {
       if (result == CR_OUT_OF_MEMORY)
          mem_result = 1;
       else
          quit = true;
   }
}

void meet_makeit(INT_OS num, state_node *t3,
                 INT_S s3)
{
   FILE* out;
   INT_OS i;

   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;
   fprintf(out, "%s = Meet(", name3);
   for(i = 0; i < num; i ++){
      if(i < num - 1)
         fprintf(out, "%s,", names1[i]);
      else
         fprintf(out, "%s)", names1[i]);
   }
   fprintf(out, "  (%ld,%ld)", s3, count_tran(t3, s3));
   appendTime(out, (INT_OS)strlen(name3)+3);
   fprintf(out, "\n\n");
   fclose(out);
   
   mergeChop((INT_OS)strlen(name3) + 3);
}

void meet_p()
{
   state_node *t3;
   INT_S  s3;
   INT_OS num = 0;

   t3 = NULL;
   s3 = 0;

   meet_r(&num, &t3, &s3);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        //meet_makeit(t3, s3);
        meet_makeit(num, t3, s3);
        user_pause();
      }
   }
   
   echo_free();
   freedes(s3, &t3);
}

void supcon_header()
{
   printw("SUPCON"); println();
   println();
   printw("DES3 = SUPCON (DES1, DES2)"); println();
   println();
}

void supcon_r(state_node **t1,
              INT_S *s1,
              state_node **t2,
              INT_S *s2,
              state_node **t3,
              INT_S *s3)
{
   INT_S  init;
   INT_S  *macro_ab, *macro_c;
   INT_OS    result;

   macro_ab = NULL;  macro_c  = NULL;

   clear();
   supcon_header();
   quit = getname("Enter name of plant generator DES1 .............  ",
                  EXT_DES, name1, false);
   if (quit) return;

   quit = getname("Enter name of legal language generator DES2 ....  ",
                  EXT_DES, name2, false);
   if (quit) return;

   printw("Enter name of supremal"); println();
   quit = getname("  controllable sublanguage generator DES3 ......  ",
                   EXT_DES, name3, true);
   if (quit) return;

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   /* Pass to command line version of this program */
   mark_start_time(); 
   result = supcon_runProgram(name3, name1, name2);   
   mark_stop_time();

   if (result == 0) {
      strcpy(long_name3, "");
      make_filename_ext(long_name3, name3, EXT_DES);
      init = 0;
      if (exist(long_name3)){
         if(!getdes(name3, s3, &init, t3))
			 quit = true; 
	  }
      else
         quit = true;
   }
   else 
   {
       if (result == CR_OUT_OF_MEMORY)
          mem_result = 1;
       else
          quit = true;
   }
}

void supcon_makeit(state_node *t3,
                   INT_S s3)
{
   FILE* out;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;
   fprintf(out, "%s = Supcon(%s,%s)", name3, name1, name2);
   fprintf(out, "  (%ld,%ld)", s3, count_tran(t3, s3));
   appendTime(out, (INT_OS)strlen(name3)+3);
   fprintf(out, "\n\n");
   fclose(out);
}

void supcon_p()
{
   state_node *t1, *t2, *t3;
   INT_S s1, s2, s3;

   t1 = t2 = t3 = NULL;
   s1 = s2 = s3 = 0;

   supcon_r(&t1, &s1, &t2, &s2, &t3, &s3);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        supcon_makeit(t3, s3);
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
   freedes(s2, &t2);
   freedes(s3, &t3);
}

void mutex_header()
{
   printw("MUTEX"); println();
   println();
   printw("DES3 = MUTEX (DES1, DES2, EXCLUDED_STATE_PAIR_LIST)"); println();
   println();
}

void mutex_header_continue()
{
	printw("MUTEX"); println();
	println();
	printw("%s = MUTEX (%s, %s, EXCLUDED_STATE_PAIR_LIST)", name3, name1, name2); println();
	println();
}

void mutex_r(state_node **t1,
             INT_S *s1,
             state_node **t2,
             INT_S *s2,
             state_node **t3,
             INT_S *s3,
             state_pair **sp,
             INT_S *s_sp)
{
   INT_S  init;
   char   ch;
   INT_S  *macro_ab, *macro_c;
   INT_S  i, j;
   INT_B  ok;
   INT_OS    result;

   macro_ab = NULL;  macro_c  = NULL;

   clear();
   mutex_header();
   quit = getname("Enter name of DES1 ....  ",
                  EXT_DES, name1, false);
   if (quit) return;

   quit = getname("Enter name of DES2 ....  ",
                  EXT_DES, name2, false);
   if (quit) return;

   quit = getname("Enter name of DES3 ....  ",
                   EXT_DES, name3, true);
   if (quit) return;

   println();
   printw("Enter list of excluded state pairs."); println();
   printw("Press <Enter> after each element and quit with -1:"); println();
   println();
   i = 0;
   while (i != -1) {
      if (_wherey() > 21) {
         clear();
         mutex_header_continue();
         printw("Continue to enter list of excluded state pairs."); println();
         printw("Press <Enter> after each element and quit with -1:"); println();
         println();
         esc_footer();
      }

      i = (INT_S) readint(&ch, -1, MAX_STATES-1);
      if (ch == CEsc) {
          quit = true;
          return;
      }
      if (i == -1) break;

      tab(15);
      j = (INT_S) readint(&ch, -1, MAX_STATES-1);
      if (ch == CEsc) {
          quit = true;
          return;
      }
      if (j == -1) break;

      addstatepair(i, j, sp, *s_sp, &ok);
      if (ok) (*s_sp)++;

      println();
   }

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();
   
   /* Pass to command line version of this program */
   mark_start_time();
   result = mutex_runProgram(name3, name1, name2, *sp, *s_sp);   
   mark_stop_time();

   if (result == 0) {
      strcpy(long_name3, "");
      make_filename_ext(long_name3, name3, EXT_DES);
      init = 0;
      if (exist(long_name3)){
         if(!getdes(name3, s3, &init, t3))
			 quit = true;
	  }
      else
         quit = true;
   }
   else 
   {
       if (result == CR_OUT_OF_MEMORY)
          mem_result = 1;
       else
          quit = true;
   }
}

void mutex_makeit(state_node *t3,
                  INT_S s3,
                  state_pair* sp,
                  INT_S s_sp)
{
   FILE* out;
   INT_S i;

   /* Write to a tempory file */
   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;
   fprintf(out, "%s = Mutex(%s,%s,[", name3, name1, name2);
   for (i=0; i < s_sp; i++) {
     fprintf(out, "[%ld,%ld]", sp[i].data1, sp[i].data2);
     if (i+1 < s_sp)
       fprintf(out, ",");
   }
   fprintf(out, "])");
   fprintf(out, "  (%ld,%ld)", s3, count_tran(t3, s3));
   appendTime(out, (INT_OS)strlen(name3)+3);
   fprintf(out, "\n\n");
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop((INT_OS)strlen(name3)+3);
}

void mutex_p()
{
   state_node *t1, *t2, *t3;
   INT_S s1, s2, s3;
   state_pair *sp;
   INT_S s_sp;

   t1 = t2 = t3 = NULL;
   s1 = s2 = s3 = 0;
   s_sp = 0; sp = NULL;

   mutex_r(&t1, &s1, &t2, &s2, &t3, &s3, &sp, &s_sp);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        mutex_makeit(t3, s3, sp, s_sp);
        user_pause();
      }
   }

   echo_free();
   free(sp);
   freedes(s1, &t1);
   freedes(s2, &t2);
   freedes(s3, &t3);
}

void condat_header()
{
   printw("CONDAT"); println();
   println();
   printw("DES3 = CONDAT (DES1, DES2)");
   println();
   println();
}

void condat_r(state_node **t1,
              INT_S *s1,
              state_node **t2,
              INT_S *s2,
              state_node **t3,
              INT_S *s3,
              state_node **t4,
              INT_S *s4)
{
   INT_S  init;
   INT_S  *macro_ab, *macro_c;
   INT_OS    result;

   macro_ab = NULL;  macro_c  = NULL;

   clear();
   condat_header();
   quit = getname("Enter name of plant generator DES1 ......  ",
                  EXT_DES, name1, false);
   if (quit) return;

   quit = getname("Enter name of supervisor DES2 ...........  ",
                  EXT_DES, name2, false);
   if (quit) return;

   quit = getname("Enter name of control data file DES3 ....  ",
                   EXT_DAT, name3, true);
   if (quit) return;

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   /* Pass to command line version of this program */
   mark_start_time();   
   result = condat_runProgram(name3, name1, name2);   
   mark_stop_time();

   if (result == 0) {
      strcpy(long_name3, "");
      make_filename_ext(long_name3, name3, EXT_DAT);
      if (exist(long_name3))
      {
         init = -1L;      
         if(!getdes(name3, s4, &init, t4))
			 quit = true;
      }
      else
         quit = true;
   }
   else 
   {
       if (result == CR_OUT_OF_MEMORY)
          mem_result = 1;
       else
          quit = true;
   }
}

void condat_makeit(state_node *t1,
                   INT_S s1)
{
   FILE* out;
   INT_S size;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;
   fprintf(out, "%s = Condat(%s,%s)", name3, name1, name2);

   size = count_tran(t1, s1);
   if (compute_controllable(t1, s1))
      fprintf(out, "  Controllable.");
   else
      fprintf(out, "  Uncontrollable.");

   appendTime(out, (INT_OS)strlen(name3)+3);
   fprintf(out, "\n\n");
   fclose(out);
}

void condat_p()
{
   state_node *t1, *t2, *t3, *t4;
   INT_S s1, s2, s3, s4;

   t1 = t2 = t3 = t4 = NULL;
   s1 = s2 = s3 = s4 = 0;

   condat_r(&t1, &s1, &t2, &s2, &t3, &s3, &t4, &s4);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        condat_makeit(t4, s4);
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
   freedes(s2, &t2);
   freedes(s3, &t3);
   freedes(s4, &t4);
}

void minstate_header() {
   printw("MINSTATE"); println();
   println();
   printw("DES2 = MINSTATE (DES1)"); println();
   println();
}

void minstate_r(state_node **t1,
                INT_S *s1)
{
   INT_S      init;
   char       ch;
   INT_OS        result;

   clear();
   minstate_header();
   quit = getname("Enter name of DES1 ....  ",
                  EXT_DES, name1, false);
   if (quit) return;

   printw("Assign new name to %s? (*y/n)   ", name1);
   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( (ch == 'N') || (ch == 'n') ) {
      strcpy(name2, name1);
      println();  println();
   } else {
      if (ch != CEnter) {
         printw("%c", ch);
      }
      println();
      println();
      
      quit = getname("Enter name of DES2 ....  ",
                     EXT_DES, name2, true);
      if (quit) return;
   }

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   /* Pass to command line version of this program */
   mark_start_time();
   result = minstate_runProgram(name2, name1);   
   mark_stop_time();

   if (result == 0) {
      strcpy(long_name2, "");
      make_filename_ext(long_name2, name2, EXT_DES);
      init = 0;
      if (exist(long_name2)){
         if(!getdes(name2, s1, &init, t1))
			 quit = true;
	  }
      else
         quit = true;
   }
   else 
   {
       if (result == CR_OUT_OF_MEMORY)
          mem_result = 1;
       else
          quit = true;
   }
}

void minstate_makeit(state_node *t1,
                     INT_S s1)
{
   FILE* out;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;
   fprintf(out, "%s = Minstate(%s)", name2, name1);
   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1));
   appendTime(out, (INT_OS)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);
}

void minstate_p()
{
   state_node *t1;
   INT_S s1;

   t1 = NULL;
   s1 = 0;

   minstate_r(&t1, &s1);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        minstate_makeit(t1, s1);
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
}

void complement_header() {
   printw("COMPLEMENT"); println();
   println();
   printw("DES2 = COMPLEMENT (DES1, LIST)"); println();
   println();
}

void complement_header_continue() {
	printw("COMPLEMENT"); println();
	println();
	printw("%s = COMPLEMENT (%s, LIST)", name2, name1); println();
	println();
}

void complement_r(state_node **t1,
                  INT_S *s1,
                  INT_T **list,
                  INT_T *slist)
{
   INT_S      init;
   INT_T      i;
   short      sign_i;
   INT_B     ok;
   char       ch;
   INT_OS        row, col;
   INT_OS        result;
   char strLabel[WIDTH_EVENT];
   INT_T index;

   clear();
   complement_header();
   quit = getname("Enter name of DES1 ....  ",
                  EXT_DES, name1, false);
   if (quit) return;

   quit = getname("Enter name of DES2 ....  ",
                  EXT_DES, name2, true);
   if (quit) return;

   printw("Compute complement using event labels of DES1 only? (*y/n)  ");
   refresh();
   ch = read_key();
   if (ch == CEsc) {
     quit = true;
     return;
   }

   if ( (ch == 'N') || (ch == 'n') ) {
      if (ch != CEnter) {
         printw("%c", ch);
      }
      println();
      println();
      printw("Enter auxiliary LIST of event labels not in DES1;"); println();
      printw("type -1 to quit:");  println();
      println();  tab(5);

      sign_i = 0;
      while (sign_i != -1) {
        col = _wherex();
        row = _wherey();
        if (col >= 75) {
           move(row+1,5);
           col = 5;
           row++;
        }
        if (_wherey() > 21) {
           clear();
           complement_header_continue();
           printw("Continue to enter auxilary LIST");
           printw("of event labels not in DES1;"); println();
           println(); tab(5);
           esc_footer();
           col = _wherex();
           row = _wherey();
        }
#if defined(_x64_)
		ch = read_string(strLabel, 1, WIDTH_EVENT);
		if (ch == CEsc) {
			quit = true; return;
		}
		sign_i = (short) generate_integer_label(strLabel, 1, &index);

		if (sign_i != -1) {
			i = (INT_T) sign_i;
			addordlist(i, list, *slist, &ok);
			if (ok) (*slist)++;

			move(row, col+10);
		}
#else
        sign_i = (short) readint_and_e(&ch, -1, MAX_TRANSITIONS);
        if (ch == CEsc) {
            quit = true;
            return;
        }
        if (sign_i != -1) {
           i = (INT_T) sign_i;
           addordlist(i, list, *slist, &ok);
           if (ok) (*slist)++;
        }
        move(row, col+7);
#endif
      }
   }

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   /* Pass to command line version of this program */
   mark_start_time();
   result = complement_runProgram(name2, name1, *list, *slist);   
   mark_stop_time();

   if (result == 0) {
      strcpy(long_name2, "");
      make_filename_ext(long_name2, name2, EXT_DES);
      init = 0;
      if (exist(long_name2)){
         if(!getdes(name2, s1, &init, t1))
			 quit = true;
	  }
      else
         quit = true;
   }
   else 
   {
       if (result == CR_OUT_OF_MEMORY)
          mem_result = 1;
       else
          quit = true;
   }
}

void complement_makeit(state_node *t1,
                       INT_S s1,
                       INT_T *list,
                       INT_T slist)
{
   FILE* out;
   INT_T i;

   /* Write to a tempory file */
   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;
   fprintf(out, "%s = Complement(%s,[", name2, name1);
   for (i=0; i < slist; i++) {
		fprintf_event(out, list[i]);
       if (i+1 < slist)
         fprintf(out, ",");
   }
   fprintf(out, "])");
   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1));
   appendTime(out, (INT_OS)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop((INT_OS)strlen(name2)+3);
}

void complement_p()
{
   state_node *t1;
   INT_S s1;
   INT_T *list, slist;

   t1 = NULL; s1 = 0;
   list = NULL; slist = 0;

   complement_r(&t1, &s1, &list, &slist);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        complement_makeit(t1, s1, list, slist);
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
   free(list);
}

void isomorph_header() {
   printw("ISOMORPH"); println();
   println();
   printw("ISOMORPH (DES1, DES2)"); println();
   println();
}

void isomorph_header_continue() {
	printw("ISOMORPH"); println();
	println();
	printw("ISOMORPH (%s, %s)", name1, name2); println();
	println();
}

void printlist1(INT_S s1,
                state_node *t1,
                INT_B  *flag,
                INT_S *mapState)
{
   INT_S i;
   INT_OS   ytop1, ytop2, windowheight, temp;
   char  ch;

   if (s1 == 0) return;

   ytop1 = _wherey();
   windowheight = 21 - ytop1;
   for (i=0; i < s1; i++) {
     if (mapState[i] != i) {
       *flag = false;
       ytop2 = _wherey() - ytop1 - 1;
       if (ytop2 > windowheight - 3) {
          move(windowheight+ytop1+2, 0);
          printw("Press <Enter> to page corresponding states or <ESC> to return  ");
          refresh();
          do {
             ch = read_key();
             if (ch == CEsc) {
                quit = true;
                return;
             }
          } while ( (ch != CEnter) && (ch != CEsc) );

          for (temp=ytop1; temp < 25; temp++) {
             move(temp, 0);
             clrtoeol();
          }

          move(1+ytop1, 0);
       }
       if (s1 <= 100000)
          printw("  [ %5d, %5d ]  ", i, mapState[i]);
       else if (s1 <= 1000000)
          printw(" [ %6d, %6d ] ", i, mapState[i]);
       else 
          printw(" [%7d,%7d]  ", i, mapState[i]);
     }
   }
   println();
}

void isomorph_makeit(INT_B  is_iso,
                     INT_B  identity,
                     INT_S *mapState,
                     INT_S s1,
                     INT_B  report)
{
   FILE* out;
   INT_S i;
   INT_OS   offset;
   INT_B  firstElem;

   /* Write to a tempory file */
   out = fopen("tmp.$$$", "w");

   if (out == NULL) return;

   if (is_iso) {
     fprintf(out, "true");
     offset = 7;
   } else {
     fprintf(out, "false");
     offset = 8;
   }

   fprintf(out, " = Isomorph(%s,%s", name1, name2);
   if (identity) {
     fprintf(out, ";identity");
   } else {
     if (is_iso) {
        firstElem = true;
        if(report){
        fprintf(out, ";[");
        for (i=0; i < s1; i++) {
           if (mapState[i] != i) {
              if (firstElem) {
                 firstElem = false;
              } else {
                 fprintf(out, ",");
              }
              fprintf(out, "[%ld,%ld]", i, mapState[i]);
           }
        }
        fprintf(out, "]");
        } else{
           fprintf(out, ";state correspondence omitted");
        }
     }
   }

   fprintf(out,")");
   appendTime(out, offset);
   fprintf(out, "\n\n");
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop(offset);
}

void isomorph_r(state_node **t1,
                INT_S *s1,
                state_node **t2,
                INT_S *s2)
{
   INT_S    init;
   INT_B   identity;
   INT_B   is_iso;
   INT_B   flag;
   INT_S    s_mapState, *mapState;
   INT_OS      x,y;
   char ch;
   INT_B  report;
   INT_S result;

   mapState = NULL;
   s_mapState = 0;
   report = false;

   clear();
   isomorph_header();
   quit = getname("Enter name of DES1 ....  ",
                  EXT_DES, name1, false);
   if (quit) return;

   quit = getname("Enter name of DES2 ....  ",
                  EXT_DES, name2, false);
   if (quit) return;

   x = _wherex();
   y = _wherey();
   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();

   result = isomorph_runProgram(name1, name2, &is_iso, &identity, &s_mapState, &mapState);
        
   mark_stop_time();

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   move(y,x);

   if(result == CR_OK){
	   /* Output the answer */
	   init = 0L;
	   if(getdes(name1, s1, &init, t1)){
		   if (is_iso) {
			   printw("%s and %s are isomorphic, under state correspondence",
				   name1, name2);
			   println();
			   println();
			   if (!identity) {
				   flag = true;
				   printlist1(*s1,*t1,&flag,mapState);
				   if (flag) {
					   printw("   IDENTITY"); println();
					   identity = true;
				   }else{
					   if(_wherey() > 21){
						   clear();
						   isomorph_header_continue();
					   }
					   println();
					   println();
					   quit = false;
					   printw("Report state correspondence in MAKEIT.TXT? (y/*n) ");
					   esc_footer();
					   refresh();
					   ch = read_key();
					   if (ch == CEsc) {
						   quit = true;
						   return;
					   }
					   if (ch != CEnter) {
						   printw("%c", ch);
					   }
					   if ( (ch == 'y') || (ch == 'Y') ) {
						   report = true;
					   }else{
						   report = false;
					   }
				   }
			   } else {
				   printw("   IDENTITY"); println();
			   }
		   } else {
			   printw("%s and %s are not isomorphic",name1,name2); println();
		   }

		   isomorph_makeit(is_iso, identity, mapState, *s1, report);
		   move(23,0); clrtoeol();
	   }
   }else{
   if (result == CR_OUT_OF_MEMORY)
	   mem_result = 1;
   else
	   quit = true;
   }


   free(mapState);
}

void isomorph_p()
{
   state_node *t1, *t2;
   INT_S s1, s2;

   t1 = t2 = NULL;
   s1 = s2 = 0;

   isomorph_r(&t1, &s1, &t2, &s2);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
   freedes(s2, &t2);
}

void nonconflict_header()
{
   printw("NONCONFLICT"); println();
   println();
   printw("NONCONFLICT (DES1, DES2)"); println();
   println();
}

INT_B  nonconflict(INT_S s,
                    state_node *t)
{
   INT_S state;

   if (s==0) return true;

   /* Make all the "reached" variable to false.
      This is needed because b_reach assumes this field is set to false
      before calling it. */
   for (state=0; state < s; state++)
     t[state].reached = false;

   for (state=0; state < s; state++) {
     if (t[state].marked) {
        t[state].reached = true;
        b_reach(t[state].next, state, &t, s);
     }
   }

   for (state=0; state < s; state++) {
      if (!t[state].reached) {
        return false;
      }
   }
   return true;
}

void nonconflict_r(state_node **t1,
                   INT_S *s1,
                   state_node **t2,
                   INT_S *s2,
                   state_node **t3,
                   INT_S *s3,
                   INT_B  *flag)
{
//   INT_S   init;
   INT_S   *macro_ab, *macro_c;
   INT_OS     x,y;
   INT_S result = 0;

   macro_ab = NULL;  macro_c  = NULL;

   clear();
   nonconflict_header();
   quit = getname("Enter name of DES1 ....  ",
                  EXT_DES, name1, false);
   if (quit) return;

   quit = getname("Enter name of DES2 ....  ",
                  EXT_DES, name2, false);
   if (quit) return;

   x = _wherex();
   y = _wherey();
   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();

   result = nonconflict_runProgram(name1, name2, flag);
     
   mark_stop_time();

   if(result == CR_OK){
	   move(23,0); clrtoeol();
	   move(y,x);
	   println();
	   println();
	   if (*flag)
		   printw("%s and %s are NONCONFLICTING", name1, name2);
	   else
		   printw("%s and %s are CONFLICTING!", name1, name2);
	   println();
   }else{
	   if (result == CR_OUT_OF_MEMORY) {
		   mem_result = 1;
	   }else
		   quit = true;
   }


   free(macro_ab);
   free(macro_c);
}

void nonconflict_makeit(INT_B  flag)
{
   FILE* out;
   INT_OS offset;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;
   if (flag) {
      fprintf(out, "true");
      offset = 7;
   } else {
      fprintf(out, "false");
      offset = 8;
   }
   fprintf(out, " = Nonconflict(%s,%s)", name1, name2);
   appendTime(out, offset);
   fprintf(out, "\n\n");
   fclose(out);
}

void nonconflict_p()
{
   state_node *t1, *t2, *t3;
   INT_S s1, s2, s3;
   INT_B  flag;
   
   t1 = t2 = t3 = NULL;
   s1 = s2 = s3 = 0;

   nonconflict_r(&t1, &s1, &t2, &s2, &t3, &s3, &flag);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        nonconflict_makeit(flag);
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
   freedes(s2, &t2);
   freedes(s3, &t3);
}

void bfs_recode_header() {
   printw("REACH & BREADTH-FIRST SEARCH RECODE"); println();
   println();
   printw("DES2 = RECODE (DES1)"); println();
   println();
}

void bfs_recode_r(state_node **t1,
                  INT_S *s1)                 
{
   INT_S      init;
   INT_OS        result;

   clear();
   bfs_recode_header();
   quit = getname("Enter name of DES1 ....  ",
                  EXT_DES, name1, false);
   if (quit) return;

   quit = getname("Enter name of DES2 ....  ",
                  EXT_DES, name2, true);
   if (quit) return;

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   /* Pass to command line version of this program */
   mark_start_time();
   result = bfs_recode_runProgram(name2, name1);   
   mark_stop_time();

   if (result == 0) {
      strcpy(long_name2, "");
      make_filename_ext(long_name2, name2, EXT_DES);
      init = 0;
      if (exist(long_name2)){
         if(!getdes(name2, s1, &init, t1))
			 quit = true;
	  }
      else
         quit = true;
   }
   else 
   {
       if (result == CR_OUT_OF_MEMORY)
          mem_result = 1;
       else
          quit = true;
   }
}

void bfs_recode_makeit(state_node *t1,
                       INT_S s1)
{
   FILE* out;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;
   fprintf(out, "%s = Recode(%s)", name2, name1);
   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1));
   appendTime(out, (INT_OS)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);
}

void bfs_recode_p()
{
   state_node *t1;
   INT_S s1;

   s1 = 0; 
   t1 = NULL;

   bfs_recode_r(&t1, &s1);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        bfs_recode_makeit(t1, s1);
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
}

void directory_header(char *name)
{
   printw("FILES IN: %s", dos_uppercase(name));
   move(3,0);
}


static INT_OS *dir_stack;
static INT_OS size_dir_stack;
static INT_OS total_dir;
static INT_B  multiPage;
static INT_OS ii;
static char ch;

void directory_output_page_control(INT_B  lastPage)
{
   continue_page(" D=PgDn  U=PgUp  Esc (Exit Directory)  ");

   do {
      refresh();
      ch = read_key();

      switch(ch) {
         case CEsc:
            quit = true;
            free(dir_stack); dir_stack = NULL;
            return;
         case CPgDn:
            if (lastPage == true) {
               ch = 0;
               ring_bell();
            } else {
               size_dir_stack++;
               dir_stack = (int*) realloc(dir_stack,
                                          sizeof(int)* size_dir_stack);
               dir_stack[size_dir_stack-1] = ii;
            }
            break;
         case CEnter:
            if (lastPage == false) {
               size_dir_stack++;
               dir_stack = (int*) realloc(dir_stack,
                                  sizeof(int)* size_dir_stack);
               dir_stack[size_dir_stack-1] = ii;
            } else{
               clear();
               directory_header(path);
               return;
            }
            break;
         case CPgUp:
            if (size_dir_stack == 0) {
               ch = 0;
               ring_bell();
            } else {
               if (size_dir_stack >= 2) {
                  ii = dir_stack[size_dir_stack-2];
                  size_dir_stack -= 2;
                  dir_stack = (int*) realloc(dir_stack,
                                     sizeof(int) * size_dir_stack);

                  /* Put back the last pop */
                  size_dir_stack++;
                  dir_stack = (int*) realloc(dir_stack,
                                     sizeof(int) * size_dir_stack);
                  dir_stack[size_dir_stack-1] = ii;
               } else {
                  ii = 0;
                  size_dir_stack = 0;
                  free(dir_stack); dir_stack = NULL;
               }
               total_dir = 0;
            }
            break;
      }
   } while ( ( ch != CEnter) && (ch != CEsc) && (ch != CPgUp) && (ch != CPgDn) );

   clear();
   directory_header(path);
}

INT_B  display_directory_output(struct _finddata_t *namelist, INT_OS num_entries)
{
   char buf[20], sbuf[20];
   INT_OS max_str = 0;
   INT_OS k;

   multiPage = false;
   total_dir = 0;
   dir_stack = NULL; size_dir_stack = 0;
   
   /* Either 1, 2 or 4 columns due to the length of the files */
   for (ii=0; ii < num_entries; ii++) {
      if (namelist[ii].attrib == _A_SUBDIR)
      {
         if (max_str < ((INT_OS)strlen(namelist[ii].name) + 2))
            max_str = (INT_OS)strlen(namelist[ii].name) + 2;
      }
      else 
      {   
         if (max_str < (INT_OS)strlen(namelist[ii].name))
            max_str = (INT_OS)strlen(namelist[ii].name);
      }
   }
   max_str += 2;   /* Add two spaces for blanks */
   
   if (max_str <= 18)
   {
      sprintf(buf, "%%-18s  ");
      sprintf(sbuf, "[%%-16s]  ");
   }
   else if (max_str <= 38)
   {
      sprintf(buf, "%%-38s  ");
      sprintf(sbuf, "[%%-36s]  ");
   }
   else
   {
      sprintf(buf, "%%-78s  ");
      sprintf(sbuf, "[%%-76s]  ");
   }
   
   ii = 0;
   do {
      while (ii < num_entries) {
        if (namelist[ii].attrib == _A_SUBDIR) {
           if (strlen(namelist[ii].name) > 78)
           {
              printw("[");
              for (k=0; k < 78; k++)
                 printw("%c", namelist[ii].name[k]);
              printw("]");
           } else {
              printw(sbuf, namelist[ii].name);
           }
        } else {
           if (strlen(namelist[ii].name) > 80)
           {
              for (k=0; k < 80; k++) 
                 printw("%c", namelist[ii].name[k]);
           } else {
              printw(buf, namelist[ii].name);
           }            
        }
      
        total_dir++;

        if (_wherey() >= 22) {
           directory_output_page_control(false);
           if (quit) return true;
        }
        ii++;
     }
     directory_output_page_control(true);
     if (quit) return true;
   } while ( (ch != CEnter) && (ch != CPgDn) );

   return false;
}

void directory_p()
{
   struct _finddata_t *namelist;
   INT_OS num_entries;
   char dir[100];
   char ch;

   namelist = NULL;
   quit = false;

   strcpy(dir, path);
   strcat(dir, "\\*.*");

   num_entries = scandir(dir, &namelist);

   clear();
   directory_header(path);

   if (num_entries) {
      display_directory_output(namelist, num_entries);
      free(namelist);
   } else {
      move(7,0);
      printw("NO FILES IN %s", dos_uppercase(path));

      move(23,0); clrtoeol();
      printw("Press <Enter> to return to CTCT Procedures  ");
      refresh();
      do {
        ch = read_key();
      } while (ch != CEnter);
   }
}


void vocalize_header() {
   printw("VOCALIZE"); println();
   println();
   printw("DES2 = VOCALIZE (DES1, [VOCAL])"); println();
   println();
}
void vocalize_header1() {
	printw("VOCALIZE"); println();
	println();
	printw("%s = VOCALIZE (%s, [VOCAL])", name2, name1); println();
	println();
}
void vocalize_list()
{
    printw("Enter list of triples [exit state, event, vocal output]."); println();
    printw("To vocalize all instances of an event, enter * for Exit state."); println();
    printw("Press <Enter> after each element and quit with -1."); println();
    println();
}

INT_B  is_valid_transition(INT_S i,
                            INT_T e,
                            INT_S *j,
                            state_node *t1,
                            INT_S s1)
{
   INT_T ii;
   INT_B  found;
   /* Have to do a linear search because, the DES maybe non-deterministic
      and also, we don't have the entrance state */
   found = false;
   ii = 0;
   while ((ii < t1[i].numelts) && (!found)) {
     if (t1[i].next[ii].data1 == e) {
       found = true;
       *j = t1[i].next[ii].data2;
     }
     ii++;
   }
   return found;
}

void vocalize_r(state_node **t1,
                INT_S *s1,
                quad__t **list,
                INT_S *slist,
                state_pair **rtlist,
                INT_S *s_rtlist,
                INT_B  *report_flag)
{
   INT_S      init;
   INT_S      i,j,ii;
   short      sign_i;
   INT_T      e;
   INT_V      v;
   INT_B     ok;
   char       ch;
   INT_B     allstate, input_error;
   INT_OS        col, row, a;
   INT_OS        result;
   INT_T index;
   char strLabel[WIDTH_EVENT];

   clear();
   vocalize_header();
   quit = getname("Enter name of DES1 ....  ",
                  EXT_DES, name1, false);
   if (quit) return;

   quit = getname("Enter name of DES2 ....  ",
                   EXT_DES, name2, true);
   if (quit) return;

   /* For this function, we load the DES file here */
   init = 0L;
   if (getdes(name1, s1, &init, t1) == false) {
      quit = true;
      return;
   }

   clear();
   vocalize_header1();
   vocalize_list();
   esc_footer();
   do  {
      if (_wherey() > 21) {
         col = _wherex(); row = _wherey()-1;
         move(23, 0); clrtoeol();
         move(24, 0);
         scroll_line();

         for (a=0; a < 8; a++) {
            move(a,0); clrtoeol();
         }

         move(0,0);
         vocalize_header1();
         vocalize_list();
         esc_footer();
         move(row, col);
      }

      allstate = false;
      printw("Exit state:  ");
      i = (INT_S) readintall(&ch, -1, (*s1)-1);

      if (ch == CEsc) {
          quit = true;
          return;
      }

      if (ch == '*') allstate = true;
      if (i == -1) break;

      tab(20);
      printw("Event:  ");
#if defined(_x64_)
	  ch = read_string(strLabel, 1, WIDTH_EVENT);
	  if (ch == CEsc) {
		  quit = true; 
		  return;
	  }
	  sign_i = (short) generate_integer_label(strLabel, 1, &index);
#else
	  sign_i = (short) readint_and_e(&ch, -1, MAX_TRANSITIONS);
	  if (ch == CEsc) {
		  quit = true;
		  return;
	  }
#endif

      if (sign_i == -1) break;
      e = (INT_T) sign_i;

      tab(40);
      printw("Entrance state vocal output:  ");
      v = (INT_V) readint(&ch, -1, MAX_VOCAL_OUTPUT);
      if (ch == CEsc) {
          quit = true;
          return;
      }
      if (v == -1) break;

      input_error = false;
      if (allstate) {
         if ( (e <= (INT_T) MAX_TRANSITIONS) &&
              ((10 <= v) && (v <= MAX_VOCAL_OUTPUT)) )
         {
             for (ii=0; ii < *s1; ii++)
             {
                 if (is_valid_transition(ii,e,&j,*t1, *s1))
                 {
                    add_quad(ii,e,j,v,list,*slist,&ok);
                    if (ok) (*slist)++;
                 }
             }
             println();
             *report_flag = true;
             addstatepair(e,v,rtlist, *s_rtlist, &ok);
             if(ok) (*s_rtlist) ++;

         } else {
             input_error = true;
         }
      } else {
         /* Filter errors */
         if ( ((0 <= i) && (i < (*s1) )) &&
              (e <= (INT_T) MAX_TRANSITIONS) &&
              ((10 <= v) && (v <= MAX_VOCAL_OUTPUT)) &&
             is_valid_transition(i,e,&j,*t1,*s1) ) {
             println();
             add_quad(i,e,j,v,list,*slist,&ok);
             if (ok) (*slist)++;
         } else {
             input_error = true;
         }
      }

      if (input_error)
      {
         if (_wherey() > 21) {
            clear();
            vocalize_header1();
            vocalize_list();
            esc_footer();
            println();
         }
         ring_bell();
         println();
         println();
         printw("This entry is illegal; please reenter!"); println();
         println();

         if (_wherey() > 19) {
            println();
            println();
            move(22,0);
         }
      }
   } while(1);
   /////////////////////////////////////////////////////
   //Updated by zry
   if(*report_flag){
      println();
      println();
      if (_wherey() > 21) {
         clear();
         vocalize_header1();
         esc_footer();
         println();
         println();
      }
      printw("Report full list of found triples (else report only * command) (y/*n)? ");
      refresh();
      ch = read_key();
      if (ch == CEsc) {
         quit = true;
         return;
      }      
      if (ch != CEnter) {
         printw("%c", ch);
      }
      if((ch == 'Y') || (ch == 'y'))
         *report_flag = true;
      else
         *report_flag = false;    
   }  
   //////////////////////////////////////////////////////
   
   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   /* Pass to command line version of this program */
   mark_start_time();
   result = vocalize_runProgram(name2, name1, *list, *slist);   
   mark_stop_time();

   if (result == 0) {
      strcpy(long_name2, "");
      make_filename_ext(long_name2, name2, EXT_DES);
      init = 0;
      if (exist(long_name2)){
         if(!getdes(name2, s1, &init, t1))
			 quit = true;
	  }
      else
         quit = true;
   }
   else 
   {
       if (result == CR_OUT_OF_MEMORY)
          mem_result = 1;
       else
          quit = true;
   }
}

void vocalize_makeit(state_node *t1,
                     INT_S s1,
                     quad__t *list,
                     INT_S slist,
                     state_pair *rtlist,
                     INT_S s_rtlist,
                     INT_B  report_flag)
{
   FILE* out;
   INT_T i;

   /* Write to a tempory file */
   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;
   fprintf(out, "%s = Vocalize(%s,[", name2, name1);
   if(!report_flag){
      for(i = 0; i < s_rtlist; i ++){
         fprintf(out, "[*,%d,%d]", rtlist[i].data1, rtlist[i].data2);
         if (i+1 < s_rtlist)
            fprintf(out, ",");
      }
      if(slist > 0)
         fprintf(out, ",");
   }
   for (i=0; i < slist; i++) {
     if(!report_flag && instatepair(list[i].b,list[i].d, &rtlist,s_rtlist))
        continue;
     fprintf(out, "[%ld,%d,%d]", list[i].a, list[i].b, list[i].d);
     if (i+1 < slist)
       fprintf(out, ",");
   }
   fprintf(out, "])");
   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1));
   appendTime(out, (INT_OS)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop((INT_OS)strlen(name2)+3);
}

void vocalize_p()
{
   state_node *t1;
   INT_S s1;
   quad__t* list; INT_S slist;
   INT_B  report_flag;
   INT_S s_rtlist; state_pair *rtlist;

   t1 = NULL; s1 = 0;
   list = NULL; slist = 0;
   s_rtlist = 0; rtlist = NULL;
   report_flag = false;

   vocalize_r(&t1, &s1, &list, &slist, &rtlist, &s_rtlist, &report_flag);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        vocalize_makeit(t1, s1, list, slist, rtlist, s_rtlist, report_flag);
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
   free(list);
}

void vocal_err_msg()
{
   move(10,0); clrtoeol();
   move(11,0); clrtoeol();
   move(12,0); clrtoeol();
   move(13,0); clrtoeol();
   move(14,0); clrtoeol();
   move(15,0); clrtoeol();
   move(10,0); clrtoeol();
   printw("_____________________________________________________________________________"); println();
   println();
   printw("        Sorry! Initial state 0 of DES1 must be silent (output 0)."); println();
   println();
   printw("        Computation cancelled."); println();
   printw("_____________________________________________________________________________");
   println();
}

void outconsis_header() {
   printw("OUTCONSIS"); println();
   println();
   printw("DES2 = OUTCONSIS (DES1)"); println();
   println();
}

void outconsis_r(state_node **t1,
                 INT_S *s1)
{
   INT_S      init;
   INT_OS        result;

   clear();
   outconsis_header();
   quit = getname("Enter name of DES1 ....  ",
                  EXT_DES, name1, false);
   if (quit) return;

   quit = getname("Enter name of DES2 ....  ",
                   EXT_DES, name2, true);
   if (quit) return;

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   /* Pass to command line version of this program */
   mark_start_time();
   result = outconsis_runProgram(name2, name1);   
   mark_stop_time();

   if (result == 0) {
      strcpy(long_name2, "");
      make_filename_ext(long_name2, name2, EXT_DES);
      init = 0;
      if (exist(long_name2)){
         if(!getdes(name2, s1, &init, t1))
			 quit = true;
	  }
      else
         quit = true;
   }
   else if (result == CR_VOCAL_ERR)
   {
       vocal_err_msg();
       user_pause();
       quit = true;
   }
   else 
   {
       if (result == CR_OUT_OF_MEMORY)
          mem_result = 1;
       else
          quit = true;
   }
   return;
}

void outconsis_makeit(state_node *t1,
                      INT_S s1)
{
   FILE* out;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;
   fprintf(out, "%s = Outconsis(%s)", name2, name1);
   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1));
   appendTime(out, (INT_OS)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);
}

void outconsis_p()
{
   state_node *t1;
   INT_S s1;

   t1 = NULL; s1 = 0;

   outconsis_r(&t1, &s1);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        outconsis_makeit(t1, s1);
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
}

void hiconsis_header() {
   printw("HICONSIS"); println();
   println();
   printw("DES2 = HICONSIS (DES1)"); println();
   println();
}


void get_output_list(INT_S s1, state_node *t1, INT_T **list1, INT_T *s_t1)
{
   /* Generate a list of all transition labels used in DES */
   INT_S i;
   INT_B  ok;
   INT_T k;

   *s_t1 = 0;
   *list1 = NULL;
   if (s1 == 0L) return;

   for (i=0L; i < s1; i++) {
       k = (INT_T) t1[i].vocal;
       addordlist(k, list1, *s_t1, &ok);
       if (ok) (*s_t1)++;
   }
}

void hiconsis_r(state_node **t1,
                INT_S *s1,
                INT_T **list,
                INT_T *s_list)
{
   INT_S      init;
   INT_OS        result;
   INT_B     old_hiconsis_flag;
   INT_T      *list1, *list2;
   INT_T      s_list1, s_list2;
   
   list1 = list2 = NULL;
   s_list1 = s_list2 = 0;

   clear();
   hiconsis_header();
   quit = getname("Enter name of DES1 ....  ",
                  EXT_DES, name1, false);
   if (quit) return;

   quit = getname("Enter name of DES2 ....  ",
                   EXT_DES, name2, true);
   if (quit) return;

   if (_wherey() > 15) clear();

   println();
   printw("Hierarchical consistency may require the addition of new low-level state"); println();
   printw("outputs (i.e. high-level event labels).  Available options are:"); println();
   println();
   printw("Single new state output (possibly split, in multiple new locations) (*s)"); println();
   println();
   printw("or"); println();
   println();
   printw("Multiple new state outputs (distinct for each new location) (m)"); println();
   println();
   printw("Select (*s/m)  ");

   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }
   if (ch != CEnter) {
      printw("%c", ch);
   }
   println();
   println();
   old_hiconsis_flag = false;
   if ( (ch == 'm') || (ch == 'M') ) {
      old_hiconsis_flag = true;
   }

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   /* Get the list of events of name1 */
   strcpy(long_name1, "");
   make_filename_ext(long_name1, name1, EXT_DES);   
   if (exist(long_name1))
   {
      init = 0;
      if(!getdes(name1, s1, &init, t1)){
		  quit = true;
		  return;
	  }        
   }         
   get_output_list(*s1, *t1, &list1, &s_list1);
   freedes(*s1, t1);
   *t1 = NULL; *s1 = 0;

   /* Pass to command line version of this program */
   mark_start_time();
   result = hiconsis_runProgram(name2, name1, old_hiconsis_flag); 
   mark_stop_time();

   if (result == CR_OK) {
      strcpy(long_name2, "");
      make_filename_ext(long_name2, name2, EXT_DES);   
      if (exist(long_name2))
      {
         init = 0;
		 if(getdes(name2, s1, &init, t1)){          

			 get_output_list(*s1, *t1, &list2, &s_list2);
			 /* list = list2 - list1 */
			 get_event_diff(list, s_list, list2, s_list2, list1, s_list1);
		 }
      }      
      else
         quit = true;
   } else if (result == CR_VOCAL_ERR) {
      vocal_err_msg();
      user_pause();
      quit = true;      
   } else if (result == CR_HICONSIS_ERR) {
      move(9,0);  clrtoeol();
      move(10,0); clrtoeol();
      move(11,0); clrtoeol();
      move(12,0); clrtoeol();
      move(13,0); clrtoeol();
      move(14,0); clrtoeol();
      move(15,0); clrtoeol();
      move(16,0); clrtoeol();
      move(17,0); clrtoeol();
      move(18,0); clrtoeol();
      move(19,0); clrtoeol();
      move(20,0); clrtoeol();
      move(10,0); clrtoeol();
      printw("___________________________________________________________________________"); println();
      println();
      printw("               Sorry! Vocal output overflow."); println();
      println();
      printw("               Computation cancelled."); println();
      printw("___________________________________________________________________________"); println();
      user_pause();
      quit = true;
   } else {
      if (result == CR_OUT_OF_MEMORY)
         mem_result = 1;
      else
         quit = true;
   }
   
   free(list1);
   free(list2);
}

void hiconsis_makeit(state_node *t1,
                     INT_S s1,
                     INT_T *list,
                     INT_T s_list)
{
   FILE* out;
   INT_T i;

   /* Write to a tempory file */
   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;
   fprintf(out, "%s = Hiconsis(%s)", name2, name1);
   fprintf(out, "   New event labels: [");
   for (i=0; i < s_list; i++)
   {
      fprintf(out, "%d", list[i]);
      if (i+1 < s_list)
         fprintf(out, ",");
   }
   fprintf(out, "]");   
   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1));
   
   appendTime(out, (INT_OS)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop((INT_OS)strlen(name2)+3);
}

void hiconsis_p()
{
   state_node *t1;
   INT_S s1;
   INT_T *list;
   INT_T s_list;

   t1 = NULL; s1 = 0;
   list = NULL; s_list = 0;

   hiconsis_r(&t1, &s1, &list, &s_list);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        hiconsis_makeit(t1, s1, list, s_list);
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
   free(list);
}

void higen_header() {
   printw("HIGEN"); println();
   println();
   printw("DES2 = HIGEN (DES1)"); println();
   println();
}

void higen_r(state_node **t1,
             INT_S *s1)
{
   INT_S      init;
   INT_T      *list, slist;
   INT_OS        result;

   list = NULL; slist = 0;

   clear();
   higen_header();
   quit = getname("Enter name of DES1 ....  ",
                  EXT_DES, name1, false);
   if (quit) return;

   quit = getname("Enter name of DES2 ....  ",
                   EXT_DES, name2, true);
   if (quit) return;

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   /* Pass to command line version of this program */
   mark_start_time();
   result = higen_runProgram(name2, name1);
   mark_stop_time();

  if (result == CR_OK) {
      strcpy(long_name2, "");
      make_filename_ext(long_name2, name2, EXT_DES);   
      if (exist(long_name2))
      {
         init = 0;
         if(!getdes(name2, s1, &init, t1))
			 quit = true;
      }      
      else
         quit = true;
   } else if (result == CR_VOCAL_ERR) {
      vocal_err_msg();
      user_pause();
      quit = true;      
   } else {
      if (result == CR_OUT_OF_MEMORY)
         mem_result = 1;
      else
         quit = true;
   }
}

void higen_makeit(state_node *t1,
                  INT_S s1)
{
   FILE* out;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;
   fprintf(out, "%s = Higen(%s)", name2, name1);
   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1));
   appendTime(out, (INT_OS)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);
}

void higen_p()
{
   state_node *t1;
   INT_S s1;

   t1 = NULL; s1 = 0;

   higen_r(&t1, &s1);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        higen_makeit(t1, s1);
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
}

void gen_complement_list(state_node *t1,
                         INT_S s1,
                         INT_T *imagelist, INT_T s_imagelist,
                         INT_T **list, INT_T *slist)
{
   INT_S i;
   INT_T j;
   INT_B  ok;

   for (i=0; i < s1; i++)
   {
      for (j=0; j < t1[i].numelts; j++)
      {
         if (!inlist(t1[i].next[j].data1, imagelist, s_imagelist))
         {
            addordlist(t1[i].next[j].data1, list, *slist, &ok);
            if (ok) (*slist)++;
         }
      }
   }
}

// Computation of the supremal normal sublanguage
void supnorm_header()
{
	printw("SUPNORM"); println();
	println();
	printw("DES3 = SUPNORM (DES1, DES2, NULL/IMAGE/IMAGE_DES)"); println();
	println();
}

void supnorm_r(state_node **t1,
               INT_S *s1,
               state_node **t2,
               INT_S *s2,
               state_node **t3,
               INT_S *s3,
               INT_T **list,
               INT_T *slist,
               INT_T **imagelist,
               INT_T *s_imagelist,
               INT_S  *mode)
{
   INT_S  init;
  // char   ch;
 //  short  sign_i;
 //  INT_T  i;
 //  INT_OS    row, col;
 //  INT_B  ok;
   INT_OS    result;

   clear();
   supnorm_header();
   refresh();

   quit = getname("Enter name of plant generator DES1 .............  ",
                  EXT_DES, name1, false);
   if (quit) return;

   quit = getname("Enter name of legal language generator DES2 ....  ",
	   EXT_DES, name2, false);
   if (quit) return;

   quit = getname("Enter name of DES3 ....  ",
                   EXT_DES, name3, true);
   if (quit) return;

   get_imagelist(s_imagelist,imagelist, slist, list, mode, 4);
   if(quit) return;


   /* Read in the two files in */
   init = 0L;
   if (getdes(name1, s1, &init, t1) == false) {
       quit = true;
       return;
   }
   
   init = 0L;
   if (getdes(name2, s2, &init, t2) == false) {
      quit = true;
      return;
   }  
   
   if (*mode != 1)
   {
       gen_complement_list(*t1, *s1,
                           *imagelist, *s_imagelist,
                           list, slist);
       gen_complement_list(*t2, *s2,
                           *imagelist, *s_imagelist,
                           list, slist);                            
   }
   freedes(*s1, t1); *s1 = 0; *t1 = NULL;
   freedes(*s2, t2); *s2 = 0; *t2 = NULL;
   
   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   /* Pass to command line version of this program */
   mark_start_time();
   result = supnorm_runProgram(name3, name2, name1, *list, *slist);   
   mark_stop_time();

   if (result == CR_OK) {
      strcpy(long_name3, "");
      make_filename_ext(long_name3, name3, EXT_DES);   
      if (exist(long_name3))
      {
         init = 0;
         if(!getdes(name3, s3, &init, t3))
			 quit = true;
      }      
      else
         quit = true;
   } else {
      if (result == CR_OUT_OF_MEMORY)
         mem_result = 1;
      else
         quit = true;
   }
}

void supnorm_makeit(state_node *t3,
	INT_S s3,
	INT_T *sp,
	INT_T s_sp, 
	INT_T *imagelist,
	INT_T s_imagelist,
	INT_S  mode)
{
	FILE* out;
	INT_S i;

	/* Write to a tempory file */
	out = fopen("tmp.$$$", "w");
	if (out == NULL) return;
	fprintf(out, "%s = Supnorm(%s,%s,", name3, name1, name2);

	if (mode == 1) 
	{
		fprintf(out, "Null[");
		for (i=0; i < s_sp; i++) {
			fprintf_event(out, sp[i]);
			if (i+1 < s_sp)
				fprintf(out, ",");
		}
		fprintf(out, "]");
	} else if(mode == 2)
	{
		fprintf(out, "Image[");
		for (i=0; i < s_imagelist; i++) {
			fprintf_event(out, imagelist[i]);
			if (i+1 < s_imagelist)
				fprintf(out, ",");
		}  
		fprintf(out, "]");
	} else{
		fprintf(out, "%s",imagename);
	}         

	fprintf(out, ")");
	fprintf(out, "  (%ld,%ld)", s3, count_tran(t3, s3));
	appendTime(out, (INT_OS)strlen(name3)+3);
	fprintf(out, "\n\n");
	fclose(out);

	/* Merge file into MAKEIT.TXT */
	mergeChop((INT_OS)strlen(name3)+3);
}

void supnorm_p()
{
	state_node *t1, *t2, *t3;
	INT_S s1, s2, s3;
	INT_T *sp;
	INT_T s_sp;
	INT_T *imagelist;
	INT_T s_imagelist;
	INT_S mode;

	t1 = t2 = t3 = NULL;
	s1 = s2 = s3 = 0;
	s_sp = 0; sp = NULL;
	imagelist = NULL; s_imagelist = 0;

	supnorm_r(&t1, &s1, &t2, &s2, &t3, &s3, &sp, &s_sp, &imagelist, &s_imagelist, &mode);

	if (mem_result == 1) {
		mem_result = 0;
		OutOfMemoryMsg();
		user_pause();
	} else {
		if (!quit) {
			supnorm_makeit(t3, s3, sp, s_sp, imagelist, s_imagelist, mode);
			user_pause();
		}
	}

	echo_free();
	freedes(s1, &t1);
	freedes(s2, &t2);
	freedes(s3, &t3);
	free(imagelist);
	free(sp);
}

//////////////////////////////////////////////////////////
// Project functions

void project_header() {
	printw("PROJECT"); println();
	println();
	printw("DES2 = PROJECT (DES1, NULL/IMAGE/IMAGE_DES)"); println();
	println();
}


void project_r(state_node **t1,
               INT_S *s1,
               INT_T **list,
               INT_T *slist,
               INT_T **imagelist,
               INT_T *s_imagelist,
			   INT_S *mode
              )
{
   INT_S      init;
   INT_OS        result;
   INT_S s2; state_node *t2;

   s2 = 0; t2 = NULL;

   clear();
   project_header();
   refresh();

   quit = getname("Enter name of DES1 to project .........  ",
                  EXT_DES, name1, false);
   if (quit) return;

   quit = getname("Enter name of DES2 to project onto ....  ",
                   EXT_DES, name2, true);
   if (quit) return;
 
	
   get_imagelist(s_imagelist, imagelist, slist, list, mode, 0);
   if(quit == true){
	   return;
   }

   init = 0L;
   if (getdes(name1, s1, &init, t1) == false) {
      quit = true;
      return;
   }

   if ((*mode != 1))
   {
      gen_complement_list(*t1, *s1,
                          *imagelist, *s_imagelist,
                          list, slist);
   }
   freedes(*s1, t1);

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   /* Pass to command line version of this program */
   mark_start_time();
   result = project_runProgram(name2, name1, *list, *slist);   
   mark_stop_time();

   if (result == CR_OK) {
      strcpy(long_name2, "");
      make_filename_ext(long_name2, name2, EXT_DES);   
      if (exist(long_name2))
      {
         init = 0;
         if(!getdes(name2, s1, &init, t1))
			 quit = true;
      }      
      else
         quit = true;   
   } else {
      if (result == CR_OUT_OF_MEMORY)
         mem_result = 1;
      else
         quit = true;
   }

   freedes(s2, &t2);
}

void project_makeit(state_node *t1,
	INT_S s1,
	INT_T *list,
	INT_T slist,
	INT_T *imagelist,
	INT_T s_imagelist,
	INT_S mode
	)
{
	FILE* out;
	INT_T i;

	/* Write to a tempory file */
	out = fopen("tmp.$$$", "w");
	if (out == NULL) return;
	fprintf(out, "%s = Project(%s,", name2, name1);

	if (mode == 1)
	{
		fprintf(out, "Null[");
		for (i=0; i < slist; i++) {
			fprintf_event(out, list[i]);
			if (i+1 < slist)
				fprintf(out, ",");
		}
		fprintf(out, "]");
	}
	else if(mode == 2)
	{
		fprintf(out, "Image[");
		for (i=0; i < s_imagelist; i++) {
			fprintf_event(out, imagelist[i]);
			if (i+1 < s_imagelist)
				fprintf(out, ",");
		}
		fprintf(out, "]");
	}else{
		fprintf(out, "%s", imagename);
	}

	fprintf(out, ")");
	fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1));
	appendTime(out, (INT_OS)strlen(name2)+3);
	fprintf(out, "\n\n");
	fclose(out);

	/* Merge file into MAKEIT.TXT */
	mergeChop((INT_OS)strlen(name2)+3);
}

void project_p()
{
	state_node *t1;
	INT_S s1;
	INT_T *list, slist;
	INT_T *imagelist;
	INT_T s_imagelist;
	INT_S mode;

	t1 = NULL; s1 = 0;
	list = NULL; slist = 0;
	imagelist = NULL; s_imagelist = 0;

	project_r(&t1, &s1, &list, &slist, &imagelist, &s_imagelist, &mode);

	if (mem_result == 1) {
		mem_result = 0;
		OutOfMemoryMsg();
		user_pause();
	} else {
		if (!quit) {
			project_makeit(t1, s1, list, slist, imagelist, s_imagelist, mode);
			user_pause();
		}
	}

	echo_free();
	freedes(s1, &t1);
	free(list);
	free(imagelist);
}

void eventmap_header()
{
   printw("RELABEL"); println();
   println();
   printw("DES2 = RELABEL (DES1, EVENT_MAP_PAIR_LIST)"); println();
   println();
}

void eventmap_r(state_node **t1,
                INT_S *s1,
                state_node **t2,
                INT_S *s2,
                state_pair **sp,
                INT_S *s_sp)
{
   INT_S  init;
   char   ch;
   INT_S i, j;
   INT_B  ok;
   INT_T *list;
   INT_T s_list;
   INT_OS   row, col, a;
   INT_OS   result;
   char strlabel[WIDTH_EVENT];
   INT_T index;
   INT_T s_temp_labellist;
   INT_T s_new_eventlist, *new_eventlist;

   list = NULL; s_list = 0;
   new_eventlist = NULL; s_new_eventlist = 0;

   clear();
   eventmap_header();
   quit = getname("Enter name of DES1 ....  ",
                  EXT_DES, name1, false);
   if (quit) return;

   quit = getname("Enter name of DES2 ....  ",
                  EXT_DES, name2, true);
   if (quit) return;

   clear();
   eventmap_header();
   println();
   esc_footer();

   printw("Enter list of event label pairs."); println();
   printw("Press <Enter> after each element and quit with -1:"); println();
   println();
   i = 0;
   while (i != -1) {
      if (_wherey() > 21) {
         col = _wherex(); row = _wherey()-1;
         move(23,0); clrtoeol();
         move(24,0);
         scroll_line();

         for (a=0; a < 7; a++) {
            move(a,0); clrtoeol();
         }

         move(0,0);
         eventmap_header();
         printw("Continue to enter list of event label pairs."); println();
         printw("Press <Enter> after each element and quit with -1:"); println();
         println();
         esc_footer();
         move(row, col);
      }
#if defined(_x64_)
	  printw("Old value:  ");
	  ch = read_string(strlabel, 1, WIDTH_EVENT);
	  if (ch == CEsc) {
		  quit = true; return;
	  }
	  i = (short) generate_integer_label(strlabel, 1, &index);	  

	  if (i == -1) break;

	  tab(25);
	  printw("New value:  ");
	  ch = read_string(strlabel, 1, WIDTH_EVENT);
	  if (ch == CEsc) {
		  quit = true; return;
	  }

	  s_temp_labellist = s_global_labellist;

	  j = (short) generate_integer_label(strlabel, 1, &index);
	 
	  if(s_temp_labellist < s_global_labellist){
		  addordlist(index, &new_eventlist, s_new_eventlist, &ok);
		  if(ok) s_new_eventlist ++;
	  }

	  println(); 

	  if (j == -1) break;
	  
#else
      printw("Old value:  ");
      i = (INT_S) readint_and_e(&ch, -1, MAX_TRANSITIONS);
      if (ch == CEsc) {
          quit = true;
          return;
      }
      if (i == -1) break;

      tab(25);
      printw("New value:  ");
      j = (INT_S) readint_and_e(&ch, -1, MAX_TRANSITIONS);
      if (ch == CEsc) {
          quit = true;
          return;
      }
      if (j == -1) break;
#endif

      addstatepair(i, j, sp, *s_sp, &ok);
      if (ok) (*s_sp)++;

      println();
   }



   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   /* Pass to command line version of this program */
   mark_start_time();
   result = convert_runProgram(name2, name1, *sp, *s_sp);   
   mark_stop_time();

   if (result == CR_OK) {
      strcpy(long_name2, "");
      make_filename_ext(long_name2, name2, EXT_DES);   
      if (exist(long_name2))
      {

		  init = 0;
		  if(getdes(name2, s2, &init, t2)){
#if defined(_x64_)
			  if(s_new_eventlist > 0){
				  assign_event_control_status(t2, s2, s_new_eventlist, new_eventlist, &quit);
				  free(new_eventlist);
				  s_new_eventlist = 0; new_eventlist = NULL;
			  }
#endif

		  }else
			  quit = true;



      }      
      else
         quit = true;
   } else {
      if (result == CR_OUT_OF_MEMORY)
         mem_result = 1;
      else
         quit = true;
   }
}
void eventmap_makeit(state_node *t3, INT_S s3, state_pair* sp, INT_S s_sp)
{
	FILE* out;
	INT_S i;
	INT_T intLabel1, intLabel2;
	char strLabel1[WIDTH_EVENT], strLabel2[WIDTH_EVENT];


	/* Write to a tempory file */
	out = fopen("tmp.$$$", "w");
	if (out == NULL) return;
	fprintf(out, "%s = Relabel(%s,[", name2, name1);
	for (i=0; i < s_sp; i++) {
		intLabel1 = (INT_T)(sp[i].data1);
		intLabel2 = (INT_T)(sp[i].data2);
		if(intLabel1 < START_INTLABEL){
			if(intLabel2 < START_INTLABEL){
				fprintf(out, "[%ld,%ld]", intLabel1, intLabel2);
			}else{
				get_strlabel_by_intlabel(intLabel2, strLabel2);
				fprintf(out, "[%ld,%s]", intLabel1, strLabel2);
			}
		}else{
			get_strlabel_by_intlabel(intLabel1, strLabel1);
			if(intLabel2 < START_INTLABEL){
				
				fprintf(out, "[%s,%ld]", strLabel1, intLabel2);
			}else{
				get_strlabel_by_intlabel(intLabel2, strLabel2);
				fprintf(out, "[%s,%s]", strLabel1, strLabel2);
			}
		}
		
		if (i+1 < s_sp)
			fprintf(out, ",");
	}
	fprintf(out, "])");
	fprintf(out, "  (%ld,%ld)", s3, count_tran(t3, s3));
	appendTime(out, (INT_OS)strlen(name2)+3);
	fprintf(out, "\n\n");
	fclose(out);

	/* Merge file into MAKEIT.TXT */
	mergeChop((INT_OS)strlen(name2)+3);

}

void eventmap_p()
{
   state_node *t1, *t2;
   INT_S s1, s2;
   state_pair *sp;
   INT_S s_sp;

   t1 = t2 = NULL;
   s1 = s2 = 0;
   s_sp = 0; sp = NULL;

   eventmap_r(&t1, &s1, &t2, &s2, &sp, &s_sp);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        eventmap_makeit(t2, s2, sp, s_sp);
        user_pause();
      }
   }

   echo_free();
   free(sp);
   freedes(s1, &t1);
   freedes(s2, &t2);
}

void allevent_header() {
	printw("ALLEVENTS"); println();
	println();
	printw("DES2 = ALLEVENTS (DES1/DAT1/[EVENTLIST])"); println();
	println();
}

boolean allevents_getname(char *prompt,
	char *ext,
	char *name,
	boolean newflag, 
	INT_B *existing)
{
	boolean quit;
	char ch;
	char longfilename[100];
	//boolean existing;

	*existing = false;
	quit = false;
	strcpy(name, "");

	//do {
		if ( _wherey() > MAXSCREENY ) {
			clear();
			println();
		}
		printw("%s", prompt);
		esc_footer();
		refresh();
		ch = read_filename(name, 1, MAX_DES_NAME_LEN);
		println();
		if (ch == CEsc) {
			quit = true;
		} else {
			make_filename_ext(longfilename, name, ext);
			if (newflag) {
				if ( exist(longfilename) ) {
					ring_bell();
					overwriteYN(name);
					refresh();
					ch = read_key();
					if (ch == CEnter) {
						println();
					} else {
						printw("%c", ch);
						println();
					}
					println();
					if (ch == CEsc) quit = true;
					if ( (ch == 'Y') || (ch == 'y') || (ch == CEnter) ) *existing = true;
					refresh();
				} else {
					*existing = true;
				}
			} else {
				if (! exist(longfilename) ) {
					ring_bell();
					doesNotExist(name);
					println();
					refresh();
					*existing = false;
				} else {
					*existing = true;
				}
			}
		}
	//} while ( (quit == false) && (existing == false));
	println();
	refresh();

	return quit;
}

void allevent_r(state_node **t1,
	INT_S *s1,
	state_node **t2,
	INT_S *s2,
	INT_T **list,
	INT_T *s_list,
	INT_OS *entry_type)
{
	INT_S      init;
	INT_OS        result;
	INT_T      i;
	short      sign_i;
	INT_B    ok, existing;
	char       ch;
	int        row, col;
	char strLabel[WIDTH_EVENT];
	INT_T index;

	result = 0;

	clear();
	allevent_header();
	esc_footer();
	refresh();

	println();
	printw("Select DES1 (to report all events occurring in existing DES1),");println();
	printw("or DAT1 (to report all events tabled in existing Condat file DAT1),"); println();
	printw("or EVENTLIST (to report all events entered by user):");println();
	println();
	//do {
START:		
	if (_wherey() > 20)	{
		clear();
		allevent_header();
		esc_footer();
	}    

	printw("DES1/DAT1/EVENTLIST?  (*d/a/e) ... ");
	refresh();
	ch = read_key();
	if (ch == CEsc) {
		quit = true;
		return;
	}   

	if (ch != CEnter) {
		printw("%c", ch);
	}
	println();
	println();

	if((ch == 'A') || (ch == 'a')){
		*entry_type = 2;
		quit = allevents_getname("Enter name of DAT1 (Condat) file to be searched .....  ",
			EXT_DAT, name1, false, &existing);
		if (quit) return;
		if(!existing)
			goto START;

	}else if((ch == 'E') || (ch == 'e')){
		*entry_type = 3;
		printw("Enter desired event list; terminate list with -1."); println();
		println();  tab(5);
		sign_i = 0;
		while (sign_i != -1) {
			col = _wherex();
			row = _wherey();
			if (col >= 75) {
				move(row+1,5);
				col = 5;
				row++;
			}
			if (_wherey() > 21) {
				clear();
				printw("Enter desired event list; terminate list with -1."); println();
				println(); tab(5);
				esc_footer();
				col = _wherex();
				row = _wherey();
			}
#if defined(_x64_)
			ch = read_string(strLabel, 1, WIDTH_EVENT);
			if (ch == CEsc) {
				quit = true; 
				return;
			}
			sign_i = (short) generate_integer_label(strLabel, 1, &index);
			if (ch == CEsc) {
				quit = true;
				return;
			}
			if (sign_i != -1) {
				i = (INT_T) sign_i;
				addordlist(i, list, *s_list, &ok);
				if (ok) (*s_list)++;
			}
			move(row, col+10);
#else
			sign_i = (short) readint_and_e(&ch, -1, MAX_TRANSITIONS);
			if (ch == CEsc) {
				quit = true;
				return;
			}
			if (sign_i != -1) {
				i = (INT_T) sign_i;
				addordlist(i, list, *s_list, &ok);
				if (ok) (*s_list)++;
			}
			move(row, col+7);
#endif

		}
		println(); println();

	}else{
		*entry_type = 1;
		quit = allevents_getname("Enter name of DES1 to be searched .....  ",
			EXT_DES, name1, false, &existing);
		if (quit) return;
		if(!existing)
			goto START;	
	}

	if (_wherey() > 18)
	{
		clear();
		allevent_header();
		esc_footer();
	} 

	println();
	//printw("Enter name of target DES2 (single state, marked, "); println();
	quit = getname("Enter name of target DES2 (single state, marked,\n   with desired events attached as selfloops) ......  ",
		EXT_DES, name2, true);
	if (quit) return;

	move(22,0); clrtoeol();
	move(23,0); clrtoeol();
	printw("Processing:  Please wait...");
	refresh();

	/* Pass to command line version of this program */
	mark_start_time();

	result = allevent_runProgram(name2, name1, *entry_type, *s_list, *list);
	
	mark_stop_time();

	if (result == CR_OK) {
		strcpy(long_name2, "");
		make_filename_ext(long_name2, name2, EXT_DES);   
		if (exist(long_name2))
		{
			init = 0; 
			if(!getdes(name2, s2, &init, t2))
				quit = true;
		}      
		else
			quit = true;
	} else {
		if (result == CR_OUT_OF_MEMORY)
			mem_result = 1;
		else
			quit = true;
	}
}

void allevent_makeit1(state_node *t1,
                     INT_S s1,
					 INT_OS entry_type)
{
   FILE* out;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;
   if(entry_type == 1)
	   fprintf(out, "%s = Allevents(%s.DES)", name2, name1);
   else if(entry_type == 2){
	   fprintf(out, "%s = Allevents(%s.DAT)", name2, name1);
   }
   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1));
   appendTime(out, (INT_OS)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);
   
}
void allevent_makeit2(INT_T s_list, INT_T *list, state_node *t1,	INT_S s1)
{
	FILE* out;
	INT_T i;

	/* Write to a tempory file */
	out = fopen("tmp.$$$", "w");
	if (out == NULL) return;
	fprintf(out, "%s = Allevents([", name2);

	for (i=0; i < s_list; i++) {
		fprintf_event(out, list[i]);
		if (i+1 < s_list)
			fprintf(out, ",");
	}

	fprintf(out, "])");
	fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1));
	appendTime(out, (INT_OS)strlen(name2)+3);
	fprintf(out, "\n\n");
	fclose(out);

	/* Merge file into MAKEIT.TXT */
	mergeChop((INT_OS)strlen(name2)+3);

}


void allevents_p()
{
	state_node *t1, *t2;
	INT_S s1, s2;
	INT_T s_list, *list;
	INT_OS entry_type;

	t1 = t2 = NULL;
	s1 = s2 = 0;
	s_list = 0; list = NULL;
	entry_type = 0;

	allevent_r(&t1, &s1, &t2, &s2, &list, &s_list, &entry_type);

	if (mem_result == 1) {
		mem_result = 0;
		OutOfMemoryMsg();
		user_pause();
	} else {
		if (!quit) {
			if(entry_type != 3){
				allevent_makeit1(t2, s2,entry_type);
			}else{
				allevent_makeit2(s_list, list,t2, s2);
			}
			user_pause();
		}
	}

	echo_free();
	freedes(s1, &t1);
	freedes(s2, &t2);
	free(list);
}

void print_des_header()
{
   printw("PRINT"); println();
   println();
   printw("PRINT(DES)"); println();
   println();
}

void print_des_stat_header(FILE *out,
                           char *name,
                           INT_S s,
                           INT_S init)
{
   fprintf(out, "%s    # states: %ld", name, s);
   if (s > 0) {
      fprintf(out, "    state set: 0 ... %ld", s-1);
      fprintf(out, "    initial state: %ld\n", init);
   } else {
      fprintf(out, "    state set: empty ");
      fprintf(out, "    initial state: none\n");
   }
}

INT_B  print_marker_states(FILE *out,
                            state_node *t1,
                            INT_S s1)
{
   INT_S i, total_marker;

   total_marker = 0;

   fprintf(out, "marker states:       "); fprintf(out, "\n");
   fprintf(out, "\n");
   for (i=0; i < s1; i++) {
      if (t1[i].marked) {
         fprintf(out, "%7ld ", i);
         total_marker++;
         if ((total_marker % 8) == 0) {
            fprintf(out, "\n");
         }
      }
   }
   fprintf(out, "\n");
   return false;
}

INT_B  print_vocal_output(FILE *out,
                           state_node *t1,
                           INT_S s1)
{
   INT_S i, total_vocal;

   total_vocal = 0;

   fprintf(out, "\n");
   fprintf(out, "vocal states:       \n");
   for (i=0; i < s1; i++) {
      if (t1[i].vocal > 0) {
         /* Tempory format fix - for 7 digit numbers */
         if (s1 <= 100000)
            fprintf(out, "[%5ld,%4d]   ", i, t1[i].vocal);
         else if (s1 <= 1000000)
            fprintf(out, "[%6ld,%4d]  ", i, t1[i].vocal);
         else
            fprintf(out, "[%7ld,%4d] ", i, t1[i].vocal);

         total_vocal++;
         if ((total_vocal % 5) == 0) {
            fprintf(out, "\n");
         }
      }
   }
   fprintf(out, "\n");
   return false;
}

INT_B  print_transitions(FILE *out,
                          state_node *t1,
                          INT_S s1)
{
   INT_S i, total_tran;
   INT_T j;

   total_tran = 0;

   fprintf(out, "\n");
   fprintf(out, "# transitions: %ld\n", count_tran(t1, s1));
   fprintf(out, "\n");
   fprintf(out, "transitions: \n");
   fprintf(out, "\n");
   for (i=0; i < s1; i++) {
     for (j=0; j< t1[i].numelts; j++) {
         
       if (t1[i].next[j].data1 == EEE)
          fprintf(out, "[%5ld,  e,%5ld]  ", i, t1[i].next[j].data2);
       else
          fprintf(out, "[%5ld,%3d,%5ld]  ", i, t1[i].next[j].data1, t1[i].next[j].data2);
       
       total_tran++;
       if ((total_tran % 4) == 0) {
          fprintf(out, "\n");
       }
     }
   }
   return false;
}

void print_des_r(state_node** t1,
                 INT_S *s1)
{
   INT_S init, nTransitions, nMark;
   FILE *out = NULL;
   char ch;
   char fullname[81];

   clear();
   print_des_header();
   quit = getname("Enter name of DES ....  ", EXT_DES, name1, false);
   if (quit) return;

   init = 0;
   if (getdes(name1, s1, &init, t1) == false) {
      quit = true;
      return;
   }

   /* Display DES to screen */
   if (init == -1) {
     clear();
     println();
     printw("This is a DAT file.");   println();
     printw("Use print DAT command."); println();
     user_pause();
     quit = true;
     return;
   }
   println();

   /* Ask user if he/she wants to print to a file */
   do {
     println();

     printw("Print to LPT1?  (*y/n) ");

     refresh();
     ch = read_key();
     if (ch == CEsc) {
        quit = true;
        return;
     }
     if (ch == CEnter) ch = 'y';
     printw("%c", ch); println();
   } while (strchr("YNyn", ch) == NULL);

   if (ch == 'n' || ch == 'N') {
      println();
      /* Get filename to print to */
      quit = getname("ASCII text file name .... ", EXT_PDS, name2, true);
      if (quit) return;
      sprintf(fullname, "%s%s%s", prefix, name2, EXT_PDS);

      out = fopen(fullname, "w");
   }

   print_des_stat_header(out, name1, *s1, init);
   fprintf(out, "\n");

   nMark = num_mark_states(*t1, *s1);
   if ((nMark == *s1) && (*s1 > 0))
   {
      fprintf(out, "marker states: all\n");
      fprintf(out, "\n");
   }
   else if ( nMark > 0) {
      quit = print_marker_states(out, *t1, *s1);
      if (quit) return;
   } else {
      fprintf(out, "marker states: none\n");
      fprintf(out, "\n");
   }

   if (num_vocal_output(*t1, *s1) > 0) {
      quit = print_vocal_output(out, *t1, *s1);
      if (quit) return;
   } else {
      fprintf(out, "\n");
      fprintf(out, "vocal states: none\n");
      fprintf(out, "\n");
   }

   nTransitions = count_tran(*t1, *s1);
   if (nTransitions > 0) {
      quit = print_transitions(out, *t1, *s1);
      fprintf(out, "\n");
      if (quit) return;
    } else {
      fprintf(out, "transition table : empty\n");
   }

}

void print_des_p()
{
   state_node *t1;
   INT_S s1;

   t1 = NULL; s1 = 0;

   print_des_r(&t1, &s1);

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   }

   freedes(s1, &t1);
}

void print_dat_header()
{
   printw("PRINT"); println();
   println();
   printw("PRINT(DAT)"); println();
   println();
}

void print_dat_header_stat(FILE *out, char *name1, INT_B  controllable)
{
    fprintf(out, "%s\n", name1);
    fprintf(out, "\n\n");
    fprintf(out, "Control data are displayed as a list of supervisor states\n");
    fprintf(out, "where disabling occurs, together with the events that must\n");
    fprintf(out, "be disabled there.\n\n");
    fprintf(out, "%s is ", name1);
    if (controllable)
       fprintf(out, "CONTROLLABLE");
    else
       fprintf(out, "NOT CONTROLLABLE");
    fprintf(out,"\n\n");
    fprintf(out, "control data:\n");
}

INT_B  print_dat(FILE *out,
                  state_node *t1,
                  INT_S s1)
{
   INT_S k, i, prevNumTran;
   INT_T j;
   INT_B  leftSide;

   leftSide = false;
   prevNumTran = 0;

   fprintf(out, "\n");
   for (i=0; i < s1; i++) {
     if (t1[i].numelts > 0) {
       if ((prevNumTran > 6) || (t1[i].numelts > 6) || (leftSide == false)) {
         fprintf(out, "\n");
         fprintf(out, "%4s", " ");
         leftSide = true;
       } else {
         for (k=prevNumTran; k <=6; k++)
            fprintf(out, "%5s", " ");
         leftSide = false;
       }
       fprintf(out, "%4ld:", i);
       prevNumTran = t1[i].numelts;
     }

     for (j=0; j< t1[i].numelts; j++) {
       if (t1[i].next[j].data1 == EEE)
          fprintf(out, "e    ");
       else   
          fprintf(out, "%4d ", t1[i].next[j].data1);

       if ( (j != 0) && ((j % 12) == 0) && (j < prevNumTran-1) ) {
          fprintf(out, "\n");
          fprintf(out, "%9s", " ");
       }
     }
   }
   fprintf(out, "\n");
   return false;
}

void print_dat_r(state_node** t1,
                 INT_S *s1)
{
   INT_S init, nTransitions;
   FILE *out = NULL;
   char ch;
   char fullname[81];
   INT_B  controllable;

   clear();
   print_dat_header();
   quit = getname("Enter name of DAT ....  ", EXT_DAT, name1, false);
   if (quit) return;

   init = -1;
   if (getdes(name1, s1, &init, t1) == false) {
      quit = true;
      return;
   }

   /* Display DAT to screen */
   if (init != -1) {
     clear();
     println();
     printw("This is a DES file.");   println();
     printw("Use print DES command."); println();
     user_pause();
     quit = true;
     return;
   }
   println();

   /* Ask user if to direct output to print or to file */
   /* For now dump to printer */
   do {
     println();

     printw("Print to LPT1?  (*y/n) ");

     refresh();
     ch = read_key();
     if (ch == CEsc) {
        quit = true;
        return;
     }
     if (ch == CEnter) ch = 'y';
     printw("%c", ch); println();
   } while (strchr("YNyn", ch) == NULL);

   if (ch == 'n' || ch == 'N') {
      println();
      /* Get filename to print to */
      quit = getname("ASCII text file name .... ", EXT_PDT, name2, true);
      if (quit) return;
      sprintf(fullname,"%s%s%s", prefix, name2, EXT_PDT);

      out = fopen(fullname, "w");
   }


   controllable = compute_controllable(*t1,*s1);
   print_dat_header_stat(out, name1, controllable);
   nTransitions = count_tran(*t1, *s1);
   if (nTransitions > 0) {
      quit = print_dat(out, *t1, *s1);
      fprintf(out, "\n");
      if (quit) return;
   } else {
      fprintf(out, "empty.\n");
   }

}

void print_dat_p()
{
   state_node *t1;
   INT_S s1;

   t1 = NULL; s1 = 0;

   print_dat_r(&t1, &s1);

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   }

   freedes(s1, &t1);
}

void print_ascii_header()
{
   printw("PRINT"); println();
   println();
   printw("PRINT(TXT)"); println();
   println();
}

void print_ascii_p()
{
   FILE *in, *out = NULL;
   char ch;
   char fullname[81];

   clear();
   print_ascii_header();
   quit = getname("Enter name of TXT ....  ", EXT_TXT, name1, false);
   if (quit) return;

   sprintf(fullname, "%s%s%s", prefix, name1, EXT_TXT);
   in = fopen(fullname, "r");
   if (in == NULL) {
      quit = true;
      return;
   }

   /* Prompt user to check the printer */
   do {
      printw("Check that printer is online, then press <Enter> to print  ");
      println();
      println();
      refresh();
      ch = read_key();
      if (ch == CEsc) {
          fclose(in);
          quit = true;
          return;
      }
   } while (ch != CEnter);

   while (!feof(in)) {
     ch = fgetc(in);
     fputc(ch, out);
   }

   fprintf(out, "\n");
   fclose(in);
}

void file_des_header()
{
   printw("FILE"); println();
   println();
   printw("FILE(DES)"); println();
   println();
}

void file_des_r(state_node** t1,
                INT_S *s1)
{
   INT_S init, nTransitions;
   FILE *out;
   char ch;
   char fullname[81];
   INT_OS ascii_output = 0;  /* 0 = .ADS, 1 = PDS, 2 = PSS */

   clear();
   file_des_header();
   quit = getname("Enter name of DES ....  ", EXT_DES, name1, false);
   if (quit) return;

   init = 0;
   if (getdes(name1, s1, &init, t1) == false) {
      quit = true;
      return;
   }

   /* Display DES to screen */
   if (init == -1) {
     clear();
     println();
     printw("This is a DAT file.");   println();
     printw("Use file DAT command."); println();
     user_pause();
     quit = true;
     return;
   }

   /* Ask user if he/she want to file as ASCII text or Postscript */
   println();
   printw("File as ADS (.ADS) or ASCII Text (.PDS)?  (*A/T) ");

   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }
   if (ch != CEnter) {
      printw("%c", ch);
   }
   println();
   println();

   if (ch == 't' || ch == 'T') {
      ascii_output = 1;
      /* Get filename */
      quit = getname("Enter ASCII text file name ....  ", EXT_PDS, name2, true);
      if (quit) return;
      sprintf(fullname, "%s%s%s", prefix, name2, EXT_PDS);
   //}
   //else if (ch == 'p' || ch == 'P') {
   //   ascii_output = 2;
      /* Get filename for Postscript */
   //   quit = getname("Enter the Postcript file name ....  ", EXT_PSS, name2, true);
   //   if (quit) return;
   //   sprintf(fullname, "%s%s%s", prefix, name2, EXT_PSS);
   } else {
      ascii_output = 0;
      /* Get filename for .ADS */
      quit = getname("Enter the ADS file name ....  ", EXT_ADS, name2, true);
      if (quit) return;
      sprintf(fullname, "%s%s%s", prefix, name2, EXT_ADS);
   }
   out = fopen(fullname, "w");

   /**** ASCII file format to file ****/
   if (ascii_output == 1)
   {
      print_des_stat_header(out, name1, *s1, init);
      fprintf(out, "\n");

      if (num_mark_states(*t1, *s1) > 0) {
        quit = print_marker_states(out, *t1, *s1);
        if (quit) return;
      } else {
        fprintf(out, "marker states: none\n");
        fprintf(out, "\n");
      }

      if (num_vocal_output(*t1, *s1) > 0) {
        quit = print_vocal_output(out, *t1, *s1);
        if (quit) return;
      } else {
        fprintf(out, "\n");
        fprintf(out, "vocal states: none\n");
        fprintf(out, "\n");
      }

      nTransitions = count_tran(*t1, *s1);
      if (nTransitions > 0) {
        quit = print_transitions(out, *t1, *s1);
        fprintf(out, "\n");
        if (quit) return;
      } else {
        fprintf(out, "transition table : empty\n");
     }
   }
   else if (ascii_output == 2) /***** Postscript *****/
   {
      postscript_outputfile(name1, out, *t1, *s1);
   }
   else
   {
      des_to_ads(name1, out, *t1, *s1);
   }

   fclose(out);

   move(22,0); clrtoeol();
   if (ascii_output == 0)
      printw("%s%s has been copied to %s%s", name1, EXT_DES, name2, EXT_ADS);
   else if (ascii_output == 1)
      printw("%s%s has been copied to %s%s", name1, EXT_DES, name2, EXT_PDS);
   else
      printw("%s%s has been copied to %s%s", name1, EXT_DES, name2, EXT_PSS);
   user_pause();
}

void file_des_p()
{
   state_node *t1;
   INT_S s1;

   t1 = NULL; s1 = 0;

   file_des_r(&t1, &s1);

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   }

   freedes(s1, &t1);
}

void file_dat_header()
{
   printw("FILE"); println();
   println();
   printw("FILE(DAT)"); println();
   println();
}

void file_dat_r(state_node** t1,
                INT_S *s1)
{
   INT_S init, nTransitions;
   FILE *out;
   char ch;
   char fullname[81];
   INT_B  ascii_output;
   INT_B  controllable;

   clear();
   file_dat_header();
   quit = getname("Enter name of DAT ....  ", EXT_DAT, name1, false);
   if (quit) return;

   init = -1;
   if (getdes(name1, s1, &init, t1) == false) {
      quit = true;
      return;
   }

   /* Display DAT to screen */
   if (init != -1) {
     clear();
     println();
     printw("This is a DES file.");   println();
     printw("Use file DES command."); println();
     user_pause();
     quit = true;
     return;
   }

   /* Ask user if he/she want to file as ASCII text or Postscript */
   println();
   printw("File as ASCII text (.PDT) or Postscript (.PST)?  (*A/P) ");

   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }
   if (ch != CEnter) {
      printw("%c", ch);
   }
   println();
   println();

   if (ch == 'p' || ch == 'P') {
      ascii_output = false;
      /* Get filename to as Postscript */
      quit = getname("Enter the Postcript file name ....  ", EXT_PST, name2, true);
      if (quit) return;
      sprintf(fullname, "%s%s%s", prefix, name2, EXT_PST);
   } else {
      ascii_output = true;
      /* Get filename to as Postscript */
      quit = getname("Enter ASCII text file name ....  ", EXT_PDT, name2, true);
      if (quit) return;
      sprintf(fullname, "%s%s%s", prefix, name2, EXT_PDT);
   }
   out = fopen(fullname, "w");


   /**** ASCII file format to file ****/
   if (ascii_output)
   {
      controllable = compute_controllable(*t1,*s1);
      print_dat_header_stat(out,name1, controllable);
      nTransitions = count_tran(*t1, *s1);
      if (nTransitions > 0) {
        quit = print_dat(out, *t1, *s1);
        fprintf(out, "\n");
        if (quit) return;
      } else {
        fprintf(out, "empty.\n");
      }
   }
   else  /* Postscript */
   {
      postscript_dat_output(name1, out, *t1, *s1);
   }
   fclose(out);

   move(22,0); clrtoeol();
   if (ascii_output)
      printw("%s%s has been copied to %s%s", name1, EXT_DAT, name2, EXT_PDT);
   else
      printw("%s%s has been copied to %s%s", name1, EXT_DAT, name2, EXT_PST);
   user_pause();
}

void file_dat_p()
{
   state_node *t1;
   INT_S s1;

   t1 = NULL; s1 = 0;

   file_dat_r(&t1, &s1);

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   }

   freedes(s1, &t1);
}

void file_ads_header()
{
   printw("FILE"); println();
   println();
   printw("DES2 = FILE (ADS1)"); println();
   println();
}

void file_ads_r(state_node** t1,
                INT_S *s1)
{
   INT_S init = 0;
   INT_OS return_code;
   long num_err = 0;
   ads_err_log_t *err_log = NULL;
   long i;
   char ch;

   clear();
   file_ads_header();
   quit =    getname("Enter name of ADS1 ........  ", EXT_ADS, name1, false);
   if (quit) return;

   printw("Same name for DES2?   (*y/n)   ", name1);
   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( (ch == 'N') || (ch == 'n') ) {
      if (ch != CEnter) {
         printw("%c", ch);
      }
      println();
      println();
      quit = getname("Enter new name for DES2 ....  ",
                     EXT_DES, name2, true);
      if (quit) return;
   } else {
      strcpy(name2, name1);
      println();
      quit = getname2("Enter new name for DES2 ...............  ",
                      EXT_DES, name2, true);
      if (quit) return;
   }

   strcpy(long_name1, "");
   make_filename_ext(long_name1, name1, EXT_ADS);

   return_code = ads_2_des(long_name1, &err_log, &num_err, t1, s1);

   if (mem_result == 1) {
      free(err_log);
      return;
   }

   if (return_code == 0)
   {
      init = 0;
      FILEDES(name2, *s1, init, *t1);

      if (!quit) {
         refresh();
         echo_save(name2);
      }
      return;
   }

   if (_wherey() > 11)
   {
      clear();
      file_ads_header();
      println();
   }

/*   println(); */
   printw("Error(s) reading file: %s", long_name1); println();
   println();

   for (i=0; (i < num_err) && (i < 10); i++)
   {
      if (err_log[i].line_num2 != -1)
      {
         printw("  %s at lines %ld and %ld.",
                ads_error_str[err_log[i].fail_code],
                err_log[i].line_num2, err_log[i].line_num1);
         println();
      }
      else if (err_log[i].line_num1 != -1)
      {
         printw("  %s at line %ld.",
                ads_error_str[err_log[i].fail_code],
                err_log[i].line_num1);
         println();
      }
      else
      {
         printw("  %s", ads_error_str[err_log[i].fail_code]);
         println();
      }
   }
   user_pause();

   quit = true;  /* Exit out */

   free(err_log);
}

void file_ads_makeit(state_node *t1,
                     INT_S s1)
{
   FILE* out;
   INT_S i,j, size;
   INT_T k;

   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;

   fprintf(out, "%s = Create(%s", name2, name2);

   /* Mark list */
   size = num_mark_states(t1, s1);
   if (size > 0) {
      fprintf(out, ",");
      fprintf(out, "[mark ");
      j = 0;
      for (i=0; i < s1; i++) {
         if (t1[i].marked) {
            fprintf(out, "%ld", i);
            j++;
            if (j < size)
               fprintf(out, ",");
         }
      }
      fprintf(out, "]");
   }

   size = num_vocal_output(t1, s1);
   if (size > 0) {
      fprintf(out, ",");
      fprintf(out, "[voc ");
      j = 0;
      for (i=0; i < s1; i++) {
         if (t1[i].vocal > 0) {
            fprintf(out, "[%ld,%d]", i, t1[i].vocal);
            j++;
            if (j < size)
               fprintf(out, ",");
         }
      }
      fprintf(out, "]");
   }

   size = count_tran(t1, s1);
   if (size > 0) {
      fprintf(out, ",");
      fprintf(out, "[tran ");
      j = 0;
      for (i=0; i < s1; i++) {
         for (k=0; k < t1[i].numelts; k++) {
            if (t1[i].next[k].data1 == EEE)
               fprintf(out, "[%ld,e,%ld]", i, t1[i].next[k].data2);
            else 
               fprintf(out, "[%ld,%d,%ld]", i, t1[i].next[k].data1,
                                               t1[i].next[k].data2);
            j++;
            if (j < size)
               fprintf(out, ",");
          }
      }
      fprintf(out, "]");
   }
   fprintf(out, ")");

   fprintf(out, "  (%ld,%ld)\n\n", s1, size);
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop((INT_OS)strlen(name2)+3);
}

/* Remove the extension */
void file_split(char* path, char *name, char *ext) {
   char *ptr;
   INT_S  pos;

   strcpy(name, path);
   ptr = strrchr(name, '.');
   if (ptr == NULL) {   /* No extension */
      ext = NULL;
      return;
   }

   pos = ptr-name;
   name[pos] = '\0';

   strcpy(ext, &(path[pos+1]));
}

INT_OS fail_num_entries;
INT_OS ok_convert;

void fail_file_ads_header()
{
   printw("FILE"); println();
   println();
   printw("DES2 = FILE(ADS1)"); println();
   println();
   println();
   printw("1.  File one .ADS to .DES"); println();
   println();
   printw("2.  File all .ADS to .DES"); println();
   println();
   println();
   printw("Please choose Option 1 or 2 ....  2"); println();
   println();
   printw("Number of successful filings is: %d", ok_convert); println();
   println();
   printw("Failures:  ");
}


void ads2des_output_page_control(INT_B  lastPage)
{
   move(20,0); clrtoeol();
   printw("Locate .ADS errors by inspection or by FD/ADS->DES/Option 1."); 
   println();
   printw("Use your ASCII Editor to correct.");
   continue_page("D=PgDn  U=PgUp  Esc (Exit)  ");

   do {
      refresh();
      ch = read_key();

      switch(ch) {
         case CEsc:
            quit = true;
            free(dir_stack); dir_stack = NULL;
            return;
         case CPgDn:
            if (lastPage == true) {
               ch = 0;
               ring_bell();
            } else {
               size_dir_stack++;
               dir_stack = (int*) realloc(dir_stack,
                                          sizeof(int)* size_dir_stack);
               dir_stack[size_dir_stack-1] = ii;
            }
            break;
         case CEnter:
            if (lastPage == false) {
               size_dir_stack++;
               dir_stack = (int*) realloc(dir_stack,
                                  sizeof(int)* size_dir_stack);
               dir_stack[size_dir_stack-1] = ii;
            } else{
               clear();
               fail_file_ads_header();
               return;
            }
            break;
         case CPgUp:
            if (size_dir_stack == 0) {
               ch = 0;
               ring_bell();
            } else {
               if (size_dir_stack >= 2) {
                  ii = dir_stack[size_dir_stack-2];
                  size_dir_stack -= 2;
                  dir_stack = (int*) realloc(dir_stack,
                                     sizeof(int) * size_dir_stack);

                  /* Put back the last pop */
                  size_dir_stack++;
                  dir_stack = (int*) realloc(dir_stack,
                                     sizeof(int) * size_dir_stack);
                  dir_stack[size_dir_stack-1] = ii;
               } else {
                  ii = 0;
                  size_dir_stack = 0;
                  free(dir_stack); dir_stack = NULL;
               }
               total_dir = 0;
            }
            break;
      }
   } while ( ( ch != CEnter) && (ch != CEsc) && (ch != CPgUp) && (ch != CPgDn) );

   clear();
   fail_file_ads_header();
}

INT_B  ads2des_directory_output(struct _finddata_t *namelist, INT_OS num_entries)
{
   char buf[80];
   INT_OS  max_str = 0;
   INT_OS  k;
   INT_OS  column;

   multiPage = false;
   total_dir = 0;
   dir_stack = NULL; size_dir_stack = 0;

   /* Either 1, 2 or 4 columns due to the length of the files */
   for (ii=0; ii < num_entries; ii++) {
      if (max_str < (INT_OS)strlen(namelist[ii].name))
         max_str = (INT_OS)strlen(namelist[ii].name);
   }
   max_str += 2;  /* Add two spaces for blanks */

   if (max_str < 17)
   {
      sprintf(buf, "%%-15s  ");
      column = 4;
   }
   else if (max_str < 34)
   {
      sprintf(buf, "%%-32s  ");
      column = 2;
   } 
   else
   {
      sprintf(buf, "%%-66s  ");
      column = 1;
   }

   ii = 0;
   do {
     while (ii < num_entries) {
        if (strlen(namelist[ii].name) > 68)
        {
           for (k=0; k < 68; k++)
              printw("%c", namelist[ii].name[k]);
        }
        else
            printw(buf, namelist[ii].name);
            
        total_dir++;
        if (total_dir % column == 0)
        {
          println();
          printw("%-11s", "");
        }

        if (_wherey() >= 19) {
           ads2des_output_page_control(false);
           if (quit) return true;
        }
        ii++;
     }
     ads2des_output_page_control(true);
     if (quit) return true;
   } while ( (ch != CEnter) && (ch != CPgDn) );

   free(dir_stack); dir_stack = NULL;
   return false;
}

void all_ads_to_des()
{
   struct _finddata_t *namelist;
   INT_OS num_entries;
   char dir[256];
   char ext1[4];
   INT_OS i;
   state_node *t;
   INT_S s;
   INT_S init;
   INT_OS return_code;
   long line_num;
   long line_num2 = -1;
   struct _finddata_t *fail_namelist = NULL;
   struct stat buf;

   fail_num_entries = 0;
   ok_convert = 0;

   strcpy(dir, path);
   strcat(dir, SEP);
   strcat(dir, "*.*");    /* Must provide a path */

   num_entries = scandir(dir, &namelist);

   for (i= 0; i < num_entries; i++) {
      t = NULL; s = 0;
      line_num2 = -1;

      sprintf(long_name1, "%s%s%s", path, SEP, namelist[i].name);
      strcpy(name1, namelist[i].name);
      file_split(name1, name1, ext1);
      dos_uppercase(ext1);
      strcpy(name2, name1);   /* Input name1 and name2 are the same name */
      stat(long_name1, &buf);

      if ( /*S_ISREG(buf.st_mode) &&*/ (strcmp(ext1, "ADS") == 0) )
      {
         sprintf(long_name1, "%s%s%s", path, SEP, namelist[i].name);

         return_code = ads_2_des_all(long_name1, &line_num, &line_num2, &t, &s);

         if ((return_code == 0) && (mem_result != 1))
         {
            init = 0;
            FILEDES(name2, s, init, t);
            file_ads_makeit(t, s);
            ok_convert++;
         }
         else
         {
            fail_num_entries++;
            fail_namelist = (struct _finddata_t*) realloc(fail_namelist, sizeof(struct _finddata_t)*fail_num_entries);
            fail_namelist[fail_num_entries-1] = namelist[i];
         }

         mem_result = 0;
      }

      freedes(s, &t);
   }
   free(namelist);

   println();
   println();
   printw("Number of successful filings is: %d", ok_convert); println();
   println();

   if (fail_num_entries == 0)
   {
      printw("Failures: %d", fail_num_entries); println();
      user_pause();
   }
   else
   {
      printw("Failures:  ");
      quit = false;
      ads2des_directory_output(fail_namelist, fail_num_entries);
   }

   free(fail_namelist);
}



INT_OS ask_file_ads_r()
{
   INT_OS option;
   char ch;

   clear();
   file_ads_header();
   esc_footer();
   refresh();

   println();
   printw("1.  File one .ADS to .DES"); println();
   println();
   printw("2.  File all .ADS to .DES"); println();

   println();
   println();
   printw("Please choose Option 1 or 2 ....  ");

   option = (INT_OS)readint(&ch, 1, 2);
   if (ch == CEsc)
   {
     quit = true;
     return 1;
   }

   if (option == 1)
      return 0;

   all_ads_to_des();

   quit = true;
   return 1;
}

void file_ads_p()
{
   state_node *t1;
   INT_S s1;

   t1 = NULL;
   s1 = 0;

   if (ask_file_ads_r()) {
      quit = true;
   } else {
      file_ads_r(&t1, &s1);
   }

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   } else {
      if (!quit) {
         file_ads_makeit(t1, s1);
      }
   }

   freedes(s1, &t1);
}

long *file_stack;
long file_stack_size;

INT_B  intro_page_control(INT_B  lastPage, FILE *in)
{
   char ch;
   long fpos;

   move(24,0); clrtoeol();


   printw(" D=PgDn  U=PgUp  Esc (Return to Main Options)  ");


   do {
       refresh();
       ch = read_key();

       switch(ch) {
          case CEsc:
            free(file_stack); file_stack = NULL;
            file_stack_size = 0;
            return true;

          case CPgDn:
          case CEnter:
            if (lastPage == true)
            {
               ch = 0;
               ring_bell();
            } else {
               file_stack_size++;
               file_stack = (long*) realloc(file_stack,
                                   sizeof(long) * file_stack_size);
               file_stack[file_stack_size-1] = ftell(in);
            }
            break;

          case CPgUp:
            if (file_stack_size == 0)
            {
               ch = 0;
               ring_bell();
            } else {
               if (file_stack_size >= 2) {
                  fpos = file_stack[file_stack_size-2];
                  file_stack_size -= 2;
                  file_stack = (long*) realloc(file_stack,
                                       sizeof(long) * file_stack_size);

                  /* Put back the last pop */
                  file_stack_size++;
                  file_stack = (long*) realloc(file_stack,
                                       sizeof(long) * file_stack_size);
                  file_stack[file_stack_size-1] = fpos;
               } else {
                  fpos = 0;
                  file_stack_size = 0;
                  free(file_stack); file_stack = NULL;
               }
               fseek(in, fpos, SEEK_SET);
            }
            break;

       }
   } while ( (ch != CEnter) && (ch != CPgUp) && (ch != CPgDn) );

   return false;
}

void introduction_p()
{
 //  FILE  *in;
 //  char  line[255];
   char  info_file_pdf[4 * MAX_PATH];
   char  cmdline[4 * MAX_PATH];
  // char  info_file_docx[4 * MAX_PATH];
  // INT_OS filetype = 0;
   char info_path[MAX_PATH];
   char work_dir[MAX_PATH];
//   HKEY hkey;
 //  long ret;

   _getcwd(work_dir, MAX_PATH);
   //_chdir(prefix);

   strcpy(info_file_pdf, "");
   //strcat(info_file_pdf, info_file);
   strcat(info_file_pdf, "TCT_Info.PDF");

   strcpy(cmdline, "");
   strcat(cmdline, "start ");
   strcat(cmdline, info_file_pdf);

   strcpy(info_path, "");
   strcat(info_path, info_file);
   strcat(info_path, ".PDF");

   file_stack = NULL;
   file_stack_size = 0;
   
   /* A defect in some versions of LINUX core dump
      if it is provided with a non-existing file.  
      This is a workaround.
   */
   if (_access(info_file_pdf, 0) ==0){//At least TCT_Info.doc exists
	    system(cmdline);
  // }else if(_access(info_file_docx, 0) ==0){//At least TCT_Info.docx exists
	//   filetype = 2; 
   }else{ // None of TCT_Info.doc and TCT_Info.docx exists
	   clear();
	   move(7,0); printw("FILE TCT_INFO.PDF NOT FOUND!");println();
	   println();
	   printw("FILE EXPECTED AT: ");println();
	   println();
	   print_fix_filename(dos_uppercase(info_path), SCREEN_WIDTH-18); println();	   
	   println();
	  // printw("or");println();
	  // println();	
	  // print_fix_filename(dos_uppercase(info_file_docx), SCREEN_WIDTH-18);
	  // printw("FILE EXPECTED AT: %s or %s", dos_uppercase(info_file_doc),dos_uppercase(info_file_doc));
	   user_pause();
	  // _chdir(work_dir);
	   return;
   }

 /*  strcpy(path, "Software\\Microsoft\\Office\\Word\\");
   
   ret = RegOpenKeyEx(HKEY_LOCAL_MACHINE, path, 0, KEY_READ, &hkey);
   if(ret != ERROR_SUCCESS){
	   clear();
	   move(7,0); printw("MICROSOFT OFFICE WORD NOT FOUND!");
	   user_pause();
   }else{
	   if(filetype == 1)
		   system(info_file_doc);
	   else
		   system(info_file_docx);
	   //user_pause();
   }
   */
  /* if (_access(info_file_doc, 0) !=0)
   {  
      clear();
      move(7,0); printw("FILE TCTINFO.TXT NOT FOUND!");
      println();
      printw("FILE EXPECTED AT: %s", dos_uppercase(info_file));
      user_pause();
      return;
   }    */
   
/*   in = fopen(info_file, "r");

   if (in == NULL) {
      clear();
      move(7,0); printw("FILE TCTINFO.TXT NOT FOUND!"); println();
      printw("FILE EXPECTED AT: ");
      print_fix_filename(dos_uppercase(info_file), SCREEN_WIDTH-18);
      user_pause();
      return;
   }

   setvbuf(in, NULL, _IOFBF, 4000);

   clear();
   while(1) {

      while ( fgets(line, 254, in) != NULL ) {
         switch(line[0]) {
           case '#': println();
                     break;
           case '$':
                     if (intro_page_control(false, in))
                     {
                        fclose(in);
                        return;
                     } else {
                        clear();
                     }
                     break;
           default:  if (strlen(line) > 0) {
                        line[strlen(line)-1] = '\0';
                     }
                     printw("%s", line); println();
         }
      }

      if (intro_page_control(true, in))
      {
         fclose(in);
         return;
      }
      clear();
   }*/
   clear();
   //_chdir(work_dir);
}

void reset_directory_header()
{
   char dir[256];

   clear();
   println();
   println();
   printw("            RESETTING USER FILE DIRECTORY PATH");
   println();
   println();
   printw("Files that you create while using TCT will be stored, by default,"); println();
   printw("in a subdirectory (subfolder) USER of the TCT directory.  However,"); println();
   printw("it is recommended that you store these files in a new directory,"); println();
   printw("say NEWFILES, specific to the current project or session."); println();
   println();
   printw("For this, after creating NEWFILES in your operating system,"); println();
   printw("enter the corresponding path in response to the prompts below."); println();
   

   strcpy(dir, path);
   printw("Current directory path is %s. OK?  (*y/n)  ", dos_uppercase(dir));
}

void reset_directory_p()
{
   char ch;
   char tempPath[256];
   char currentDir[256];

   reset_directory_header();
   refresh();
   ch = read_key();
   if (ch == CEsc) return;

   if ( (ch == 'N') || (ch == 'n') ) {
       if (ch != CEnter) {
          printw("%c", ch);
       }
       println();
       println();
       printw("Have you created an alternative user directory? (*y/n)  ");
       refresh();
       ch = read_key();
       if (ch == CEsc) return;

       if ( (ch == 'N') || (ch == 'n') ) {
          if (ch != CEnter) {
            printw("%c", ch);
          }
          println();
          println();
          
          printw("Create new directory in your operating system, then restart TCT."); println();
          println();
          printw("Press any key to exit.  ");

          refresh();
          ch = read_key();
          exit(0);

	   }
       strcpy(tempPath,"");
       println(); println();
       printw("Enter path for new user directory:  ");
       refresh();
       ch = read_filename(tempPath, 1, 79);
       if (ch == CEsc) return;

       /* Verify that the given directory exists */
       _getcwd(currentDir, 255);
       if (_chdir(tempPath) == -1) {
         println();
         println();
         printw("Directory %s does not exist!", tempPath);
         move(23,0); clrtoeol();
         printw("Press <Enter> to return %s Procedures  ", TCTNAME);
         refresh();
         do {
           ch = read_key();
         } while (ch != CEnter);
       } else {
         /* TCT version would save the path in a variable
            that would be used to indicate the current directory */
         /* In CTCT, we will allow the path to be changed */
         strcpy(path,tempPath);


         if (tempPath[strlen(tempPath)-1] != '\\')
             strcat(tempPath, "\\");


         strcpy(prefix, tempPath);

         _chdir(currentDir);

         /* Save the current path in ctct_ini_file */
         {
             FILE *out;
             out = fopen(ctct_ini_file, "wt");
             if (out != NULL)
             {
                fprintf(out, "%s\n", path);
                fprintf(out, "CLOCK %d\n", timing_mode);
                fclose(out);
             }
         }
       }
   }
}

void bell_control_p()
{
   ring_active = !ring_active;
   ring_bell();
}

void display_control_p()
{
   debug_mode = !debug_mode;
}

void timing_control_p()
{
   FILE *out;
     
   timing_mode = !timing_mode;
   
   /* Write the change into the ctct.ini file */
   out = fopen(ctct_ini_file, "wt");
   if (out != NULL)
   {
      fprintf(out, "%s\n", path);
      fprintf(out, "CLOCK %d\n", timing_mode);
      fclose(out);
   }   
}

void check_des_header()
{
   printw("CHECK DES SANITY"); println();
   println();
   printw("CHECK (DES1)"); println();
   println();
}

void check_des_r(state_node** t1, INT_S *s1)
{
   INT_S init;
   INT_OS   x,y;
   INT_B  flag;

   clear();
   check_des_header();

   quit = getname("Enter name of DES ....  ", EXT_DES, name1, false);
   if (quit) return;

   init = 0L;
   if (getdes(name1, s1, &init, t1) == false) {
      quit = true;
      return;
   }

   x = _wherex(); y = _wherey();
   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   flag = check_des_sanity(*t1, *s1);
   move(23,0); clrtoeol();
   move(y,x);
   println();
   println();

   if (flag) {
      printw("%s is OK.", name1);
   } else {
      printw("%s is insane.", name1);
   }
}

void check_des_p()
{

   state_node *t1;
   INT_S s1;

   t1 = NULL; s1 = 0;

   check_des_r(&t1, &s1);

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   } else {
      if (!quit) {
         user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
}

void supreduce_header() {
   printw("SUPREDUCE"); println();
   println();
   printw("DES3 = SUPREDUCE (DES1, DES2, DAT2)"); println();
   println();
}

void supreduce_header1() {
	printw("SUPREDUCE"); println();
	println();
	printw("%s = SUPREDUCE (%s, %s, %s)", name4, name1, name2, name3); println();
	println();
}

INT_OS supreduce_r(INT_S *lb, float *cr, INT_B *check_flag, INT_B *slb_flag)
{
	INT_S init,i,j;
	INT_OS result;
	INT_B   ok, iso_flag;
	INT_OS x, y;
	INT_S s4, s5, s6; state_node *t4, *t5, *t6;
	INT_T s_list1, s_list2, *list1, *list2;
	INT_S    *mapState;

	s4 = s5 = s6 = 0; t4 = t5 = t6 = NULL;
	s_list1 = s_list2 = 0;
	list1 = list2 = NULL;
	mapState = NULL;

	clear();
	supreduce_header();
	quit = getname("Enter name of plant generator DES1 ..........  ", EXT_DES, name1, false);
	if (quit) return 0;

	quit = getname("Enter name of DES2 [= Supcon(DES1,DES?)] ....  ", EXT_DES, name2, false);
	if (quit) return 0;

	quit = getname("Enter name of DAT2 [= Condat(DES1,DES2)] ....  ", EXT_DAT, name3, false);
	if (quit) return 0;

	quit = getname("Enter name of DES3 ..........................  ", EXT_DES, name4, true);
	if (quit) return 0;

	if (_wherey() > 20)
	{
		clear();
		supreduce_header1();
		esc_footer();
	}    

	printw("Compute slb estimate (at cost of run time increase)? ......  (*y/n)");
	refresh();
	ch = read_key();
	if (ch == CEsc) {
		quit = 1;
		return 0;
	}   

	if (ch != CEnter) {
		printw("%c", ch);
	}
	println();
	println();

	if(ch != 'n' && ch != 'N'){
		*slb_flag = true;
	}else
		*slb_flag = false;

	// Recompute the Condat file

	condat_runProgram(name3, name1, name2);

	//compare the event list of PLANT and SUPER and check if the cleanup procedure is necessary
	init = 0L;
	if(getdes(name1, &s4, &init, &t4)){
		for(i = 0; i < s4; i ++){
			for(j = 0; j < t4[i].numelts; j ++){
				addordlist(t4[i].next[j].data1, &list1, s_list1, &ok);
				if(ok) s_list1 ++;
			}
		}
	}

	init = 0L;
	if(getdes(name2, &s5, &init, &t5)){
		for(i = 0; i < s5; i ++){
			for(j = 0; j < t5[i].numelts; j ++){
				addordlist(t5[i].next[j].data1, &list2, s_list2, &ok);
				if(ok) s_list2 ++;
			}
		}
	}
	*check_flag = true;
	if(s_list1 == s_list2){
		for(i = 0; i < s_list1; i ++){
			if(list1[i] != list2[i]){
				*check_flag = false;
				break;
			}
		}
	}else{
		*check_flag = false;
	}

	freedes(s4, &t4);
	freedes(s5, &t5);
	s4 = s5 = 0; t4 = t5 = NULL;

	x = wherex()-1; y = wherey();
	move(22, 0); clrtoeol(); refresh();
	move(23, 0); clrtoeol(); refresh();
	printw("Processing:  Please wait...");
	refresh();

	/* Pass to command line version of this program */
	mark_start_time();
#if defined(_x64_)
	result = supreduce_runProgram(name4, name1, name2, name3, 1, lb, cr, *slb_flag);
	//if(*lb == 0)
	//*lb = -1;
	
#else 
	//result = supreduce(long_name1, long_name2, long_name3, long_name4, lb, cr);
	result = supreduce_runProgram(name4, name1, name2, name3, 0, lb, cr, *slb_flag);
	if((result != 0)&&(result != 4)){
		mem_result = 0;
		move(y,x);
		printw("Owing to problem size, only the reduced supervisor will be computed,"); println();
		printw("not the state lower bound (slb) estimate.");
		move(22, 0); clrtoeol(); refresh();
		move(23, 0); clrtoeol(); refresh();
		printw("Processing:  Please wait...");
		refresh();
		result = supreduce_runProgram(name4, name1, name2, name3, 1, lb, cr, *slb_flag);
		//result = ex_supreduce( long_name1, long_name2, long_name3, long_name4, lb, cr);
		//*lb = 0;
	}  
#endif

	mark_stop_time();  

	if (result == 0) {
		strcpy(long_name4, "");
		make_filename_ext(long_name4, name4, EXT_DES);
		init = 0;
		if (exist(long_name4)){
			if(!getdes(name4, &s4, &init, &t4))
				return 0;
			export_copy_des(&s5, &t5, s4, t4);
			if(*check_flag){
				init = -1L;
				getdes(name3, &s6, &init, &t6);
				iso_flag = true;
				if(s5 != 0){
					clean_selfloop(s5, t5, s6, t6);				
					mapState = (INT_S*)CALLOC(s5, sizeof(INT_S));
					memset(mapState, -1, s5 * sizeof(INT_S));
					mapState[0] = 0;
					iso1(s5, s4, t5, t4, &iso_flag, mapState);
					free(mapState);
				}
				if(!iso_flag){
					//do {
						if (_wherey() > 20)
						{
							clear();
							supreduce_header1();
							esc_footer();
						}    

						printw("Execute clean-up procedure? (*y/n)");
						refresh();
						ch = read_key();
						if (ch == CEsc) {
							quit = 1;
							return 0;
						}   

						if (ch != CEnter) {
							printw("%c", ch);
						}
						println();
						println();
					//} while (strchr(YNCommandSet, ch) == NULL);

					if(ch != 'n' && ch != 'N'){
						*check_flag = true;
					}else
						*check_flag = false;
				}
			}  
			init = 0L;
			if(*check_flag){
				filedes(name4, s5, init, t5);
			}else{
				init = 0L;
				filedes(name4, s4, init, t4);
			}
		}
		else
			quit = true;
	}
	else 
	{
		if (result > 0){
			if(result == CR_OUT_OF_MEMORY)
				mem_result = 1;
			else
				supreduce_flag = 3;
		}
		else{
			quit = true;
		}
	}
	free(list1);
	free(list2);
	freedes(s4, &t4);
	freedes(s5, &t5);
	freedes(s6, &t6);

	return 0;
}


void supreduce_makeit (state_node* t1, INT_S s1, INT_S lb, INT_B slb_flag)
{
   FILE* out;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;
   fprintf(out, "%s = Supreduce(%s,%s,%s)", name4, name1, name2, name3);
   fprintf(out, "  (%ld,%ld", s1, count_tran(t1, s1), lb);
   if((slb_flag == true) && (lb > 0)){
	   fprintf(out, ";slb=%ld)", lb);
   }else{
	    fprintf(out, ")");
   }

   appendTime(out, (INT_OS)strlen(name4)+3);
   fprintf(out, "\n\n");
   fclose(out);
}

void supreduce_p()
{
   state_node *t4;
   INT_S s4, init;
   INT_S lb;
   float cr;
   float cr2;
   INT_OS result;
   INT_B check_flag;
   INT_B slb_flag;

   t4 = NULL;
   s4 = 0;
   lb = 0;
   cr = 0;

   slb_flag = true;
   supreduce_flag = 0;
   result = supreduce_r(&lb, &cr, &check_flag, &slb_flag);

   if (mem_result == 1) {
      mem_result = 0;   /* Reset memory result counter */
      OutOfMemoryMsg();
      user_pause();
   } else if (supreduce_flag > 0) {
      move(22,0); clrtoeol(); refresh();
      printw("Error, check the entries");//, supreduce_flag);
      supreduce_flag = 0;
      user_pause();
   } else {
      if (!quit) {
		 init = 0L;
		 if(getdes(name4, &s4, &init, &t4)){

			 supreduce_makeit(t4, s4, lb, slb_flag);

			 move(17,0); clrtoeol(); refresh();
			 move(18,0); clrtoeol(); refresh();
			 move(19,0); clrtoeol(); refresh();
			 move(20,0); clrtoeol(); refresh();
			 move(21,0); clrtoeol(); refresh();
			 move(18,0);
			 cr2 = (float) cr;
			 if(s4 == 1)
				 printw("Reduced supervisor %s has %d state; compression ratio = ", name4, s4);
			 else
				 printw("Reduced supervisor %s has %d states; compression ratio = ", name4, s4);
			 printw("%f", cr2);
			 if(lb != 0){
				 move(19,0); clrtoeol(); refresh();
				 printw("Lower bound estimate of minimal state size: %d", lb);
				 move(21,0); clrtoeol(); refresh();
				 if(check_flag){
					 printw("Verify %s = Sync(%s,%s), possibly after application of Minstate",name2,name1,name4);
				 }else{
					 printw("Verify %s = Meet(%s,%s), possibly after application of Minstate",name2,name1,name4);
				 }
			 }else{
				 move(20,0); clrtoeol(); refresh();
				 if(check_flag){
					 printw("Verify %s = Sync(%s,%s), possibly after application of Minstate",name2,name1,name4);
				 }else{
					 printw("Verify %s = Meet(%s,%s), possibly after application of Minstate",name2,name1,name4);
				 }
			 }
			 refresh();
			 user_pause();
		 }
      }else{
         if(result == 1){
            move(19,0); clrtoeol(); refresh();
            move(20,0); clrtoeol(); refresh();
            move(21,0); clrtoeol(); refresh();
            move(20,0);
            printw("Input supervisor is too large to compute");
            refresh();
            user_pause();
         }
      }
   }

   echo_free();
   quit = 0;
   freedes(s4, &t4);
}

/*
 * Supscop 
 */

void supscop_header() {
	printw("SUPSCOP"); println();
	println();
	printw("DES3 = SUPSCOP (DES1, DES2, NULL/IMAGE/IMAGE_DES)"); println();
	println();
}

void supscop_r(state_node **t1,
                  INT_S *s1,
                  state_node **t2,
                  INT_S *s2,
                  state_node **t3,
                  INT_S *s3,
                  INT_T **list,
                  INT_T *slist, 
                  INT_T **imagelist,
                  INT_T *s_imagelist,
                  INT_S  *mode)
{
   INT_S  init;
   INT_OS    result;

   clear();
   supscop_header();
   refresh();

   quit = getname("Enter name of plant generator DES1 .............  ",
	   EXT_DES, name1, false);
   if (quit) return;

   quit = getname("Enter name of legal language generator DES2 ....  ",
                  EXT_DES, name2, false);
   if (quit) return;


   quit = getname("Enter name of DES3 ....  ",
                   EXT_DES, name3, true);
   if (quit) return;
   
	get_imagelist(s_imagelist, imagelist, slist, list, mode, 3);
   if(quit) return;

   /* Read in the two files in */
   init = 0L;
   if (getdes(name1, s1, &init, t1) == false) {
       quit = true;
       return;
   }
   
   init = 0L;
   if (getdes(name2, s2, &init, t2) == false) {
      quit = true;
      return;
   }  
   
   if ((*mode != 1))
   {
       gen_complement_list(*t1, *s1,
                           *imagelist, *s_imagelist,
                           list, slist);
       gen_complement_list(*t2, *s2,
                           *imagelist, *s_imagelist,
                           list, slist);                            
   }
   //freedes(*s1, t1); *s1 = 0; *t1 = NULL;
   //freedes(*s2, t2); *s2 = 0; *t2 = NULL;

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();


   /* Pass to command line version of this program */
   mark_start_time();
   result = supscop_runProgram(name3, name2, name1, *list, *slist);   
   mark_stop_time();

   if (result == CR_OK) {
      strcpy(long_name3, "");
      make_filename_ext(long_name3, name3, EXT_DES);   
      if (exist(long_name3))
      {
         init = 0;
         if(!getdes(name3, s3, &init, t3))
			 quit = true;
      }      
      else
         quit = true;
   } else {
      if (result == CR_OUT_OF_MEMORY)
         mem_result = 1;
      else
         quit = true;
   }
}

void supscop_makeit(state_node *t3,
	INT_S s3,
	INT_T *sp,
	INT_T s_sp,
	INT_T *imagelist,
	INT_T s_imagelist,
	INT_S  mode)
{
	FILE* out;
	INT_S i;

	/* Write to a tempory file */
	out = fopen("tmp.$$$", "w");
	if (out == NULL) return;
	fprintf(out, "%s = Supscop(%s,%s,", name3, name1, name2);

	if (mode == 1)
	{
		fprintf(out, "Null[");   
		for (i=0; i < s_sp; i++) {
			fprintf_event(out, sp[i]);
			if (i+1 < s_sp)
				fprintf(out, ",");
		}
		fprintf(out, "]");
	} else if(mode == 2) {
		fprintf(out, "Image[");
		for (i=0; i < s_imagelist; i++) {
			fprintf_event(out, imagelist[i]);
			if (i+1 < s_imagelist)
				fprintf(out, ",");
		}  
		fprintf(out, "]");
	}  else{
		fprintf(out, "%s", imagename);
	}         

	fprintf(out, ")");
	fprintf(out, "  (%ld,%ld)", s3, count_tran(t3, s3));
	appendTime(out, (INT_OS)strlen(name3)+3);
	fprintf(out, "\n\n");
	fclose(out);

	/* Merge file into MAKEIT.TXT */
	mergeChop((INT_OS)strlen(name3)+3);
}

void supscop_p()
{
	state_node *t1, *t2, *t3;
	INT_S s1, s2, s3;
	INT_T *sp;
	INT_T s_sp;
	INT_T *imagelist;
	INT_T s_imagelist;
	INT_S mode;

	t1 = t2 = t3 = NULL;
	s1 = s2 = s3 = 0;
	s_sp = 0; sp = NULL;
	imagelist = NULL; s_imagelist = 0;

	supscop_r(&t1, &s1, &t2, &s2, &t3, &s3, &sp, &s_sp, &imagelist, &s_imagelist,&mode);

	if (mem_result == 1) {
		mem_result = 0;
		OutOfMemoryMsg();
		user_pause();
	} else {
		if (!quit) {
			supscop_makeit(t3, s3, sp, s_sp, imagelist, s_imagelist, mode);
			user_pause();
		}
	}

	echo_free();
	freedes(s1, &t1);
	freedes(s2, &t2);
	freedes(s3, &t3);
	free(imagelist);
	free(sp);
}

/*******************************/
/*  CanQC/CanSQC               */
/*******************************/

     

void CanQC_header() {
	printw("SUPREMAL QUASI-CONGRUENCE"); println();
	println();
	printw("DES2 = SUPQC (DES1, NULL/IMAGE/IMAGE_DES)"); println();
	println();
}

void CanSQC_header() {
	printw("SUPREMAL STRONG QUASI-CONGRUENCE"); println();
	println();
	printw("DES2 = SUPSQC (DES1, NULL/IMAGE/IMAGE_DES)"); println();
	println();  
}     
   
void SupQC_header() {
	printw("SUPREMAL (STRONG) QUASI-CONGRUENCE"); println();
	println();
	printw("DES2 = SUP(S)QC (DES1, NULL/IMAGE/IMAGE_DES)"); println();
	println();  
} 

void CanQC_r(state_node **t1,
             INT_S *s1,
             INT_T **list,
             INT_T *slist,
             INT_T **imagelist,
             INT_T *s_imagelist,
             INT_S **statemap,
             INT_S *s_statemap,
             INT_B  *null_flag,
             INT_B  *is_det,
             INT_B  *report_qc,
             INT_OS *mode,
			 INT_S *image_flag)
{
   INT_S      init;
   INT_OS        result;

   clear();
   SupQC_header();
   refresh();

   quit = getqc("Select supqc/supsqc .................... qc/sqc? ", mode);
   if (quit) return;   

   clear();
   if (*mode == 1)
	   CanQC_header();
   else 
	   CanSQC_header();      
   esc_footer();

   quit = getname("Enter name of DES1 .....................  ",
                  EXT_DES, name1, false);
   if (quit) return;

   quit = getname("Enter name of DES2 .....................  ",
                  EXT_DES, name2, true);                                                
   if (quit) return;    


	if(*mode == 1)
		get_imagelist(s_imagelist, imagelist, slist, list, image_flag, 1);
	else
		get_imagelist(s_imagelist, imagelist, slist, list, image_flag, 2);
	if(quit) return;

   if (_wherey() > 20)
   {
       clear();
	   if (*mode == 1)
		   CanQC_header_continue2((INT_OS)*image_flag);
	   else 
		   CanSQC_header_continue2((INT_OS)*image_flag);  
       esc_footer();
   }       

   println();
   if (*mode == 1)
      printw("Report QC state partition in MAKEIT.TXT?  (y/*n)  ");
   else
      printw("Report SQC state partition in MAKEIT.TXT?  (y/*n)  ");   

   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }
   if (ch != CEnter) {
      printw("%c", ch);
   }
   println();
   println();
   if ( (ch == 'y') || (ch == 'Y') ) {
      *report_qc = true;
   }

   init = 0L;
   if (getdes(name1, s1, &init, t1) == false) {
      quit = true;
      return;
   }

   if (*image_flag != 1)  {
      gen_complement_list(*t1, *s1,
                          *imagelist, *s_imagelist,
                          list, slist);
   }
    
   freedes(*s1, t1);

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();
     
   result = CanQC_runProgram (name2, name1, *slist, *list,s_statemap, statemap, *mode);    
   mark_stop_time();

   if (result == CR_OK) {
      strcpy(long_name2, "");
      make_filename_ext(long_name2, name2, EXT_DES);   
      if (exist(long_name2))
      {
         init = 0;
		 if(getdes(name2, s1, &init, t1)){  
			 *is_det = is_deterministic(*t1, *s1);
			 move(20,0); clrtoeol();
			 move(21,0); clrtoeol();
			 move(22,0); clrtoeol();
			 move(21,0);
			 if (*is_det)
				 printw("%s is DETERMINISTIC.", name2);
			 else
				 printw("%s is NONDETERMINISTIC.", name2);     
		 }
      }      
      else
         quit = true;   
   } else {
      if (result == CR_OUT_OF_MEMORY)
         mem_result = 1;
      else
         quit = true;
   }
}

void CanQC_makeit(state_node *t1, INT_S s1, INT_T *list, INT_T slist, INT_T *imagelist, INT_T s_imagelist,
					  INT_S *statemap,  INT_S s_statemap, INT_B  is_det, INT_B  report_qc, INT_OS mode, INT_S image_flag)
{
	FILE* out;
	INT_T i;
	INT_S ii, jj;
	INT_B  elem, prev;

	/* Write to a tempory file */
	out = fopen("tmp.$$$", "w");
	if (out == NULL) return;

	if (mode == 1)   
		fprintf(out, "%s = Supqc(%s,", name2, name1);
	else
		fprintf(out, "%s = Supsqc(%s,", name2, name1);

	if (image_flag == 1)
	{
		fprintf(out, "Null[");
		for (i=0; i < slist; i++) {
			fprintf_event(out, list[i]);
			if (i+1 < slist)
				fprintf(out, ",");
		}
		fprintf(out, "]");
	}
	else if(image_flag == 2)
	{
		fprintf(out, "Image[");
		for (i=0; i < s_imagelist; i++) {
			fprintf_event(out, imagelist[i]);
			if (i+1 < s_imagelist)
				fprintf(out, ",");
		}
		fprintf(out, "]");
	}else{
		fprintf(out, "%s", imagename);
	}


	if (report_qc) {
		/* Dump QC */
		if (mode == 1)
			fprintf(out, ",QC[");
		else
			fprintf(out, ",SQC[");

		prev = FALSE;
		for (ii=0; ii < (s_statemap-1); ii++) {
			elem = FALSE; 
			for (jj=ii+1; ((jj < s_statemap) && (statemap[ii] == ii)); jj++) {
				if (ii == statemap[jj])
				{
					if (!elem) 
					{
						if (prev == TRUE)
							fprintf(out,","); 
						fprintf(out, "[%d,%d", ii, jj);
						elem = TRUE;
					}  
					else
						fprintf(out, ",%d", jj);
				}      
			}          
			if (elem)
			{
				fprintf(out, "]");
				prev = TRUE;
			}  
		}    

		fprintf(out, "]");
	} else {

		if (mode == 1)
			fprintf(out, ",QC[omitted]");
		else    
			fprintf(out, ",SQC[omitted]");    
	}
	fprintf(out, ")");

	fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1));

	if (is_det)
		fprintf(out, "  Deterministic.");
	else
		fprintf(out, "  Nondeterministic.");      

	appendTime(out, (INT_OS)strlen(name2)+3);
	fprintf(out, "\n\n");
	fclose(out);

					  /* Merge file into MAKEIT.TXT */
	mergeChop((INT_OS)strlen(name2)+3);
}

void CanQC_p()
{
	state_node *t1;
	INT_S s1;
	INT_T *list, slist;
	INT_B  null_flag = true;
	INT_B  is_det = true;
	INT_B  report_qc = false;
	INT_T *imagelist, s_imagelist;
	INT_S *statemap, s_statemap;
	INT_S image_flag;
	INT_OS mode = 1;

	t1 = NULL; s1 = 0;
	list = NULL; slist = 0;
	imagelist = NULL; s_imagelist = 0;
	statemap = NULL; s_statemap = 0;

	CanQC_r(&t1, &s1, &list, &slist, &imagelist, &s_imagelist, &statemap,
		&s_statemap, &null_flag, &is_det, &report_qc, &mode, &image_flag);

	if (mem_result == 1) {
		mem_result = 0;
		OutOfMemoryMsg();
		user_pause();
	} else {
		if (!quit) {
			CanQC_makeit(t1, s1, list, slist, imagelist, s_imagelist, 
				statemap, s_statemap, is_det, report_qc, mode, image_flag);
			user_pause();
		}
	}

	echo_free();
	freedes(s1, &t1);
	free(list);
	free(imagelist);
	free(statemap);
}

/// Check (strong) observability
void obs_header()
{
	printw("(STRONG) OBSERVABLILITY"); println();
	println();
	printw("OBS (DES1, DES2, NULL/IMAGE/IMAGE_DES)");println();
	println();
}
void oc_header()
{
	printw("OBSERVABLILITY"); println();
	println();
	printw("OBS (DES1, DES2, NULL/IMAGE/IMAGE_DES)");println();
	println();
}
void soc_header()
{
	printw("STRONG OBSERVABLILITY"); println();
	println();
	printw("SOBS (DES1, DES2, NULL/IMAGE/IMAGE_DES)");println();
	println();
}
void obs_display_dat(state_node *t1,
                    INT_S s1,FILE *f1)
{
   INT_S k;
   INT_T t;
   state_pair *tran_stack;INT_S s_tran_stack;
   INT_S total_tran,prevNumTran;
   INT_B  leftSide;
   INT_S i,j;
   char strLabel[WIDTH_EVENT];

   tran_stack = NULL; s_tran_stack = 0;

   total_tran = 0;
   leftSide = false;
   prevNumTran = 0;
   i = 0; j = 0;


      while (i < s1) {
         if (t1[i].numelts > 0) {
           if ((prevNumTran > 6) || (t1[i].numelts > 6) || (leftSide == false)) {
              fprintf(f1,"\n%4s", " ");
              leftSide = true;
           } else {
              for (k=prevNumTran; k < 6; k++)
                 fprintf(f1,"%5s", " ");
              leftSide = false;
           }
           
           fprintf(f1,"%4d:", i);
           prevNumTran = t1[i].numelts;
         }

         while (j < t1[i].numelts) {
            t = t1[i].next[j].data1;
			if(t < START_INTLABEL)
				fprintf(f1,"%4d ", t);
			else{
				get_strlabel_by_intlabel(t, strLabel);
				fprintf(f1,"%s ", strLabel);
			}

            if ( (j != 0) && ((j % 12) == 0) && (j < prevNumTran-1) ) {              
               fprintf(f1,"\n%9s", " ");
            }
            j++;
         }
         j = 0;
         i++;
      }
   free(tran_stack);  tran_stack = NULL;

}
void obs_report(INT_OS mode, char *filename, INT_S s, state_node *t)
{
     FILE *f1;  
     INT_S j,k; 
     INT_S s_list, s_list1;
     char cmode[30];
     char ccmode[30];
     INT_B  ok;
     state_node *t1;INT_S s1;
     INT_T ee;
     
     strcpy(cmode,"");
     strcpy(ccmode,"");
     
     s_list = 0;
     s_list1 = 0;
       
     s1 = s;
     t1 = newdes(s1);
     
     for(j = 0; j < s; j ++){
        for(k = 0;k < t[j].numelts; k ++){
           ee = t[j].next[k].data1;
           if( ee== MMM){
              s_list ++;
           }
           else{
                addordlist1(ee,t[j].next[k].data2,&(t1[j].next),t1[j].numelts,&ok);
                if(ok) t1[j].numelts ++;
           }
           s_list1 ++;
        }
     }
     f1 = fopen(filename, "w");
     if(mode == 1){
        strcpy(cmode,"Observability");
        strcpy(ccmode,"observable");
     }
     else{
        strcpy(cmode,"Strong observability");
        strcpy(ccmode,"strongly observable");
     }
     fprintf(f1, "\n%s.DES is not %s with respect to %s.DES\n\n",name2,ccmode,name1);        
     ok = false;
     if(s_list1 != s_list){
        fprintf(f1, "%s fails at the following states of %s \nand the corresponding events. \n\n", cmode, name2); 
        obs_display_dat(t1,s1,f1);
        if(s_list != 0){
           fprintf(f1, "\n\n%s also fails at the following unmarked states of %s:\n\n", cmode,name2);
           ok = false;
           for(j = 0; j < s; j ++){
              for(k = 0;k < t[j].numelts; k ++){
                 if(t[j].next[k].data1 == MMM){
                     if(ok == false)
                         fprintf(f1,"%4s%4d"," ",j);
                     else{
                         fprintf(f1,"%9s"," ");
                         fprintf(f1,"%4d\n",j);                     
                     }
                     ok = !ok;
                 }
                    
              }
           }
         }
     }
     else{
        fprintf(f1, "%s fails at the following unmarked states of %s:\n\n", cmode, name2);
        ok = false;
        for(j = 0; j < s; j ++){
           for(k = 0;k < t[j].numelts; k ++){
                 if(t[j].next[k].data1 == MMM){
                     if(ok == false)
                         fprintf(f1,"%4s,%4d"," ",j);
                     else{
                         fprintf(f1,"%9s"," ");
                         fprintf(f1,"%4d\n",j);                     
                     }
                     ok = !ok;
                 }
           }
        }
     }    
     fclose(f1);
     freedes(s1,&t1);
}

void redisplay(INT_OS mode)
{
	clear();
	if(_wherey()>21){
		if(mode == 1)
			oc_header_continue1();
		else if(mode == 2)
			soc_header_continue1();
		esc_footer();
	}
}

void redisplay1(INT_OS mode, INT_OS entry_type)
{
	if(_wherey()>18){
		clear();
		if(mode == 1)
			oc_header_continue2(entry_type);
		else if(mode == 2)
			soc_header_continue2(entry_type);
		esc_footer();
	}
}

void obs_makeit(INT_B  is_observable, INT_OS mode, INT_S s1, state_node * t1, INT_S  null_flag, 
	INT_T s_list, INT_T *list, INT_T s_imagelist, INT_T *imagelist)
{
	FILE* out;
	INT_S i,j;
	INT_OS offset;
	INT_B first_elem;
	char tempstr[10];
	INT_T ee;
	char strLabel[WIDTH_EVENT];

	/*Write to a tempory file*/
	out = fopen("tmp.$$$","w");
	if(out == NULL) return;

	if(is_observable){
		fprintf(out, "true");
		offset = 7;
	}
	else{
		fprintf(out, "false");
		offset = 8;
	}

	if(mode == 1)
		fprintf(out, " = Obs(%s,%s,", name1, name2);
	else 
		fprintf(out, " = Sobs(%s,%s,", name1, name2);

	if (null_flag == 1)
	{
		fprintf(out, "Null[");
		for (i=0; i < s_list; i++) {
			fprintf_event(out, list[i]);
			if (i+1 < s_list)
				fprintf(out, ",");
		}
		fprintf(out, "]");
	}
	else if(null_flag == 2)
	{
		fprintf(out, "Image[");
		for (i=0; i < s_imagelist; i++) {
			fprintf_event(out, imagelist[i]);
			if (i+1 < s_imagelist)
				fprintf(out, ",");
		}
		fprintf(out, "]");
	}else{
		fprintf(out, "%s", imagename);
	}
	fprintf(out, ")");

	if(!is_observable){
		memset(tempstr, ' ', offset);
		tempstr[offset] = '\0';

		fprintf(out, "\n");
		if(mode == 1)
			fprintf(out, "%sFailObs(%s,%s[", tempstr, name1, name2);
		else 
			fprintf(out, "%sFailSobs(%s,%s[", tempstr, name1, name2);
		first_elem = true;
		for(i = 0; i < s1; i ++){
			for(j = 0; j < t1[i].numelts; j ++){
				if(!first_elem)
					fprintf(out, ";");
				first_elem = false;
				fprintf(out, "%d,", i);
				ee = t1[i].next[j].data1;
				if(ee == MMM)
					fprintf(out, "_");
				else if(ee < START_INTLABEL)
					fprintf(out, "%d", ee);
				else{
					get_strlabel_by_intlabel(ee, strLabel);
					fprintf(out, "%s", strLabel);
				}
				
			}
		}
		fprintf(out, "])");
	}

	appendTime(out, offset);
	fprintf(out,"\n\n");
	fclose(out);
	mergeChop(offset);

}
void obs_r()
{
	INT_OS mode;
	INT_T *list, slist, *imagelist, s_imagelist;
	INT_S  null_flag;
	INT_S      init;
	INT_OS        result;
	INT_B     is_observable;
	INT_OS x, y;
	char filename[MAX_PATH];

	state_node *t1, *t2;
	INT_S s1, s2;

	list = imagelist = NULL;
	slist = s_imagelist = 0;
	s1 = s2 = 0;
	t1 = t2 = NULL;
	result = 0;

	clear();
	obs_header();
	refresh();

	quit = getObs("Test for observability/strong observability ..... o/so ? ", &mode);
	if(quit) return;    

	quit = getname("Enter the name of DES1 ...............................  ", EXT_DES, name1, false);
	if(quit) return;

	quit = getname("Enter the name of DES2 ...............................  ", EXT_DES, name2, false);
	if(quit) return;

	if(mode == 1)
		get_imagelist(&s_imagelist, &imagelist, &slist, &list, &null_flag, 5);
	else
		get_imagelist(&s_imagelist, &imagelist, &slist, &list, &null_flag, 6);
	if(quit) goto LABEL;

	x = _wherex();
	y = _wherey();
	move(22,0); clrtoeol();
	move(23,0); clrtoeol();
	printw("Processing:  Please wait... ");
	refresh();   


	mark_start_time();

	is_observable = false;
	init = 0L;
	if(getdes(name1, &s1, &init, &t1) == false){
		quit = true;
		goto LABEL;
	}    

	if (null_flag != 1)	{
		gen_complement_list(t1, s1,	imagelist, s_imagelist,	&list, &slist);
	}
	freedes(s1,&t1);
	s1 = 0; t1 = NULL;

	/*the main program of checking observability and strong observability*/    
	result = obs_runProgram(name2,name1,&s2,&t2,slist,list,mode,&is_observable);

	mark_stop_time();

	if(result != CR_OK){
		if(result == CR_OUT_OF_MEMORY)
			mem_result = 1;
		goto LABEL; 
	}

	move(22,0); clrtoeol();
	move(23,0); clrtoeol();
	move(y,x);

	strcpy(filename,"");
	strcat(filename,prefix);
	strcat(filename,name2);
	strcat(filename, EXT_TXT);    

	redisplay1(mode, (INT_OS)null_flag);
	if(is_observable){
		if(mode == 1)
			printw("%s is observable with respect to %s", name2,name1);
		else 
			printw("%s is strongly observable with respect to %s", name2,name1);

	}else {
		if(mode == 1){
			printw("%s is not observable with respect to %s\n", name2,name1);println();              
			println();
			redisplay1(mode, (INT_OS)null_flag);
			printw("States and corresponding events at which\n");               
			//println();
			printw("observability fails are reported in MAKEIT.TXT");        


		}
		else {
			printw("%s is not strongly observable with respect to %s\n", name2,name1);println();              
			println();
			redisplay1(mode, (INT_OS)null_flag);
			printw("States and corresponding events at which\n"); 
			//println();
			printw("strong observability fails are reported in MAKEIT.TXT");              
		}
		//obs_report(mode,filename,s2,t2);         
	}
	println();
	println();

	obs_makeit(is_observable, mode, s2, t2, null_flag, slist,list, s_imagelist,imagelist);

	move(23,0); clrtoeol();
LABEL:   
	free(list);
	free(imagelist);
	freedes(s1,&t1);
	freedes(s2,&t2); 
}
void obs_p()
{
     obs_r();
     if(mem_result == 1){
         mem_result = 0;
         OutOfMemoryMsg();
         user_pause();
     }
     else{
         if(!quit)
            user_pause();
     }     
     echo_free();
}
void convert_des_header()
{
    printw("CONVERT_DES"); println();
    println();
    printw("GIF = CONVERT (DES)");println();
    println();
}
void convert_des_makeit(char *name1, char*name2)
{
    FILE* out;
    
    /*Write to a tempory file*/
    out = fopen("tmp.$$$","w");
    if(out == NULL) return;
    
    fprintf(out,"%s = Convert(%s)", name2,name1);
    appendTime(out, (INT_OS)strlen(name2) + 3);
    fprintf(out,"\n\n");
    fclose(out);
    mergeChop((INT_OS)strlen(name2) + 3);
}
INT_B  convert_des_r()
{
    INT_OS x,y;
    INT_OS result;
    char ch;
    INT_T event;
	INT_B color_flag;
    result = 0;
    
    event = 0;
    
    clear();
    convert_des_header();
    refresh();
    
    quit = getname("Enter name of DES ...............................  ", EXT_DES, name1, false);
    if(quit) return true;
    
    printw("Assign new name to %s?  (y/*n)  ", name1);
    refresh();
    ch = read_key();
    if(ch == CEsc){
       quit = true;
       return true;
    }
    if(ch == 'Y' || ch == 'y'){
       println();
       println(); 
       quit = getname("Enter name of GIF ...............................  ", EXT_GIF, name2, true);
       if(quit) return true;

    } else{
       if(ch != CEnter)
          printw("%c",ch);
       strcpy(name2,name1);
       println();
       println();
    }    

	printw("Color transitions (controllable/uncontrollable as red/green)   (y/*n) ?");
	refresh();
	ch = read_key();
	if(ch == CEsc){
		quit = true;
		return true;
	}
	if(ch == 'Y' || ch == 'y'){
		color_flag = 1;

	} else{
		if(ch != CEnter)
			printw("%c",ch);
		color_flag = 0;
	}  
	    
    if(_wherey() > 21) {
         convert_des_header();
         esc_footer();
    }
	println();
	println();
    x = _wherex();
    y = _wherey();
    move(22,0); clrtoeol();
    move(23,0); clrtoeol();
    printw("Processing:  Please wait... ");
    refresh();
    
    move(y,x);
    refresh();
    
    mark_start_time();
    
    result = convert_des_program(name1,name2, color_flag);
    
    mark_stop_time();     
     
    if (result == 0)  {
        move(22,0); clrtoeol();
        move(23,0); clrtoeol();
        move(y,0);  clrtoeol();
        move(y+1,0);clrtoeol();
        move(y+2,0);clrtoeol();
        move(y,x); 
        printw("\n%s.DES successfully converted to %s.GIF",name1,name2);println();
        println();
        println();
        println();
        printw("Call DE to display transition diagram.");        
        //convert_des_makeit(name1,name2);
        return true;
     } else if(result == -2){
        printw("\nOut of Capability, %s.DES is too huge to convert!\n",name1);
     }  else{
        return false;
     }
    return true;
}

void convert_des_p()
{
     if(!convert_des_r()){
        user_pause();
        return;
     }
     if(mem_result == 1){
         mem_result = 0;
         OutOfMemoryMsg();
         user_pause();
     }
     else{
         if(!quit)
            user_pause();
     }     
     echo_free();
}
void display_des_header()
{
     printw("DISPLAY DES");println();
     println();
     printw("DISPLAY (DES)");println();
     println();
}
void user_pause_d(HANDLE hProcess)
{
   char ch;

   DWORD dwExitCode;

   move(23,0); clrtoeol();
   printw("Press <Enter> to return to %s Procedures  ", TCTNAME);
   refresh();
   do {
     ch = read_key();
   } while (ch != CEnter);

   GetExitCodeProcess(hProcess,&dwExitCode); 

   if(dwExitCode == STILL_ACTIVE && hProcess != NULL)
      TerminateProcess(hProcess,0); 
   
}

void display_des_p()
{
	char fullname[MAX_PATH];
	char cwd[MAX_PATH];
	char tmp_path[MAX_PATH];
	char cmdline[1024];
	char systemdirectory[1024];
	INT_OS errorno;

	STARTUPINFO si;
	PROCESS_INFORMATION pi;

	errorno = 0;
	clear();
	display_des_header();
	refresh();

	quit = getname("Enter name of GIF file for display...................  ", EXT_GIF, name1, false);
	if(quit) return;

	GetSystemDirectory(systemdirectory,MAX_PATH);
	// Get the path of the gif to be displayed
	strcpy(fullname, "");	
	strcpy(tmp_path, "");
	strcpy(cwd, "");
	_getcwd(cwd, MAX_PATH);
	if(strchr(prefix,':')){		
		_chdir(prefix);
		_getcwd(tmp_path, MAX_PATH);
		strcat(tmp_path, "\\");
		_chdir(cwd);
	}else{
		strcpy(tmp_path, cwd);
		strcat(tmp_path, "\\");
		strcat(tmp_path, prefix);
	}
	sprintf(fullname, "%s%s.GIF", tmp_path, name1);


	si.cb = sizeof(STARTUPINFO);
	GetStartupInfo(&si);
	si.wShowWindow = SW_SHOW;
	si.dwFlags = STARTF_USESHOWWINDOW;
	strcpy(cmdline,"");
	sprintf(cmdline,"%s\\rundll32.exe %s\\shimgvw.dll,ImageView_Fullscreen ",systemdirectory,systemdirectory);    
	strcat(cmdline,fullname);
	errorno = CreateProcess(NULL,(LPTSTR)cmdline,NULL,NULL,TRUE,0,NULL,NULL,&si,&pi);    
	if(errorno == 0){
		println();
		println();
		printw("error happened");  
		user_pause();             
	} else{
		user_pause_d(pi.hProcess);
	}
}

void localize_header()
{
     printw("LOCALIZE");println();
     println();
     printw("(LOC1, LOC2, ...) = LOCALIZE (PLANT, (PLANT1, PLANT2, ...), SUPER)");println();
     println();
}

void localize_header1(INT_S sfile)
{
	INT_S i;
	printw("LOCALIZE");println();
	println();
	if(sfile <= 3){
		printw("(");
		for(i = 0; i < sfile; i ++){
			printw("LOC%d",i + 1);
			if(i < sfile - 1)
				printw(", ");
		}
		printw(") = LOCALIZE (%s, (", name1);
		for(i = 0; i < sfile; i ++){
			printw(names1[i]);
			if(i < sfile - 1)
				printw(", ");
		}
		printw("), %s)", name2);
	}else{
		printw("(LOC1, LOC2, ..., LOC%d) = LOCALIZE(%s, (%s, %s, ..., %s), %s)", sfile, name1, names1[0], names1[1], names1[sfile - 1], name2);
	}
	//printw("{LOC1, LOC2,...} = LOCALIZE (FACT, {MACH1, MACH2, ... }, SUPER)");
	println();
	println();
}
void localize_header2(INT_S sfile)
{
	INT_S i;
	printw("LOCALIZE");println();
	println();
	if(sfile <= 3){
		printw("(");
		for(i = 0; i < sfile; i ++){
			printw(names2[i]);
			if(i < sfile - 1)
				printw(", ");
		}
		printw(") = LOCALIZE (%s, (", name1);
		for(i = 0; i < sfile; i ++){
			printw(names1[i]);
			if(i < sfile - 1)
				printw(", ");
		}
		printw("), %s)", name2);
	}else{
		printw("(%s, %s, ..., %s) = LOCALIZE(%s, (%s, %s, ..., %s), %s)", names2[0], names2[1], names2[sfile - 1], name1, names1[0], names1[1], names1[sfile - 1], name2);
	}
	//printw("{LOC1, LOC2,...} = LOCALIZE (FACT, {MACH1, MACH2, ... }, SUPER)");
	println();
	println();
}

void localize_makeit(INT_S sfile, INT_S sloc, char ch, INT_B  equ_flag, INT_B flag)
{
     FILE* out;
     INT_S s1; state_node *t1;
     INT_S init,i;
     
     s1 = 0; t1 = NULL;    
  
     
     for(i = 0; i < sloc; i ++){
		 out = fopen("tmp.$$$", "w");
		 if (out == NULL) return;

        fprintf(out,"%s",names2[i]);
        fprintf(out," = Localize(%s,%s,%s)", name1,names1[i],name2);
        init = 0L;
        if(!getdes(names2[i],&s1,&init,&t1))
			return;
        fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1)); 
        appendTime(out, (INT_OS)strlen(names2[i]) + 3);
        fprintf(out, "\n\n");		
		fclose(out); out = NULL;
		mergeChop((INT_OS)strlen(names2[i]) + 3);

        freedes(s1,&t1);
        s1 = 0; t1 = NULL;
     }
     if(ch != 'n' && ch != 'N' && flag == true){
		 out = fopen("tmp.$$$", "w");
		 if (out == NULL) return;

        if(equ_flag)
           fprintf(out,"true");
        else
           fprintf(out,"false");
        fprintf(out," = ControlEqu(%s,(",name1);
        for(i = 0; i < sloc; i ++){
           fprintf(out,"%s",names2[i]);
           if(i < sloc - 1)
              fprintf(out,",");
        }
        fprintf(out,"), %s)", name2);
        if(equ_flag){
            appendTime(out, 7);
			fprintf(out, "\n\n");
			fclose(out);
			mergeChop(7);
		}
        else{
            appendTime(out, 8);
			fprintf(out, "\n\n");
			fclose(out);
			mergeChop(8);
		}		
     }     
}
void localize_p()
{    
     INT_S init,i,j,k;
     INT_OS sfile,sloc;
     char prompt[100];
//     char long_txtname[_MAX_PATH]; 
     INT_OS x,y; 
     INT_B  equ_flag, ok, flag;
     INT_OS result, clean_mode, display_mode;
	 char tmp_name1[MAX_PATH];//, tmp_name2[MAX_PATH];
	 INT_S s1, s2;
	 state_node *t1, *t2;
	 INT_T s_tranlist, *tranlist;
	 INT_S *mapstate;

     s1  = s2 = 0;
     t1  = t2 = NULL;
     sfile = sloc = 0;
     equ_flag = false;
     clean_mode = display_mode = 0;
	 s_tranlist = 0; tranlist = NULL;
	 mapstate = NULL;
     
     clear();
     localize_header();
     refresh();
     result = 0;
     
     quit = getname("Enter name of PLANT ......... ",EXT_DES,name1,false);
     if(quit) return;
          
     printw("Enter number of independent plant components ... (between 1 and %d) ", MAX_DESS);
     sfile = (INT_OS)readint(&ch,1,MAX_DESS); println();
     if(ch == CEsc){
        quit = true;
        return;
     }
     println();
     for(i = 0; i < sfile; i ++){
        strcpy(prompt,"");
        sprintf(prompt,"Enter name of PLANT%d ........ ",i + 1);
        if(_wherey() > 19){
           clear();
           localize_header();
           esc_footer();
        }
        quit = getname(prompt,EXT_DES,names1[i],false);
        if(quit) return;
		init = 0L;
		if(!getdes(names1[i],&s1,&init,&t1))
			goto LOCALIZE_LABEL;
		if(mem_result == 1)
			goto LOCALIZE_LABEL;
		for(j = 0; j < s1; j ++){
			for(k = 0; k < t1[j].numelts; k ++){
				addordlist(t1[j].next[k].data1,&tranlist, s_tranlist,&ok);
				if(ok) s_tranlist ++;
			}
		}
		freedes(s1,&t1);
		s1 = 0; t1 = NULL;
     }

	 // Pre-check if PLANT = Sync(PLANT1, PLANT2, ...): if YES, continue; otherwise the user will choose to continue or not.

	 strcpy(tmp_name1, "$$$$$$$$$$");
	 synck_runProgram(tmp_name1, sfile, names1);

	 init = 0L;
	 if(!getdes(name1, &s1, &init, &t1))
		 goto LOCALIZE_LABEL;
	 init = 0L;
	 if(!getdes(tmp_name1, &s2, &init, &t2))
		 goto LOCALIZE_LABEL;
	 strcpy(long_name3, "");
	 make_filename_ext(long_name3, tmp_name1, EXT_DES);
	 remove(long_name3);

	 flag = false;
	 mapstate = NULL;

	 if(s1 == 0 && s2 == 0){
		 flag = true;
	 }else if(s1 == 0 || s2 == 0){
		 flag = false;
	 }else{	 
		minimize(&s1,&t1);
		minimize(&s2,&t2);
		mapstate = (INT_S*)CALLOC(s1,sizeof(INT_S));
		if((s1!= 0)  && (mapstate == NULL)){
			mem_result = 1;
			goto LOCALIZE_LABEL;
		}
		memset(mapstate,-1,s1 * sizeof(INT_S));
		mapstate[0] = 0;
		iso1(s1,s2,t1,t2,&flag,mapstate);
		free(mapstate); mapstate = NULL;
	 }
	 freedes(s1, &t1); s1 = 0; t1 = NULL;
	 freedes(s2, &t2); s2 = 0; t2 = NULL;
	 free(tranlist); tranlist = NULL;

	 if(flag == false){
		 println();     
		 printw("Input PLANT is not the synchronous product of input PLANT components,"); println();
		 printw("  and ControlEqu procedure will be invalid; continue?  (y/*n)");
		 refresh();
		 ch = read_key();
		 if(ch == CEsc){
			 quit = 1;
			 return;
		 }
		 if(ch != CEnter)
			 printw("%c",ch);
		 println(); println();
		 if(ch == 'y' || ch == 'Y'){
			 //mode = 1;
		 }else{
			 quit = 1;
			 return;
		 }
	 }

     if(_wherey() > 19){
        clear();
        localize_header();
        esc_footer();
     }
     quit = getname("Enter name of SUPER ......... ",EXT_DES,name2,false);
     if(quit) return;
     
     if(_wherey() > 12){
        clear();
        localize_header1(sfile);
        esc_footer();
     }
	 sloc = sfile;
     for(i = 0; i < sloc; i ++){ 
        strcpy(prompt,"");
        sprintf(prompt,"Enter name of LOC%d ........ ",i + 1);
        if(_wherey() > 19){
           clear();
           localize_header1(sloc);
           esc_footer();
        }
        quit = getname(prompt,EXT_DES,names2[i],true);
        if(quit) return;
     }
     
     println();     
     printw("Execute clean up procedure?  (*y/n)");
     refresh();
     ch = read_key();
     if(ch == CEsc){
         quit = 1;
         return;
     }
     if(ch != CEnter)
        printw("%c",ch);
     println(); println();
     if(ch == 'n' || ch == 'N'){
        clean_mode = 1;
     }
     x = _wherex();
     y = _wherey();
     move(22,0); clrtoeol();
     move(23,0); clrtoeol();
     printw("Processing:  Please wait... ");
     refresh();
         
     move(y,x);
     refresh();
     
     if(_wherey() > 12){
        clear();
        localize_header2(sfile);
        esc_footer();
     }
          
     mark_start_time();
     
     display_mode = 1;
     result = localize_proc(sfile,sloc,name1,name2,names1,names2,clean_mode,display_mode);
     
     mark_stop_time();
     
     if(result != 0){
        quit = 1;
        goto LOCALIZE_LABEL;
     }
     
     for(i = 0; i < sloc; i ++){
        init = 0L;
        strcpy(long_names2[i],"");
        make_filename_ext(long_names2[i],names2[i],EXT_DES);
        if(!exist(long_names2[i])){
           quit = true;
           break;
        }
     }
     if(quit)
        goto LOCALIZE_LABEL;
     println();

	 if(flag == false){
		 goto LOCALIZE_LABEL;
	 }
	// do{
		 if (_wherey() > 17)
		 {
			 clear();
			 localize_header2(sfile);
			 esc_footer();
		 } 
		 println();     
		 printw("Confirm localization control-equivalent to %s?  (*y/n)",name2);
		 refresh();
		 ch = read_key();
		 if(ch == CEsc){
			 quit = 1;
			 return;
		 }
		 if(ch != CEnter)
			 printw("%c",ch);	

		 println(); 
		 
	// } while(strchr(YNCommandSet, ch) == NULL);

	 println(); 
	 println();

     if((ch != 'n') && (ch != 'N')){
        if(sfile != sloc){
           // printw("The number of independent components is different with the number \n");
            //printw("of local controllers, cannot check control-equivalent.\n");
        } else{
          check_control_equ(sfile,name1,name2,names1,names2,&equ_flag);
          if(equ_flag)
             printw("Localization succeeds!\n");     
          else
             printw("Localization fails!\n");
        }
     }    
LOCALIZE_LABEL:
	 freedes(s1, &t1);
	 freedes(s2, &t2);
	 free(tranlist);
     if(mem_result == 1){
        mem_result = 0;
        OutOfMemoryMsg();
     } else{
        if(!quit){
           localize_makeit(sfile,sloc,ch, equ_flag,flag);     
        } 
     } 
     user_pause();   

}

///////////////////////////////////
// Force
void force_header()
{
     printw("FORCE"); println();
     println();
     printw("DES2 = FORCE (DES1, [FORCIBLE], [PREEMPTIBLE], TIMEOUT)"); println();
     println();
}
void force_header_continue()
{
	printw("FORCE"); println();
	println();
	printw("%s = FORCE (%s, [FORCIBLE], [PREEMPTIBLE], TIMEOUT)", name2, name1); println();
	println();
}
void force_r(INT_S *s1, state_node **t1, INT_T *s_force_event_list, INT_T ** force_event_list, 
                       INT_T *s_preempt_event_list, INT_T **preempt_event_list, INT_T *timeout_event)
{
     INT_T event;
     short sign_i;
     char ch;
     INT_OS col, row;
     INT_B  ok;
     INT_OS result; 
     INT_S init;
	 INT_S s2; state_node *t2;
	 INT_T slist, *list;
	 char strLabel[WIDTH_EVENT];
	 INT_T index;
     
	 s2 = 0; t2 = NULL;
	 slist = 0; list = NULL;
     result = 0;     
     
     clear();
     force_header();
     refresh();
     
     quit = getname("Enter name of DES1 ......... ",EXT_DES,name1,false);
     if(quit) return;
     
     quit = getname("Enter name of DES2 ......... ",EXT_DES,name2,true);
     if(quit) return;

	 init = 0L;
	 if(!getdes(name1, &s2, &init, &t2))
		 return;
	 gentranlist(s2, t2, &slist, &list);

INPUT_FORCE:     
     if(_wherey() > 19){
        clear();
        force_header_continue();
        esc_footer();
     }
     
     printw("Enter list of forcible events;"); println();
     printw("terminate list with -1"); println();
     println(); tab(5);
     sign_i = 0;
     while(sign_i != -1){
        col = _wherex();
        row = _wherey();
        if(col > 75){ 
           col = 5;
           row ++;
           move(row, col);
        }
        if (row > 21) {
           clear();
		   force_header_continue();
		   esc_footer();
           printw("Enter list of forcible events;"); println();
           printw("terminate list with -1."); println();
           println(); tab(5);
           esc_footer();
           col = _wherex();
           row = _wherey();
        }
#if defined(_x64_)
		ch = read_string(strLabel, 1, WIDTH_EVENT);
		if (ch == CEsc) {
			quit = true; return;
		}
		sign_i = (short) get_integer_label(strLabel, &index);
		if(sign_i != -1){
			event = (INT_T)sign_i;
			if(!inlist(event, list, slist)){
				println();
				println();
				if(_wherey() > 17){
					clear();
					force_header_continue();
					esc_footer();
				}
				printw("Illegal entry!  Forcible events must be contained in %s.", name1);
				println();
				println();
				*s_force_event_list = 0;
				*force_event_list = (INT_T*)REALLOC(*force_event_list, (*s_force_event_list * sizeof(INT_T)));
				goto INPUT_FORCE;
			}
			addordlist(event, force_event_list, *s_force_event_list, &ok);
			if(ok)  (*s_force_event_list) ++;
		}
		move(row, col + 10);
#else

        sign_i = (short)readint_and_e(&ch, -1, MAX_TRANSITIONS);
        if(ch == CEsc){
           quit = 1;
           return;
        }
        if(sign_i != -1){
           event = (INT_T)sign_i;
		   if(!inlist(event, list, slist)){
			   println();
			   println();
			   if(_wherey() > 17){
				   clear();
				   force_header_continue();
				   esc_footer();
			   }
			   printw("Illegal entry!  Forcible events must be contained in %s.", name1);
			   println();
			   println();
			   *s_force_event_list = 0;
			   *force_event_list = (INT_T*)REALLOC(*force_event_list, (*s_force_event_list * sizeof(INT_T)));
			   goto INPUT_FORCE;
		   }
           addordlist(event, force_event_list, *s_force_event_list, &ok);
           if(ok)  (*s_force_event_list) ++;
        }
        move(row, col + 7);
#endif
     }
INPUT_PREEMPT:
	 println();
     println();     
	 if(_wherey() > 19){
		 clear();
		 force_header_continue();
		 esc_footer();
	 }
     printw("Enter list of preemptible events;"); println();
     printw("terminate list with -1"); println();
     println(); tab(5);
     sign_i = 0;
     while(sign_i != -1){
        col = _wherex();
        row = _wherey();
        if(col > 75){ 
           col = 5;
           row ++;
           move(row, col);
        }
        if (row > 19) {
           clear();
		   force_header_continue();
		   esc_footer();
           printw("Enter list of preemptible events;"); println();
           printw("terminate list with -1."); println();
           println(); tab(5);
           esc_footer();
           col = _wherex();
           row = _wherey();
        }
#if defined(_x64_)
		ch = read_string(strLabel, 1, WIDTH_EVENT);
		if (ch == CEsc) {
			quit = true; return;
		}
		sign_i = (short) get_integer_label(strLabel, &index);
		if(sign_i != -1){
			event = (INT_T)sign_i;
			if(inlist(event, *force_event_list, *s_force_event_list)){
				println();
				println();
				if(_wherey() > 17){
					clear();
					force_header_continue();
					esc_footer();
				}
				printw("Illegal entry!  Lists of forcible and preemptible events must be disjoint.");
				*s_preempt_event_list = 0;
				*preempt_event_list = (INT_T*)REALLOC(*preempt_event_list, (*s_preempt_event_list * sizeof(INT_T)));
				goto INPUT_PREEMPT;
			}
			if(!inlist(event, list, slist)){
				println();
				println();
				if(_wherey() > 17){
					clear();
					force_header_continue();
					esc_footer();
				}
				printw("Illegal entry!  Preemptible events must be contained in %s.", name1);
				*s_preempt_event_list = 0;
				*preempt_event_list = (INT_T*)REALLOC(*preempt_event_list, (*s_preempt_event_list * sizeof(INT_T)));
				goto INPUT_PREEMPT;
			}
			addordlist(event, preempt_event_list, *s_preempt_event_list, &ok);
			if(ok)  (*s_preempt_event_list) ++;
			move(row, col + 10);
		}
#else
        sign_i = (short)readint_and_e(&ch, -1, MAX_TRANSITIONS);
        if(ch == CEsc){
           quit = 1;
           return;
        }
        if(sign_i != -1){
           event = (INT_T)sign_i;
           if(inlist(event, *force_event_list, *s_force_event_list)){
			  println();
			  println();
			  if(_wherey() > 17){
				  clear();
				  force_header_continue();
				  esc_footer();
			  }
			  printw("Illegal entry!  Lists of forcible and preemptible events must be disjoint.");
			  *s_preempt_event_list = 0;
			  *preempt_event_list = (INT_T*)REALLOC(*preempt_event_list, (*s_preempt_event_list * sizeof(INT_T)));
			  goto INPUT_PREEMPT;
           }
		   if(!inlist(event, list, slist)){
			   println();
			   println();
			   if(_wherey() > 17){
				   clear();
				   force_header_continue();
				   esc_footer();
			   }
			   printw("Illegal entry!  Preemptible events must be contained in %s.", name1);
			   *s_preempt_event_list = 0;
			   *preempt_event_list = (INT_T*)REALLOC(*preempt_event_list, (*s_preempt_event_list * sizeof(INT_T)));
			   goto INPUT_PREEMPT;
		   }
		   addordlist(event, preempt_event_list, *s_preempt_event_list, &ok);
		   if(ok)  (*s_preempt_event_list) ++;
		   move(row, col + 7);
        }
#endif        
     }
     println();

INPUT_TIMEOUT:   
     if (row > 19) {
        clear();
        force_header_continue();
        esc_footer();
     }  

     println();  
     printw("Enter new controllable timeout event ... "); 
#if defined (_x64_)
	 ch = read_string(strLabel, 1, WIDTH_EVENT);
	 if (ch == CEsc) {
		 quit = true; return;
	 }
	 sign_i = (short) generate_integer_label(strLabel, 1, &index);

#else
	 sign_i = (short)readint_and_e(&ch, -1, MAX_TRANSITIONS);
	 if(ch == CEsc){
		 quit = 1;
		 return;
	 }

#endif 
	 if(sign_i != -1){
		 *timeout_event = (INT_T)sign_i;
		 if(inlist(*timeout_event, list, slist)){
			 println();
			 println();
			 if(_wherey() > 17){
				 clear();
				 force_header_continue();
				 esc_footer();
			 }
			 printw("Illegal entry!  Timeout event must not occur in %s.", name1); println();
			 goto INPUT_TIMEOUT;
		 }
	 }

     println();
     col = _wherex();
     row = _wherey();
     move(22,0); clrtoeol();
     move(23,0); clrtoeol();
     printw("Processing:  Please wait... ");
     refresh();

     mark_start_time();
     
	 result = force_runProgram(name1, name2, *s_force_event_list, *force_event_list,
		                                  *s_preempt_event_list, *preempt_event_list, *timeout_event);

     
     mark_stop_time();
     
     if (result == CR_OK) {
        strcpy(long_name2, "");
        make_filename_ext(long_name2, name2, EXT_DES);        
        if (exist(long_name2)){
			init = 0;
           if(getdes(name2, s1, &init, t1) == false)
			   quit = true;
		}
        else
           quit = true;
     }
     else{
       if (result == CR_OUT_OF_MEMORY)
          mem_result = 1;
       else
          quit = true;
     }
     
	 freedes(s2, &t2);
	 free(list);
}
void force_makeit(INT_S s1, state_node *t1, INT_T s_force_event_list, INT_T * force_event_list, 
                       INT_T s_preempt_event_list, INT_T *preempt_event_list, INT_T timeout_event)
{
     FILE* out;
     INT_S i;
	 char strLabel[WIDTH_EVENT];

     out = fopen(get_makeit(), "a");
     if (out == NULL) return;
     
     fprintf(out,"%s = Force(%s", name2,name1);
	 fprintf(out, ",Forcible [");
     if(s_force_event_list > 0){        
        for(i = 0; i < s_force_event_list; i ++){
		   fprintf_event(out, force_event_list[i]);
           if(i < s_force_event_list - 1)
           fprintf(out, ",");
        }
        
     }
	 fprintf(out, "]");
	 fprintf(out, ",Preemptible [");
     if(s_preempt_event_list > 0){        
        for(i = 0; i < s_preempt_event_list; i ++){
		   fprintf_event(out, preempt_event_list[i]);
           if(i < s_preempt_event_list - 1)
           fprintf(out, ",");
        }        
     }
	 fprintf(out, "]");
	 fprintf(out, ",Timeout [");
	 if(timeout_event >= 0 && timeout_event <= MAX_TRANSITIONS)
		fprintf(out, "%ld", timeout_event);
	 else{
		 get_strlabel_by_intlabel(timeout_event, strLabel);
		 fprintf(out, "%s", strLabel);
	 }

     fprintf(out, "])  (%ld,%ld)", s1, count_tran(t1, s1)); 

     appendTime(out, sizeof(name2 + 3));
     
     fprintf(out, "\n\n");

     fclose(out);
}
void force_p()
{
     state_node *t1;  INT_S s1;
     INT_T s_force_event_list, *force_event_list;
     INT_T s_preempt_event_list, *preempt_event_list;
     INT_T timeout_event;
     
     s1 = 0; t1 = NULL;
     s_force_event_list = s_preempt_event_list = 0;
     force_event_list = preempt_event_list = NULL;
	 timeout_event = NEE;
     
     force_r(&s1, &t1, &s_force_event_list, &force_event_list, 
                       &s_preempt_event_list, &preempt_event_list, &timeout_event);
     
     if (mem_result == 1) {
        mem_result = 0;
        OutOfMemoryMsg();
        user_pause();
     } else {
        if (!quit) {
           force_makeit(s1, t1, s_force_event_list, force_event_list, 
                       s_preempt_event_list, preempt_event_list, timeout_event);
           user_pause();
        }
     }
     echo_free();
     
     freedes(s1, &t1);
     free(force_event_list);
     free(preempt_event_list);
}
////////////////////////////////////////////////
// Supremal relatively observable
void supobs_header()
{
	printw("SUPROBS"); println();
	println();
	printw("DES3 = SUPROBS (DES1, DES2, NULL/IMAGE/IMAGE_DES)"); println();
	println();
}
void supobs_makeit(INT_S s, state_node *t, INT_S  null_flag, 
	INT_T s_list, INT_T *list, INT_T s_imagelist, INT_T *imagelist)
{
	FILE* out;
	INT_S i;

	/*Write to a tempory file*/
	out = fopen("tmp.$$$","w");
	if(out == NULL) return;

	fprintf(out, "%s = Suprobs(%s,%s,", name3, name1, name2);

	if ( null_flag == 1)
	{
		fprintf(out, "Null[");
		for (i=0; i < s_list; i++) {
			fprintf_event(out, list[i]);
			if (i+1 < s_list)
				fprintf(out, ",");
		}
		fprintf(out, "]");
	}
	else if( null_flag == 2)
	{
		fprintf(out, "Image[");
		for (i=0; i < s_imagelist; i++) {
			fprintf_event(out, imagelist[i]);
			if (i+1 < s_imagelist)
				fprintf(out, ",");
		}
		fprintf(out, "]");
	}else{
		fprintf(out, "%s", imagename);
	}
	fprintf(out, ")");
	fprintf(out, "  (%ld,%ld)", s, count_tran(t, s));
	appendTime(out, (INT_OS)strlen(name3) + 3);
	fprintf(out,"\n\n");
	fclose(out);

	mergeChop((INT_OS)strlen(name3) + 3);

}
void supobs_r()
{
	INT_T *list, slist, *imagelist, s_imagelist;
	INT_S  null_flag;
	INT_S      init;
	INT_OS        result; 
	INT_OS mode;

	state_node *t1, *t2;
	INT_S s1, s2;

	list = imagelist = NULL;
	slist = s_imagelist = 0;
	s1 = s2 = 0;
	t1 = t2 = NULL;
	result = 0;

	clear();
	supobs_header();
	refresh(); 

	mode = 1;

	quit = getname("Enter name of plant generator DES1 .................. ", EXT_DES, name1, false);
	if(quit) return;

	quit = getname("Enter name of legal language generator DES2 ......... ", EXT_DES, name2, false);
	if(quit) return;

	printw("Enter name of supremal"); println();
	quit = getname(" relatively observable sublanguage generator DES3 ... ", EXT_DES, name3, true);
	if(quit) return;

	get_imagelist(&s_imagelist, &imagelist, &slist, &list, &null_flag,7);
	if(quit) return;

	move(22,0); clrtoeol();
	move(23,0); clrtoeol();
	printw("Processing:  Please wait... ");
	refresh();   


	mark_start_time();

	init = 0L;
	if(getdes(name1, &s1, &init, &t1) == false){
		quit = true;
		goto LABEL;
	}    

	if (null_flag != 1)	{
		gen_complement_list(t1, s1,
			imagelist, s_imagelist,
			&list, &slist);
	}
	freedes(s1,&t1);
	s1 = 0; t1 = NULL;

	/*the main program of checking observability*/    
	result = supobs_runProgram(name3, name1,name2,slist,list, mode);

	mark_stop_time();

	if(result == CR_OK){
		strcpy(long_name3, "");
		make_filename_ext(long_name3, name3, EXT_DES);
		if(exist(long_name3)){
			init = 0L;
			if(getdes(name3, &s1, &init, &t1))		
				supobs_makeit(s1,t1, null_flag, slist, list,s_imagelist, imagelist);
		}else
			quit = 1;
	}else{
		if(result == CR_OUT_OF_MEMORY){
			mem_result = 1;
		}else{
			quit = 1;
		}		
	}

LABEL:   
	free(list);
	free(imagelist);
	freedes(s1,&t1);
	freedes(s2,&t2); 
}
void supobs_p()
{
	supobs_r();
	if(mem_result == 1){
		mem_result = 0;
		OutOfMemoryMsg();
		user_pause();
	}
	else{
		if(!quit){
			user_pause();
		}    
	}
	echo_free();
}
/////////////////////////////////////////////////
///////////////////////////////////////////////////
//Feasible = Supcon and Supobs

void feasible_header()
{
	printw("SUPCONROBS"); println();
	println();
	printw("DES3 = SUPCONROBS (DES1, DES2, NULL/IMAGE/IMAGE_DES)"); println();
	println();
}

void feasible_makeit(INT_S s, state_node *t, INT_S  null_flag, 
	INT_T s_list, INT_T *list, INT_T s_imagelist, INT_T *imagelist)
{
	FILE* out;
	INT_S i;

	/*Write to a tempory file*/
	out = fopen("tmp.$$$","w");
	if(out == NULL) return;

	fprintf(out, "%s = Supconrobs(%s,%s,", name3, name1, name2);

	if (null_flag == 1)
	{
		fprintf(out, "Null[");
		for (i=0; i < s_list; i++) {
			fprintf_event(out, list[i]);
			if (i+1 < s_list)
				fprintf(out, ",");
		}
		fprintf(out, "]");
	}
	else if(null_flag == 2)
	{
		fprintf(out, "Image[");
		for (i=0; i < s_imagelist; i++) {
			fprintf_event(out, imagelist[i]);
			if (i+1 < s_imagelist)
				fprintf(out, ",");
		}
		fprintf(out, "]");
	}else{
		fprintf(out, "%s", imagename);
	}
	fprintf(out, ")");
	fprintf(out, "  (%ld,%ld)", s, count_tran(t, s));
	appendTime(out, (INT_OS)strlen(name3) + 3);
	fprintf(out,"\n\n");
	fclose(out);

	mergeChop((INT_OS)strlen(name3) + 3);

}
void feasible_r(state_node **t, INT_S *s)
{
	state_node *t1, *t2, *t3, *t4;
	INT_S s1, s2, s3, s4;
	INT_S  init;
	INT_S null_flag;
	INT_T *list, slist, *imagelist, s_imagelist;
	INT_OS result;
	INT_S *mapState;
	INT_S *macro_ab, *macro_c;

	macro_ab = NULL;  macro_c  = NULL;
	list = imagelist = NULL;
	slist = s_imagelist = 0;
	t1 = t2 = t3 = t4 = NULL;
	s1 = s2 = s3 = s4 = 0;
	mapState = NULL;

	result = 0;

	clear();
	feasible_header();
	refresh();

	quit = getname("Enter name of plant generator DES1 .................  ",
		EXT_DES, name1, false);
	if (quit) return;

	quit = getname("Enter name of legal language generator DES2 ........  ",
		EXT_DES, name2, false);
	if (quit) return;

	printw("Enter name of supremal controllable and"); println();
	quit = getname(" relatively observable sublanguage generator DES3 ...  ",
		EXT_DES, name3, true);
	if (quit) return;

	get_imagelist(&s_imagelist, &imagelist, &slist, &list, &null_flag, 8);
	if(quit) goto LABEL;

	move(22,0); clrtoeol();
	move(23,0); clrtoeol();
	printw("Processing:  Please wait...");
	refresh();

	/* Pass to command line version of this program */
	mark_start_time(); 
	init = 0L;
	if(getdes(name1, &s1, &init, &t1) == false){
		quit = true;
		goto LABEL;
	}    

	if (null_flag != 1)	{
		gen_complement_list(t1, s1,
			imagelist, s_imagelist,
			&list, &slist);
	}
	freedes(s1,&t1);
	s1 = 0; t1 = NULL;

	result = supconrobs_runProgram(name3, name1, name2, slist, list);
	
	mark_stop_time();

LABEL:
	if((mem_result != 1) && (result == 0) && (quit != true)) {
		strcpy(long_name3, "");
		make_filename_ext(long_name3, name3, EXT_DES);
		if(exist(long_name3)){
			init = 0L;
			if(getdes(name3, &s1, &init, &t1))
				feasible_makeit(s1, t1, null_flag, slist, list, s_imagelist, imagelist);
		}
	}else{
		if(result == CR_OUT_OF_MEMORY){
			mem_result = 1;
		}else{
			quit = 1;
		}
	}
	freedes(s1, &t1);
	freedes(s2, &t2);
	freedes(s3, &t3);
	freedes(s4, &t4);
	free(mapState);
	free(list);
	free(imagelist);
	free(macro_c);
	free(macro_ab);

}

void feasible_p()
{
	state_node *t1;
	INT_S s1;

	t1 = NULL;
	s1 = 0;

	feasible_r(&t1, &s1);

	if (mem_result == 1) {
		mem_result = 0;
		OutOfMemoryMsg();
		user_pause();
	} else {
		if (!quit) {
			user_pause();
		}
	}

	echo_free();
	freedes(s1, &t1);
}

// Procedure uncertmod for uncertainty set modelling
void uncertmod_header()
{
	printw("UNCERTMOD"); println();
	println();
	printw("DES2 = UNCERTMOD (DES1, NULL/IMAGE/IMAGE_DES)"); println();
	println();
}
void uncertmod_makeit(INT_S s, state_node *t, INT_S  null_flag, INT_T s_list, INT_T *list, INT_T s_imagelist, INT_T *imagelist)
{
	FILE* out;
	INT_S i;

	/*Write to a tempory file*/
	out = fopen("tmp.$$$","w");
	if(out == NULL) return;

	fprintf(out, "%s = Uncertmod(%s,", name2, name1);

	if ( null_flag == 1)
	{
		fprintf(out, "Null[");
		for (i=0; i < s_list; i++) {
			fprintf_event(out, list[i]);
			if (i+1 < s_list)
				fprintf(out, ",");
		}
		fprintf(out, "]");
	}
	else if( null_flag == 2)
	{
		fprintf(out, "Image[");
		for (i=0; i < s_imagelist; i++) {
			fprintf_event(out, imagelist[i]);
			if (i+1 < s_imagelist)
				fprintf(out, ",");
		}
		fprintf(out, "]");
	}else{
		fprintf(out, "%s", imagename);
	}
	fprintf(out, ")");
	fprintf(out, "  (%ld,%ld)", s, count_tran(t, s));
	appendTime(out, (INT_OS)strlen(name2) + 3);
	fprintf(out,"\n\n");
	fclose(out);

	mergeChop((INT_OS)strlen(name2) + 3);

}
void uncertmod_r()
{
	INT_T *list, slist, *imagelist, s_imagelist;
	INT_S  null_flag;
	INT_S      init;
	INT_OS        result; 

	state_node *t1;
	INT_S s1;

	list = imagelist = NULL;
	slist = s_imagelist = 0;
	s1 = 0;
	t1 = NULL;
	result = 0;

	clear();
	uncertmod_header();
	refresh(); 

	quit = getname("Enter name of DES1 .................. ", EXT_DES, name1, false);
	if(quit) return;

	quit = getname("Enter name of DES2 .................. ", EXT_DES, name2, true);
	if(quit) return;

	if(_wherey() > 16){
		clear();
		uncertmod_header();
		esc_footer();
	}

	get_imagelist(&s_imagelist, &imagelist, &slist, &list, &null_flag,9);
	if(quit) goto LABEL;

	init = 0L;
	if (getdes(name1, &s1, &init, &t1) == false) {
		quit = true;
		return;
	}

	if ((null_flag != 1))
	{
		gen_complement_list(t1, s1,
			imagelist, s_imagelist,
			&list, &slist);
	}
	freedes(s1, &t1);

	if(_wherey() > 12){
		clear();
		uncertmod_header();
		esc_footer();
	}

	move(22,0); clrtoeol();
	move(23,0); clrtoeol();
	printw("Processing:  Please wait... ");
	refresh();   


	mark_start_time();

	result = uncertmod_runProgram(name2, name1, list, slist);

	mark_stop_time();

	if(result == CR_OK){
		strcpy(long_name2, "");
		make_filename_ext(long_name2, name2, EXT_DES);
		if(exist(long_name2)){
			init = 0L;
			if(getdes(name2, &s1, &init, &t1))
				uncertmod_makeit(s1,t1, null_flag, slist, list,s_imagelist, imagelist);
		}
	}else{
		quit = 1;
	}

LABEL:   
	free(list);
	free(imagelist);
	freedes(s1,&t1);
}
void uncertmod_p()
{

	uncertmod_r();
	if(mem_result == 1){
		mem_result = 0;
		OutOfMemoryMsg();
		user_pause();
	}
	else{
		if(!quit){
			user_pause();
		}    
	}
	echo_free();
}

#ifdef __cplusplus
}
#endif

