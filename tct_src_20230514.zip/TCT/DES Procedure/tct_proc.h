#ifndef _TCT_PROC_H
#define _TCT_PROC_H
#include "des_data.h"
#include <stdlib.h>


#include <dos.h>
#include <io.h>

#define EXT_DES       ".DES"
#define EXT_DAT       ".DAT"
#define EXT_TXT       ".TXT"
#define EXT_PDS       ".PDS"
#define EXT_PDT       ".PDT"
#define EXT_PSS       ".PSS"
#define EXT_PST       ".PST"
#define EXT_ADS       ".ADS"



#ifdef __cplusplus
extern "C" {
#endif

//#define MAX_PATH   256

typedef char filename[MAX_FILENAME];
typedef char long_filename[_MAX_PATH];

extern void setuserpath(char *ini_file);
extern char *dos_uppercase(char *string);

extern void not_yet();
extern void create_p(); 
extern void trim_p(); 
extern void selfloop_p(); 
extern void sync_p();  
extern void meet_p(); 
extern void supcon_p();  
extern void mutex_p();  
extern void condat_p();
extern void supreduce_p();
extern void minstate_p();  
extern void complement_p(); 
extern void simsup_p();
extern void isomorph_p();  
extern void nonconflict_p();
extern void bfs_recode_p();
extern void directory_p();
extern void localize_p();
extern void force_p();

extern void vocalize_p();
extern void outconsis_p();
extern void hiconsis_p();
extern void higen_p();
extern void allevents_p();

extern void project_p();
extern void eventmap_p();
extern void supnorm_p();
extern void supscop_p();

extern void CanQC_p();
extern void obs_p();
extern void supobs_p();
extern void feasible_p();
extern void uncertmod_p();

extern void print_des_p();
extern void print_dat_p();
extern void print_ascii_p();

extern void file_des_p();
extern void file_dat_p();
extern void file_ads_p();

extern void convert_des_p();
extern void display_des_p();

extern void introduction_p();
extern void reset_directory_p();
extern void bell_control_p();
extern void display_control_p();
extern void timing_control_p();

/////////////////////////////////////
/*Export these functions*/
extern void user_pause();
extern void mergeChop(INT_OS);
extern void mark_start_time();
extern void mark_stop_time();
extern void appendTime(FILE *, INT_OS);
extern INT_B  any_mark_states(state_node*, INT_S);
extern INT_B  any_vocal_output(state_node*, INT_S);
extern void check_determinism(state_node*, INT_S, char*, INT_B *, INT_B );
extern INT_B  is_deterministic(state_node *, INT_S);
extern void check_des_p();
extern char* get_makeit();
extern void echo_free();
extern void gen_complement_list(state_node *, INT_S, INT_T *, INT_T , INT_T **, INT_T *);
extern void print_eventlist(INT_T, INT_T * );
extern void print_des_stat_header(FILE *, char *, INT_S, INT_S);
extern INT_B  print_marker_states(FILE *,state_node *,INT_S );
extern INT_B  print_vocal_output(FILE *,state_node *,INT_S);
extern INT_B  print_transitions(FILE *,	state_node *,INT_S );
extern void print_dat_header_stat(FILE *, char *, INT_B);
extern INT_B  print_dat(FILE *, state_node *, INT_S);

//used in executing script file
extern INT_B nonconflict(INT_S, state_node *);
extern INT_B is_valid_transition(INT_S, INT_T, INT_S *, state_node *, INT_S);
extern void get_output_list(INT_S , state_node *, INT_T **, INT_T *); 
extern void sync_blockevents(state_node *,INT_S,state_node *,INT_S,	state_node *,INT_S,INT_T **, INT_T *);
extern void get_imagelist(INT_T *, INT_T**, INT_T *, INT_T **, INT_S *, INT_S );

extern INT_B IsNumericalLabel(char * strLabel, INT_T width);

extern INT_T get_integer_label(char *str_label, INT_T *index);
extern INT_T generate_integer_label(char *str_label, INT_B is_contrl, INT_T *index);
extern void gen_global_labellist_from_file();
extern void update_labellist_file();


#ifdef __cplusplus
}
#endif

#endif



