/* 16 to 32 bit DES file format converter */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "des_data.h"

typedef short INT16;
typedef long  INT32;



static INT_OS endian = 0xFF00AA55;

void trans16(INT16 a, INT_OS *b)
{
   *b = (INT_OS) a;
}

void trans32(INT_OS a, INT16 *b)
{
   *b = (INT16) a;
}

// Translate from 16 to 32 bit
void trans16to32(FILE *in, FILE *out)
{
  INT16 value16, value16_1, value16_2, value16_3;
  INT_OS value32; //, value32_1, value32_2, value32_3;
  INT16 i, size;
  long offset, offset2;
  tran_node tnode;
  char signature[10];
  char  header[100];
  INT_OS header_len;
  INT_OS block_type, block_size;
  INT_OS cur_pos;
  INT_OS temp;
//  INT_OS read_endian;
//  char ch;

  /* Setup a buffer for faster I/O */
  setvbuf(in, NULL, _IOFBF, 4000);
  setvbuf(out, NULL, _IOFBF, 4000);

  /* Enter some useful ASCII text */
#if defined(__BORLANDC__)
  sprintf(header, "CTCT DES file. Borland C/C++ version.  For testing only");
#else
  sprintf(header, "CTCT DES file. Version 1.0");
#endif
  header_len = (INT_OS)strlen(header);
  header[header_len] = 26;
  fwrite(&header, sizeof(char), header_len+1, out);

  signature[0] = 'Z';
  signature[1] = '8';
  signature[2] = '^';
  signature[3] = '0';
  signature[4] = 'L';
  signature[5] = ';';
  signature[6] = '1';
  signature[7] = '\0';

  /* Unique string to uniquely identify it is a CTCT DES file.
     Some other program put a header string. */
  fwrite(&signature, sizeof(char), 7, out);

  /* Big-endian and Little-endian information */
  fwrite(&endian, sizeof(INT_OS), 1, out);

  /* Block type zero (0) - required */
  block_type = 0;
  fwrite(&block_type, sizeof(INT_OS), 1, out);

  /* Block size */
  fwrite(&block_size, sizeof(INT_OS), 1, out);
  block_size = ftell(out);

  /* Read size and init variable */
  fread(&value16, sizeof(INT16), 1, in);
  trans16(value16, &value32);
  size = value16;
  fwrite(&value32, sizeof(INT_OS), 1, out);

  fread(&value16, sizeof(INT16), 1, in);
  trans16(value16, &value32);
  fwrite(&value32, sizeof(INT_OS), 1, out);

  if (size == 0) {
     value32 = -1L;
     fwrite(&value32, sizeof(INT_OS), 1, out);   /* Mark */
     fwrite(&value32, sizeof(INT_OS), 1, out);   /* Trans */
     fwrite(&value32, sizeof(INT_OS), 1, out);   /* Vocal */
     goto END_1;
  }

  /* Marked states */
  value16 = 0;
  while (value16 != -1) {
     fread(&value16, sizeof(INT16), 1, in);
     trans16(value16, &value32);
     fwrite(&value32, sizeof(INT_OS), 1, out);
  }

  /* The transitions */
  value16 = -1;
  fread(&value16_1, sizeof(INT16), 1, in);
  fread(&value16_2, sizeof(INT16), 1, in);
  fread(&value16_3, sizeof(INT16), 1, in);

  while (value16_1 != -1) {
     trans16(value16_1, &value32);
     fwrite(&value32, sizeof(INT_OS), 1, out);
     offset = ftell(out);
     fwrite(&value16, sizeof(INT16), 1, out);     /* Junk value */

     value16 = value16_1;
     i = 0;
     while (value16_1 == value16) {
        tnode.data1 = value16_2;
        trans16(value16_3, &value32);
        tnode.data2 = value32;
        fwrite(&tnode, sizeof(tran_node), 1, out);
        i++;

        fread(&value16_1, sizeof(INT16), 1, in);
        fread(&value16_2, sizeof(INT16), 1, in);
        fread(&value16_3, sizeof(INT16), 1, in);
     }
     offset2 = ftell(out);
     fseek(out, offset, SEEK_SET);
     fwrite(&i, sizeof(INT16), 1, out);
     fseek(out, offset2, SEEK_SET);
  }
  value32 = -1L;
  fwrite(&value32, sizeof(INT_OS), 1, out);

  /* Vocal states */
  value16_1 = 0;
  while (value16_1 != -1) {
     fread(&value16_1, sizeof(INT16), 1, in);
     fread(&value16_2, sizeof(INT16), 1, in);

     if (feof(in)) break;
     if (value16_1 == -1) break;
     trans16(value16_1, &value32);
     fwrite(&value32, sizeof(INT_OS), 1, out);
     fwrite(&value16_2, sizeof(INT16), 1, out);
  }
  value32 = -1L;
  fwrite(&value32, sizeof(INT_OS), 1, out);

END_1:
  /* Update the block size */
  cur_pos = ftell(out);
  fseek(out, block_size, SEEK_CUR);
  block_size = cur_pos - block_size;
  fwrite(&block_size, sizeof(INT_OS), 1, out);
  fseek(out, 0, SEEK_END);

  /* Block type zero (-1) - required */
  block_type = -1;
  fwrite(&block_type, sizeof(INT_OS), 1, out);
  block_size = 8;
  fwrite(&block_size, sizeof(INT_OS), 1, out);
  temp = 0;
  fwrite(&temp, sizeof(INT_OS), 1, out);
  fwrite(&temp, sizeof(INT_OS), 1, out);
}

// Translate from 32 to 16 bit
void trans32to16(FILE *in, FILE *out)
{
  INT16 value16, value16_1, value16_2, value16_3;
  INT_OS value32, value32_1, value32_3; //, value32_2;
  INT16 i;
  long offset; //, offset2;
  tran_node tnode;
  char signature[10];
  char  header[100];
//  INT_OS header_len;
  INT_OS block_type, block_size;
//  INT_OS cur_pos;
//  INT_OS temp;
  INT_OS read_endian;
  char ch;

  /*  Setup a buffer for faster I/O */
  setvbuf(in, NULL, _IOFBF, 4000);
  setvbuf(out, NULL, _IOFBF, 4000);

  /* Read the ASCII header and junk */
  ch = 0;
  while ((ch != 26) && !feof(in)) {
     fread(&ch, sizeof(char), 1, in);
  }

  if (ferror(in)) {
     printf("Not a CTCT file\n");
     return;
  }

  signature[0] = 'Z';
  signature[1] = '8';
  signature[2] = '^';
  signature[3] = '0';
  signature[4] = 'L';
  signature[5] = ';';
  signature[6] = '1';
  signature[7] = '\0';

  memset(header, 0, 8); /* Zero out the string */
  /* Read the unique string to authenic CTCT DES file */
  fread(header, sizeof(char), 7, in);
  if (strcmp(header, signature) != 0) {
     printf("Not a CTCT file\n");
     return;
  }

  /* Big-endian and Little-endian information */
  fread(&read_endian, sizeof(INT_OS), 1, in);
  if (read_endian != endian) {
     printf("This file was generated from an unknown architecture\n");
     return;
  }

  /* Block type */
  fread(&block_type, sizeof(INT_OS), 1, in);
  if (block_type != 0) {
     printf("The first block type must be zero\n");
     return;
  }

  /* Read the number of bytes of this block type */
  fread(&block_size, sizeof(INT_OS), 1, in);

  /* Read size and init varable */
  fread(&value32, sizeof(INT_OS), 1, in);
  trans32(value32, &value16);
  fwrite(&value16, sizeof(INT16), 1, out);

  fread(&value32, sizeof(INT_OS), 1, in);
  trans32(value32, &value16);
  fwrite(&value16, sizeof(INT16), 1, out);

  /* Marked states */
  value32 = 0;
  while (value32 != -1) {
     fread(&value32, sizeof(INT_OS), 1, in);
     trans32(value32, &value16);
     fwrite(&value16, sizeof(INT16), 1, out);
  }

  /* The transitions */
  value32_1 = 0;
  while (value32_1 != -1L) {
      fread(&value32_1, sizeof(INT_OS), 1, in);
      if (value32_1 == -1L) break;
      trans32(value32_1, &value16_1);

      fread(&value16, sizeof(INT16), 1, in);
      for (i=0; i < value16; i++) {
         fread(&tnode, sizeof(tran_node), 1, in);
         value16_2 = tnode.data1;
         value32_3 = (INT_OS)tnode.data2;
         trans32(value32_3, &value16_3);

         fwrite(&value16_1, sizeof(INT16), 1, out);
         fwrite(&value16_2, sizeof(INT16), 1, out);
         fwrite(&value16_3, sizeof(INT16), 1, out);
      }
   }
   /* Write the terminating signature. */
   value16 = -1;
   fwrite(&value16, sizeof(INT16), 1, out);
   fwrite(&value16, sizeof(INT16), 1, out);
   fwrite(&value16, sizeof(INT16), 1, out);

   /* Vocal states */
   value32 = 0;
   while (value32 != -1) {
      fread(&value32, sizeof(INT_OS), 1, in);
      if (value32 == -1) break;
      trans32(value32, &value16);
      fwrite(&value16, sizeof(INT16), 1, out);

      fread(&value16, sizeof(INT16), 1, in);
      fwrite(&value16, sizeof(INT16), 1, out);
   }
   value16 = -1;
   fwrite(&value16, sizeof(INT16), 1, out);
   fwrite(&value16, sizeof(INT16), 1, out);

   /* Need to bring this up to TCT 2.01 format */
   offset = ftell(out);
   value16 = 10;      /* Block type */
   fwrite(&value16, sizeof(INT16), 1, out);
   value16 = 14;      /* Size of block */
   fwrite(&value16, sizeof(INT16), 1, out);
   value32 = offset;  /* Offset of the start block */
   fwrite(&value32, sizeof(INT_OS), 1, out);
   value16 = 0x0201;
   fwrite(&value16, sizeof(INT16), 1, out);

   signature[0] = 7;
   signature[1] = 'Z';
   signature[2] = '8';
   signature[3] = '^';
   signature[4] = '0';
   signature[5] = 'L';
   signature[6] = ';';
   signature[7] = '1';

   fwrite(&signature, sizeof(char), 8, out);
   value16 = -1;
   fwrite(&value16, sizeof(INT16), 1, out);
}

