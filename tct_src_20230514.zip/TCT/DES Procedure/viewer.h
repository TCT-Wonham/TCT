#ifndef _VIEWER_H
#define _VIEWER_H

#ifdef __cplusplus
extern "C" {
#endif

extern void ascii_viewer(char*, char*);
extern void ascii_print(char*, char*);

#ifdef __cplusplus
}
#endif

#endif /* _VIEWER_H */
