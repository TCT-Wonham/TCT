/*
 * Program: CTCT
 *
 * $Header$
 * Hierarchical and supervisor control of discrete event systems.
 *
 */

#include <stdio.h>
#include <signal.h>
#include <string.h>
#include "wtct.h"
#include "cl_tct.h"
#include "tct_io.h"
#include "setup.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Tempory due to supreduce being a recursive routine */
extern unsigned _stklen = 1048576;

typedef void (*fptr)(int);

void CatcherINT(INT_OS *reglist)
{
   signal(SIGINT, (fptr)CatcherINT);
}

int main(int argc, char *argv[])
{
   FILE *in;
   char ch;  

   if (argc > 1) {
      if (strcmp(argv[1], "-autotest") == 0) {
         autotest = 1;
         ring_active = 0;
         debug_mode = 0;
         timing_mode = 1;
      } else if (strcmp(argv[1], "-cmdline") == 0) {
         cmdline = 1;
      } else {
         in = fopen(argv[1], "rb");
         if (in == NULL) {
            printf("Error reading %s\n", argv[1]);
            return 1;
         }

         ch = 0;
         while ((ch != 26) && !feof(in)) {
            fread(&ch, sizeof(char), 1, in);
            printf("%c", ch);
         }
         fclose(in);
         return 0;
      }
   } else {
      signal(SIGINT, (fptr)CatcherINT);       
   }

   argv0 = argv[0]; 

   if (autotest) {
      auto_in = fopen(argv[2], "rb");
      if (auto_in == NULL) {
         printf("Error reading %s\n", argv[2]);
         return 1;
      }
   }

   wtct_init(argv[0]);
   
   if (cmdline) {
      cmdline_tct_run();
      wtct_done();
   } else {
      wtct_run();
      wtct_done();
   }
   return 0;
}

#ifdef __cplusplus
}
#endif

