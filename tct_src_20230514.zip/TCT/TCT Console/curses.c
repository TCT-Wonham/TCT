#include "curses.h"
#include "setup.h"
#include <stdlib.h>


#ifdef __cplusplus
extern "C" {
#endif

#include <dos.h>
#include <string.h>
#include <conio.h>
#include <Windows.h>
#include <io.h>
#include <WinCon.h>

int _wherex()
{
   return wherex()-1;
}

int _wherey()
{
   return wherey()-1;
}

void beep()
{
    /* To be implemented _beep(0,100)???? */
}

int sort_function(const void *a, const void *b)
{
   struct _finddata_t *ffblk_a, *ffblk_b;

   ffblk_a = (struct _finddata_t*) a;
   ffblk_b = (struct _finddata_t*) b;

   return strcmp ( ffblk_a->name, ffblk_b->name );
}

int scandir(char *dir, struct _finddata_t **namelist)
{
   struct _finddata_t ffblk;
   long done;
   int count;

   *namelist = NULL;
   count = 0;

   /* Read in the file names and subdirectories */
   done = (long)_findfirst(dir,&ffblk);

   if (done == -1) return -1;

   do 
   {
      if (!( (strcmp(ffblk.name, ".") == 0) ||
             (strcmp(ffblk.name, "..") == 0)) )
      {
        count++;
        *namelist = (struct _finddata_t*) realloc(*namelist, sizeof(ffblk)*count);
        (*namelist)[count-1] = ffblk;
      }
   } while ( _findnext(done, &ffblk) == 0);
   _findclose(done);

   /* Sort filenames using qsort */
   qsort((void*) *namelist, count, sizeof(struct _finddata_t), sort_function);
   
   return count;   
}        
        
/*
void scroll_line()
{
   int row = wherey();
   int col = wherex();
   char line[81];
   int i;
   
   for (i=2; i<= 25; i++)
   {
      _conio_gettext(1,i,80,i,line);
      puttext(1,i-1,80,i-1,line);
   }
   move(row, col);
}
*/

void scroll_line()
{
    SMALL_RECT r;
    CHAR_INFO buffer[25][80];
	COORD cood0, cood1;
    
    int left   = 1;
    int top    = 2;
    int right  = 80;
    int bottom = 25;

    memset (buffer, 0, sizeof (buffer));

	r.Bottom = bottom - 1;
	r.Left = left - 1;
	r.Right = right - 1;
	r.Top = top - 1;

    //r = (SMALL_RECT) {left - 1, top - 1, right - 1, bottom - 1};
	cood0.X = 80;cood0.Y = 25;
	cood1.X = cood1.Y = 0;
    ReadConsoleOutput (GetStdHandle (STD_OUTPUT_HANDLE),
      (PCHAR_INFO) buffer, cood0, cood1, &r);
    
    left = 1;
    top  = 1;
    right = 80;
    bottom = 24;
    //r = (SMALL_RECT) {left - 1, top - 1, right - 1, bottom - 1};   
	r.Bottom = bottom - 1;
	r.Left = left - 1;
	r.Right = right - 1;
	r.Top = top - 1;
                      
    WriteConsoleOutput (GetStdHandle (STD_OUTPUT_HANDLE),
      (CHAR_INFO *) buffer, cood0, cood1, &r);   
}    
        
void println()
{
   if (_wherey() < 23) 
     cprintf("\r\n");
}
        

void ring_bell()
{
   if (ring_active) beep();
}

#ifdef __cplusplus
}
#endif
