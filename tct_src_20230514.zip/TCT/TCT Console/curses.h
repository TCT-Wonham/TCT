/*
   This a wrapper interface to CURSES.
   Under the UNIX operating system, the module just includes
   the standard curses library header.
   In the MSDOS environment, the curses procedures is translated into
   Borland's CONIO.H or DJGPP's GPPCONIO.H or Dev-C++ CONIO.H.

   Therefore, the programmer uses the curses user interface calls
   and display model.
 */

#ifndef _CURSES_H_
#define _CURSES_H_

#ifdef __cplusplus
extern "C" {
#endif


#include <conio.h>
#include <windows.h>
#include <io.h>


#define clear()    clrscr()
#define move(y,x)  gotoxy(x+1,y+1)
#define addstr(s)  cprintf(s)
#define printw  cprintf
#define clrtoeol() clreol()
#define addch(ch)  putch(ch)

#define initscr()
#define nonl()
#define cbreak()
#define noecho()
#define endwin()
#define refresh()   

	extern int scandir(char*, struct _finddata_t**);
	extern void ring_bell();

	extern void println(); 
	extern int _wherex();
	extern int _wherey();
	extern void scroll_line();      



#ifdef __cplusplus
}
#endif

#endif /* _CURSES_H_ */
