#include "display.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "curses.h"
#include "setup.h"
#include "des_data.h"


#ifdef __cplusplus
extern "C" {
#endif

void confirm_right_size()
{
	HANDLE hOut;
	CONSOLE_SCREEN_BUFFER_INFO scr;
	COORD size = {SCREEN_WIDTH,25};
	SMALL_RECT rc = {0,0,SCREEN_WIDTH-1,24};
	
	hOut = GetStdHandle(STD_OUTPUT_HANDLE); /* ��ȡ��׼������ */
	
	//SMALL_RECT rc; rc.Left = 1; rc.Top = 1; rc.Bottom = 25; rc.Right = 80;
	SetConsoleWindowInfo(hOut, true, &rc);
	SetConsoleScreenBufferSize(hOut, size);

	//GetConsoleScreenBufferInfo(hOut, &scr);

	//if((scr.srWindow.Bottom - scr.srWindow.Top != 80) & (scr.srWindow.Right - scr.srWindow.Left != 25)){
	//	   system("mode con cols=80 lines=25");
	//}
}

void main_menu()
{
   INT_OS xLeft;
   INT_OS y;

   //confirm_right_size();

   xLeft = 24;
   y     = 9;
  
   clear();
   move(4,    xLeft); printw("PROGRAM %s", TCTNAME);
   move(7,    xLeft); addstr("MAIN OPTIONS");
   move(y,    xLeft); addstr("I:  Introduction to TCT");
   move(y+1,  xLeft); addstr("T:  TCT Procedures");
   move(y+2,  xLeft); addstr("R:  Reset USER File Directory Path");
   move(y+3,  xLeft); printw("B:  Bell (%s)", ring_active ? "On":"Off");
   move(y+4,  xLeft); printw("D:  Debug mode (%s)", debug_mode ? "On":"Off");
   move(y+5,  xLeft); printw("C:  Clocking mode (%s)", timing_mode ? "On":"Off");
/*   move(y+6,  xLeft); addstr("O:  OS Shell"); */

   move(y+6,  xLeft); addstr("X:  Quit TCT");
   move(y+10, xLeft); addstr("Option desired?    ");
}

void display_memory(INT_OS y, INT_OS x)
{
#if defined(__BORLANDC__)
   move(y,x);
   printw("# of bytes free on heap: %lu\n", coreleft());
#elif defined(__DOS32__)
   _go32_dpmi_meminfo info;

   _go32_dpmi_get_free_memory_information(&info);
   move(y,x);
   printw("# of bytes free on heap: %d\n", info.available_memory);
#else
#endif
}



void advance_menu() {
   INT_OS xLeft;    /* left column offset   */
   INT_OS xMiddle;  /* middle column offset */
   INT_OS xRight;   /* right column offset  */
   INT_OS y;        /* row offset           */
   char dir[MAX_PATH];
   INT_OS num_entries;
   struct _finddata_t *namelist;

   //confirm_right_size();

   xLeft   = 5;
   xMiddle = 31;
   xRight  = 53;
   y       = 3;

   clear();
   move(3   ,xMiddle);  printw("%s PROCEDURES", TCTNAME);

   /* Left command list panel */
   move(y+2 ,xLeft);  addstr(" 0: Create");
   move(y+3 ,xLeft);  addstr(" 1: Selfloop");
   move(y+4 ,xLeft);  addstr(" 2: Trim");
   move(y+5 ,xLeft);  addstr(" 3: Sync");
   move(y+6 ,xLeft);  addstr(" 4: Meet");
   move(y+7 ,xLeft);  addstr(" 5: Supcon");
   move(y+8 ,xLeft);  addstr(" 6: Mutex");
   move(y+9 ,xLeft);  addstr(" 7: Condat");
   move(y+10,xLeft);  addstr(" 8: Supreduce");
   move(y+11,xLeft);  addstr(" 9: Minstate");
   move(y+12,xLeft);  addstr("10: Complement");
   move(y+13,xLeft);  addstr("11: Localize");
   move(y+14,xLeft);  addstr("12: Force");

   /* Middle command list panel */
   move(y+2 ,xMiddle); addstr("P0: Project");
   move(y+3 ,xMiddle); addstr("R0: Relabel");

   move(y+5 ,xMiddle); addstr("H0: Vocalize");
   move(y+6 ,xMiddle); addstr("H1: Outconsis");
   move(y+7 ,xMiddle); addstr("H2: Hiconsis"); 
   move(y+8 ,xMiddle); addstr("H3: Higen");
   move(y+9,xMiddle); addstr("H4: Allevents");

   move(y+11,xMiddle);  addstr("SN: Supnorm");
   move(y+12,xMiddle);  addstr("SS: Supscop");
   move(y+13,xMiddle);  addstr("RR: Supconrobs");
   move(y+14,xMiddle);  addstr("QC: Sup(s)qc");

   /* Right command list panel */
   move(y+2 ,xRight);  addstr("I: Isomorph");
   move(y+3,xRight);   addstr("NC: Nonconflict");  
   move(y+4,xRight);   addstr("OB: (S)Observable");
   move(y+5,xRight);   addstr("NO: Natobs");   
   move(y+6,xRight);   addstr("SR: Suprobs");
   move(y+7,xRight);   addstr("UM: Uncertmod");
   move(y+8 ,xRight);  addstr("E: Edit");
   move(y+9 ,xRight);  addstr("B: BFS-recode");
   move(y+10 ,xRight);  addstr("UD: User file Directory");
   move(y+11 ,xRight);  addstr("SE/SA/SX: Show DES/DAT/TXT");
   move(y+12, xRight);  addstr("FE/FA/FD: File DES/DAT/ADS");
   move(y+13, xRight); addstr("CE/DE: Convert/Display DES");
   move(y+14,xRight);  addstr("X: Exit to main menu");

   /* Display some useful information */
   strcpy(dir, path);
   strcat(dir, "\\*.*");

   num_entries = scandir(dir, &namelist);
   free(namelist);

   move(y+18, xLeft); printw("User directory: "); print_fix_filename(path,59);
   if (num_entries < 0) {
      move(y+19, xLeft); printw("Number files: DIRECTORY NOT SET!");
   } else {
      move(y+19, xLeft); printw("Number files: %d", num_entries);
   }

   /* For DOS32 to BORLAND C/C++, try to display the amount of memory */
   display_memory(y+20,xLeft);

   /* Command Prompt */
   move(y+16,xMiddle); addstr("Procedure desired: ");
}

void tct_logo1(char *version)
{
   move(5,7);  printw("        OOOO");
   move(6,7);  printw("       O    O             X    X    PPPPPP  TTTTTTT   CCCCC   TTTTTTT");
   move(7,7);  printw("<----> O    O              X X     P     P     T     C     C     T");
   move(8,7);  printw("       O    O               X     PPPPPP      T     C           T");
   move(9,7);  printw("        OOOO              X  X   P           T     C     C     T");
   move(10,7); printw("        /  \\            X     X P           T       CCCCC     T");
   move(11,7); printw("       /    \\");
   move(12,7); printw("      /      \\          %s", version);
   move(13,7); printw("     v        v");
   move(14,7); printw("  OOOO        OOOO      Systems Control Group");
   move(15,7); printw(" O    O      O    O     Dept of Electrical & Computer Engineering");
   move(16,7); printw(" O    O <--> O    O     University of Toronto");
   move(17,7); printw(" O    O      O    O     Toronto, Ontario M5S 1A4");
   move(18,7); printw("  OOOO        OOOO      CANADA");
}

void tct_logo(char *version)
{
	move(5,7);  printw("        OOOO               TTTTTTTTT    CCCCCCC    TTTTTTTTT  ");
	move(6,7);  printw("       O    O                 T        C     C        T");
	move(7,7);  printw("<----> O    O                T        C              T");
	move(8,7);  printw("       O    O               T        C              T");
	move(9,7);  printw("        OOOO               T        C     C        T");
	move(10,7); printw("        /  \\              T        CCCCCCC        T");
	move(11,7); printw("       /    \\");
	move(12,7); printw("      /      \\          %s", version);
	move(13,7); printw("     v        v");
	move(14,7); printw("  OOOO        OOOO      Systems Control Group");
	move(15,7); printw(" O    O      O    O     Dept of Electrical & Computer Engineering");
	move(16,7); printw(" O    O <--> O    O     University of Toronto");
	move(17,7); printw(" O    O      O    O     Toronto, Ontario M5S 1A4");
	move(18,7); printw("  OOOO        OOOO      CANADA");
}


void statusline(char *s)
{
   INT_OS x,y;

   x = _wherex();
   y = _wherey();
   move(23,0); clrtoeol(); printw(s);
   move(y,x);
}

void esc_footer()
{
   statusline("Press <ESC> to cancel");
}

void overwriteYN(char *s)
{
   println();
   printw("Filename %s already exists.  OK to overwrite?  (*y/n)  ", s);
}

void doesNotExist(char *s)
{
   println();
   printw("Filename %s not in directory!", s);
   println();
}

void OutOfMemoryMsg()
{
   move(22,0); clrtoeol();
   printw("Problem too large -- out of memory!");
   println();
}

void continue_page(char *s)
{
   move(23,0); clrtoeol();
   printw("%s", s);
}

/*
 * At the current position (column position zero), print the filename.
 * Either print the fullname if it fixes the width.
 * Or make it fix by only showing the directory and part
 * of the path and filename.
 * Example:  C:.../what/test.des    [DOS/Windows]
 * Example:  .../what/test.des      [Linux]
 */  
void print_fix_filename(char *name, INT_OS width)
{
   INT_OS i, len, prefix_to_print;
   
   len = (INT_OS)strlen(name);
   
   if (len >= width)
   {

      for (i=0; i < 3; i++)
         printw("%c", name[i]);
      printw("...");
      
      prefix_to_print = width - 7;
      
      for (i=len-prefix_to_print; i < len; i++)
          printw("%c", name[i]);
    
   }
   else 
   {
      printw("%s", name);
   }
}



void ctct_development_menu() {
   INT_OS xLeft;    /* left column offset   */
   INT_OS xMiddle;  /* middle column offset */
   INT_OS xRight;   /* right column offset  */
   INT_OS y;        /* row offset           */
   char dir[_MAX_PATH];
   INT_OS num_entries;
   struct _finddata_t *namelist;

   xLeft   = 5;
   xMiddle = 31;
   xRight  = 53;
   y       = 4;

   clear();
   move(3   ,xMiddle);  printw("%s DEVELOPMENT", TCTNAME);

   /* Left command list panel */
   move(y+2 ,xLeft);  addstr("0: ProjectBDD");
   move(y+3 ,xLeft);  addstr("1: Simsup");
   move(y+4 ,xLeft);  addstr("2: Supclo");
   move(y+5 ,xLeft);  addstr("3: Supnormclo");
   move(y+6 ,xLeft);  addstr("4: Supscop");
   move(y+7 ,xLeft);  addstr("5: Supnormclo1");
   move(y+8 ,xLeft);  addstr("6: Supscop1");
   move(y+9 ,xLeft);  addstr("7: Project1");
   move(y+10, xLeft); addstr("8: Hiconsis1");
   move(y+11, xLeft); addstr("9: CheckDES");
   move(y+12, xLeft); addstr("M: Minflag"); 
   if (minflag)
      addstr("(new)");
   else
      addstr("(old)");     

   /* Middle command list panel */
   move(y+2 ,xMiddle); addstr("");
   move(y+3 ,xMiddle); addstr("");

   move(y+6 ,xMiddle); addstr("");
   move(y+7 ,xMiddle); addstr("");
   move(y+8 ,xMiddle); addstr(""); 
   move(y+9 ,xMiddle); addstr("");
   move(y+10,xMiddle); addstr("");

   move(y+13,xMiddle);  addstr("");

   /* Right command list panel */
   move(y+2 ,xRight);  addstr("");

   move(y+12,xRight);  addstr("X: Exit to CTCT PROCEDURES");

   /* Display some useful information */
   strcpy(dir, path);
   strcat(dir, "\\*.*");

   num_entries = scandir(dir, &namelist);
   free(namelist);

   move(y+17, xLeft); printw("User directory: "); print_fix_filename(path,59);
   if (num_entries < 0) {
      move(y+18, xLeft); printw("Number files: DIRECTORY NOT SET!");
   } else {
      move(y+18, xLeft); printw("Number files: %d", num_entries);
   }

   /* For DOS32 to BORLAND C/C++, try to display the amount of memory */
   display_memory(y+19,xLeft);

   /* Command Prompt */
   move(y+15,xMiddle); addstr("Procedure desired: ");
}

void ctct_menu_page1() {
   INT_OS xLeft;    /* left column offset   */
   INT_OS xMiddle;  /* middle column offset */
   INT_OS xRight;   /* right column offset  */
   INT_OS y;        /* row offset           */
   char dir[_MAX_PATH];
   INT_OS num_entries;
   struct _finddata_t *namelist;

   xLeft   = 5;
   xMiddle = 31;
   xRight  = 53;
   y       = 4;

   clear();
   move(3   ,xMiddle);  printw("%s DEVELOPMENT", TCTNAME);

   /* Left command list panel */
   move(y+1 ,xLeft);  addstr("0: Path-to-Block");
   move(y+2 ,xLeft);  addstr("1: Shortest-path");
   move(y+3 ,xLeft);  addstr("2: ExtOCC");
   move(y+4, xLeft);  addstr("3: ExLocalize");
   move(y+5, xLeft);  addstr("4: SupQC&LCC");
   move(y+6, xLeft);  addstr("5: Suprobs(language)");
 //  move(y+7, xLeft);  addstr("6: UncertaintySet");

  // move(y+6, xLeft);  addstr("5: SupRR");
  // move(y+7, xLeft);  addstr("6: Suprobs(language)");

   move(y+12,xRight);  addstr("X: Exit to TCT PROCEDURES");

   /* Display some useful information */
   strcpy(dir, path);
   strcat(dir, "\\*.*");

   num_entries = scandir(dir, &namelist);
   free(namelist);

   move(y+17, xLeft); printw("User directory: "); print_fix_filename(path,59);
   if (num_entries < 0) {
      move(y+18, xLeft); printw("Number files: DIRECTORY NOT SET!");
   } else {
      move(y+18, xLeft); printw("Number files: %d", num_entries);
   }

   /* For DOS32 to BORLAND C/C++, try to display the amount of memory */
   display_memory(y+19,xLeft);

   /* Command Prompt */
   move(y+15,xMiddle); addstr("Procedure desired: ");
}
void ctct_menu_page2() {
	INT_OS xLeft;    /* left column offset   */
	INT_OS xMiddle;  /* middle column offset */
	INT_OS xRight;   /* right column offset  */
	INT_OS y;        /* row offset           */
	char dir[_MAX_PATH];
	INT_OS num_entries;
	struct _finddata_t *namelist;

	xLeft   = 5;
	xMiddle = 31;
	xRight  = 53;
	y       = 4;

	clear();
	move(3   ,xMiddle);  printw("%s DEVELOPMENT", TCTNAME);

	/* Left command list panel */
	move(y+1, xLeft);	addstr("0: Supcon");
	move(y+2 ,xLeft);	addstr("1: Attach");
	move(y+3 ,xLeft);	addstr("2: Ehmeet");
	move(y+4 ,xLeft);	addstr("3: Ehsync");
	move(y+5, xLeft);	addstr("4: Project");
	move(y+6, xLeft);	addstr("5: RelObs");
	move(y+7, xLeft);	addstr("6: SupRelCoObs");
	move(y+8, xLeft);	addstr("7: Synthsupobs");
	move(y+9, xLeft);	addstr("8: Statemap");
	move(y+10,xLeft);	addstr("9: InvRelabel");

	move(y+12,xRight);  addstr("X: Exit to TCT PROCEDURES");

	/* Display some useful information */
	strcpy(dir, path);
	strcat(dir, "\\*.*");

	num_entries = scandir(dir, &namelist);
	free(namelist);

	move(y+17, xLeft); printw("User directory: "); print_fix_filename(path,59);
	if (num_entries < 0) {
		move(y+18, xLeft); printw("Number files: DIRECTORY NOT SET!");
	} else {
		move(y+18, xLeft); printw("Number files: %d", num_entries);
	}

	/* For DOS32 to BORLAND C/C++, try to display the amount of memory */
	display_memory(y+19,xLeft);

	/* Command Prompt */
	move(y+15,xMiddle); addstr("Procedure desired: ");
}


#ifdef __cplusplus
}
#endif

