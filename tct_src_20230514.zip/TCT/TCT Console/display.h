#ifndef _DISPLAY_H
#define _DISPLAY_H

#ifdef __cplusplus
extern "C" {
#endif

#define SCREEN_WIDTH    80

void confirm_right_size();

extern void advance_menu();
extern void main_menu();
extern void tct_logo(char*);

extern void esc_footer();
extern void overwriteYN(char*);
extern void doesNotExist(char*);
extern void OutOfMemoryMsg();
extern void continue_page(char*);
extern void print_fix_filename(char*, int);
extern void ctct_development_menu();
extern void ctct_menu_page1();
extern void ctct_menu_page2();


#ifndef TCTNAME
#define TCTNAME "TCT"
#endif

#ifdef __cplusplus
}
#endif


#endif

