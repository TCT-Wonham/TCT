#ifndef _SETUP_H
#define _SETUP_H

#ifdef __cplusplus
extern "C" {
#endif

#include "des_data.h"

extern INT_OS autotest;
extern INT_OS ring_active;
extern INT_OS debug_mode;
extern INT_OS timing_mode;
extern INT_OS cmdline;
extern INT_OS minflag;
extern char path[256];
extern char prefix[256];
extern char ctct_ini_file[256];
extern char info_file[256];
extern char *argv0;

#ifdef __cplusplus
}
#endif

#endif
