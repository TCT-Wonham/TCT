#include "tct_io.h"
#include <io.h>
#include "display.h"
#include "curses.h"
#include "setup.h"
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

FILE* auto_in;

char read_key()
{
   char ch1;
   INT_OS ch;
   
   if (autotest) {
      fread(&ch1, sizeof(char), 1, auto_in);
      if (feof(auto_in)) exit(255);
      if (ch1 == 26) exit(255);
      return ch1;
   }

   ch = getch();
   if (ch == 0) {
      switch (getch()) {
         case 73: ch = CPgUp;
                  break;
         case 81: ch = CPgDn;
                  break;
      }
   } 
   return (char) ch;
}

char get_command()
{
   char ch;

   clrtoeol(); 
   refresh();

   ch = read_key();
   addch(ch);
   refresh();
   return ch;
}
char get_upcase_command()
{
	char ch;

	clrtoeol(); 
	refresh();

	ch = read_key();
	ch = (char) toupper(ch);
	addch(ch);
	refresh();
	return ch;
}

INT_B  validfilename(char *s,
                      INT_OS lmin,
                      INT_OS lmax)
{
  INT_OS n;

  n = (INT_OS)strlen(s);
  if ( (n >= lmin) && (n <= lmax) ) {
    return true;
  } else {
    return false;
  }
}

char read_filename(char* name,
                   INT_OS lmin,
                   INT_OS lmax)
{
   INT_OS x,y;
   char s[255];
   INT_OS p;
   char ch;
   INT_B  start, stop;
   char buf[10];

   strcpy(s, "");
   x = _wherex();
   y = _wherey();
   start = true;
   stop = false;
   p = 0;

   while(!stop) {
     move(y,x);
     clrtoeol();
     printw("%s", s);
     move(y, x+p);
     refresh();
     ch = read_key();

     ch = toupper(ch);

     if ( (ch >= 0x20) ) {
        if (start) strcpy(s, "");
                
        if ((INT_OS)strlen(s) < lmax) {
           sprintf(buf, "%c", ch);
           strcat(s, buf);
           
           if (strcmp(s, " ") == 0)
              strcpy(s, "");
           else            
              p++;
        } else {
           ring_bell();
        }
     } else if (ch == CBack) {   /* Backspace */
        if (p > 0) {
           s[strlen(s)-1] = '\0';
           p--;
        }
     } else if (ch == CEnter) {
        if (validfilename(s, lmin, lmax)) {
           strcpy(name, s);
           stop = true;
        } else {
           ring_bell();
        }
     } else if (ch == CEsc) {
        stop = true;
     } else {
        ring_bell();
     }
     start = false;
   }

   return ch;
}


char read_string(char* name,
	INT_OS lmin,
	INT_OS lmax)
{
	INT_OS x,y;
	char s[255];
	INT_OS p;
	char ch;
	INT_B  start, stop;
	char buf[10];

	strcpy(s, "");
	x = _wherex();
	y = _wherey();
	start = true;
	stop = false;
	p = 0;

	while(!stop) {
		move(y,x);
		clrtoeol();
		printw("%s", s);
		move(y, x+p);
		refresh();
		ch = read_key();

		//ch = toupper(ch);

		if ( (ch >= 0x20) ) {
			if (start) strcpy(s, "");

			if ((INT_OS)strlen(s) < lmax) {
				sprintf(buf, "%c", ch);
				strcat(s, buf);

				if (strcmp(s, " ") == 0)
					strcpy(s, "");
				else            
					p++;
			} else {
				ring_bell();
			}
		} else if (ch == CBack) {   /* Backspace */
			if (p > 0) {
				s[strlen(s)-1] = '\0';
				p--;
			}
		} else if (ch == CEnter) {
			if (validfilename(s, lmin, lmax)) {
				strcpy(name, s);
				stop = true;
			} else {
				ring_bell();
			}
		} else if (ch == CEsc) {
			stop = true;
		} else {
			ring_bell();
		}
		start = false;
	}

	return ch;
}


char read_filestr(char* name,
                  INT_OS lmin,
                  INT_OS lmax)
{
   INT_OS x,y;
   char s[255];
   INT_OS p;
   char ch;
   INT_B  start, stop;
   char buf[10];

   strcpy(s, "");
   x = _wherex();
   y = _wherey();
   start = true;
   stop = false;
   p = 0;

   while(!stop) {
     move(y,x);
     clrtoeol();
     printw("%s", s);
     move(y, x+p);
     refresh();
     ch = read_key();

     if ( (ch >= 0x20) ) {
        if (start) strcpy(s, "");
                
        if ((INT_OS)strlen(s) < lmax) {
           sprintf(buf, "%c", ch);
           strcat(s, buf);
           
           if (strcmp(s, " ") == 0)
              strcpy(s, "");
           else            
              p++;
        } else {
           ring_bell();
        }
     } else if (ch == CBack) {   /* Backspace */
        if (p > 0) {
           s[strlen(s)-1] = '\0';
           p--;
        }
     } else if (ch == CEnter) {
        if (validfilename(s, lmin, lmax)) {
           strcpy(name, s);
           stop = true;
        } else {
           ring_bell();
        }
     } else if (ch == CEsc) {
        stop = true;
     } else {
        ring_bell();
     }
     start = false;
   }

   return ch;
}

/* Construct the full filename base on the name and the extension */
void make_filename_ext(char* longfilename,
                       char* name,
                       char* ext)
{
   INT_OS len;
   strcpy(longfilename, prefix);

   /* Trim excessive blank characters from the name */
   if (name[0] == ' ')
   {
      len = (INT_OS)strlen(name);
      memmove(name, &(name[1]), len-1);
      name[len-1] = '\0';
   }

   if (name[0] == ' ')
   {
      len = (INT_OS)strlen(name);
      memmove(name, &(name[1]), len-1);
      name[len-1] = '\0';
   }

   strcat(longfilename, name);
   strcat(longfilename, ext);
}

/* Determine if the file exist on the disk */
INT_OS exist(char* s)
{
   return (_access(s, 0) == 0);
}

/* Get filename.  ESC key only way to abort entering a name */
INT_B  getname(char *prompt,
                char *ext,
                char *name,
                INT_B  newflag)
{
   INT_B  quit;
   char ch;
   char longfilename[100];
   INT_B  existing;

   existing = false;
   quit = false;
   strcpy(name, "");

   do {
     if ( _wherey() > MAXSCREENY ) {
        clear();
        println();
     }
     printw("%s", prompt);
     esc_footer();
     refresh();
     ch = read_filename(name, 1, MAX_DES_NAME_LEN);
     println();
     if (ch == CEsc) {
        quit = true;
     } else {
        make_filename_ext(longfilename, name, ext);
        if (newflag) {
           if ( exist(longfilename) ) {
              ring_bell();
              overwriteYN(name);
              refresh();
              ch = read_key();
              if (ch == CEnter) {
                 println();
              } else {
                 printw("%c", ch);
                 println();
              }
              println();
              if (ch == CEsc) quit = true;
              if ( (ch == 'Y') || (ch == 'y') || (ch == CEnter) ) existing = true;
              refresh();
           } else {
              existing = true;
           }
        } else {
            if (! exist(longfilename) ) {
              ring_bell();
              doesNotExist(name);
              println();
              refresh();
              existing = false;
            } else {
              existing = true;
            }
        }
     }
   } while ( (quit == false) && (existing == false));
   println();
   refresh();

   return quit;
}

/* Get filename.  Do not display the prompt the first time. */
INT_B  getname2(char *prompt,
                char *ext,
                char *name,
                INT_B  newflag)
{
   INT_B  quit;
   char ch;
   char longfilename[100];
   INT_B  existing;
   INT_B  first_time = true;

   existing = false;
   quit = false;
   ch = 'Y';

   do {
     if ( _wherey() > MAXSCREENY ) {
        clear();
        println();
     }

     if (first_time == false) {
        printw("%s", prompt);
        esc_footer();
        refresh();
        ch = read_filename(name, 1, MAX_DES_NAME_LEN);
        println();
     }
     first_time = false;

     if (ch == CEsc) {
        quit = true;
     } else {
        make_filename_ext(longfilename, name, ext);
        if (newflag) {
           if ( exist(longfilename) ) {
              ring_bell();
              overwriteYN(name);
              refresh();
              ch = read_key();
              if (ch == CEnter) {
                 println();
              } else {
                 printw("%c", ch);
                 println();
              }
              println();
              if (ch == CEsc) quit = true;
              if ( (ch == 'Y') || (ch == 'y') || (ch == CEnter) ) existing = true;
              refresh();
           } else {
              existing = true;
           }
        } else {
            if (! exist(longfilename) ) {
              ring_bell();
              doesNotExist(name);
              println();
              refresh();
              existing = false;
            } else {
              existing = true;
            }
        }
     }
   } while ( (quit == false) && (existing == false));
   println();
   refresh();

   return quit;
}

/* Get a file.  Empty name is a valid name to indicate termination of list
   of names */
INT_B  getname3(char *prompt,
                 char *ext,
                 char *name,
                 INT_B  newflag)
{
   INT_B  quit;
   char ch;
   char longfilename[100];
   INT_B  existing;

   existing = false;
   quit = false;
   strcpy(name, "");

   do {
     if ( _wherey() > MAXSCREENY ) {
        clear();
        println();
     }
     printw("%s", prompt);
     esc_footer();
     refresh();
     ch = read_filename(name, 0, MAX_DES_NAME_LEN);
     println();
     if (ch == CEsc) {
        quit = true;
     } else if (strlen(name) == 0) {
        existing = true;  /* End of list */
     } else {
        make_filename_ext(longfilename, name, ext);
        if (newflag) {
           if ( exist(longfilename) ) {
              ring_bell();
              overwriteYN(name);
              refresh();
              ch = read_key();
              if (ch == CEnter) {
                 println();
              } else {
                 printw("%c", ch);
                 println();
              }
              println();
              if (ch == CEsc) quit = true;
              if ( (ch == 'Y') || (ch == 'y') || (ch == CEnter) ) existing = true;
              refresh();
           } else {
              existing = true;
           }
        } else {
           if (! exist(longfilename) ) {
              ring_bell();
              doesNotExist(name);
              println();
              refresh();
              existing = false;
           } else {
              existing = true;
           }
        }
     }
   } while ( (quit == false) && (existing == false));
   println();
   refresh();

   return quit;
}

/* Move over "n" spaces */
void tab(INT_OS n)
{
   INT_OS y;
   y = _wherey(); move(y,n);
}

INT_B  validint(char *s,
                 INT_S lmin,
                 INT_S lmax)
{
   INT_S n;
   if (strcmp(s, "0") == 0) {
     n = 0;
   } else {
     /* Known bug - if user enters "1-", it will be converted to "1".
        Fix needed for this minor bug. */
     n = atoi(s);
     if (n == 0) return false;
   }

   return ((n >= lmin) && (n <= lmax));
}

/* Read in an integer (short).  Return true if aborted with ESC key */
INT_S readint(char *ch,
            INT_S lmin,
            INT_S lmax)
{
   INT_OS x,y;
   char s[255];
   INT_OS p;
   INT_S n;
   INT_B  start, stop;
   char buf[20];
   INT_OS maxlen;

   maxlen = 0;
   sprintf(buf, "%d", lmin);   maxlen = (INT_OS) max(maxlen, (INT_OS)strlen(buf));
   sprintf(buf, "%d", lmax);   maxlen = (INT_OS) max(maxlen, (INT_OS)strlen(buf));

   strcpy(s, "");
   x = _wherex();
   y = _wherey();
   start = true;
   stop = false;
   n = 0; p = 0;

   while(!stop) {
     move(y,x);
     clrtoeol();
     printw("%s", s);
     esc_footer();
     move(y, x+p);
     refresh();
     *ch = read_key();
     if ( (*ch == '-') || ((*ch >= '0') && (*ch <= '9')) ) {
        if (start) strcpy(s, "");
        if ((INT_OS)strlen(s) < maxlen) {
           sprintf(buf, "%c", *ch);
           strcat(s, buf);
           p++;
        } else {
           ring_bell();
        }
     } else if (*ch == CBack) {   /* Backspace */
        if (p > 0) {
           s[strlen(s)-1] = '\0';
           p--;
        }
     } else if (*ch == CEnter) {
        if (validint(s, lmin, lmax)) {
           n = (INT_S) atoi(s);
           stop = true;
           break;
        } else {
           ring_bell();
        }
     } else if (*ch == CEsc) {
        stop = true;
     } else {
        ring_bell();
     }
     start = false;
   }

   return n;
}

/* Read integer in the range (lmin,lmax).
 * Besides integers, "*" is equal to all numbers.
 */
INT_S readintall(char *ch,
               INT_S lmin,
               INT_S lmax)
{
   INT_OS x,y;
   char s[255];
   INT_OS p; INT_S n;
   INT_B  start, stop;
   char buf[20];
   INT_OS maxlen;

   maxlen = 0;
   sprintf(buf, "%d", lmin);   maxlen = (INT_OS) max(maxlen, (INT_OS)strlen(buf));
   sprintf(buf, "%d", lmax);   maxlen = (INT_OS) max(maxlen, (INT_OS)strlen(buf));

   strcpy(s, "");
   x = _wherex();
   y = _wherey();
   start = true;
   stop = false;
   n = 0; p = 0;

   while(!stop) {
     move(y,x);
     clrtoeol();
     printw("%s", s);
     esc_footer();
     move(y, x+p);
     refresh();
     *ch = read_key();
     if ( (*ch == '-') || ((*ch >= '0') && (*ch <= '9')) || (*ch == '*') ) {
        if (start) strcpy(s, "");
        if ((INT_OS)strlen(s) < maxlen) {
           sprintf(buf, "%c", *ch);
           strcat(s, buf);
           p++;
        } else {
           ring_bell();
        }
     } else if (*ch == CBack) {   /* Backspace */
        if (p > 0) {
           s[strlen(s)-1] = '\0';
           p--;
        }
     } else if (*ch == CEnter) {
        if (strcmp(s, "*") == 0) {
           n = 0;
           *ch = '*';
           stop = true;
           break;
        }

        if (strchr(s, '*') != NULL)
        {
           ring_bell();
        }
        else
        {
           if (validint(s, lmin, lmax)) {
              n = (INT_S) atoi(s);
              stop = true;
              break;
           } else {
              ring_bell();
           }
        }
     } else if (*ch == CEsc) {
        stop = true;
     } else {
        ring_bell();
     }
     start = false;
   }

   return n;
}

/* Read integer in the range (lmin,lmax).
 * Besides integers, "e" is equal to the number EEE .
 */
INT_S readint_and_e(char *ch,
                  INT_S lmin,
                  INT_S lmax)
{
   INT_OS x,y;
   char s[255];
   INT_OS p; INT_S n;
   INT_B  start, stop;
   char buf[20];
   INT_OS maxlen;

   maxlen = 0;
   sprintf(buf, "%d", lmin);   maxlen = (INT_OS)max(maxlen, (INT_OS)strlen(buf));
   sprintf(buf, "%d", lmax);   maxlen = (INT_OS)max(maxlen, (INT_OS)strlen(buf));

   strcpy(s, "");
   x = _wherex();
   y = _wherey();
   start = true;
   stop = false;
   n = 0; p = 0;

   while(!stop) {
     move(y,x);
     clrtoeol();
     printw("%s", s);
     esc_footer();
     move(y, x+p);
     refresh();
     *ch = read_key();
     if ( (*ch == '-') || ((*ch >= '0') && (*ch <= '9')) || (*ch == 'e') ) {
        if (start) strcpy(s, "");
        if ((INT_OS)strlen(s) < maxlen) {
           sprintf(buf, "%c", *ch);
           strcat(s, buf);
           p++;
        } else {
           ring_bell();
        }
     } else if (*ch == CBack) {   /* Backspace */
        if (p > 0) {
           s[strlen(s)-1] = '\0';
           p--;
        }
     } else if (*ch == CEnter) {
        if (strcmp(s, "e") == 0) {
           n = EEE;   /* Should use variable EEE */
           *ch = 'e';
           stop = true;
           break;
        }

        if (strchr(s, 'e') != NULL)
        {
           ring_bell();
        }
        else
        {
           if (validint(s, lmin, lmax)) {
              n = (INT_S) atoi(s);
              stop = true;
              break;
           } else {
              ring_bell();
           }
        }
     } else if (*ch == CEsc) {
        stop = true;
     } else {
        ring_bell();
     }
     start = false;
   }

   return n;
}

/* Read qc or sqc.
 */
INT_B  getqc(char *prompt,
              INT_OS *mode)
{
   INT_B  quit;
   char ch;
  // char longfilename[100];
   char name[4];
   INT_B  existing;

   existing = false;
   quit = false;
   strcpy(name, "");

   do {
     if ( _wherey() > MAXSCREENY ) {
        clear();
        println();
     }
     printw("%s", prompt);
     esc_footer();
     refresh();
     ch = read_filestr(name, 1, 3);
     println();
     if (ch == CEsc) {
        quit = true;
     } else {
        if (strcmp(name, "qc") == 0 || strcmp(name, "QC") == 0) {
           *mode = 1;
           break;
        }
        else if (strcmp(name, "sqc") == 0 || strcmp(name, "SQC") == 0) {    
           *mode = 2;
           break;
        } else {
           ring_bell();
        }
     }
   } while (quit == false);
   println();
   refresh();

   return quit;
}

/* Read qc or sqc.
 */
INT_B  getqc_lcc(char *prompt,
              INT_OS *mode)
{
   INT_B  quit;
   char ch;
  // char longfilename[100];
   char name[4];
   INT_B  existing;

   existing = false;
   quit = false;
   strcpy(name, "");

   do {
     if ( _wherey() > MAXSCREENY ) {
        clear();
        println();
     }
     printw("%s", prompt);
     esc_footer();
     refresh();
     ch = read_filestr(name, 1, 3);
     println();
     if (ch == CEsc) {
        quit = true;
     } else {
        if (strcmp(name, "qc") == 0 || strcmp(name, "QC") == 0) {
           *mode = 1;
           break;
        }
        else if (strcmp(name, "qcl") == 0 || strcmp(name, "QCL") == 0) {    
           *mode = 2;
           break;
        } else {
           ring_bell();
        }
     }
   } while (quit == false);
   println();
   refresh();

   return quit;
}
/* Read Obs checking or SObs checking
*/
INT_B  getObs(char *prompt, INT_OS *mode)
{
    INT_B  quit;
    char ch;
    char name[4];
    
    quit = false;
    strcpy(name,"");
    
    do{
        if(_wherey() > MAXSCREENY){
           clear();
           println();
        }
        printw("%s",prompt);
        esc_footer();
        ch = read_filestr(name,1,2);        
        println();
        if(ch == CEsc)
           quit = true;
        else{
           if(strcmp(name, "o") == 0 || strcmp(name,"O") == 0){
                *mode = 1;
                break;
           }else if(strcmp(name,"so") == 0 || strcmp(name,"SO") == 0
                    || strcmp(name,"sO") == 0 || strcmp(name,"So") == 0){
                *mode = 2;
                break;
           } else
              ring_bell();
        }
    
    }while (quit == false);
    println();
    refresh();
    
    return quit;
}

#ifdef __cplusplus
}
#endif

