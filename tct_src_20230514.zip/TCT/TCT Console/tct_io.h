#ifndef _TCT_IO_H
#define _TCT_IO_H

#include <stdio.h>
#include "des_data.h"

#define MAXSCREENY       22


  #define MAX_DES_NAME_LEN  20
   
  #define CBack      8
  #define CEsc       27
  #define CEnter     13
  #define CPgUp      117
  #define CPgDn      100

#ifdef __cplusplus
extern "C" {
#endif


extern FILE* auto_in;

extern char read_key();
extern char get_command();
extern char get_upcase_command();
extern INT_B  getname(char*, char*, char*, INT_B );
extern INT_B  getname2(char*, char*, char*, INT_B );
extern INT_B  getname3(char*, char*, char*, INT_B );
extern void tab(INT_OS);
extern INT_S readint(char*, INT_S, INT_S);
extern INT_S readintall(char*, INT_S, INT_S);
extern INT_S readint_and_e(char*, INT_S, INT_S);
extern char read_filename(char*, INT_OS, INT_OS);
extern char read_string(char* name, INT_OS lmin, INT_OS lmax);
extern INT_OS exist(char*);
extern void make_filename_ext(char*, char*, char*);
extern INT_B  getqc(char*, INT_OS*);
extern INT_B  getqc_lcc(char*, INT_OS*);
extern INT_B  getObs(char*,INT_OS *);

#ifdef __cplusplus
}
#endif

#endif

