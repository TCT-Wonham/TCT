#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>
#include <conio.h>
#include <direct.h>
#include <windows.h>

#include "wtct.h"
#include "tct_proc.h"
#include "display.h"
#include "tct_io.h"
#include "curses.h"
#include "editor.h"
#include "show.h"
#include "setup.h"
#include "ext_proc.h"


#ifdef __cplusplus
extern "C" {
#endif

#define DCommandSet "0123456789X"
/* #define CommandSet  "0123456789PHRNIBEDSOXMFW"  */
#define CommandSet  "0123456789ABCDEFHIMNOPQRSUXZ" 
#define MCommandSet "IRBTXDC"

#define SEPC  '\\'
#define SEP   "\\"

void ctct_dev();

//Process 1 command
void _1_proc() {
	char ch;

	ch = get_command();
	ch = (char) toupper(ch);

	switch (ch) {
	case CEnter: selfloop_p();   break;
	case '0'   : complement_p(); break;
	case '1'   : localize_p();   break;
	case '2'   : force_p();	  break;
	}
}
//process c command
void c_proc()
{
	char ch;
	ch = get_command();
	ch = (char) toupper(ch);

	switch (ch){
	case 'E' : convert_des_p(); break;
	}
}
//Process d command
void d_proc()
{
	char ch;
	ch = get_command();
	ch = (char) toupper(ch);

	switch(ch){
	case 'E': display_des_p();break;
	}
}

//Process f command
void f_proc() {
	char ch;

	ch = get_command();
	ch = (char) toupper(ch);

	switch (ch) {
	case 'E': file_des_p();    break;
	case 'A': file_dat_p();    break;
	case 'D': file_ads_p();    break;
	}
}

//Process h command
void hierchical()
{
	char ch;

	ch = get_command();
	ch = toupper(ch);

	switch (ch) {
	case '0': vocalize_p();     break;
	case '1': outconsis_p();    break;
	case '2': hiconsis_p();     break;
	case '3': higen_p();        break;
	case '4': allevents_p();    break;
	}
}
//Process m command
void makeit_p();
void m_proc()
{
	char ch;

	ch = get_upcase_command();
	ch = (char) toupper(ch);

	switch (ch) {
	case 'A': makeit_p(); break;
	}
}

//Process n command
void n_proc()
{
	char ch;

	ch = get_command();
	ch = (char) toupper(ch);

	switch (ch) {
	case 'C': nonconflict_p(); break;
	case 'O' : ext_obs_p();     break;
	}
}
//Process o command
void o_proc() {
	char ch;

	ch = get_command();
	ch = (char) toupper(ch);

	switch (ch) {
	case 'B' : obs_p();     break;
	}
}

//Process p command
void p_proc()
{
	char ch;

	ch = get_command();
	ch = (char) toupper(ch);

	switch (ch) {
	case '0' : project_p();     break;
	case 'E': print_des_p();    break;
	case 'A': print_dat_p();    break;
	case 'X': print_ascii_p();  break;
	}
}
//Process q command
void q_proc() {
	char ch;

	ch = get_command();
	ch = (char) toupper(ch);

	switch (ch) { 
	case 'C'   : CanQC_p(); break;
	}    
}  
// process >iudr command
void r_proc()
{
     char ch;

     ch = get_command();
     ch = toupper(ch);

	 switch (ch) {
	 case '0' : eventmap_p();    break;
	 case 'R' : feasible_p();     break;
	 }
}

//Process s command
void s_proc()
{
   char ch;

   ch = get_command();
   ch = (char) toupper(ch);
   
   switch (ch) {
   case 'R':  supobs_p();	 break;
   case 'E': show_des_p();     break;
   case 'A': show_dat_p();     break;
   case 'X': show_ascii_p();   break;
   case 'S': supscop_p();      break;
   case 'N': supnorm_p();     break;
   }
}   

//process u command
void u_proc()
{
	char ch;
	ch = get_command();
	ch = (char) toupper(ch);

	switch(ch){
	case 'D': directory_p();	break;
	case 'M': uncertmod_p();	break;
	}
}

void makeit_p()
{
   char  makeit_file_txt[4 * MAX_PATH];
   char  cmdline[4 * MAX_PATH];
   char  path[MAX_PATH];
   FILE *file;

   _getcwd(path, MAX_PATH);
   _chdir(prefix);

   strcpy(makeit_file_txt,"");
   //strcat(makeit_file_txt, prefix);
   strcat(makeit_file_txt, "MAKEIT.TXT");
   
   strcpy(cmdline,"");
   strcat(cmdline, "start ");
   strcat(cmdline, makeit_file_txt);

   if (_access(makeit_file_txt, 0) ==0){
	   system(cmdline);
   }else{ 

	   file = fopen(makeit_file_txt, "w");
	   if(file != NULL){ 
		   fclose(file);
	   }

	   if (_access(makeit_file_txt, 0) ==0){
		   system(cmdline);
	   }else{

		   clear();
		   move(7,0); printw("FILE MAKEIT.TXT NOT FOUND!");println();
		   println();
		   printw("FILE EXPECTED AT: ");println();
		   println();
		   print_fix_filename(dos_uppercase(makeit_file_txt), SCREEN_WIDTH-18); println();	   
		   println();
		   user_pause();
		   _chdir(path);
		   return;
	   }
   }
   _chdir(path);
   clear();
}


//Process zry command by input Z1 or Z2
void ctct_dev_ext1();
void ctct_dev_ext2();
void z_proc()
{
	char ch;
	ch = get_upcase_command();
	ch = (char) toupper(ch);

	switch(ch){
	case '1': ctct_dev_ext1(); break;
    case '2': ctct_dev_ext2(); break;
	}
}
void ext_p_proc()
{
	char ch;

	ch = get_command();
	ch = (char) toupper(ch);

	switch (ch) {
	case '0' : plain_project_p();     break;
	case '1' : project_f_p();    break; // Project and f defined for rel-obs
	}
}

void dcommand_ext1(char ch)
{
   switch (ch) {
	  // Left panel
      case '0': path2block_p();			break;
	  case '1': subdes_p();				break;
	  case '2': ext_occ_p();			break;
	  case '3': exlocalize_p();			break;
	  case '4': supqc_lcc_p();			break;
	  case '5': ext_suprobs_p();			break;
	 // case '6': synsupobs_p();			break;
	  //case '5': suprr_p();				break;
	  //case '6': LB_suprobs_p();			break;
   }
}
void dcommand_ext2(char ch)
{
	switch (ch) {
		// Left panel
	case '0': supcon_comb_p();			break;
	case '1': attach_p();				break;
	case '2': ehmeet_p();				break;
	case '3': ehsync_p();				break;
	case '4': plain_project_p();		break;
	case '5': rel_observ_p();			break;
	case '6': sup_rel_coobs_p();		break;
	case '7': synsupobs_p();			break;
	case '8': statemap_p();				break;
	case '9': inv_relabel_p();			break;
		
		// Right pannel
		//  case 'O': execute_p();			break;
	}
}
void ctct_dev_ext1()
{
   INT_OS x,y;
   char ch;

   do {
      ctct_menu_page1();
      refresh();
      x = _wherex();
      y = _wherey();
      do {
         move(y,x);
         ch = get_upcase_command();
         refresh();
      } while (strchr(DCommandSet, ch) == NULL);

      dcommand_ext1(ch);

    } while (ch != 'X');
}
void ctct_dev_ext2()
{
	INT_OS x,y;
	char ch;

	do {
		ctct_menu_page2();
		refresh();
		x = _wherex();
		y = _wherey();
		do {
			move(y,x);
			ch = get_upcase_command();
			refresh();
		} while (strchr(DCommandSet, ch) == NULL);

		dcommand_ext2(ch);

	} while (ch != 'X');
}
void process_command(char ch)
{
  switch (ch) {
     case '0': create_p();      break;
     case '1': _1_proc();       break; 
     case '2': trim_p();        break;
     case '3': sync_p();        break;
     case '4': meet_p();        break;
     case '5': supcon_p();      break;
     case '6': mutex_p();       break;
     case '7': condat_p();      break;
     case '8': supreduce_p();   break;
     case '9': minstate_p();    break;
     case 'P': p_proc();        break;
     case 'I': isomorph_p();    break;
	 case 'N': n_proc();		break;
     case 'B': bfs_recode_p();  break;
     case 'E': edit_p();        break;
     case 'U': u_proc();        break;
     case 'D': d_proc();        break;
     case 'S': s_proc();        break;
     case 'O': o_proc();        break;
     case 'F': f_proc();        break;
     case 'H': hierchical();    break;
     case 'R': r_proc();		break;
	 case 'M': m_proc();		break;
     case 'C': c_proc();        break;
     case 'Q': q_proc();        break;
	 case 'Z': z_proc();		break;
   }
}
void tcommand()
{
   INT_OS x,y;
   char ch;

   do {
      advance_menu();
      refresh();
      x = _wherex();
      y = _wherey();
      do {
         move(y,x);
         ch = get_upcase_command();
         refresh();
      } while (strchr(CommandSet, ch) == NULL);

      process_command(ch);

    } while (ch != 'X');
}
void exit_os_p()
{
    not_yet();
}

void process_m_command(char ch)
{
    switch (ch) {
      case 'I': introduction_p();          break;
      case 'R': reset_directory_p();       break;
      case 'B': bell_control_p();          break;
      case 'T': tcommand();                break;
      case 'D': display_control_p();       break;
      case 'O': exit_os_p();               break;
      case 'C': timing_control_p();        break;
   }
}



INT_OS wtct_init(char *ctct_exe_file) {
   char *ptr;
   INT_P  pos;
   char currentDir[_MAX_PATH];
   char tctinfo_buf[_MAX_PATH];
   char ctct_ini_buf[_MAX_PATH];

   confirm_right_size();        /* Need a 80x25 screen size minimum */

   initscr();                   /* Initialize curses */
   nonl(); cbreak(); noecho();  /* To get character-at-a-time input */



   /* Determine if a "ctct.ini" file exists */
   /* It is store in the same place as ctct.exe */
   if (_fullpath(ctct_ini_buf, ctct_exe_file, _MAX_PATH) == NULL)
   {
      _getcwd(currentDir, 255);
      ptr = strchr(currentDir, SEPC);
      if (ptr != NULL)
      {
         ptr[0] = 0;
         strcpy(ctct_ini_file, currentDir);
         strcat(ctct_ini_file, SEP);
         strcat(ctct_ini_file, "ctct.ini");
      } 
      else
      {
         strcat(ctct_ini_file, "C:");
         strcat(ctct_ini_file, SEP);
         strcat(ctct_ini_file, "ctct.ini");   
      }       
   }
   else 
   {
      ptr = strrchr(ctct_ini_buf, SEPC);
      pos = ptr-ctct_ini_buf;
      
      if (pos < 0) pos = 0;
      
      strncpy(ctct_ini_file, ctct_ini_buf, pos+1);
      ctct_ini_file[pos+1] = '\0';
      strcat(ctct_ini_file, "ctct.ini");
   }

   if (_fullpath(tctinfo_buf, ctct_exe_file, _MAX_PATH) == NULL){
	  strcpy(info_file,"TCT_Info");
   }
   else
   {
      ptr = strrchr(tctinfo_buf, SEPC);
      pos = ptr-tctinfo_buf;

      if (pos < 0) pos = 0;
   
      strncpy(info_file, tctinfo_buf, pos+1);
      info_file[pos+1] = '\0';         
      strcat(info_file, "TCT_Info");
   }

   setuserpath(ctct_ini_file);

   gen_global_labellist_from_file();

   return 0;
}


INT_OS wtct_run() {
   char version_str[80];
   char ch;
   INT_OS x,y;

   sprintf(version_str, "%s 2023.05.14", TCTNAME);  /* YY/MM/DD */

   clear();
   tct_logo(version_str);
   move(0,0);
   refresh();
   ch = read_key();

   clear();
   do {
      main_menu();
      refresh();
      x = _wherex();
      y = _wherey();
      do {
          ch = get_command();
          ch = (char) toupper(ch);
          move(y,x);
          refresh();
      } while (strchr(MCommandSet, ch) == NULL);

      process_m_command(ch);
   } while (ch != 'X');

   return 0;
}

INT_OS wtct_done() {
   //free memory of global label list
	free(global_labellist);
   clear();  refresh();
   endwin();                    /* End curses */
   return 0;
}

#ifdef __cplusplus
}
#endif

