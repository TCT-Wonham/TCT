#ifndef _WTCT_H
#define _WTCT_H

#include <dos.h>
#include "des_data.h"

#ifdef __cplusplus
extern "C" {
#endif

extern	void confirm_right_size();

extern INT_OS wtct_init(char *);
extern INT_OS wtct_run();
extern INT_OS wtct_done();

#ifdef __cplusplus
}
#endif

#endif

